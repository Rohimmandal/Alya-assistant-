import fs from 'fs';
import path from 'path';

const files = [
  'server/alyaBrain/alyaBrainEngine.ts',
  'server/livekitAgent/ttsProvider.ts',
  'server/geminiService.ts',
  'server/geminiLiveService.ts',
  'server/capabilities/locationCapability.ts',
  'server/gemini3.1FlashLiveService.ts',
  'server.ts'
];

files.forEach(file => {
  if (!fs.existsSync(file)) {
      console.log(`File not found: ${file}`);
      return;
  }
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace all usages
  content = content.replace(/geminiKeyStore/g, 'keyManager');
  
  // Fix imports
  if (file === 'server.ts') {
    content = content.replace(/import { keyManager } from '.\/server\/[^\']+.ts';/g, "import { keyManager } from './src/utils/KeyManager.ts';");
  } else {
    // Other files are in /server/ or subdirectories of /server/
    // We need to figure out the path to src/utils/KeyManager.ts
    // For file in /server/ -> '../src/utils/KeyManager.ts'
    // For file in /server/subdir/ -> '../../src/utils/KeyManager.ts'
    
    let depth = file.split('/').length - 1;
    let relativePath = '../'.repeat(depth) + 'src/utils/KeyManager.ts';
    
    // Replace all variations of import from geminiKeyStore
    content = content.replace(/import { keyManager } from '..\/[^\']+.ts';/g, `import { keyManager } from '${relativePath}';`);
    content = content.replace(/import { keyManager } from '.\/[^\']+.ts';/g, `import { keyManager } from '${relativePath}';`);
  }
  
  fs.writeFileSync(file, content);
  console.log(`Updated ${file}`);
});
