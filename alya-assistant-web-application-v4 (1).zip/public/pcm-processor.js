/**
 * Dedicated AudioWorkletProcessor for Strict 20ms 16kHz PCM Audio Streaming
 * Accumulates Web Audio frames from arbitrary hardware context sample rates (48000Hz, 44100Hz, 16000Hz),
 * performs stateful linear downsampling to exact 16000Hz, applies 100Hz high-pass filter,
 * and transfers 320-sample (20ms at 16kHz / 640-byte) Int16 ArrayBuffers off-thread with zero-copy.
 */
class PCM20msWorkletProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.targetSampleRate = 16000;
    this.bufferSize = 320; // Exact 20ms frame at 16000Hz (16000 * 0.020 = 320 samples / 640 bytes)
    this.buffer = new Int16Array(this.bufferSize);
    this.bufferIndex = 0;
    this.lastSample = 0;
    this.phase = 0;
    this.x1 = 0;
    this.y1 = 0;
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;
    const channelData = input[0];
    if (!channelData || channelData.length === 0) return true;

    const inputRate = sampleRate; // Hardware context sample rate (e.g. 48000, 44100, 16000)
    const ratio = inputRate / this.targetSampleRate;
    const R = Math.max(0.95, 1.0 - (2.0 * Math.PI * 100.0 / inputRate)); // 100Hz high-pass DC blocker

    let inIdx = this.phase;
    const len = channelData.length;

    while (inIdx < len) {
      const idx = Math.floor(inIdx);
      const frac = inIdx - idx;
      
      const s0 = channelData[idx];
      const s1 = (idx + 1 < len) ? channelData[idx + 1] : s0;

      // Phase-accurate linear interpolation between current and next sample
      const raw = s0 + frac * (s1 - s0);
      
      // 100Hz High-Pass Filter (DC offset & sub-bass rumble elimination)
      const filtered = raw - this.x1 + R * this.y1;
      this.x1 = raw;
      this.y1 = filtered;

      // Clamped Int16 Little-Endian conversion with pristine audio fidelity
      const clamped = Math.max(-1.0, Math.min(1.0, filtered));
      const pcm16 = clamped < 0 ? Math.floor(clamped * 0x8000) : Math.floor(clamped * 0x7FFF);
      this.buffer[this.bufferIndex++] = pcm16;

      if (this.bufferIndex >= this.bufferSize) {
        const copy = new Int16Array(this.buffer);
        this.port.postMessage(copy.buffer, [copy.buffer]);
        this.bufferIndex = 0;
      }

      inIdx += ratio;
    }

    this.phase = inIdx - len;
    this.lastSample = channelData[len - 1] || 0;
    return true;
  }
}

registerProcessor('pcm-worklet-processor', PCM20msWorkletProcessor);
