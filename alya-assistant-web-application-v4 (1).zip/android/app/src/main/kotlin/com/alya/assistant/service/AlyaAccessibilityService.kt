package com.alya.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * AlyaAccessibilityService
 * Provides authorized accessibility automation on Android devices.
 * Enables Alya to execute user-requested gestures, click navigation targets,
 * press home/back buttons, and automate accessibility interactions.
 */
class AlyaAccessibilityService : AccessibilityService() {

    private var windowManager: WindowManager? = null
    private var gridOverlay: GridOverlayView? = null

    companion object {
        var instance: AlyaAccessibilityService? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val eventType = event.eventType
        if (eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED || 
            eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
            checkForAndSkipYouTubeAds()
        }
    }

    fun checkForAndSkipYouTubeAds(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        return scanForAdElementsAndClick(rootNode)
    }

    private fun scanForAdElementsAndClick(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false

        val text = node.text?.toString()?.lowercase() ?: ""
        val desc = node.contentDescription?.toString()?.lowercase() ?: ""
        val id = node.viewIdResourceName?.lowercase() ?: ""

        val isAdSkipButton = (
            text.contains("skip ad") || 
            text.contains("skip ads") || 
            text.contains("skip video") ||
            desc.contains("skip ad") || 
            desc.contains("skip ads") ||
            id.contains("skip_ad_button") || 
            id.contains("skip_button") || 
            id.contains("ad_skip") ||
            text.contains("विज्ञापन छोड़ें")
        )

        if (isAdSkipButton) {
            if (node.isClickable) {
                val clicked = node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                if (clicked) {
                    android.util.Log.i("AlyaAccessibility", "Successfully skipped YouTube Ad programmatically via accessibility click!")
                    return true
                }
            }
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    val clicked = parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    if (clicked) {
                        android.util.Log.i("AlyaAccessibility", "Successfully skipped YouTube Ad programmatically via parent click!")
                        return true
                    }
                }
                parent = parent.parent
            }
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            if (scanForAdElementsAndClick(child)) {
                return true
            }
        }
        return false
    }

    override fun onInterrupt() {
        // Handle interruption
    }

    override fun onDestroy() {
        super.onDestroy()
        hideGridOverlay()
        instance = null
    }

    /**
     * Perform global navigation action (Home, Back, Recents)
     */
    fun performGlobal(action: Int): Boolean {
        return performGlobalAction(action)
    }

    /**
     * Perform a tap gesture at coordinate (x, y)
     */
    fun performClick(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(clickPath, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Perform a double tap gesture at coordinate (x, y)
     */
    fun performDoubleTap(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        performClick(x, y) { success ->
            if (success) {
                android.os.Handler(mainLooper).postDelayed({
                    performClick(x, y, callback)
                }, 200)
            } else {
                callback?.invoke(false)
            }
        }
    }

    /**
     * Perform a long press gesture at coordinate (x, y)
     */
    fun performLongPress(x: Float, y: Float, callback: ((Boolean) -> Unit)? = null) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }
        val stroke = GestureDescription.StrokeDescription(clickPath, 0, 1000)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Perform a swipe gesture from start to end coordinates
     */
    fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long = 300, callback: ((Boolean) -> Unit)? = null) {
        val swipePath = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val stroke = GestureDescription.StrokeDescription(swipePath, 0, duration)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        
        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                callback?.invoke(true)
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                callback?.invoke(false)
            }
        }, null)
    }

    /**
     * Scroll up or down dynamically on active scrollable nodes
     */
    fun scroll(scrollUp: Boolean): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollableNode = findScrollableNode(rootNode)
        return if (scrollableNode != null) {
            scrollableNode.performAction(
                if (scrollUp) AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
                else AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            )
        } else {
            // Fallback: simulate vertical swipe
            val displayMetrics = resources.displayMetrics
            val width = displayMetrics.widthPixels.toFloat()
            val height = displayMetrics.heightPixels.toFloat()
            val startY = if (scrollUp) height * 0.3f else height * 0.7f
            val endY = if (scrollUp) height * 0.7f else height * 0.3f
            performSwipe(width / 2, startY, width / 2, endY)
            true
        }
    }

    private fun findScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findScrollableNode(child)
            if (result != null) return result
        }
        return null
    }

    /**
     * Find and click a node by text or content description
     */
    fun clickNodeByText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val nodes = rootNode.findAccessibilityNodeInfosByText(text)
        for (node in nodes) {
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            var parent = node.parent
            while (parent != null) {
                if (parent.isClickable) {
                    return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                parent = parent.parent
            }
        }
        return false
    }

    /**
     * Set text in currently focused editable node
     */
    fun typeText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val focused = findFocusedEditableNode(rootNode)
        return if (focused != null) {
            focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            })
        } else {
            false
        }
    }

    /**
     * Advanced Text Editing Options
     */
    fun textEditingAction(action: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val focused = findFocusedEditableNode(rootNode) ?: return false
        return when (action.uppercase()) {
            "SELECT_ALL" -> focused.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, Bundle().apply {
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
                putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, focused.text?.length ?: 0)
            })
            "DELETE_PREVIOUS_WORD" -> {
                val currentText = focused.text?.toString() ?: ""
                if (currentText.isNotEmpty()) {
                    val lastSpace = currentText.trimEnd().lastIndexOf(" ")
                    val newText = if (lastSpace != -1) currentText.substring(0, lastSpace + 1) else ""
                    focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                        putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, newText)
                    })
                } else true
            }
            "DELETE_SELECTED" -> focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, "")
            })
            "PASTE" -> focused.performAction(AccessibilityNodeInfo.ACTION_PASTE)
            "COPY" -> focused.performAction(AccessibilityNodeInfo.ACTION_COPY)
            "CUT" -> focused.performAction(AccessibilityNodeInfo.ACTION_CUT)
            else -> false
        }
    }

    private fun findFocusedEditableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val result = findFocusedEditableNode(child)
            if (result != null) return result
        }
        return null
    }

    /**
     * System Magnification Controller API
     */
    fun controlMagnification(action: String): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            val controller = magnificationController
            return try {
                when (action.uppercase()) {
                    "ZOOM_IN" -> {
                        controller.setScale(controller.scale + 1.0f, true)
                        true
                    }
                    "ZOOM_OUT" -> {
                        val currentScale = controller.scale
                        if (currentScale > 1.0f) {
                            controller.setScale(maxOf(1.0f, currentScale - 1.0f), true)
                        }
                        true
                    }
                    "RESET" -> {
                        controller.reset(true)
                        true
                    }
                    else -> false
                }
            } catch (e: Exception) {
                false
            }
        }
        return false
    }

    /**
     * Show Configurable Grid Overlay
     */
    fun showGridOverlay() {
        android.os.Handler(mainLooper).post {
            if (gridOverlay != null) return@post
            val displayMetrics = resources.displayMetrics
            val params = WindowManager.LayoutParams().apply {
                type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_SYSTEM_ALERT
                }
                format = PixelFormat.TRANSLUCENT
                flags = WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                width = WindowManager.LayoutParams.MATCH_PARENT
                height = WindowManager.LayoutParams.MATCH_PARENT
                gravity = Gravity.FILL
            }
            gridOverlay = GridOverlayView(this)
            windowManager?.addView(gridOverlay, params)
        }
    }

    fun hideGridOverlay() {
        android.os.Handler(mainLooper).post {
            gridOverlay?.let {
                windowManager?.removeView(it)
                gridOverlay = null
            }
        }
    }

    fun tapGridCell(cellIndex: Int): Boolean {
        if (cellIndex < 1 || cellIndex > 9) return false
        val displayMetrics = resources.displayMetrics
        val cellWidth = displayMetrics.widthPixels / 3f
        val cellHeight = displayMetrics.heightPixels / 3f
        
        val col = (cellIndex - 1) % 3
        val row = (cellIndex - 1) / 3
        
        val targetX = col * cellWidth + cellWidth / 2f
        val targetY = row * cellHeight + cellHeight / 2f
        
        performClick(targetX, targetY)
        hideGridOverlay()
        return true
    }

    /**
     * Dumps the current screen hierarchy to a flat text representation for the AI to "view"
     */
    fun dumpScreenHierarchy(): String {
        val rootNode = rootInActiveWindow ?: return "SCREEN_EMPTY: No active window or root node."
        val builder = StringBuilder()
        traverseNodes(rootNode, 0, builder)
        return builder.toString()
    }

    private fun traverseNodes(node: AccessibilityNodeInfo?, depth: Int, builder: StringBuilder) {
        if (node == null) return
        
        val indent = "  ".repeat(depth)
        val text = node.text?.toString() ?: ""
        val contentDesc = node.contentDescription?.toString() ?: ""
        val viewId = node.viewIdResourceName ?: ""
        
        if (text.isNotEmpty() || contentDesc.isNotEmpty()) {
            builder.append(indent)
            builder.append("[")
            builder.append(node.className?.split(".")?.lastOrNull() ?: "View")
            builder.append("] ")
            if (text.isNotEmpty()) builder.append("Text: \"$text\" ")
            if (contentDesc.isNotEmpty()) builder.append("Desc: \"$contentDesc\" ")
            if (viewId.isNotEmpty()) builder.append("ID: $viewId ")
            builder.append("\n")
        }

        for (i in 0 until node.childCount) {
            traverseNodes(node.getChild(i), depth + 1, builder)
        }
    }
}

/**
 * GridOverlayView renders a clean numbered 3x3 layout
 */
class GridOverlayView(context: Context) : View(context) {
    private val linePaint = Paint().apply {
        color = Color.CYAN
        strokeWidth = 4f
        style = Paint.Style.STROKE
    }
    private val textPaint = Paint().apply {
        color = Color.CYAN
        textSize = 64f
        isFakeBoldText = true
        textAlign = Paint.Align.CENTER
    }
    private val bgPaint = Paint().apply {
        color = Color.BLACK
        alpha = 150
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val stepX = w / 3f
        val stepY = h / 3f

        // Draw grid lines
        for (i in 1..2) {
            canvas.drawLine(i * stepX, 0f, i * stepX, h, linePaint)
            canvas.drawLine(0f, i * stepY, w, i * stepY, linePaint)
        }

        // Draw numbers 1 to 9 inside background circles for excellent readability
        for (row in 0..2) {
            for (col in 0..2) {
                val num = row * 3 + col + 1
                val cx = col * stepX + stepX / 2f
                val cy = row * stepY + stepY / 2f
                canvas.drawCircle(cx, cy, 50f, bgPaint)
                canvas.drawText(num.toString(), cx, cy + 22f, textPaint)
            }
        }
    }
}
