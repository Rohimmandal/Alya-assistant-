package com.alya.assistant.audio

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

/**
 * WakeWordEngine - Lightweight local detector for "Alya"
 * Uses simple energy-based spectral analysis (Simplified for native Android)
 */
class WakeWordEngine(private val onWakeWordDetected: () -> Unit) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var job: Job? = null
    private var audioRecord: AudioRecord? = null

    private val sampleRate = 16000
    private val bufferSize = 1024

    @SuppressLint("MissingPermission")
    fun start() {
        if (job != null) return

        val minBufSize = AudioRecord.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )

        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            maxOf(minBufSize, bufferSize * 2)
        )

        audioRecord?.startRecording()

        job = scope.launch {
            val buffer = ShortArray(bufferSize)
            var consecutiveHits = 0
            
            while (isActive) {
                val read = audioRecord?.read(buffer, 0, bufferSize) ?: 0
                if (read > 0) {
                    val rms = calculateRMS(buffer, read)
                    
                    // Simple logic: If volume spikes (potential "Alya") 
                    // In a production app, we'd use a TFLite model or Porcupine here.
                    if (rms > 2500) {
                        consecutiveHits++
                        if (consecutiveHits >= 2) {
                            onWakeWordDetected()
                            consecutiveHits = 0
                            kotlinx.coroutines.delay(2000) // Cooling period
                        }
                    } else {
                        consecutiveHits = 0
                    }
                }
            }
        }
    }

    private fun calculateRMS(buffer: ShortArray, read: Int): Double {
        var sum = 0.0
        for (i in 0 until read) {
            sum += buffer[i] * buffer[i]
        }
        return sqrt(sum / read)
    }

    fun stop() {
        job?.cancel()
        job = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {}
        audioRecord = null
    }
}
