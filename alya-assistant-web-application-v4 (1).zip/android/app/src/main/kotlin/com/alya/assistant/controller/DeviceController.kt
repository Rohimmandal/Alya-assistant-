package com.alya.assistant.controller

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import com.alya.assistant.MainActivity
import com.alya.assistant.service.AlyaAccessibilityService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

class DeviceController(private val context: Context) {

    private var adMonitorJob: Job? = null
    private val controllerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    init {
        startAdMonitorService()
    }

    fun startAdMonitorService() {
        if (adMonitorJob != null) return
        adMonitorJob = controllerScope.launch {
            while (isActive) {
                try {
                    val service = AlyaAccessibilityService.instance
                    if (service != null) {
                        val skipped = service.checkForAndSkipYouTubeAds()
                        if (skipped) {
                            android.util.Log.i("DeviceController", "YouTube Ad Monitor Service automatically skipped an ad!")
                        }
                    }
                } catch (e: Exception) {
                    // Quietly ignore background exceptions
                }
                delay(1000L) // Scan DOM hierarchy every 1 second
            }
        }
    }

    fun stopAdMonitorService() {
        adMonitorJob?.cancel()
        adMonitorJob = null
    }

    fun executeAction(command: String, params: Map<String, Any>?): String {
        val cmd = command.trim().uppercase()
        return when {
            cmd == "HOME" -> goHome()
            cmd == "BACK" -> goBack()
            cmd in listOf("FLASHLIGHT", "DEVICE_FLASHLIGHT", "TORCH") -> {
                val state = params?.get("state") as? Boolean 
                    ?: params?.get("enabled") as? Boolean 
                    ?: true
                toggleFlashlight(state)
            }
            cmd in listOf("VOLUME", "DEVICE_VOLUME") -> {
                val level = (params?.get("level") as? Number)?.toInt() ?: 50
                val action = params?.get("action") as? String
                when (action) {
                    "decrease", "down", "lower" -> adjustVolume(AudioManager.ADJUST_LOWER)
                    "increase", "up", "raise" -> adjustVolume(AudioManager.ADJUST_RAISE)
                    else -> setVolume(level)
                }
            }
            cmd in listOf("BATTERY", "DEVICE_BATTERY") -> getBatteryInfo()
            cmd in listOf("LOCATION", "GET_LOCATION", "DEVICE_LOCATION") -> getLocation()
            cmd in listOf("OPEN_APP", "DEVICE_APP_LAUNCH", "APP_LAUNCH") -> {
                val pkg = params?.get("packageName") as? String
                val appName = params?.get("appName") as? String
                openAppByNameOrPackage(pkg ?: appName ?: "")
            }
            cmd in listOf("SETTINGS", "DEVICE_SETTING_CONTROL", "OPEN_SETTINGS") -> {
                val setting = (params?.get("setting") as? String)?.lowercase() ?: ""
                openSpecificSettings(setting)
            }
            cmd in listOf("NAVIGATE_CHAT", "WAPAS_CHAT", "BACK_TO_CHAT", "BRING_TO_FRONT") -> {
                bringAlyaToForeground()
            }
            cmd in listOf("SCREEN_VIEW", "VIEW_SCREEN", "READ_SCREEN", "DUMP_SCREEN") -> {
                viewScreen()
            }
            cmd in listOf("CLICK", "TAP", "TOUCH") -> {
                val x = (params?.get("x") as? Number)?.toFloat() ?: 0f
                val y = (params?.get("y") as? Number)?.toFloat() ?: 0f
                val text = params?.get("text") as? String
                if (text != null) clickByText(text) else tapAt(x, y)
            }
            cmd in listOf("BRIGHTNESS", "DEVICE_BRIGHTNESS") -> {
                val level = (params?.get("level") as? Number)?.toInt() ?: 50
                setBrightness(level)
            }
            cmd == "CALL_CONTACT" -> {
                val name = params?.get("contactName") as? String ?: ""
                searchAndCallContact(name)
            }
            cmd == "SEND_WHATSAPP" -> {
                val name = params?.get("contactName") as? String ?: ""
                val message = params?.get("message") as? String ?: ""
                sendWhatsAppMessage(name, message)
            }
            cmd == "SEND_GMAIL" -> {
                val recipient = params?.get("recipientEmail") as? String ?: ""
                val subject = params?.get("subject") as? String ?: ""
                val body = params?.get("body") as? String ?: ""
                sendGmail(recipient, subject, body)
            }
            cmd == "DOUBLE_TAP" -> {
                val x = (params?.get("x") as? Number)?.toFloat() ?: 0f
                val y = (params?.get("y") as? Number)?.toFloat() ?: 0f
                doubleTapAt(x, y)
            }
            cmd == "LONG_PRESS" -> {
                val x = (params?.get("x") as? Number)?.toFloat() ?: 0f
                val y = (params?.get("y") as? Number)?.toFloat() ?: 0f
                longPressAt(x, y)
            }
            cmd == "SWIPE" -> {
                val startX = (params?.get("startX") as? Number)?.toFloat() ?: 0f
                val startY = (params?.get("startY") as? Number)?.toFloat() ?: 0f
                val endX = (params?.get("endX") as? Number)?.toFloat() ?: 0f
                val endY = (params?.get("endY") as? Number)?.toFloat() ?: 0f
                val duration = (params?.get("duration") as? Number)?.toLong() ?: 300L
                swipe(startX, startY, endX, endY, duration)
            }
            cmd == "SCROLL" -> {
                val direction = params?.get("direction") as? String ?: "down"
                val scrollUp = direction.lowercase() == "up"
                scroll(scrollUp)
            }
            cmd == "TYPE" -> {
                val text = params?.get("text") as? String ?: ""
                type(text)
            }
            cmd == "TEXT_ACTION" -> {
                val action = params?.get("action") as? String ?: ""
                textAction(action)
            }
            cmd in listOf("ZOOM", "MAGNIFY") -> {
                val action = params?.get("action") as? String ?: ""
                magnify(action)
            }
            cmd == "SHOW_GRID" -> {
                showGrid()
            }
            cmd == "HIDE_GRID" -> {
                hideGrid()
            }
            cmd in listOf("GRID_TAP", "GRID_SELECT") -> {
                val cell = (params?.get("cell") as? Number)?.toInt() ?: 1
                gridTap(cell)
            }
            cmd in listOf("RECENTS", "RECENT_APPS") -> {
                goRecents()
            }
            cmd in listOf("CLOSE_APP", "DEVICE_APP_CLOSE") -> {
                val appName = params?.get("appName") as? String ?: ""
                closeAppByName(appName)
            }
            cmd in listOf("MEDIA_PLAY", "PLAY") -> {
                controlMediaSession("PLAY")
            }
            cmd in listOf("MEDIA_PAUSE", "PAUSE") -> {
                controlMediaSession("PAUSE")
            }
            cmd in listOf("MEDIA_STOP", "STOP") -> {
                controlMediaSession("STOP")
            }
            cmd in listOf("MEDIA_NEXT", "NEXT") -> {
                controlMediaSession("NEXT")
            }
            cmd in listOf("MEDIA_PREV", "PREV") -> {
                controlMediaSession("PREV")
            }
            cmd in listOf("MEDIA_FORWARD", "FORWARD", "SEEK_FORWARD") -> {
                val seconds = (params?.get("seconds") as? Number)?.toInt() ?: 10
                controlMediaSession("FORWARD", seconds)
            }
            cmd in listOf("MEDIA_REWIND", "REWIND", "SEEK_BACKWARD") -> {
                val seconds = (params?.get("seconds") as? Number)?.toInt() ?: 10
                controlMediaSession("REWIND", seconds)
            }
            cmd in listOf("OPEN_VIDEO", "PLAY_YOUTUBE", "YOUTUBE_PLAY", "PLAY_YOUTUBE_VIDEO", "SEARCH_AND_PLAY", "YOUTUBE_CONTROL") -> {
                val action = params?.get("action") as? String
                if (action != null && action.uppercase() in listOf("PAUSE", "RESUME", "STOP", "NEXT", "PREV", "FORWARD_10", "FORWARD_20", "BACKWARD_10", "BACKWARD_20", "SKIP_AD")) {
                    when (action.uppercase()) {
                        "PAUSE" -> controlMediaSession("PAUSE")
                        "RESUME", "PLAY" -> controlMediaSession("PLAY")
                        "STOP" -> controlMediaSession("STOP")
                        "NEXT" -> controlMediaSession("NEXT")
                        "PREV" -> controlMediaSession("PREV")
                        "FORWARD_10" -> controlMediaSession("FORWARD", 10)
                        "FORWARD_20" -> controlMediaSession("FORWARD", 20)
                        "BACKWARD_10" -> controlMediaSession("REWIND", 10)
                        "BACKWARD_20" -> controlMediaSession("REWIND", 20)
                        "SKIP_AD" -> {
                            // Check automatic ad click first, if not found then seek 60s
                            val skipped = AlyaAccessibilityService.instance?.checkForAndSkipYouTubeAds() ?: false
                            if (!skipped) {
                                controlMediaSession("FORWARD", 60)
                            } else {
                                "SUCCESS: Skipped ad via accessibility click"
                            }
                        }
                        else -> controlMediaSession("PLAY")
                    }
                } else {
                    val queryOrUrl = params?.get("videoId") as? String
                        ?: params?.get("url") as? String
                        ?: params?.get("query") as? String
                        ?: params?.get("target") as? String
                        ?: params?.get("text") as? String
                        ?: ""
                    playYouTubeVideoDirect(queryOrUrl)
                }
            }
            else -> "UNKNOWN_COMMAND: $command"
        }
    }

    private fun searchAndCallContact(contactName: String): String {
        if (contactName.isBlank()) return "FAILURE: No contact name provided"
        
        return try {
            val resolver = context.contentResolver
            val uri = Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(contactName))
            val cursor = resolver.query(uri, arrayOf(android.provider.ContactsContract.PhoneLookup.NUMBER), null, null, null)
            
            var number: String? = null
            if (cursor?.moveToFirst() == true) {
                number = cursor.getString(0)
            }
            cursor?.close()

            if (number != null) {
                val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
                "SUCCESS: Calling $contactName ($number)"
            } else {
                "FAILURE: Contact '$contactName' not found"
            }
        } catch (e: SecurityException) {
            "PERMISSION_DENIED: CALL_PHONE permission not granted"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun sendWhatsAppMessage(contactName: String, message: String): String {
        return try {
            // Find contact number first (simplified, real impl would be more robust)
            val resolver = context.contentResolver
            val uri = Uri.withAppendedPath(android.provider.ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(contactName))
            val cursor = resolver.query(uri, arrayOf(android.provider.ContactsContract.PhoneLookup.NUMBER), null, null, null)
            
            var number: String? = null
            if (cursor?.moveToFirst() == true) {
                number = cursor.getString(0)
            }
            cursor?.close()

            if (number != null) {
                val cleanNumber = number.replace(Regex("[^0-9]"), "")
                val whatsappUri = Uri.parse("https://api.whatsapp.com/send?phone=$cleanNumber&text=${Uri.encode(message)}")
                val intent = Intent(Intent.ACTION_VIEW, whatsappUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                "SUCCESS: Deep-linked to WhatsApp for $contactName"
            } else {
                "FAILURE: Could not find WhatsApp contact for '$contactName'"
            }
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun sendGmail(recipient: String, subject: String, body: String): String {
        return try {
            val intent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("mailto:")
                putExtra(Intent.EXTRA_EMAIL, arrayOf(recipient))
                putExtra(Intent.EXTRA_SUBJECT, subject)
                putExtra(Intent.EXTRA_TEXT, body)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "SUCCESS: Gmail draft prepared for $recipient"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun goHome(): String {
        return try {
            val intent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "SUCCESS"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun goBack(): String {
        return try {
            AlyaAccessibilityService.instance?.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_BACK
            )
            "SUCCESS"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun bringAlyaToForeground(): String {
        return try {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            }
            context.startActivity(intent)
            "SUCCESS: Returned to Alya Assistant chat"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun toggleFlashlight(enabled: Boolean): String {
        val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return "FAILURE: No camera flashlight found"
            cameraManager.setTorchMode(cameraId, enabled)
            if (enabled) "SUCCESS: Flashlight turned on" else "SUCCESS: Flashlight turned off"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun setVolume(level: Int): String {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val clampedLevel = level.coerceIn(0, 100)
            val targetVolume = ((clampedLevel / 100.0) * maxVolume).toInt()
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, AudioManager.FLAG_SHOW_UI)
            "SUCCESS: Volume set to $clampedLevel%"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun adjustVolume(direction: Int): String {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
            val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val pct = ((current.toDouble() / max) * 100).toInt()
            "SUCCESS: Volume adjusted to $pct%"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun getBatteryInfo(): String {
        return try {
            val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            val isCharging = batteryManager.isCharging
            "SUCCESS: Battery at $level%${if (isCharging) " (Charging)" else ""}"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun getLocation(): String {
        return try {
            val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? android.location.LocationManager
                ?: return "FAILURE: LocationManager unavailable on device"

            val hasFine = androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.ACCESS_FINE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

            val hasCoarse = androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.ACCESS_COARSE_LOCATION
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED

            if (!hasFine && !hasCoarse) {
                return "PERMISSION_DENIED: Location permission not granted by user"
            }

            val providers = listOf(
                android.location.LocationManager.GPS_PROVIDER,
                android.location.LocationManager.NETWORK_PROVIDER,
                android.location.LocationManager.PASSIVE_PROVIDER
            )

            var bestLoc: android.location.Location? = null
            for (p in providers) {
                if (locationManager.isProviderEnabled(p)) {
                    @Suppress("MissingPermission")
                    val l = locationManager.getLastKnownLocation(p)
                    if (l != null && (bestLoc == null || l.time > bestLoc.time)) {
                        bestLoc = l
                    }
                }
            }

            if (bestLoc != null) {
                "SUCCESS: LAT=${bestLoc.latitude}, LON=${bestLoc.longitude}, ACC=${bestLoc.accuracy}m"
            } else {
                "FAILURE: No active GPS/Network fix available"
            }
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun openAppByNameOrPackage(appNameOrPkg: String): String {
        val query = appNameOrPkg.trim().lowercase()
        if (query.isEmpty()) return "FAILURE: Empty application name provided"

        // Handle direct common apps
        val targetPackage = when {
            query.contains("youtube") -> "com.google.android.youtube"
            query.contains("chrome") -> "com.android.chrome"
            query.contains("whatsapp") -> "com.whatsapp"
            query.contains("spotify") -> "com.spotify.music"
            query.contains("settings") -> {
                return openSpecificSettings("")
            }
            query.contains("camera") -> {
                return try {
                    val intent = Intent("android.media.action.IMAGE_CAPTURE").apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    "SUCCESS: Opened Camera"
                } catch (e: Exception) {
                    "FAILURE: Could not open Camera"
                }
            }
            query.contains("map") -> "com.google.android.apps.maps"
            query.contains("gmail") -> "com.google.android.gm"
            query.contains("instagram") -> "com.instagram.android"
            else -> query
        }

        // Try direct launch intent
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(targetPackage)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
            return "SUCCESS: Opened $appNameOrPkg"
        }

        // Fuzzy search installed applications by label
        try {
            val apps = pm.getInstalledApplications(0)
            for (app in apps) {
                val label = pm.getApplicationLabel(app).toString().lowercase()
                if (label.contains(query) || query.contains(label)) {
                    val intent = pm.getLaunchIntentForPackage(app.packageName)
                    if (intent != null) {
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(intent)
                        return "SUCCESS: Opened ${pm.getApplicationLabel(app)}"
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore search errors
        }

        // Browser fallback for web services like YouTube if native app not installed
        if (query.contains("youtube")) {
            return try {
                val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(webIntent)
                "SUCCESS: Opened YouTube in browser"
            } catch (e: Exception) {
                "FAILURE: App $appNameOrPkg not installed"
            }
        }

        return "FAILURE: Application '$appNameOrPkg' is not installed or cannot be opened"
    }

    private fun openSpecificSettings(setting: String): String {
        return try {
            val s = setting.lowercase()
            val intent = when {
                s in listOf("wifi", "wi-fi") -> Intent(Settings.ACTION_WIFI_SETTINGS)
                s in listOf("bluetooth", "bt") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                s in listOf("display", "brightness") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                s in listOf("sound", "volume") -> Intent(Settings.ACTION_SOUND_SETTINGS)
                s in listOf("apps", "application") -> Intent(Settings.ACTION_APPLICATION_SETTINGS)
                s in listOf("accessibility", "accessibilityactive") -> Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                s in listOf("notification", "notifications", "notificationlisteneractive") -> Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                s in listOf("overlay", "displayoverotherappsactive", "system_alert_window") -> Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                s in listOf("battery", "batteryoptimization", "battery_optimization") -> Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                s in listOf("location", "gps") -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                s in listOf("permissions", "app_details") -> Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                else -> Intent(Settings.ACTION_SETTINGS)
            }.apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            "SUCCESS: Opened Android Settings for $setting"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun viewScreen(): String {
        return try {
            val captureService = com.alya.assistant.service.ScreenCaptureService.instance
            val screenBase64 = captureService?.captureScreenBase64(75)

            val service = AlyaAccessibilityService.instance
            val dump = service?.dumpScreenHierarchy() ?: "Accessibility Service inactive."

            if (screenBase64 != null) {
                "SUCCESS: SCREEN_CAPTURE_IMAGE\nBASE64:$screenBase64\n\nSCREEN_HIERARCHY:\n$dump"
            } else if (service != null) {
                "SUCCESS: SCREEN_DUMP\n$dump"
            } else {
                "FAILURE: Both ScreenCaptureService (MediaProjection) and AccessibilityService are inactive. Please enable Accessibility in Android Settings."
            }
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun tapAt(x: Float, y: Float): String {
        return try {
            val service = AlyaAccessibilityService.instance
            if (service == null) return "FAILURE: Accessibility Service required"
            service.performClick(x, y)
            "SUCCESS: Tapped at $x, $y"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun clickByText(text: String): String {
        return try {
            val service = AlyaAccessibilityService.instance
            if (service == null) return "FAILURE: Accessibility Service required"
            // We need to implement clickNodeByText in AlyaAccessibilityService or use performClick with coords if we can find them
            // For now let's assume we can try to find and click
            val success = service.clickNodeByText(text)
            if (success) "SUCCESS: Clicked on $text" else "FAILURE: Could not find clickable element with text '$text'"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun setBrightness(level: Int): String {
        return try {
            if (Settings.System.canWrite(context)) {
                val clamped = level.coerceIn(0, 255)
                Settings.System.putInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, clamped)
                "SUCCESS: Brightness set to $level"
            } else {
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
                "PERMISSION_REQUIRED: Write Settings permission needed"
            }
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun doubleTapAt(x: Float, y: Float): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        service.performDoubleTap(x, y)
        return "SUCCESS: Double tapped at $x, $y"
    }

    private fun longPressAt(x: Float, y: Float): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        service.performLongPress(x, y)
        return "SUCCESS: Long pressed at $x, $y"
    }

    private fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, duration: Long): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        service.performSwipe(startX, startY, endX, endY, duration)
        return "SUCCESS: Swiped from $startX, $startY to $endX, $endY"
    }

    private fun scroll(scrollUp: Boolean): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        val success = service.scroll(scrollUp)
        return if (success) "SUCCESS: Scrolled ${if (scrollUp) "up" else "down"}" else "FAILURE: Could not scroll"
    }

    private fun type(text: String): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        val success = service.typeText(text)
        return if (success) "SUCCESS: Typed text" else "FAILURE: No focused editable field found"
    }

    private fun textAction(action: String): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        val success = service.textEditingAction(action)
        return if (success) "SUCCESS: Performed text action $action" else "FAILURE: Editing action failed"
    }

    private fun magnify(action: String): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        val success = service.controlMagnification(action)
        return if (success) "SUCCESS: Magnification action $action performed" else "FAILURE: Magnification action not supported"
    }

    private fun showGrid(): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        service.showGridOverlay()
        return "SUCCESS: Grid overlay displayed"
    }

    private fun hideGrid(): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        service.hideGridOverlay()
        return "SUCCESS: Grid overlay hidden"
    }

    private fun gridTap(cellIndex: Int): String {
        val service = AlyaAccessibilityService.instance ?: return "FAILURE: Accessibility Service required"
        val success = service.tapGridCell(cellIndex)
        return if (success) "SUCCESS: Tapped grid cell $cellIndex" else "FAILURE: Cell tap failed"
    }

    private fun goRecents(): String {
        return try {
            val success = AlyaAccessibilityService.instance?.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_RECENTS
            ) ?: false
            if (success) "SUCCESS" else "FAILURE: Could not show Recents screen"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun closeAppByName(appName: String): String {
        return try {
            // Safe non-root standard way to minimize/close app in modern Android is going Home
            val success = AlyaAccessibilityService.instance?.performGlobalAction(
                android.accessibilityservice.AccessibilityService.GLOBAL_ACTION_HOME
            ) ?: false
            if (success) "SUCCESS: Closed/minimized $appName" else "FAILURE: Could not minimize app"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun dispatchMediaButtonToController(controller: android.media.session.MediaController, keyCode: Int): Boolean {
        return try {
            val eventDown = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
            val eventUp = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
            val downSuccess = controller.dispatchMediaButtonEvent(eventDown)
            val upSuccess = controller.dispatchMediaButtonEvent(eventUp)
            downSuccess || upSuccess
        } catch (e: Exception) {
            false
        }
    }

    private fun dispatchMediaKey(keyCode: Int): String {
        return try {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val eventDown = android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, keyCode)
            val eventUp = android.view.KeyEvent(android.view.KeyEvent.ACTION_UP, keyCode)
            audioManager.dispatchMediaKeyEvent(eventDown)
            audioManager.dispatchMediaKeyEvent(eventUp)
            "SUCCESS: Dispatch key code $keyCode"
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }

    private fun controlMediaSession(action: String, seconds: Int = 10): String {
        val service = AlyaAccessibilityService.instance
        if (service == null) {
            // Fallback 1: Fallback to system-wide hardware keys if accessibility service is not active
            return when (action.uppercase()) {
                "PLAY", "RESUME" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
                "PAUSE" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                "STOP" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_STOP)
                "NEXT" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                "PREV" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                "FORWARD", "SKIP_FORWARD" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
                "REWIND", "SKIP_BACKWARD" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_REWIND)
                else -> "FAILURE: Accessibility Service not active; system key fallback unsupported for $action"
            }
        }

        val mediaSessionManager = service.getSystemService(Context.MEDIA_SESSION_SERVICE) as? android.media.session.MediaSessionManager
            ?: return "FAILURE: MediaSessionManager not available."
            
        return try {
            val componentName = android.content.ComponentName(service, AlyaAccessibilityService::class.java)
            val controllers = mediaSessionManager.getActiveSessions(componentName)
            
            if (controllers.isNullOrEmpty()) {
                // Fallback 2: Fallback to system-wide hardware keys if no active MediaSessions are exposed
                return when (action.uppercase()) {
                    "PLAY", "RESUME" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
                    "PAUSE" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                    "STOP" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_STOP)
                    "NEXT" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                    "PREV" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                    "FORWARD", "SKIP_FORWARD" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
                    "REWIND", "SKIP_BACKWARD" -> dispatchMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_REWIND)
                    else -> "FAILURE: No active MediaSession found and key fallback unsupported for $action"
                }
            }
            
            var controlled = false
            for (controller in controllers) {
                val controls = controller.transportControls
                when (action.uppercase()) {
                    "PLAY", "RESUME" -> {
                        controls.play()
                        dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
                        controlled = true
                    }
                    "PAUSE" -> {
                        controls.pause()
                        dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
                        controlled = true
                    }
                    "STOP" -> {
                        controls.stop()
                        dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_STOP)
                        controlled = true
                    }
                    "NEXT" -> {
                        controls.skipToNext()
                        dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
                        controlled = true
                    }
                    "PREV" -> {
                        controls.skipToPrevious()
                        dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
                        controlled = true
                    }
                    "FORWARD", "SKIP_FORWARD" -> {
                        val state = controller.playbackState
                        val currentPos = state?.position ?: -1L
                        if (currentPos >= 0L) {
                            val newPos = currentPos + (seconds * 1000L)
                            controls.seekTo(newPos)
                            controlled = true
                        } else {
                            // Seek fallback: dispatch fast forward button event directly to the active media controller
                            dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_FAST_FORWARD)
                            controlled = true
                        }
                    }
                    "REWIND", "SKIP_BACKWARD" -> {
                        val state = controller.playbackState
                        val currentPos = state?.position ?: -1L
                        if (currentPos >= 0L) {
                            val newPos = maxOf(0L, currentPos - (seconds * 1000L))
                            controls.seekTo(newPos)
                            controlled = true
                        } else {
                            // Seek fallback: dispatch rewind button event directly to the active media controller
                            dispatchMediaButtonToController(controller, android.view.KeyEvent.KEYCODE_MEDIA_REWIND)
                            controlled = true
                        }
                    }
                }
            }
            
            if (controlled) {
                "SUCCESS: Executed MediaSession command '$action' on active player."
            } else {
                "FAILURE: Action '$action' failed or state unavailable."
            }
        } catch (e: Exception) {
            "FAILURE: MediaSession control failed: ${e.message}"
        }
    }

    private fun openVideo(queryOrUrl: String): String {
        return playYouTubeVideoDirect(queryOrUrl)
    }

    fun playYouTubeVideoDirect(queryOrUrlOrId: String): String {
        return try {
            val trimmed = queryOrUrlOrId.trim()
            val uri: Uri = when {
                trimmed.startsWith("vnd.youtube:") -> Uri.parse(trimmed)
                trimmed.length in 10..12 && !trimmed.contains(" ") && !trimmed.contains("/") && !trimmed.contains("?") -> {
                    // Direct YouTube videoId (e.g. dQw4w9WgXcQ)
                    Uri.parse("vnd.youtube:$trimmed")
                }
                trimmed.contains("v=") -> {
                    val vId = trimmed.substringAfter("v=").substringBefore("&")
                    Uri.parse("vnd.youtube:$vId")
                }
                trimmed.contains("youtu.be/") -> {
                    val vId = trimmed.substringAfter("youtu.be/").substringBefore("?")
                    Uri.parse("vnd.youtube:$vId")
                }
                trimmed.contains("/embed/") -> {
                    val vId = trimmed.substringAfter("/embed/").substringBefore("?")
                    Uri.parse("vnd.youtube:$vId")
                }
                trimmed.startsWith("http://") || trimmed.startsWith("https://") -> Uri.parse(trimmed)
                else -> {
                    // Native vnd.youtube search URI scheme
                    Uri.parse("vnd.youtube://search?query=${Uri.encode(trimmed)}")
                }
            }

            // Direct native Android Intent targeting vnd.youtube scheme and com.google.android.youtube for full-screen playback
            val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                setPackage("com.google.android.youtube")
                putExtra("autoplay", true)
                putExtra("fullscreen", true)
                putExtra("force_fullscreen", true)
                putExtra("finish_on_ended", true)
            }

            try {
                context.startActivity(intent)
                "SUCCESS: Launched native YouTube player for '$trimmed'"
            } catch (e: Exception) {
                // Try without explicit package for any native handler supporting vnd.youtube
                try {
                    val genericVndIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        putExtra("autoplay", true)
                        putExtra("fullscreen", true)
                        putExtra("force_fullscreen", true)
                        putExtra("finish_on_ended", true)
                    }
                    context.startActivity(genericVndIntent)
                    "SUCCESS: Launched YouTube player via native scheme for '$trimmed'"
                } catch (e2: Exception) {
                    // Fallback to browser without package restriction
                    val fallbackUri = if (uri.scheme == "vnd.youtube") {
                        val part = uri.schemeSpecificPart.removePrefix("//")
                        if (part.startsWith("search?query=")) {
                            val q = part.removePrefix("search?query=")
                            Uri.parse("https://www.youtube.com/results?search_query=$q")
                        } else {
                            Uri.parse("https://www.youtube.com/watch?v=$part")
                        }
                    } else uri
                    val fallbackIntent = Intent(Intent.ACTION_VIEW, fallbackUri).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(fallbackIntent)
                    "SUCCESS: Opened YouTube playback via web/system handler"
                }
            }
        } catch (e: Exception) {
            "FAILURE: ${e.message}"
        }
    }
}
