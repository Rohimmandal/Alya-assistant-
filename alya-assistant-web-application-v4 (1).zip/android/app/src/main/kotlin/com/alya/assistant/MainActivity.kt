package com.alya.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alya.assistant.service.AlyaForegroundService
import com.alya.assistant.ui.theme.AlyaTheme
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Ensure service is running
        AlyaForegroundService.startService(this)

        setContent {
            AlyaTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF020408) // Deep space black
                ) {
                    AlyaAssistantApp()
                }
            }
        }
    }
}

enum class AppScreen {
    ONBOARDING,
    ASSISTANT,
    SETTINGS
}

@Composable
fun AlyaAssistantApp() {
    val context = LocalContext.current
    var currentScreen by remember { mutableStateOf(AppScreen.ASSISTANT) }
    
    val requiredPermissions = remember {
        mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        ).apply {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    fun checkPermissions(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    LaunchedEffect(Unit) {
        if (!checkPermissions()) {
            currentScreen = AppScreen.ONBOARDING
        }
    }

    Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
        when (screen) {
            AppScreen.ONBOARDING -> OnboardingScreen(
                permissions = requiredPermissions,
                onComplete = { currentScreen = AppScreen.ASSISTANT }
            )
            AppScreen.ASSISTANT -> AssistantScreen(onOpenSettings = { currentScreen = AppScreen.SETTINGS })
            AppScreen.SETTINGS -> SettingsScreen(onBack = { currentScreen = AppScreen.ASSISTANT })
        }
    }
}

@Composable
fun OnboardingScreen(permissions: List<String>, onComplete: () -> Unit) {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            onComplete()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            modifier = Modifier
                .size(120.dp)
                .background(
                    Brush.radialGradient(listOf(Color(0xFF00D4FF), Color(0xFF003DFF).copy(alpha = 0.2f))),
                    CircleShape
                )
                .blur(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Shield,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(40.dp))

        Text(
            text = "Permissions Required",
            style = MaterialTheme.typography.headlineMedium,
            color = Color.White,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Alya needs access to your mic, contacts, and phone to become your perfect sassy companion.",
            textAlign = TextAlign.Center,
            color = Color.Gray,
            lineHeight = 22.sp
        )

        Spacer(modifier = Modifier.height(48.dp))

        Button(
            onClick = { launcher.launch(permissions.toTypedArray()) },
            modifier = Modifier.fillMaxWidth().height(56.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D4FF)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Text("Grant Access", color = Color.Black, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun AssistantScreen(onOpenSettings: () -> Unit) {
    val context = LocalContext.current
    val voiceManager = remember { AlyaForegroundService.instance?.getVoiceManager() }
    val assistantState by voiceManager?.state?.collectAsState() ?: remember { mutableStateOf("IDLE") }
    
    Box(modifier = Modifier.fillMaxSize()) {
        // Futuristic background elements
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                brush = Brush.radialGradient(
                    0.0f to Color(0xFF00D4FF).copy(alpha = 0.05f),
                    1.0f to Color.Transparent
                ),
                radius = size.width * 0.8f,
                center = center
            )
        }

        // Top Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .statusBarsPadding(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "ALYA",
                    style = MaterialTheme.typography.titleLarge,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 4.sp
                )
                Text(
                    text = "v3.1 LIVE ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF00D4FF),
                    fontWeight = FontWeight.Bold
                )
            }
            
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.05f))
            ) {
                Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White)
            }
        }

        // Central Orb
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            AlyaOrb(state = assistantState)
        }

        // Bottom Status Text
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 64.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedContent(
                targetState = assistantState,
                transitionSpec = {
                    fadeIn() + slideInVertically { it / 2 } with fadeOut()
                },
                label = "StatusText"
            ) { state ->
                Text(
                    text = when(state) {
                        "LISTENING" -> "Listening..."
                        "THINKING" -> "Thinking..."
                        "SPEAKING" -> "Alya is speaking"
                        else -> "Say \"Alya\" or tap to start"
                    },
                    color = Color.White.copy(alpha = 0.7f),
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
fun AlyaOrb(state: String) {
    val infiniteTransition = rememberInfiniteTransition(label = "OrbAnimation")
    
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(2000, easing = LinearOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "OrbScale"
    )

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(10000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "OrbRotation"
    )

    val listeningPulse = remember { Animatable(0f) }
    
    LaunchedEffect(state) {
        if (state == "LISTENING") {
            while(true) {
                listeningPulse.animateTo(1f, tween(500))
                listeningPulse.animateTo(0.2f, tween(500))
            }
        } else {
            listeningPulse.snapTo(0f)
        }
    }

    Box(contentAlignment = Alignment.Center) {
        // Outer glow
        Box(
            modifier = Modifier
                .size(280.dp)
                .scale(scale)
                .blur(40.dp)
                .background(
                    Brush.radialGradient(
                        0.0f to Color(0xFF003DFF).copy(alpha = 0.4f),
                        1.0f to Color.Transparent
                    ),
                    CircleShape
                )
        )

        // Waveform ring (Visible when listening/speaking)
        if (state == "LISTENING" || state == "SPEAKING") {
            Canvas(modifier = Modifier.size(240.dp)) {
                drawCircle(
                    color = Color(0xFF00D4FF).copy(alpha = 0.3f),
                    radius = size.minDimension / 2 * scale,
                    style = Stroke(width = 2.dp)
                )
            }
        }

        // Core Orb
        Box(
            modifier = Modifier
                .size(160.dp)
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(Color(0xFF00D4FF), Color(0xFF003DFF)),
                    )
                )
                .drawBehind {
                    drawCircle(
                        Brush.verticalGradient(
                            listOf(Color.White.copy(alpha = 0.3f), Color.Transparent)
                        ),
                        radius = size.width / 2.2f
                    )
                }
                .clickable {
                    AlyaForegroundService.instance?.getVoiceManager()?.startLiveSession()
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = "Mic",
                tint = Color.Black.copy(alpha = 0.8f),
                modifier = Modifier.size(48.dp)
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("alya_user_preferences_v1", Context.MODE_PRIVATE) }
    
    var geminiApiKey by remember { mutableStateOf(prefs.getString("gemini_api_key", "") ?: "") }
    var isKeySaved by remember { mutableStateOf(geminiApiKey.isNotEmpty()) }
    var showPassword by remember { mutableStateOf(false) }
    var testStatus by remember { mutableStateOf("") }
    
    // Background Service States
    var isServiceRunning by remember { mutableStateOf(AlyaForegroundService.instance != null) }
    var micPermissionGranted by remember { 
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) 
    }
    var accessibilityServiceActive by remember { mutableStateOf(AlyaAccessibilityService.isServiceRunning) }

    // Automatic Status Updates when screen is viewed
    LaunchedEffect(Unit) {
        while (true) {
            isServiceRunning = AlyaForegroundService.instance != null
            micPermissionGranted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
            accessibilityServiceActive = AlyaAccessibilityService.isServiceRunning
            kotlinx.coroutines.delay(1000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF020408))
            .padding(24.dp)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
    ) {
        // Top Back Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.05f))
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Text(
                text = "Settings",
                style = MaterialTheme.typography.titleLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // 1. API Key Section
        Text(
            text = "GEMINI API KEY CONFIGURATION",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF00D4FF),
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )
        
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Enter your Gemini API key to use A.L.Y.A. AI features. Your key is used to authenticate requests to the Gemini API.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray
        )
        
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = if (isKeySaved && !showPassword) "••••••••••••••••••••" else geminiApiKey,
            onValueChange = {
                if (!isKeySaved || showPassword) {
                    geminiApiKey = it.trim()
                }
            },
            enabled = !isKeySaved || showPassword,
            label = { Text("Gemini API Key") },
            placeholder = { Text("Enter your Gemini API key", color = Color.Gray) },
            singleLine = true,
            visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
            trailingIcon = {
                IconButton(onClick = { showPassword = !showPassword }) {
                    Icon(
                        imageVector = if (showPassword) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                        contentDescription = if (showPassword) "Hide Key" else "Show Key",
                        tint = Color.White.copy(alpha = 0.6f)
                    )
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = TextFieldDefaults.outlinedTextFieldColors(
                focusedBorderColor = Color(0xFF00D4FF),
                unfocusedBorderColor = Color.White.copy(alpha = 0.15f),
                disabledBorderColor = Color.White.copy(alpha = 0.08f),
                focusedTextColor = Color.White,
                unfocusedTextColor = Color.White,
                disabledTextColor = Color.White.copy(alpha = 0.5f),
                focusedLabelColor = Color(0xFF00D4FF),
                unfocusedLabelColor = Color.Gray
            ),
            shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (!isKeySaved) {
                Button(
                    onClick = {
                        if (geminiApiKey.isNotEmpty()) {
                            prefs.edit().putString("gemini_api_key", geminiApiKey).apply()
                            isKeySaved = true
                            testStatus = "Key saved successfully!"
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D4FF)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Save Key", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            } else {
                Button(
                    onClick = {
                        isKeySaved = false
                        showPassword = true
                        testStatus = "Ready to update key."
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.1f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Update Key", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
                
                Button(
                    onClick = {
                        prefs.edit().remove("gemini_api_key").apply()
                        geminiApiKey = ""
                        isKeySaved = false
                        testStatus = "Key removed successfully."
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("Remove Key", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            Button(
                onClick = {
                    coroutineScope.launch {
                        testStatus = "Testing Connection..."
                        try {
                            val keyToTest = geminiApiKey.ifEmpty { prefs.getString("gemini_api_key", "") ?: "" }
                            if (keyToTest.isEmpty()) {
                                testStatus = "Error: Key is empty!"
                                return@launch
                            }
                            val url = java.net.URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=$keyToTest")
                            val responseCode = withContext(Dispatchers.IO) {
                                val c = url.openConnection() as java.net.HttpURLConnection
                                c.requestMethod = "POST"
                                c.setRequestProperty("Content-Type", "application/json")
                                c.doOutput = true
                                val payload = "{\"contents\":[{\"parts\":[{\"text\":\"ping\"}]}]}"
                                c.outputStream.use { os ->
                                    os.write(payload.toByteArray())
                                }
                                c.responseCode
                            }
                            testStatus = if (responseCode == 200) {
                                "Valid Key (Connected Successfully)"
                            } else {
                                "Invalid Key (Error: $responseCode)"
                            }
                        } catch (e: Exception) {
                            testStatus = "Network Error: ${e.message}"
                        }
                    }
                },
                modifier = Modifier.weight(1.2f),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF003DFF)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = Color.White, modifier = Modifier.size(12.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Test Connection", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        if (testStatus.isNotEmpty()) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = testStatus,
                style = MaterialTheme.typography.bodySmall,
                color = when {
                    testStatus.contains("Valid") || testStatus.contains("success") -> Color.Green
                    testStatus.contains("Error") || testStatus.contains("Invalid") -> Color.Red
                    else -> Color(0xFF00D4FF)
                },
                fontWeight = FontWeight.Medium
            )
        }

        Spacer(modifier = Modifier.height(32.dp))

        // 2. Background Assistant Section
        Text(
            text = "BACKGROUND ASSISTANT",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF00D4FF),
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Status Information
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Assistant Service Status", style = MaterialTheme.typography.bodyMedium, color = Color.White)
                    Text(
                        text = if (isServiceRunning) "A.L.Y.A. is listening" else "Assistant inactive",
                        color = if (isServiceRunning) Color.Green else Color.Red,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Microphone Permission", style = MaterialTheme.typography.bodyMedium, color = Color.White)
                    Text(
                        text = if (micPermissionGranted) "Granted" else "Required",
                        color = if (micPermissionGranted) Color.Green else Color.Yellow,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Background listener state", style = MaterialTheme.typography.bodyMedium, color = Color.White)
                    Text(
                        text = if (isServiceRunning) "Background assistant active" else "Stopped",
                        color = if (isServiceRunning) Color(0xFF00D4FF) else Color.Gray,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Service Controls
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = {
                            AlyaForegroundService.startService(context)
                            isServiceRunning = true
                        },
                        enabled = !isServiceRunning,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00D4FF)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Start", tint = Color.Black, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Start", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    Button(
                        onClick = {
                            AlyaForegroundService.stopService(context)
                            isServiceRunning = false
                        },
                        enabled = isServiceRunning,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Stop, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Stop", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // 3. Accessibility Service Section
        Text(
            text = "ALYA AUTOMATION SERVICE",
            style = MaterialTheme.typography.labelSmall,
            color = Color(0xFF00D4FF),
            fontWeight = FontWeight.Bold,
            letterSpacing = 2.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    try {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                },
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.03f))
        ) {
            Row(
                modifier = Modifier.padding(20.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Enable Accessibility Mode",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (accessibilityServiceActive) "Active" else "Inactive",
                            color = if (accessibilityServiceActive) Color.Green else Color.Yellow,
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tap to open Accessibility settings and turn on 'ALYA Automation Service' for advanced screen control, gestures, grid navigation, and magnification.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray
                    )
                }
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Go",
                    tint = Color(0xFF00D4FF)
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Features list
        Text(
            text = "FEATURES",
            style = MaterialTheme.typography.labelSmall,
            color = Color.White.copy(alpha = 0.5f),
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        Spacer(modifier = Modifier.height(16.dp))

        AutomationFeatureRow(
            title = "Advanced Navigation",
            desc = "Use voice commands on any supported screen. Execute Back, Home, and Recents actions dynamically."
        )
        AutomationFeatureRow(
            title = "Advanced Gestures",
            desc = "Use voice commands to tap, scroll, perform swipes, and execute precise screen gestures."
        )
        AutomationFeatureRow(
            title = "Advanced Grid Selection",
            desc = "Display an unobtrusive grid overlay and say the cell number to interact at that precise location."
        )
        AutomationFeatureRow(
            title = "Advanced Text Editing",
            desc = "Type, edit, and format text in any focused editable text field directly using your voice."
        )
        AutomationFeatureRow(
            title = "Advanced Magnification",
            desc = "Use voice commands to zoom in or out and pan around the screen via accessibility APIs."
        )
    }
}

@Composable
fun AutomationFeatureRow(title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .background(Color(0xFF00D4FF), CircleShape)
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }
    }
}

