import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Key, 
  Eye, 
  EyeOff, 
  ShieldCheck, 
  Check, 
  AlertCircle, 
  ExternalLink, 
  RefreshCw, 
  Trash2, 
  Cpu, 
  Sparkles,
  Zap,
  Info,
  Volume2,
  Clock
} from 'lucide-react';
import { geminiClient, GEMINI_API_KEY_STORAGE_KEY } from '../lib/geminiClient';
import { secureStorage, ApiKeyVerificationResult, Provider } from '../lib/secureStorage';
import { userSettingsService } from '../lib/userSettingsService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onKeySaved?: () => void;
}

// Gemini model presets for user selection
const GEMINI_MODELS = [
  { 
    id: 'gemini-3.8-flash', 
    name: 'Gemini 3.8 Flash', 
    desc: 'Ultra-fast multimodal conversational intelligence & live tools (Recommended)',
    badge: 'Recommended'
  },
  { 
    id: 'gemini-3.1-flash-lite', 
    name: 'Gemini 3.1 Flash Lite', 
    desc: 'Lightweight high-throughput model with near-instant latency',
    badge: 'Ultra Fast'
  },
  { 
    id: 'gemini-3.1-pro-preview', 
    name: 'Gemini 3.1 Pro Preview', 
    desc: 'Maximum depth, complex coding, and structured data analysis',
    badge: 'High Reasoning'
  }
];

export function SettingsModal({ isOpen, onClose, onKeySaved }: SettingsModalProps) {
  const [apiKey, setApiKey] = useState('');
  const [provider, setProvider] = useState<Provider>('gemini');
  const [showKey, setShowKey] = useState(false);
  const [selectedModel, setSelectedModel] = useState('gemini-3.8-flash');
  const [selectedVoice, setSelectedVoice] = useState<string>('Aoede');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<ApiKeyVerificationResult | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [hasStoredKey, setHasStoredKey] = useState(false);
  const [keyStoreStatus, setKeyStoreStatus] = useState<any>(null);
  const [isTestingServerKey, setIsTestingServerKey] = useState(false);
  const [serverTestResult, setServerTestResult] = useState<any>(null);

  // Sync state on modal open
  useEffect(() => {
    if (!isOpen) return;

    // Load backend 6-hour key rotation status
    fetch('/api/alya/keys/status')
      .then(r => r.json())
      .then(d => {
        if (d && d.success) {
          setKeyStoreStatus(d);
        }
      })
      .catch(() => {});

    const loadSettings = async () => {
      const savedProvider = (localStorage.getItem('alya_api_provider') || 'gemini') as Provider;
      setProvider(savedProvider);
      
      const activeKey = await secureStorage.getSecureApiKey(savedProvider);
      if (activeKey) {
        setApiKey(activeKey);
        setHasStoredKey(true);
      } else {
        setApiKey('');
        setHasStoredKey(false);
      }
    };
    loadSettings();

    const savedModel = localStorage.getItem('alya_preferred_gemini_model');
    if (savedModel) {
      setSelectedModel(savedModel);
    }

    const savedVoice = (localStorage.getItem('alya_voice_name') || userSettingsService.getPreferences().voiceName) as any;
    if (['Aoede', 'Kore', 'Ursa'].includes(savedVoice)) {
      setSelectedVoice(savedVoice);
    } else {
      setSelectedVoice('Aoede');
    }

    setVerificationResult(null);
    setErrorMessage(null);
    setSaveSuccess(false);

    // ESC to close
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Handle Provider Switch
  const handleProviderChange = async (newProvider: Provider) => {
    setProvider(newProvider);
    localStorage.setItem('alya_api_provider', newProvider);
    const key = await secureStorage.getSecureApiKey(newProvider);
    setApiKey(key);
    setHasStoredKey(!!key);
    setVerificationResult(null);
    setErrorMessage(null);
  };

  // Test and verify user's Gemini API key with live endpoint probe
  const handleTestKey = async () => {
    const keyToTest = apiKey.trim();
    if (!keyToTest) {
      setErrorMessage('Please enter an API key to test.');
      return;
    }

    setErrorMessage(null);
    setIsVerifying(true);
    setVerificationResult(null);

    try {
      const result = await secureStorage.verifyApiKeyQuota(keyToTest);
      setVerificationResult(result);
      if (!result.valid) {
        setErrorMessage(result.message);
      }
    } catch (err: any) {
      setVerificationResult({
        valid: false,
        message: err.message || 'Verification failed. Could not reach Gemini servers.'
      });
      setErrorMessage(err.message || 'Verification failed.');
    } finally {
      setIsVerifying(false);
    }
  };

  // Test currently scheduled backend Gemini API Key slot
  const handleTestServerSlot = async (slotNumber?: number) => {
    setIsTestingServerKey(true);
    setServerTestResult(null);
    try {
      const res = await fetch('/api/alya/keys/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ slotNumber })
      });
      const data = await res.json();
      setServerTestResult(data);
    } catch (e: any) {
      setServerTestResult({ success: false, error: e.message || 'Server test failed' });
    } finally {
      setIsTestingServerKey(false);
    }
  };

  // Save to localStorage & secure storage and re-instantiate Google Generative AI client
  const handleSaveKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);
    let cleanKey = apiKey.trim();
    if ((cleanKey.startsWith('"') && cleanKey.endsWith('"')) || (cleanKey.startsWith("'") && cleanKey.endsWith("'"))) {
      cleanKey = cleanKey.slice(1, -1).trim();
    }

    const validation = secureStorage.validateApiKeyFormat(provider, cleanKey);
    if (!validation.valid) {
      setErrorMessage(validation.reason || 'Invalid API key format.');
      return;
    }

    setIsSaving(true);
    try {
      await secureStorage.saveSecureApiKey(provider, cleanKey);
      
      if (provider === 'gemini') {
        localStorage.setItem('alya_preferred_gemini_model', selectedModel);
      }

      setHasStoredKey(Boolean(cleanKey));
      setSaveSuccess(true);
      onKeySaved?.();
      setTimeout(() => {
        setSaveSuccess(false);
        onClose();
      }, 1500);
    } catch (err: any) {
      setErrorMessage(err.message || `Failed to save ${provider} API key.`);
    } finally {
      setIsSaving(false);
    }
  };

  // Clear stored key
  const handleClearKey = async () => {
    if (!confirm(`Are you sure you want to remove your stored ${provider} API key?`)) {
      return;
    }

    await secureStorage.clearSecureApiKey(provider);
    setApiKey('');
    setHasStoredKey(false);
    setVerificationResult(null);
    setErrorMessage(null);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        {/* Backdrop */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm"
        />

        {/* Modal Dialog */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 15 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 15 }}
          transition={{ duration: 0.2 }}
          className="relative w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl shadow-2xl overflow-hidden z-10 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="p-5 md:p-6 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50/50 dark:bg-slate-900/50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-600/10 dark:bg-indigo-500/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center shadow-xs">
                <Key className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-base text-slate-900 dark:text-white">
                  Gemini API Key & Model Settings
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Manage your personal Google AI Studio quota & models
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Close settings"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Body */}
          <form onSubmit={handleSaveKey} className="p-5 md:p-6 space-y-5 overflow-y-auto flex-1">
            {/* API Provider Selection */}
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Active API Provider</label>
              <div className="flex gap-2">
                {(['gemini', 'openai'] as Provider[]).map((p) => (
                  <button
                    key={p}
                    type="button"
                    onClick={() => handleProviderChange(p)}
                    className={`flex-1 py-2 rounded-xl text-xs font-bold capitalize transition-all ${
                      provider === p
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                    }`}
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>

            {/* API Key Input Section */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                  <span>{provider === 'gemini' ? 'Google Gemini' : 'OpenAI'} API Key</span>
                  {hasStoredKey && (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400">
                      Active
                    </span>
                  )}
                </label>
                <a
                  href={provider === 'gemini' ? "https://aistudio.google.com/app/apikey" : "https://platform.openai.com/api-keys"}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1 font-semibold"
                >
                  <span>Get Free Key</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              <div className="relative">
                <input
                  type={showKey ? 'text' : 'password'}
                  value={apiKey}
                  onChange={(e) => {
                    setApiKey(e.target.value);
                    setErrorMessage(null);
                    setVerificationResult(null);
                  }}
                  placeholder={provider === 'gemini' ? "AIzaSy..." : "sk-..."}
                  className="w-full pl-3.5 pr-20 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="p-1.5 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition rounded-lg"
                    title={showKey ? 'Hide key' : 'Show key'}
                  >
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                  {apiKey && (
                    <button
                      type="button"
                      onClick={() => setApiKey('')}
                      className="p-1.5 text-slate-400 hover:text-red-500 transition rounded-lg"
                      title="Clear input"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>

              <p className="text-[11px] text-slate-500 dark:text-slate-400 leading-relaxed flex items-center gap-1">
                <Info className="w-3 h-3 text-slate-400 shrink-0" />
                <span>Keys are encrypted & stored in your browser's localStorage.</span>
              </p>
            </div>

            {/* Test Connection / Verify Button */}
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleTestKey}
                disabled={isVerifying || !apiKey.trim()}
                className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isVerifying ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-500" />
                    <span>Verifying Key...</span>
                  </>
                ) : (
                  <>
                    <Zap className="w-3.5 h-3.5 text-amber-500" />
                    <span>Verify Connection</span>
                  </>
                )}
              </button>

              {hasStoredKey && (
                <button
                  type="button"
                  onClick={handleClearKey}
                  className="px-3 py-2 rounded-xl text-xs font-semibold text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 transition flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Key</span>
                </button>
              )}
            </div>

            {/* Verification Result Banner */}
            {verificationResult && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className={`p-3 rounded-xl border text-xs flex items-start gap-2.5 ${
                  verificationResult.valid
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800 text-emerald-800 dark:text-emerald-200'
                    : 'bg-red-50 dark:bg-red-950/40 border-red-200 dark:border-red-800 text-red-800 dark:text-red-200'
                }`}
              >
                {verificationResult.valid ? (
                  <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-red-600 dark:text-red-400 shrink-0 mt-0.5" />
                )}
                <div>
                  <p className="font-bold">
                    {verificationResult.valid ? 'API Key Validated & Quota Active' : 'Key Verification Failed'}
                  </p>
                  <p className="text-[11px] opacity-90 mt-0.5">{verificationResult.message}</p>
                </div>
              </motion.div>
            )}

            {/* 6-Hour Scheduled Key Rotation Diagnostics (Gemini) */}
            {provider === 'gemini' && keyStoreStatus && (
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-indigo-500" />
                    <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                      Backend 6-Hour Key Rotation Schedule
                    </span>
                  </div>
                  <span className="flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-700 dark:bg-emerald-950/80 dark:text-emerald-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                    Auto-Rotating 24/7
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px]">
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60">
                    <span className="text-slate-400 block text-[10px]">Active Shift:</span>
                    <span className="font-semibold text-slate-700 dark:text-slate-300">
                      Slot {keyStoreStatus.activeSlot?.slotNumber}: {keyStoreStatus.activeSlot?.label}
                    </span>
                    <span className="text-[10px] text-slate-500 block">{keyStoreStatus.activeSlot?.timeRange}</span>
                  </div>
                  <div className="p-2 rounded-lg bg-white dark:bg-slate-950 border border-slate-100 dark:border-slate-800/60">
                    <span className="text-slate-400 block text-[10px]">Active Key:</span>
                    <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">
                      {keyStoreStatus.activeSlot?.maskedKey}
                    </span>
                    <span className="text-[10px] text-slate-500 block">Next switch in ~{keyStoreStatus.timeUntilNextRotationMinutes}m</span>
                  </div>
                </div>

                {/* 4 Shift Slots Schedule List */}
                <div className="space-y-1 pt-1">
                  <div className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Configured Key Store Slots</div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                    {(keyStoreStatus.slots || []).map((slot: any) => (
                      <div 
                        key={slot.slotNumber}
                        className={`px-2.5 py-1.5 rounded-lg border text-[11px] flex items-center justify-between ${
                          slot.isActiveNow 
                            ? 'bg-indigo-50/70 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800 font-medium text-indigo-900 dark:text-indigo-200'
                            : 'bg-white dark:bg-slate-950 border-slate-100 dark:border-slate-800/60 text-slate-600 dark:text-slate-400'
                        }`}
                      >
                        <div>
                          <div className="flex items-center gap-1">
                            <span>KEY {slot.slotNumber}:</span>
                            <span className="font-mono text-[10px]">{slot.maskedKey}</span>
                          </div>
                          <div className="text-[9px] text-slate-400">{slot.timeRange}</div>
                        </div>
                        {slot.isActiveNow && (
                          <span className="text-[9px] px-1.5 py-0.5 rounded font-bold bg-indigo-600 text-white">
                            LIVE
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                </div>

                {/* Server Key Test Button */}
                <div className="flex items-center justify-between pt-1">
                  <button
                    type="button"
                    onClick={() => handleTestServerSlot()}
                    disabled={isTestingServerKey}
                    className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:hover:bg-indigo-900/50 text-indigo-600 dark:text-indigo-300 transition flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
                  >
                    {isTestingServerKey ? (
                      <>
                        <RefreshCw className="w-3 h-3 animate-spin text-indigo-500" />
                        <span>Testing Active Key...</span>
                      </>
                    ) : (
                      <>
                        <Zap className="w-3 h-3 text-indigo-500" />
                        <span>Test Scheduled Slot Key</span>
                      </>
                    )}
                  </button>

                  {serverTestResult && (
                    <span className={`text-[11px] font-semibold ${serverTestResult.success ? 'text-emerald-600 dark:text-emerald-400' : 'text-red-600 dark:text-red-400'}`}>
                      {serverTestResult.success 
                        ? `Slot ${serverTestResult.slotNumber} Verified (${serverTestResult.latencyMs}ms)`
                        : `Test failed: ${serverTestResult.error || 'Invalid'}`}
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* Error Message */}
            {errorMessage && !verificationResult && (
              <div className="p-3 rounded-xl bg-red-50 dark:bg-red-950/40 border border-red-200 dark:border-red-800 text-red-700 dark:text-red-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-red-500" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Model Selection Grid */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-indigo-500" />
                <span>Preferred Gemini Model</span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {/* 
                  Unique key assigned using `model-${model.id}` to guarantee no key collisions 
                  across re-renders or model selection updates.
                */}
                {GEMINI_MODELS.map((model, index) => {
                  const isSelected = selectedModel === model.id;
                  return (
                    <button
                      key={`model-${model.id || index}-${index}`}
                      type="button"
                      onClick={() => setSelectedModel(model.id)}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-50/80 dark:bg-indigo-950/50 border-indigo-500/80 text-slate-900 dark:text-white shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold">{model.name}</span>
                        <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded ${
                          isSelected 
                            ? 'bg-indigo-600 text-white' 
                            : 'bg-slate-200 dark:bg-slate-800 text-slate-500'
                        }`}>
                          {model.badge}
                        </span>
                      </div>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-tight">
                        {model.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Voice Selection Section */}
            <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-indigo-500" />
                  <span>Alya Live & TTS Voice</span>
                </span>
                <span className="text-[10px] text-indigo-600 dark:text-indigo-400 font-bold uppercase tracking-wider">
                  Default: Aoede
                </span>
              </label>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                {[
                  {
                    id: 'Aoede',
                    name: 'Aoede',
                    tag: 'Standard (Default)',
                    desc: 'Expressive, natural tone with lively cadence'
                  },
                  {
                    id: 'Kore',
                    name: 'Kore',
                    tag: 'Warm Female',
                    desc: 'Soft, gentle, conversational rhythm'
                  },
                  {
                    id: 'Ursa',
                    name: 'Ursa',
                    tag: 'Confident',
                    desc: 'Crisp, resonant, clear vocal delivery'
                  }
                ].map((voice) => {
                  const isSelected = selectedVoice === voice.id;
                  return (
                    <button
                      key={`modal-voice-${voice.id}`}
                      type="button"
                      onClick={() => {
                        setSelectedVoice(voice.id as any);
                        localStorage.setItem('alya_voice_name', voice.id);
                        userSettingsService.updatePreferences({ voiceName: voice.id });
                        window.dispatchEvent(new CustomEvent('alya:voice-changed', { detail: { voiceName: voice.id } }));
                      }}
                      className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-indigo-50/80 dark:bg-indigo-950/50 border-indigo-500/80 text-slate-900 dark:text-white shadow-xs'
                          : 'bg-slate-50 dark:bg-slate-950 border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:border-slate-300 dark:hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs font-bold">{voice.name}</span>
                        {isSelected ? (
                          <Check className="w-3.5 h-3.5 text-indigo-500" />
                        ) : (
                          <span className="text-[9px] text-slate-400 font-medium">{voice.tag}</span>
                        )}
                      </div>
                      <p className="text-[10px] text-slate-500 dark:text-slate-400 line-clamp-2 leading-tight">
                        {voice.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Success Notification */}
            {saveSuccess && (
              <motion.div
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2"
              >
                <Check className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>Gemini API key saved to localStorage and client re-instantiated!</span>
              </motion.div>
            )}

            {/* Actions */}
            <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2.5">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              >
                Cancel
              </button>

              <button
                type="submit"
                disabled={isSaving}
                className="px-5 py-2.5 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white shadow-md shadow-indigo-600/20 transition flex items-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
              >
                {isSaving ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving Key...</span>
                  </>
                ) : (
                  <>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Save Key & Apply</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
