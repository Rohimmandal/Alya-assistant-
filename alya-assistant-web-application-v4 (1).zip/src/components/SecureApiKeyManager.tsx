import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Key, Shield, ShieldCheck, Eye, EyeOff, Check, X, RefreshCw, 
  ExternalLink, Lock, AlertTriangle, Sparkles, Cpu, Zap, Trash2,
  CheckCircle2, Info
} from 'lucide-react';
import { secureStorage, ApiKeyVerificationResult } from '../lib/secureStorage';
import { geminiClient } from '../lib/geminiClient';
import { apiKeyManager } from '../lib/ApiKeyManager';

interface SecureApiKeyManagerProps {
  onKeySaved?: () => void;
  compact?: boolean;
}

export function SecureApiKeyManager({ onKeySaved, compact = false }: SecureApiKeyManagerProps) {
  const [apiKey, setApiKey] = useState('');
  const [hasStoredKey, setHasStoredKey] = useState(false);
  const [maskedPreview, setMaskedPreview] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Verification states
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<ApiKeyVerificationResult | null>(null);
  
  // Save states
  const [isSaving, setIsSaving] = useState(false);
  const [saveStep, setSaveStep] = useState<'idle' | 'verifying' | 'encrypting'>('idle');
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Load existing key from secure encrypted storage on mount
  useEffect(() => {
    loadStoredKey();

    const handleKeyUpdate = () => loadStoredKey();
    window.addEventListener('alya:api-key-updated', handleKeyUpdate);
    return () => window.removeEventListener('alya:api-key-updated', handleKeyUpdate);
  }, []);

  const loadStoredKey = async () => {
    try {
      const stored = await secureStorage.getSecureApiKey();
      if (stored) {
        setApiKey(stored);
        setHasStoredKey(true);
        setMaskedPreview(secureStorage.maskApiKey(stored));
      } else {
        setApiKey('');
        setHasStoredKey(false);
        setMaskedPreview('');
      }
    } catch (e) {
      console.warn('[SecureApiKeyManager] Failed to load stored key:', e);
    }
  };

  const handleTestAndVerify = async () => {
    let keyToTest = apiKey.trim();
    if (!keyToTest && hasStoredKey) {
      // If box is empty but a key is stored, test the active stored key
      keyToTest = await secureStorage.getSecureApiKey();
    }

    if (!keyToTest) {
      setErrorMessage('Please enter an API key to test.');
      return;
    }

    setErrorMessage(null);
    setIsVerifying(true);
    setVerificationResult(null);

    try {
      const result = await secureStorage.verifyApiKeyQuota(keyToTest);
      setVerificationResult(result);
    } catch (err: any) {
      setVerificationResult({
        valid: false,
        message: err.message || 'Verification failed. Could not reach Gemini servers.'
      });
    } finally {
      setIsVerifying(false);
    }
  };

  const handleRevealStoredKey = async () => {
    try {
      const stored = await secureStorage.getSecureApiKey();
      if (stored) {
        setApiKey(stored);
        setShowPassword(true);
      }
    } catch (e) {
      console.warn('Failed to reveal stored key:', e);
    }
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    let keyToSave = apiKey.trim();
    if ((keyToSave.startsWith('"') && keyToSave.endsWith('"')) || (keyToSave.startsWith("'") && keyToSave.endsWith("'"))) {
      keyToSave = keyToSave.slice(1, -1).trim();
    }

    if (!keyToSave) {
      setIsSaving(true);
      try {
        await secureStorage.clearSecureApiKey();
        await geminiClient.setApiKey('');
        setHasStoredKey(false);
        setMaskedPreview('');
        setVerificationResult(null);
        setSaveSuccess(true);
        setTimeout(() => setSaveSuccess(false), 3000);
        onKeySaved?.();
      } finally {
        setIsSaving(false);
      }
      return;
    }

    setIsSaving(true);
    setErrorMessage(null);
    setSaveStep('encrypting');

    try {
      // 1. Encrypt with AES-GCM 256-bit & persist to localStorage and encrypted storage
      await apiKeyManager.setApiKey(keyToSave);
      // Re-instantiate Google Generative AI client dynamically
      // (The client manager is notified via the custom event dispatched by ApiKeyManager)
      await geminiClient.getClient();

      setHasStoredKey(true);
      setMaskedPreview(secureStorage.maskApiKey(keyToSave));
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3500);
      onKeySaved?.();

      // Run asynchronous quota probe in background to update verification badge
      secureStorage.verifyApiKeyQuota(keyToSave).then((result: any) => {
        setVerificationResult(result);
      }).catch(() => {});
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to encrypt and save key.');
    } finally {
      setIsSaving(false);
      setSaveStep('idle');
    }
  };

  const handleClear = async () => {
    if (!confirm('Are you sure you want to remove your stored Gemini API key? Alya will fall back to default server credentials.')) {
      return;
    }

    await secureStorage.clearSecureApiKey();
    await geminiClient.setApiKey('');
    setApiKey('');
    setHasStoredKey(false);
    setMaskedPreview('');
    setVerificationResult(null);
    setErrorMessage(null);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
    onKeySaved?.();
  };

  const formatValidation = apiKey ? secureStorage.validateApiKeyFormat(apiKey) : null;

  return (
    <div className={`rounded-3xl border border-white/5 transition-all ${
      compact ? 'p-4 bg-slate-900/90' : 'p-6 bg-slate-900/80 shadow-xl'
    }`}>
      {/* Header with Security Shield */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/5 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 shadow-inner">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white tracking-wide">
                Gemini API Key & Personal Quota
              </h3>
              <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <Lock className="w-2.5 h-2.5" /> AES-GCM 256
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Encrypted locally on device with WebCrypto. Authenticates all live voice & brain conversations.
            </p>
          </div>
        </div>

        {/* Quota Attribution Badge */}
        <div className="flex items-center gap-2 self-start sm:self-auto">
          {hasStoredKey ? (
            <span className="px-2.5 py-1 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              Dedicated Project Quota Active
            </span>
          ) : (
            <span className="px-2.5 py-1 rounded-xl bg-slate-800/80 border border-slate-700/50 text-slate-400 text-[11px] font-medium flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              Shared Server Fallback Quota
            </span>
          )}
        </div>
      </div>

      {/* Main Form Body */}
      <form onSubmit={handleSave} className="mt-5 space-y-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <span>Google Gemini API Key</span>
              {hasStoredKey && (
                <span className="text-[10px] text-indigo-400 font-mono font-normal">
                  ({maskedPreview})
                </span>
              )}
            </label>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-indigo-400 hover:text-indigo-300 font-medium flex items-center gap-1 transition"
            >
              <span>Get API Key from Google AI Studio</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>

          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setVerificationResult(null);
                setErrorMessage(null);
              }}
              placeholder={hasStoredKey ? "•••••••••••• (Encrypted key active — paste new key to update)" : "Enter your Gemini API key (AIzaSy...)"}
              autoComplete="off"
              spellCheck="false"
              className="w-full pl-3.5 pr-28 py-2.5 bg-slate-950/80 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 font-mono tracking-wide focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500/30 transition"
            />

            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              {apiKey ? (
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="p-1.5 text-slate-400 hover:text-slate-200 transition rounded-lg hover:bg-slate-800"
                  title={showPassword ? 'Hide Key' : 'Reveal Key'}
                >
                  {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                </button>
              ) : (hasStoredKey && (
                <button
                  type="button"
                  onClick={handleRevealStoredKey}
                  className="px-2 py-1 text-[10px] text-indigo-400 hover:text-indigo-300 font-medium bg-indigo-950/40 border border-indigo-500/30 rounded-lg hover:bg-indigo-900/50 transition flex items-center gap-1"
                  title="Reveal or edit the saved API key"
                >
                  <Eye className="w-3 h-3" />
                  <span>Reveal</span>
                </button>
              ))}
            </div>
          </div>

          {/* Validation Pill */}
          {apiKey && formatValidation && (
            <div className="mt-1.5 flex items-center gap-1.5 text-[11px]">
              {formatValidation.valid ? (
                <span className="text-emerald-400 flex items-center gap-1">
                  <Check className="w-3 h-3" /> Standard Google Gemini Key format
                </span>
              ) : (
                <span className="text-amber-400/90 flex items-center gap-1">
                  <Info className="w-3 h-3" /> {formatValidation.reason}
                </span>
              )}
            </div>
          )}
        </div>

        {/* Verification Result Feedback Box */}
        <AnimatePresence>
          {verificationResult && (
            <motion.div
              key="api-verify-result"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className={`p-3.5 rounded-2xl border text-xs flex items-start gap-2.5 ${
                verificationResult.valid
                  ? 'bg-emerald-950/40 border-emerald-500/30 text-emerald-200'
                  : 'bg-rose-950/40 border-rose-500/30 text-rose-200'
              }`}
            >
              {verificationResult.valid ? (
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              ) : (
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              )}
              <div className="flex-1">
                <div className="font-semibold flex items-center justify-between">
                  <span>{verificationResult.valid ? 'Verification Successful' : 'Verification Issue'}</span>
                  {verificationResult.latencyMs && (
                    <span className="text-[10px] font-mono text-slate-400">
                      {verificationResult.latencyMs}ms latency
                    </span>
                  )}
                </div>
                <p className="text-[11px] mt-0.5 opacity-90">{verificationResult.message}</p>
              </div>
            </motion.div>
          )}

          {errorMessage && (
            <motion.div
              key="api-save-error"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="p-3 rounded-xl bg-rose-950/40 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2"
            >
              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
              <span>{errorMessage}</span>
            </motion.div>
          )}

          {saveSuccess && (
            <motion.div
              key="api-save-success"
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="p-3 rounded-xl bg-emerald-950/40 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2 font-medium"
            >
              <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
              <span>Key successfully encrypted with AES-GCM 256-bit and saved. Live voice sessions are now bound to your quota.</span>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleTestAndVerify}
              disabled={isVerifying || !apiKey.trim()}
              className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-2 transition"
            >
              {isVerifying ? (
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-indigo-400" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              )}
              <span>{isVerifying ? 'Verifying with Gemini...' : 'Verify Key & Quota'}</span>
            </button>

            {hasStoredKey && (
              <button
                type="button"
                onClick={handleClear}
                className="px-3 py-2 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 text-xs font-medium flex items-center gap-1.5 transition"
                title="Remove saved key"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Remove Key</span>
              </button>
            )}
          </div>

          <button
            type="submit"
            disabled={isSaving || !apiKey.trim()}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white text-xs font-bold flex items-center gap-2 shadow-md shadow-indigo-600/20 transition"
          >
            {isSaving ? (
              <RefreshCw className="w-3.5 h-3.5 animate-spin" />
            ) : (
              <Lock className="w-3.5 h-3.5" />
            )}
            <span>
              {isSaving 
                ? (saveStep === 'verifying' ? 'Testing Connection...' : 'Encrypting & Storing...') 
                : 'Test Connection & Save Key'}
            </span>
          </button>
        </div>

        {/* Security Disclaimers and Live Quota Guarantees */}
        <div className="pt-3 border-t border-white/5 text-[11px] text-slate-400 space-y-1.5">
          <div className="flex items-center gap-1.5 text-slate-300 font-medium">
            <Shield className="w-3 h-3 text-indigo-400" />
            <span>Encrypted Quota Isolation Architecture:</span>
          </div>
          <p className="leading-relaxed">
            • <strong>No Plaintext Exposure:</strong> Keys are scrambled on your machine using standard WebCrypto AES-GCM with a device-unique salt before touching storage.
          </p>
          <p className="leading-relaxed">
            • <strong>Dedicated Rate Limits:</strong> All Gemini Live audio sessions (24kHz PCM) and cognitive tool executions run strictly against your individual Google Cloud / AI Studio project quota.
          </p>
        </div>
      </form>
    </div>
  );
}
