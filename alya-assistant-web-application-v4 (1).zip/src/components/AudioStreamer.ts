/**
 * Alya Assistant AudioStreamer
 * 
 * Strict Audio Alignment & Buffer Management:
 * - 16kHz Little-Endian Int16 Microphone Input via phase-accurate AudioWorklet
 * - 24kHz PCM Little-Endian Mono Audio Output with gapless Jitter Buffer
 * - Automatic residual noise flush & empty frame trimming at turn-end
 * - Instant Barge-In / Interruption Node Termination with 4ms pop-free micro-fadeout
 * - Explicit AudioContext Lifecycle & Interruption Auto-Recovery
 */

import { registerResamplerWorklet } from './AudioWorkletProcessor';
import { webSocketDiagnosticsService } from '../services/WebSocketDiagnosticsService';

export interface AudioLifecycleLogEntry {
  timestamp: number;
  fromState: string;
  toState: string;
  reason?: string;
}

export interface AudioDiagnosticMetrics {
  contextState: AudioContextState | 'uninitialized';
  streamingBufferStatus: 'healthy' | 'buffering' | 'stalled' | 'idle';
  activeSourcesCount?: number;
  sampleRate?: number;
  errorMessage?: string;
  lifecycleHistory?: AudioLifecycleLogEntry[];
}

export class AudioStreamer {
  private audioCtx: AudioContext | null = null;
  private nextStartTime: number = 0;
  private activeSources: AudioBufferSourceNode[] = [];
  private volumeGain: GainNode | null = null;
  private muteGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;
  private analyser: AnalyserNode | null = null;
  
  private inputMediaStream: MediaStream | null = null;
  private workletNode: AudioWorkletNode | null = null;
  private isCapturingMic: boolean = false;

  // Turn tracking and boundary management
  private isTurnActive: boolean = false;
  private lastScheduledEndTime: number = 0;
  private turnEndTimer: any = null;

  // Lifecycle State Tracking & Transition History
  private lastKnownState: AudioContextState | 'uninitialized' = 'uninitialized';
  private lifecycleLogs: AudioLifecycleLogEntry[] = [];
  private autoRecoveryHandlerAttached: boolean = false;

  constructor(
    private onInputChunk?: (base64Audio: string) => void,
    private onDiagnosticsUpdate?: (metrics: AudioDiagnosticMetrics) => void
  ) {
    this.setupWindowInterruptionListeners();
  }

  /**
   * Returns current AudioContext state or 'uninitialized'
   */
  public getContextState(): AudioContextState | 'uninitialized' {
    return this.audioCtx ? this.audioCtx.state : 'uninitialized';
  }

  /**
   * Returns historical array of state transition logs
   */
  public getLifecycleLogs(): AudioLifecycleLogEntry[] {
    return [...this.lifecycleLogs];
  }

  /**
   * Records a state transition and logs to console
   */
  private logStateTransition(toState: AudioContextState | 'uninitialized', reason?: string): void {
    const fromState = this.lastKnownState;
    if (fromState === toState && !reason) return;

    this.lastKnownState = toState;
    const entry: AudioLifecycleLogEntry = {
      timestamp: Date.now(),
      fromState,
      toState,
      reason: reason || 'State change event'
    };

    this.lifecycleLogs.push(entry);
    if (this.lifecycleLogs.length > 50) {
      this.lifecycleLogs.shift();
    }

    console.log(
      `[AudioStreamer] Lifecycle Transition: ${fromState} ➔ ${toState}${reason ? ` (${reason})` : ''}`
    );
  }

  /**
   * Initializes a single, unified AudioContext at 24000 Hz.
   * Configures dual-stage noise suppression (100Hz Butterworth High-Pass + Soft-Knee Compressor).
   */
  public async initAudioContext(): Promise<AudioContext> {
    try {
      if (!this.audioCtx || this.audioCtx.state === 'closed') {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        try {
          // Standardize output rate to strict 24kHz
          this.audioCtx = new AudioCtxClass({ sampleRate: 24000 });
        } catch {
          this.audioCtx = new AudioCtxClass();
        }

        this.logStateTransition(this.audioCtx.state, 'AudioContext created');

        this.audioCtx.onstatechange = () => {
          if (this.audioCtx) {
            const newState = this.audioCtx.state;
            this.logStateTransition(newState, 'Hardware or browser event');

            if (newState === 'suspended' && (this.activeSources.length > 0 || this.isCapturingMic)) {
              console.warn('[AudioStreamer] AudioContext unexpectedly suspended! Attempting auto-recovery...');
              this.attemptAutoRecovery();
            }
          }
          this.emitDiagnostics();
        };

        // Master Volume Gain Node
        this.volumeGain = this.audioCtx.createGain();
        this.volumeGain.gain.setValueAtTime(0.90, this.audioCtx.currentTime);

        // Sub-millisecond Mute Gain Node for pop-free barge-in cutoffs
        this.muteGain = this.audioCtx.createGain();
        this.muteGain.gain.setValueAtTime(1.0, this.audioCtx.currentTime);

        // Fast visualizer Analyser Node
        this.analyser = this.audioCtx.createAnalyser();
        this.analyser.fftSize = 64;
        this.analyser.smoothingTimeConstant = 0.75;

        // 100Hz Butterworth High-Pass Filter (DC blocker + sub-bass room rumble removal)
        this.filterNode = this.audioCtx.createBiquadFilter();
        this.filterNode.type = 'highpass';
        this.filterNode.frequency.setValueAtTime(100, this.audioCtx.currentTime);
        this.filterNode.Q.setValueAtTime(0.707, this.audioCtx.currentTime);

        // Soft-Knee Dynamics Compressor / Peak Limiter
        this.compressor = this.audioCtx.createDynamicsCompressor();
        this.compressor.threshold.setValueAtTime(-14, this.audioCtx.currentTime);
        this.compressor.knee.setValueAtTime(10, this.audioCtx.currentTime);
        this.compressor.ratio.setValueAtTime(4, this.audioCtx.currentTime);
        this.compressor.attack.setValueAtTime(0.002, this.audioCtx.currentTime);
        this.compressor.release.setValueAtTime(0.08, this.audioCtx.currentTime);

        // Signal Chain: MuteGain -> VolumeGain -> Analyser -> HighPassFilter -> Compressor -> Destination
        this.muteGain.connect(this.volumeGain);
        this.volumeGain.connect(this.analyser);
        this.analyser.connect(this.filterNode);
        this.filterNode.connect(this.compressor);
        this.compressor.connect(this.audioCtx.destination);
      }

      if (this.audioCtx.state === 'suspended') {
        await this.resumeContext('initAudioContext invocation');
      }

      this.emitDiagnostics();
      return this.audioCtx;
    } catch (err: any) {
      console.error('[AudioStreamer] Error initializing AudioContext:', err);
      this.logStateTransition('closed', `Init error: ${err?.message}`);
      this.emitDiagnostics(err?.message || 'Failed to initialize AudioContext');
      throw err;
    }
  }

  /**
   * Resumes the AudioContext safely
   */
  public async resumeContext(reason: string = 'User action / stream request'): Promise<void> {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      await this.initAudioContext();
      return;
    }

    if (this.audioCtx.state === 'suspended' || (this.audioCtx.state as string) === 'interrupted') {
      try {
        await this.audioCtx.resume();
        this.logStateTransition(this.audioCtx.state, `Resumed successfully (${reason})`);
      } catch (err: any) {
        console.warn(`[AudioStreamer] AudioContext resume failed (${reason}):`, err);
        this.logStateTransition(this.audioCtx.state, `Resume failed: ${err?.message || 'Gesture required'}`);
        this.emitDiagnostics(`Resume failed: ${err?.message || 'User gesture required'}`);
        throw err;
      }
    } else {
      this.emitDiagnostics();
    }
  }

  /**
   * Suspends the AudioContext
   */
  public async suspendContext(reason: string = 'Explicit suspend call'): Promise<void> {
    if (this.audioCtx && this.audioCtx.state === 'running') {
      try {
        await this.audioCtx.suspend();
        this.logStateTransition(this.audioCtx.state, reason);
      } catch (err: any) {
        console.warn('[AudioStreamer] AudioContext suspend failed:', err);
        this.emitDiagnostics(`Suspend failed: ${err?.message}`);
      }
    }
    this.emitDiagnostics();
  }

  /**
   * Explicit public method to attempt recovery when browser audio state is interrupted
   */
  public async recoverContext(): Promise<boolean> {
    console.log('[AudioStreamer] Manual context recovery triggered.');
    try {
      if (!this.audioCtx || this.audioCtx.state === 'closed') {
        await this.initAudioContext();
      } else if (this.audioCtx.state === 'suspended' || (this.audioCtx.state as string) === 'interrupted') {
        await this.resumeContext('Manual recovery');
      }
      return this.audioCtx?.state === 'running';
    } catch (err) {
      console.error('[AudioStreamer] Context recovery attempt failed:', err);
      return false;
    }
  }

  /**
   * Sets up window interaction listeners to resume context on user gesture
   */
  private setupWindowInterruptionListeners(): void {
    if (typeof window === 'undefined' || this.autoRecoveryHandlerAttached) return;

    const handleUserGesture = async () => {
      if (this.audioCtx && (this.audioCtx.state === 'suspended' || (this.audioCtx.state as string) === 'interrupted')) {
        console.log('[AudioStreamer] User gesture detected. Attempting AudioContext auto-recovery...');
        try {
          await this.audioCtx.resume();
          this.logStateTransition(this.audioCtx.state, 'Auto-recovered via user gesture');
          this.emitDiagnostics();
        } catch (e) {}
      }
    };

    window.addEventListener('pointerdown', handleUserGesture, { passive: true });
    window.addEventListener('keydown', handleUserGesture, { passive: true });
    window.addEventListener('touchstart', handleUserGesture, { passive: true });
    
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && this.audioCtx && this.audioCtx.state === 'suspended') {
        if (this.activeSources.length > 0 || this.isCapturingMic) {
          console.log('[AudioStreamer] Tab became visible. Recovering suspended AudioContext...');
          this.recoverContext().catch(() => {});
        }
      }
    });

    this.autoRecoveryHandlerAttached = true;
  }

  private attemptAutoRecovery(): void {
    setTimeout(() => {
      this.recoverContext().catch(() => {});
    }, 300);
  }

  /**
   * Instantly terminates all playback nodes, ramps down gain in 4ms, and clears queued frames.
   * Fixes overlapping audio by clearing the playback node immediately upon barge-in/interruption.
   */
  public flushBuffer(): void {
    const ctx = this.audioCtx;
    if (ctx && this.muteGain && ctx.state === 'running') {
      const now = ctx.currentTime;
      try {
        // Fast 4ms micro-fadeout to eliminate DC step click/pop
        this.muteGain.gain.cancelScheduledValues(now);
        this.muteGain.gain.setValueAtTime(this.muteGain.gain.value, now);
        this.muteGain.gain.linearRampToValueAtTime(0.0001, now + 0.004);
      } catch {}
    }

    if (this.turnEndTimer) {
      clearTimeout(this.turnEndTimer);
      this.turnEndTimer = null;
    }

    // Immediately stop and disconnect all scheduled audio nodes
    for (const source of this.activeSources) {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
      } catch (e) {}
    }

    this.activeSources = [];
    this.nextStartTime = 0;
    this.isTurnActive = false;
    this.lastScheduledEndTime = 0;

    // Reset mute gain for upcoming speech turns
    setTimeout(() => {
      if (this.muteGain && ctx) {
        try {
          this.muteGain.gain.cancelScheduledValues(ctx.currentTime);
          this.muteGain.gain.setValueAtTime(1.0, ctx.currentTime);
        } catch {}
      }
      this.emitDiagnostics();
    }, 8);
  }

  /**
   * Alias for flushBuffer to ensure compatibility with stopPlayback calls.
   */
  public stopPlayback(): void {
    this.flushBuffer();
  }

  /**
   * Flushes residual noise and resets jitter buffer state at turn-end
   */
  public flushResidual(): void {
    if (this.activeSources.length === 0) {
      this.nextStartTime = 0;
      this.isTurnActive = false;
      this.lastScheduledEndTime = 0;
    }
  }

  // --- Strict 24kHz Output Handling ---
  public async playOutputChunk(base64Audio: string): Promise<void> {
    if (!base64Audio) return;

    try {
      await this.initAudioContext();
      const ctx = this.audioCtx!;

      if (ctx.state === 'suspended') {
        await this.resumeContext('playOutputChunk auto-resume');
      }

      // Decode base64 to binary bytes
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      if (len < 4) return;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Strip optional 44-byte RIFF/WAVE header
      let offset = 0;
      if (
        len >= 44 &&
        bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 // 'RIFF'
      ) {
        offset = 44;
      }

      const pcmBytes = len - offset;
      if (pcmBytes <= 1) return;

      const sampleCount = Math.floor(pcmBytes / 2);
      if (sampleCount === 0) return;

      const float32 = new Float32Array(sampleCount);
      const dataView = new DataView(bytes.buffer, bytes.byteOffset + offset, sampleCount * 2);
      let sumSquare = 0;
      for (let i = 0; i < sampleCount; i++) {
        const sample = dataView.getInt16(i * 2, true) / 32768.0;
        const clamped = Math.max(-1.0, Math.min(1.0, sample));
        float32[i] = clamped;
        sumSquare += clamped * clamped;
      }

      // Noise Gate: Drop empty frames or residual quantization hiss (< 0.00025 RMS)
      const rms = Math.sqrt(sumSquare / sampleCount);
      if (rms < 0.00025) {
        return;
      }

      const inputSampleRate = 24000;
      const targetSampleRate = ctx.sampleRate || 24000;

      let resampledData: Float32Array;
      if (targetSampleRate === inputSampleRate) {
        resampledData = float32;
      } else {
        const ratio = inputSampleRate / targetSampleRate;
        const targetLen = Math.round(sampleCount / ratio);
        resampledData = new Float32Array(targetLen);

        for (let i = 0; i < targetLen; i++) {
          const srcIdx = i * ratio;
          const idx0 = Math.floor(srcIdx);
          const idx1 = Math.min(sampleCount - 1, idx0 + 1);
          const frac = srcIdx - idx0;
          resampledData[i] = float32[idx0] * (1 - frac) + float32[idx1] * frac;
        }
      }

      const currentTime = ctx.currentTime;
      const isNewTurn = !this.isTurnActive || (currentTime - this.lastScheduledEndTime) > 0.12;

      // Anti-Click Micro Fade-In (4ms) if starting a new speech turn
      if (isNewTurn) {
        this.isTurnActive = true;
        const fadeSamples = Math.floor(targetSampleRate * 0.004);
        const actualFade = Math.min(fadeSamples, Math.floor(resampledData.length / 2));
        for (let i = 0; i < actualFade; i++) {
          resampledData[i] *= (i / actualFade);
        }
      }

      const audioBuffer = ctx.createBuffer(1, resampledData.length, targetSampleRate);
      audioBuffer.getChannelData(0).set(resampledData);

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(this.muteGain || this.volumeGain!);

      // Jitter buffer scheduling with 60ms lookahead
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime + 0.06;
      } else if (this.nextStartTime > currentTime + 0.40) {
        this.nextStartTime = currentTime + 0.08;
      }

      webSocketDiagnosticsService.trackAudioChunkArrival();

      source.start(this.nextStartTime);
      this.activeSources.push(source);
      this.nextStartTime += audioBuffer.duration;
      this.lastScheduledEndTime = this.nextStartTime;

      // Schedule turn-end buffer cleanup
      if (this.turnEndTimer) clearTimeout(this.turnEndTimer);
      this.turnEndTimer = setTimeout(() => {
        this.flushResidual();
      }, Math.max(150, Math.round(audioBuffer.duration * 1000) + 100));

      source.onended = () => {
        this.activeSources = this.activeSources.filter((s) => s !== source);
        if (this.activeSources.length === 0) {
          this.flushResidual();
        }
        this.emitDiagnostics();
      };

      this.emitDiagnostics();
    } catch (err: any) {
      console.error('[AudioStreamer] Error playing audio output chunk:', err);
      this.emitDiagnostics(err?.message || 'Error playing audio chunk');
    }
  }

  // --- Strict 16kHz Input Handling ---
  public async startMicrophoneCapture(): Promise<void> {
    try {
      this.stopMicrophoneCapture();

      this.inputMediaStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      });
      
      await this.initAudioContext();
      const ctx = this.audioCtx!;

      await registerResamplerWorklet(ctx);
      
      const source = ctx.createMediaStreamSource(this.inputMediaStream);
      this.workletNode = new AudioWorkletNode(ctx, 'pcm-resampler-processor');
      
      this.workletNode.port.onmessage = (e) => {
        if (!e.data || !e.data.pcm16 || !this.onInputChunk) return;
        try {
          const pcm16 = new Int16Array(e.data.pcm16);
          const bytes = new Uint8Array(pcm16.buffer);
          let binary = '';
          const chunkSize = 8192;
          for (let i = 0; i < bytes.length; i += chunkSize) {
            const sub = bytes.subarray(i, i + chunkSize);
            binary += String.fromCharCode.apply(null, sub as unknown as number[]);
          }
          this.onInputChunk(btoa(binary));
        } catch (msgErr) {
          console.warn('[AudioStreamer] Error processing worklet message:', msgErr);
        }
      };

      source.connect(this.workletNode);
      const silentGain = ctx.createGain();
      silentGain.gain.setValueAtTime(0, ctx.currentTime);
      this.workletNode.connect(silentGain);
      silentGain.connect(ctx.destination);
      this.isCapturingMic = true;

      this.emitDiagnostics();
    } catch (err: any) {
      console.error('[AudioStreamer] Microphone capture failed:', err);
      this.emitDiagnostics(err?.message || 'Microphone capture failed');
      throw err;
    }
  }

  public stopMicrophoneCapture(): void {
    if (this.workletNode) {
      try {
        this.workletNode.disconnect();
      } catch {}
      this.workletNode = null;
    }

    if (this.inputMediaStream) {
      try {
        this.inputMediaStream.getTracks().forEach((track) => {
          track.enabled = false;
          track.stop();
        });
      } catch {}
      this.inputMediaStream = null;
    }
    this.isCapturingMic = false;
    this.emitDiagnostics();
  }

  public setVolume(volume: number): void {
    if (this.volumeGain && this.audioCtx) {
      const clamped = Math.max(0, Math.min(1, volume));
      this.volumeGain.gain.setValueAtTime(clamped, this.audioCtx.currentTime);
    }
  }

  public stop(): void {
    this.flushBuffer();
    this.stopMicrophoneCapture();
    
    if (this.audioCtx && this.audioCtx.state !== 'closed') {
      try {
        this.audioCtx.close().then(() => {
          this.logStateTransition('closed', 'Engine stop / close()');
          this.emitDiagnostics();
        }).catch(() => {});
      } catch {}
      this.audioCtx = null;
    } else {
      this.logStateTransition('closed', 'Engine stop');
    }
    this.emitDiagnostics();
  }

  private emitDiagnostics(errorMessage?: string): void {
    if (!this.onDiagnosticsUpdate) return;
    const contextState = this.audioCtx ? this.audioCtx.state : 'uninitialized';
    let streamingBufferStatus: 'healthy' | 'buffering' | 'stalled' | 'idle' = 'idle';

    if (this.activeSources.length > 0) {
      streamingBufferStatus = 'healthy';
    } else if (this.isCapturingMic) {
      streamingBufferStatus = 'healthy';
    }

    this.onDiagnosticsUpdate({
      contextState,
      streamingBufferStatus,
      activeSourcesCount: this.activeSources.length,
      sampleRate: this.audioCtx?.sampleRate || 24000,
      lifecycleHistory: this.getLifecycleLogs(),
      ...(errorMessage ? { errorMessage } : {})
    });
  }
}
