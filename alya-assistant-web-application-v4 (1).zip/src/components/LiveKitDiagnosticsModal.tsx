import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  X, 
  RefreshCw, 
  Trash2, 
  Download, 
  Copy, 
  Check, 
  AlertTriangle, 
  CheckCircle2, 
  Radio, 
  Clock, 
  Zap, 
  Layers, 
  ShieldCheck,
  RotateCcw
} from 'lucide-react';
import { 
  liveKitDiagnosticService, 
  DiagnosticLogEntry, 
  DiagnosticMetrics, 
  LiveKitConnectionState 
} from '../lib/LiveKitDiagnosticService';

interface LiveKitDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onForceReconnect?: () => void;
}

export const LiveKitDiagnosticsModal: React.FC<LiveKitDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  onForceReconnect
}) => {
  const [logs, setLogs] = useState<DiagnosticLogEntry[]>([]);
  const [metrics, setMetrics] = useState<DiagnosticMetrics>(liveKitDiagnosticService.getMetrics());
  const [filterLevel, setFilterLevel] = useState<string>('all');
  const [copied, setCopied] = useState<boolean>(false);
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const logContainerRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!isOpen) return;

    const unsubscribe = liveKitDiagnosticService.subscribe((updatedLogs, updatedMetrics) => {
      setLogs(updatedLogs);
      setMetrics(updatedMetrics);
    });

    return () => unsubscribe();
  }, [isOpen]);

  useEffect(() => {
    if (autoScroll && logContainerRef.current) {
      logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
    }
  }, [logs, autoScroll]);

  if (!isOpen) return null;

  const filteredLogs = logs.filter((log) => {
    if (filterLevel === 'all') return true;
    if (filterLevel === 'errors') return log.level === 'error' || log.level === 'warn';
    return log.level === filterLevel;
  });

  const copyReport = () => {
    const report = liveKitDiagnosticService.exportDiagnosticReport();
    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadReport = () => {
    const report = liveKitDiagnosticService.exportDiagnosticReport();
    const blob = new Blob([report], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alya-livekit-diagnostics-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStateColor = (state: LiveKitConnectionState) => {
    switch (state) {
      case 'connected': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'connecting': return 'text-amber-400 bg-amber-500/10 border-amber-500/30 animate-pulse';
      case 'reconnecting': return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30 animate-pulse';
      case 'timeout': return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      case 'failed': return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      default: return 'text-slate-400 bg-slate-800 border-slate-700';
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/80 backdrop-blur-md">
        <motion.div
          initial={{ opacity: 0, scale: 0.95, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 10 }}
          className="w-full max-w-4xl max-h-[92vh] bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl flex flex-col overflow-hidden text-slate-100"
        >
          {/* Header */}
          <div className="flex items-center justify-between p-4 sm:p-5 border-b border-slate-800 bg-slate-900/90 sticky top-0 z-10">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
                <Activity className="w-5 h-5 text-indigo-400" />
              </div>
              <div>
                <div className="flex items-center gap-2.5">
                  <h2 className="text-base sm:text-lg font-bold">LiveKit WebSocket Diagnostics</h2>
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono font-semibold border ${getStateColor(metrics.connectionState)}`}>
                    {metrics.connectionState.toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-slate-400">Real-time connection telemetry, 10s watchdog monitor & memory leak diagnostics</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {onForceReconnect && (
                <button
                  onClick={onForceReconnect}
                  className="px-3 py-1.5 rounded-xl bg-indigo-600/20 border border-indigo-500/30 hover:bg-indigo-600/30 text-indigo-300 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
                  title="Trigger explicit state reset and reconnect"
                >
                  <RotateCcw className="w-3.5 h-3.5" /> Force Reset & Reconnect
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Metrics Quick Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 p-3 sm:p-4 bg-slate-950/60 border-b border-slate-800 text-xs">
            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Watchdog Timeout</span>
              <span className="text-xs font-bold text-amber-400 mt-0.5 block">&le; 10.0s Auto-Reset</span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Roundtrip Latency</span>
              <span className="text-xs font-bold text-cyan-400 mt-0.5 block">
                {metrics.lastLatencyMs !== null ? `${metrics.lastLatencyMs} ms` : '—'}
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Connect Duration</span>
              <span className="text-xs font-bold text-slate-200 mt-0.5 block">
                {metrics.connectingDurationMs > 0 ? `${metrics.connectingDurationMs} ms` : 'Active'}
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Attempts / Timeouts</span>
              <span className="text-xs font-bold text-slate-200 mt-0.5 block">
                {metrics.totalAttempts} / <span className={metrics.timeoutCount > 0 ? 'text-rose-400' : 'text-slate-400'}>{metrics.timeoutCount}</span>
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Cleanups Freed</span>
              <span className="text-xs font-bold text-emerald-400 mt-0.5 block flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> {metrics.cleanupsPerformed}
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Active Sockets</span>
              <span className="text-xs font-bold text-slate-300 mt-0.5 block">
                {metrics.activeSocketsCount} socket(s)
              </span>
            </div>

            <div className="p-2.5 rounded-2xl bg-slate-900/60 border border-slate-800/80">
              <span className="text-[10px] text-slate-400 font-mono block">Audio Frames</span>
              <span className="text-xs font-bold text-indigo-400 mt-0.5 block">
                &uarr;{metrics.audioPacketsSent} &darr;{metrics.audioPacketsReceived}
              </span>
            </div>
          </div>

          {/* Controls Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 bg-slate-900 border-b border-slate-800 text-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto">
              <span className="text-[11px] text-slate-400 mr-1 font-medium">Filter:</span>
              {['all', 'errors', 'lifecycle', 'timeout', 'cleanup', 'heartbeat'].map((lvl) => (
                <button
                  key={lvl}
                  onClick={() => setFilterLevel(lvl)}
                  className={`px-2.5 py-1 rounded-lg font-medium transition-all ${
                    filterLevel === lvl
                      ? 'bg-indigo-600 text-white shadow-sm'
                      : 'bg-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-700'
                  }`}
                >
                  {lvl.charAt(0).toUpperCase() + lvl.slice(1)}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2">
              <label className="flex items-center gap-1.5 text-slate-400 hover:text-slate-200 cursor-pointer select-none">
                <input
                  type="checkbox"
                  checked={autoScroll}
                  onChange={(e) => setAutoScroll(e.target.checked)}
                  className="rounded border-slate-700 bg-slate-800 text-indigo-500 focus:ring-0"
                />
                <span className="text-[11px]">Auto-scroll</span>
              </label>

              <button
                onClick={copyReport}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-all active:scale-95"
                title="Copy Full Diagnostic JSON"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>

              <button
                onClick={downloadReport}
                className="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center gap-1 transition-all active:scale-95"
                title="Download JSON Report"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export</span>
              </button>

              <button
                onClick={() => liveKitDiagnosticService.clearLogs()}
                className="px-2.5 py-1 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 flex items-center gap-1 transition-all active:scale-95"
                title="Clear Log Buffer"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Clear</span>
              </button>
            </div>
          </div>

          {/* Log Stream Area */}
          <div
            ref={logContainerRef}
            className="flex-1 p-4 overflow-y-auto space-y-1.5 font-mono text-xs bg-slate-950/80 min-h-[280px] max-h-[420px]"
          >
            {filteredLogs.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-48 text-slate-500 font-sans">
                <CheckCircle2 className="w-8 h-8 mb-2 opacity-40 text-slate-400" />
                <p className="text-sm">No diagnostic events recorded for current filter.</p>
              </div>
            ) : (
              filteredLogs.map((entry) => {
                const isError = entry.level === 'error';
                const isWarn = entry.level === 'warn';
                const isTimeout = entry.category === 'timeout';
                const isCleanup = entry.category === 'cleanup' || entry.level === 'cleanup';
                const isState = entry.level === 'state_change';

                return (
                  <div
                    key={entry.id}
                    className={`p-2 rounded-xl border flex flex-col sm:flex-row sm:items-start gap-1.5 sm:gap-2.5 transition-colors ${
                      isError
                        ? 'bg-rose-950/30 border-rose-800/40 text-rose-300'
                        : isTimeout
                        ? 'bg-amber-950/30 border-amber-800/40 text-amber-300'
                        : isWarn
                        ? 'bg-amber-950/20 border-amber-800/30 text-amber-200'
                        : isCleanup
                        ? 'bg-emerald-950/20 border-emerald-800/30 text-emerald-300'
                        : isState
                        ? 'bg-indigo-950/20 border-indigo-800/30 text-indigo-300'
                        : 'bg-slate-900/60 border-slate-800/60 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 shrink-0 text-[10px] text-slate-400">
                      <span>{entry.isoTime.substring(11, 23)}</span>
                      <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                        isError ? 'bg-rose-500/20 text-rose-300' :
                        isTimeout ? 'bg-amber-500/20 text-amber-300' :
                        isCleanup ? 'bg-emerald-500/20 text-emerald-300' :
                        isState ? 'bg-indigo-500/20 text-indigo-300' :
                        'bg-slate-800 text-slate-400'
                      }`}>
                        {entry.category}
                      </span>
                    </div>

                    <div className="flex-1 break-words">
                      <span className="font-semibold">{entry.message}</span>
                      {entry.data && (
                        <pre className="text-[10px] text-slate-400 mt-1 overflow-x-auto bg-slate-950/60 p-1.5 rounded-lg border border-slate-800/60">
                          {JSON.stringify(entry.data, null, 2)}
                        </pre>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Footer note */}
          <div className="p-3 bg-slate-900 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <span>Watchdog Active: Automatically handles WebSocket state recovery and eliminates stale resource leaks.</span>
            </div>
            <span>{logs.length} logs in buffer</span>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
