import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Zap, AlertCircle, Database, Gauge, RefreshCcw } from 'lucide-react';
import { audioPipelineDiagnostics, AudioDiagnosticMetrics } from '../lib/AudioPipelineDiagnostics';

export const AudioPipelineHUD: React.FC = () => {
  const [metrics, setMetrics] = useState<AudioDiagnosticMetrics>(audioPipelineDiagnostics.getMetrics());
  const [isVisible, setIsVisible] = useState(false);
  const [lastFlushAnim, setLastFlushAnim] = useState(false);

  useEffect(() => {
    const unsubscribe = audioPipelineDiagnostics.subscribe((newMetrics) => {
      if (newMetrics.flushCount > metrics.flushCount) {
        setLastFlushAnim(true);
        setTimeout(() => setLastFlushAnim(false), 1000);
      }
      setMetrics(newMetrics);
    });

    return unsubscribe;
  }, [metrics.flushCount]);

  // Toggle HUD visibility with Shift+D
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.shiftKey && e.key === 'D') {
        setIsVisible(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!isVisible) return null;

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.9, x: 20 }}
      animate={{ opacity: 1, scale: 1, x: 0 }}
      className="fixed top-20 right-4 z-[9999] w-64 bg-slate-900/80 backdrop-blur-md border border-indigo-500/30 rounded-2xl p-4 shadow-2xl pointer-events-none select-none font-mono text-[10px]"
    >
      <div className="flex items-center justify-between mb-3 border-b border-white/10 pb-2">
        <div className="flex items-center gap-2 text-indigo-400">
          <Activity className="w-3.5 h-3.5" />
          <span className="font-bold tracking-tight uppercase">Audio Pipeline HUD</span>
        </div>
        <div className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${metrics.contextState === 'running' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'}`}>
          {metrics.contextState}
        </div>
      </div>

      <div className="space-y-2.5">
        <MetricRow 
          icon={<Gauge className="w-3 h-3" />}
          label="Latency"
          value={`${metrics.latencyMs}ms`}
          color={metrics.latencyMs > 150 ? 'text-amber-400' : 'text-slate-200'}
        />
        
        <MetricRow 
          icon={<Database className="w-3 h-3" />}
          label="Buffer"
          value={`${metrics.bufferSize} chunks`}
          color={metrics.bufferSize > 8 ? 'text-amber-400' : 'text-slate-200'}
        />

        <MetricRow 
          icon={<Zap className="w-3 h-3" />}
          label="Processed"
          value={metrics.totalChunks.toLocaleString()}
          color="text-slate-200"
        />

        <MetricRow 
          icon={<AlertCircle className="w-3 h-3" />}
          label="Drops"
          value={metrics.frameDrops}
          color={metrics.frameDrops > 0 ? 'text-red-400' : 'text-slate-400'}
        />

        <div className={`mt-3 p-2 rounded-xl transition-all duration-300 border ${lastFlushAnim ? 'bg-red-500/30 border-red-500/50 scale-105' : 'bg-white/5 border-white/5'}`}>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-400 uppercase font-bold text-[8px]">
              <RefreshCcw className={`w-2.5 h-2.5 ${lastFlushAnim ? 'animate-spin' : ''}`} />
              <span>Hard Resets</span>
            </div>
            <span className={`font-bold ${metrics.flushCount > 0 ? 'text-red-400' : 'text-slate-500'}`}>
              {metrics.flushCount}
            </span>
          </div>
          {metrics.lastFlushTime > 0 && (
            <div className="text-[8px] text-slate-500 mt-1 text-right italic">
              Last: {new Date(metrics.lastFlushTime).toLocaleTimeString()}
            </div>
          )}
        </div>
      </div>

      <div className="mt-4 pt-2 border-t border-white/5 text-[8px] text-slate-600 text-center uppercase tracking-widest">
        Press Shift+D to toggle
      </div>
    </motion.div>
  );
};

const MetricRow: React.FC<{ icon: React.ReactNode, label: string, value: string | number, color: string }> = ({ icon, label, value, color }) => (
  <div className="flex items-center justify-between group">
    <div className="flex items-center gap-2 text-slate-400 uppercase text-[9px]">
      {icon}
      <span>{label}</span>
    </div>
    <span className={`font-bold tabular-nums ${color}`}>{value}</span>
  </div>
);
