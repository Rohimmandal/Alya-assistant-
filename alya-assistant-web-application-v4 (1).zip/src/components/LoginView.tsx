import React, { useState, useEffect } from 'react';
import { useAuth } from '../lib/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { Bot, LogIn, Key, Eye, EyeOff, Check, Sparkles, ExternalLink, ShieldCheck, AlertCircle } from 'lucide-react';
import { geminiClient, GEMINI_API_KEY_STORAGE_KEY } from '../lib/geminiClient';
import { secureStorage } from '../lib/secureStorage';

export function LoginView() {
  const { login } = useAuth();
  const [apiKey, setApiKey] = useState('');
  const [showKey, setShowKey] = useState(false);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [keyError, setKeyError] = useState<string | null>(null);

  // Load existing key from localStorage / secure storage on mount
  useEffect(() => {
    const existing = geminiClient.getApiKey();
    if (existing) {
      setApiKey(existing);
    }
  }, []);

  // Save key to localStorage and re-instantiate Google Generative AI client
  const handleSaveApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setKeyError(null);

    const cleanKey = apiKey.trim();
    if (cleanKey && !cleanKey.startsWith('AIza') && !cleanKey.startsWith('AQ.')) {
      setKeyError('Google Gemini API keys typically start with "AIza" or "AQ.". Please check your key.');
      return;
    }

    try {
      // Re-instantiates @google/genai client dynamically with the new key
      await geminiClient.setApiKey(cleanKey);
      setSavedSuccess(true);
      setTimeout(() => setSavedSuccess(false), 3000);
    } catch (err: any) {
      setKeyError(err.message || 'Failed to save API key.');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950 p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-md bg-white dark:bg-slate-900 rounded-3xl p-8 shadow-xl shadow-slate-200/50 dark:shadow-none border border-slate-100 dark:border-slate-800 text-center"
      >
        <div className="flex items-center justify-center w-16 h-16 bg-slate-900 dark:bg-white rounded-2xl mx-auto mb-6">
          <Bot className="w-8 h-8 text-white dark:text-slate-900" />
        </div>
        
        <h1 className="text-2xl font-bold mb-2 tracking-tight">Alya Assistant</h1>
        <p className="text-slate-500 dark:text-slate-400 mb-6 text-sm">
          Your production-ready personal assistant, everywhere.
        </p>

        {/* Continue with Google Authentication */}
        <button
          onClick={login}
          className="flex items-center justify-center w-full gap-3 px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-white dark:text-slate-900 dark:hover:bg-slate-100 rounded-2xl font-semibold transition-all shadow-lg shadow-slate-900/10 active:scale-[0.98] text-sm"
        >
          <LogIn className="w-4 h-4" />
          Continue with Google
        </button>

        {/* Divider */}
        <div className="relative my-6">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-slate-200 dark:border-slate-800" />
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white dark:bg-slate-900 px-3 text-slate-400 font-semibold">
              Or Use Personal Gemini Key
            </span>
          </div>
        </div>

        {/* Gemini API Key Input Form */}
        <form onSubmit={handleSaveApiKey} className="space-y-3 text-left">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-indigo-500" />
              <span>Gemini API Key</span>
            </label>
            <a
              href="https://aistudio.google.com/app/apikey"
              target="_blank"
              rel="noopener noreferrer"
              className="text-[11px] text-indigo-500 hover:underline flex items-center gap-0.5"
            >
              <span>Get API Key</span>
              <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </div>

          <div className="relative">
            <input
              type={showKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => {
                setApiKey(e.target.value);
                setKeyError(null);
              }}
              placeholder="AIzaSy..."
              className="w-full pl-3.5 pr-20 py-2.5 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-mono text-slate-900 dark:text-white placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
            />
            <div className="absolute right-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
              <button
                type="button"
                onClick={() => setShowKey(!showKey)}
                className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition"
                title={showKey ? 'Hide key' : 'Show key'}
              >
                {showKey ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>

          {keyError && (
            <div className="text-[11px] text-red-500 dark:text-red-400 flex items-center gap-1 mt-1">
              <AlertCircle className="w-3 h-3 shrink-0" />
              <span>{keyError}</span>
            </div>
          )}

          {savedSuccess && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-[11px] text-emerald-600 dark:text-emerald-400 flex items-center gap-1 mt-1 font-semibold"
            >
              <Check className="w-3 h-3 shrink-0" />
              <span>Gemini API Key saved and client instantiated!</span>
            </motion.div>
          )}

          <button
            type="submit"
            className="w-full py-2.5 px-4 bg-indigo-50 hover:bg-indigo-100 text-indigo-600 dark:bg-indigo-950/60 dark:hover:bg-indigo-900/60 dark:text-indigo-300 rounded-xl font-semibold text-xs transition-all flex items-center justify-center gap-1.5"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Save Key to LocalStorage</span>
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-slate-100 dark:border-slate-800">
          <p className="text-xs text-slate-400">
            By continuing, you agree to our Terms of Service and Privacy Policy.
          </p>
        </div>
      </motion.div>
    </div>
  );
}

