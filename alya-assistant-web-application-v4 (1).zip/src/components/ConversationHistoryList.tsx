import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  History, 
  Search, 
  PhoneCall, 
  MessageSquare, 
  Terminal, 
  Zap, 
  Trash2, 
  Download, 
  Clock, 
  Gauge, 
  Sparkles, 
  CheckCircle2, 
  AlertTriangle, 
  X,
  ChevronRight,
  Filter,
  RefreshCw
} from 'lucide-react';
import { 
  conversationHistoryManager, 
  ConversationLogEntry, 
  ConversationHistoryStats 
} from '../lib/ConversationHistoryManager';

export function ConversationHistoryList() {
  const [logs, setLogs] = useState<ConversationLogEntry[]>([]);
  const [stats, setStats] = useState<ConversationHistoryStats>({
    totalInteractions: 0,
    voiceCallsCount: 0,
    commandsExecuted: 0,
    chatMessagesCount: 0
  });
  const [activeFilter, setActiveFilter] = useState<'all' | 'voice' | 'websocket_command' | 'chat' | 'automation'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEntry, setSelectedEntry] = useState<ConversationLogEntry | null>(null);
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  useEffect(() => {
    const unsub = conversationHistoryManager.subscribe((items) => {
      setLogs(items);
      setStats(conversationHistoryManager.getStats());
    });

    return () => unsub();
  }, []);

  const filteredLogs = logs.filter((item) => {
    if (activeFilter !== 'all' && item.mode !== activeFilter) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase().trim();
    return (
      item.title.toLowerCase().includes(q) ||
      (item.userQuery && item.userQuery.toLowerCase().includes(q)) ||
      (item.assistantResponse && item.assistantResponse.toLowerCase().includes(q)) ||
      (item.intent && item.intent.toLowerCase().includes(q)) ||
      (item.language && item.language.toLowerCase().includes(q))
    );
  });

  const handleDelete = async (e: React.MouseEvent, id: string) => {
    e.stopPropagation();
    await conversationHistoryManager.deleteInteraction(id);
  };

  const handleClearAll = async () => {
    await conversationHistoryManager.clearHistory();
    setShowClearConfirm(false);
  };

  const handleExport = () => {
    const jsonStr = conversationHistoryManager.exportHistoryAsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alya-conversation-history-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getModeIcon = (mode: string) => {
    switch (mode) {
      case 'voice':
        return <PhoneCall className="w-4 h-4 text-emerald-400" />;
      case 'websocket_command':
        return <Terminal className="w-4 h-4 text-cyan-400" />;
      case 'chat':
        return <MessageSquare className="w-4 h-4 text-purple-400" />;
      case 'automation':
        return <Zap className="w-4 h-4 text-amber-400" />;
      default:
        return <History className="w-4 h-4 text-slate-400" />;
    }
  };

  const formatTimestamp = (ts: number) => {
    const date = new Date(ts);
    return date.toLocaleDateString([], { 
      month: 'short', 
      day: 'numeric', 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex flex-col h-full bg-slate-950 text-slate-100 overflow-hidden">
      {/* Header Bar */}
      <div className="p-4 sm:p-6 border-b border-slate-800/80 bg-slate-900/50 backdrop-blur-sm">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-purple-500/10 border border-purple-500/20 text-purple-400">
                <History className="w-5 h-5" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white tracking-tight">Interaction History</h1>
                <p className="text-xs text-slate-400">Local persistent logs for voice sessions, commands & chat transcripts</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={handleExport}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-xs font-medium text-slate-200 border border-slate-700/60 transition-all"
              title="Export history as JSON"
            >
              <Download className="w-3.5 h-3.5 text-purple-400" />
              Export
            </button>
            <button
              onClick={() => setShowClearConfirm(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-xs font-medium text-rose-300 border border-rose-500/30 transition-all"
              title="Clear all local history"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear
            </button>
          </div>
        </div>

        {/* Stats Strip */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">{stats.totalInteractions}</div>
              <div className="text-[11px] text-slate-400">Total Logs</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
              <PhoneCall className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">{stats.voiceCallsCount}</div>
              <div className="text-[11px] text-slate-400">Voice Calls</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-cyan-500/10 text-cyan-400">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">{stats.commandsExecuted}</div>
              <div className="text-[11px] text-slate-400">Commands</div>
            </div>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-purple-500/10 text-purple-400">
              <MessageSquare className="w-4 h-4" />
            </div>
            <div>
              <div className="text-lg font-bold text-white">{stats.chatMessagesCount}</div>
              <div className="text-[11px] text-slate-400">Chat Sessions</div>
            </div>
          </div>
        </div>

        {/* Filter Tabs & Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mt-4 pt-3 border-t border-slate-800/60">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: 'All' },
              { id: 'voice', label: 'Voice Calls' },
              { id: 'websocket_command', label: 'Commands' },
              { id: 'chat', label: 'Chat' },
              { id: 'automation', label: 'Automation' }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveFilter(tab.id as any)}
                className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition-all ${
                  activeFilter === tab.id
                    ? 'bg-purple-600 text-white shadow-sm'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-800'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="relative flex-1 sm:max-w-xs">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search history, queries, intents..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 rounded-lg bg-slate-900/90 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-purple-500/60 transition-colors"
            />
          </div>
        </div>
      </div>

      {/* Log List View */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-3">
        {filteredLogs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-center">
            <div className="p-3.5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-500 mb-3">
              <History className="w-6 h-6" />
            </div>
            <div className="text-sm font-semibold text-slate-300">No interaction logs found</div>
            <p className="text-xs text-slate-500 max-w-sm mt-1">
              {searchQuery ? 'Try adjusting your search terms or filter.' : 'Your voice calls and device commands will be recorded here.'}
            </p>
          </div>
        ) : (
          filteredLogs.map((log) => (
            <motion.div
              key={log.id}
              initial={{ opacity: 0, y: 4 }}
              animate={{ opacity: 1, y: 0 }}
              onClick={() => setSelectedEntry(log)}
              className="group p-4 rounded-xl bg-slate-900/60 hover:bg-slate-900 border border-slate-800/80 hover:border-purple-500/30 transition-all cursor-pointer relative"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3 min-w-0">
                  <div className="p-2 rounded-lg bg-slate-800 border border-slate-700/60 shrink-0 mt-0.5">
                    {getModeIcon(log.mode)}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-sm text-slate-100 truncate">{log.title}</span>
                      {log.intent && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/20">
                          {log.intent}
                        </span>
                      )}
                      {log.language && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] bg-slate-800 text-slate-400 border border-slate-700">
                          {log.language}
                        </span>
                      )}
                    </div>

                    {log.userQuery && (
                      <div className="text-xs text-slate-300 mt-1.5 line-clamp-2">
                        <span className="text-purple-400 font-medium">User: </span>
                        {log.userQuery}
                      </div>
                    )}

                    {log.assistantResponse && (
                      <div className="text-xs text-slate-400 mt-1 line-clamp-2">
                        <span className="text-emerald-400 font-medium">Alya: </span>
                        {log.assistantResponse}
                      </div>
                    )}

                    <div className="flex items-center gap-3 mt-2.5 text-[11px] text-slate-500">
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {formatTimestamp(log.timestamp)}
                      </span>
                      {log.durationSeconds !== undefined && log.durationSeconds > 0 && (
                        <span>Duration: {log.durationSeconds}s</span>
                      )}
                      {log.latencyMs !== undefined && (
                        <span className="flex items-center gap-1 text-slate-400">
                          <Gauge className="w-3 h-3 text-cyan-400" />
                          {log.latencyMs}ms
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        {log.status === 'success' ? (
                          <span className="text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="w-3 h-3" /> Verified
                          </span>
                        ) : (
                          <span className="text-rose-400 flex items-center gap-1">
                            <AlertTriangle className="w-3 h-3" /> {log.status}
                          </span>
                        )}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={(e) => handleDelete(e, log.id)}
                    className="opacity-0 group-hover:opacity-100 p-1.5 rounded-lg hover:bg-rose-500/10 text-slate-400 hover:text-rose-400 transition-all"
                    title="Delete log"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <ChevronRight className="w-4 h-4 text-slate-600 group-hover:text-purple-400 transition-colors" />
                </div>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Detail Modal */}
      <AnimatePresence>
        {selectedEntry && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-lg bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-6 overflow-hidden"
            >
              <div className="flex items-start justify-between gap-4 pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-xl bg-slate-800 border border-slate-700">
                    {getModeIcon(selectedEntry.mode)}
                  </div>
                  <div>
                    <h2 className="font-bold text-base text-white">{selectedEntry.title}</h2>
                    <div className="text-xs text-slate-400">{formatTimestamp(selectedEntry.timestamp)}</div>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="py-4 space-y-3 max-h-[60vh] overflow-y-auto">
                {selectedEntry.userQuery && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider mb-1">User Query</div>
                    <div className="text-sm text-slate-200">{selectedEntry.userQuery}</div>
                  </div>
                )}

                {selectedEntry.assistantResponse && (
                  <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800">
                    <div className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider mb-1">Assistant Response</div>
                    <div className="text-sm text-slate-200">{selectedEntry.assistantResponse}</div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[10px]">Intent</span>
                    <span className="font-semibold text-slate-200">{selectedEntry.intent || 'N/A'}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[10px]">Language</span>
                    <span className="font-semibold text-slate-200">{selectedEntry.language || 'Auto'}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[10px]">Latency</span>
                    <span className="font-semibold text-slate-200">{selectedEntry.latencyMs ? `${selectedEntry.latencyMs}ms` : 'N/A'}</span>
                  </div>
                  <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800/80">
                    <span className="text-slate-400 block text-[10px]">Status</span>
                    <span className="font-semibold text-emerald-400 capitalize">{selectedEntry.status}</span>
                  </div>
                </div>
              </div>

              <div className="pt-3 border-t border-slate-800 flex justify-end">
                <button
                  onClick={() => setSelectedEntry(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition-colors"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Clear Confirmation Modal */}
      <AnimatePresence>
        {showClearConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="w-full max-w-sm bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-5"
            >
              <div className="flex items-center gap-3 text-rose-400 mb-3">
                <AlertTriangle className="w-5 h-5" />
                <h3 className="font-bold text-white text-sm">Clear Conversation History?</h3>
              </div>
              <p className="text-xs text-slate-400 mb-5">
                This will delete all local interaction logs, voice transcripts, and command records from this device.
              </p>
              <div className="flex items-center justify-end gap-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-xs font-medium text-slate-300 hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 text-xs font-medium text-white hover:bg-rose-500 shadow-sm"
                >
                  Clear History
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
