/**
 * AudioWorkletProcessor for high-performance, phase-accurate 16kHz input streaming.
 * Preserves fractional phase, sample history, and DC-blocking filters across process() callbacks
 * to eliminate boundary phase jumps, mic crackling, and background room hum.
 */

export const PCM_RESAMPLER_WORKER_CODE = `
class PCMResamplerProcessor extends AudioWorkletProcessor {
  constructor() {
    super();
    this.targetSampleRate = 16000;
    this.lastSample = 0;
    this.phase = 0;
    
    // DC Blocker / High-pass filter state variables (fc ~ 100Hz)
    this.x1 = 0;
    this.y1 = 0;

    // Output buffer of 512 samples = 32ms frame at 16kHz for ultra-low latency streaming
    this.buffer = new Int16Array(512);
    this.bufferIdx = 0;
  }

  process(inputs, outputs, parameters) {
    const input = inputs[0];
    if (!input || input.length === 0) return true;

    const inputData = input[0];
    if (!inputData || inputData.length === 0) return true;

    const inputSampleRate = sampleRate; // Native AudioWorklet hardware sample rate (e.g. 48000 or 44100)
    const ratio = inputSampleRate / this.targetSampleRate;

    // High-pass DC filter pole (R ~ 0.985 at 48kHz for ~110Hz cutoff)
    const R = Math.max(0.95, 1.0 - (2.0 * Math.PI * 110.0 / inputSampleRate));

    let inIdx = this.phase;
    const len = inputData.length;

    while (inIdx < len) {
      const idx = Math.floor(inIdx);
      const frac = inIdx - idx;
      
      const s0 = idx === 0 ? this.lastSample : inputData[idx - 1];
      const s1 = inputData[idx];

      // Linear interpolation between raw input samples
      const rawSample = s0 + frac * (s1 - s0);

      // Single-pole DC blocker & high-pass filtering
      const filteredSample = rawSample - this.x1 + R * this.y1;
      this.x1 = rawSample;
      this.y1 = filteredSample;

      // Soft saturation clamp [-1.0, 1.0]
      const clamped = Math.max(-1.0, Math.min(1.0, filteredSample));

      // Int16 Little-Endian conversion
      const pcm16Val = clamped < 0 ? clamped * 0x8000 : clamped * 0x7FFF;
      this.buffer[this.bufferIdx++] = Math.floor(pcm16Val);

      if (this.bufferIdx >= this.buffer.length) {
        // Transfer 512-sample (32ms) Int16 PCM frame with zero-copy
        const pcmCopy = new Int16Array(this.buffer);
        this.port.postMessage({ pcm16: pcmCopy.buffer }, [pcmCopy.buffer]);
        this.bufferIdx = 0;
      }

      inIdx += ratio;
    }

    // Retain phase offset and trailing sample for seamless inter-block continuity
    this.phase = inIdx - len;
    this.lastSample = inputData[len - 1] || 0;

    return true;
  }
}

registerProcessor('pcm-resampler-processor', PCMResamplerProcessor);
`;

/**
 * Registers the resampler worklet processor module from a Blob URL.
 */
export async function registerResamplerWorklet(audioContext: AudioContext): Promise<string> {
  const blob = new Blob([PCM_RESAMPLER_WORKER_CODE], { type: 'application/javascript' });
  const url = URL.createObjectURL(blob);
  try {
    await audioContext.audioWorklet.addModule(url);
  } finally {
    URL.revokeObjectURL(url);
  }
  return url;
}
