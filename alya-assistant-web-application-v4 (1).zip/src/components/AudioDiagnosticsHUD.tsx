/**
 * src/components/AudioDiagnosticsHUD.tsx
 * 
 * Floating translucent HUD for real-time monitoring of the Alya Assistant audio pipeline.
 * Displays AudioContext state, latency, buffer sizes, frame drops, and interruption events.
 */

import React, { useState, useEffect } from 'react';
import { audioPipelineDiagnostics, AudioDiagnosticMetrics } from '../lib/AudioPipelineDiagnostics';
import { webSocketDiagnosticsService, WebSocketDiagnosticMetrics } from '../services/WebSocketDiagnosticsService';
import { liveSessionManager } from '../lib/LiveSessionManager';
import { Activity, Zap, RefreshCw, BarChart, AlertTriangle, ShieldCheck, Sliders } from 'lucide-react';

export const AudioDiagnosticsHUD: React.FC = () => {
  const [metrics, setMetrics] = useState<AudioDiagnosticMetrics>(audioPipelineDiagnostics.getMetrics());
  const [wsMetrics, setWsMetrics] = useState<WebSocketDiagnosticMetrics>(webSocketDiagnosticsService.getMetrics());
  const [isVisible, setIsVisible] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [hpFreq, setHpFreq] = useState(() => liveSessionManager.getHighpassFreq());

  useEffect(() => {
    // Listen for metrics updates
    const unsubscribe = audioPipelineDiagnostics.subscribe((newMetrics) => {
      setMetrics(newMetrics);
    });

    const unsubscribeWs = webSocketDiagnosticsService.subscribe((newMetrics) => {
      setWsMetrics(newMetrics);
    });

    // Check if we should be visible (e.g., dev mode or via localStorage toggle)
    const storedVisibility = localStorage.getItem('alya_audio_hud_visible');
    if (storedVisibility === 'true') {
      setIsVisible(true);
    }

    // Shortcut: Ctrl + Shift + D to toggle HUD
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey && e.shiftKey && e.key === 'D') {
        setIsVisible(prev => {
          const newState = !prev;
          localStorage.setItem('alya_audio_hud_visible', String(newState));
          return newState;
        });
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      unsubscribe();
      unsubscribeWs();
      window.removeEventListener('keydown', handleKeyDown);
    };
  }, []);

  if (!isVisible) return null;

  const getStatusColor = (state: string) => {
    switch (state) {
      case 'running': return 'text-emerald-400';
      case 'suspended': return 'text-amber-400';
      case 'closed': return 'text-rose-400';
      default: return 'text-slate-400';
    }
  };

  const getLatencyColor = (latency: number) => {
    if (latency < 100) return 'text-emerald-400';
    if (latency < 250) return 'text-amber-400';
    return 'text-rose-400';
  };

  const timeSinceFlush = metrics.lastFlushTime > 0 
    ? Math.floor((Date.now() - metrics.lastFlushTime) / 1000)
    : -1;

  const handleHpChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseInt(e.target.value, 10);
    setHpFreq(val);
    liveSessionManager.setHighpassFreq(val);
  };

  return (
    <div className={`fixed top-4 right-4 z-[9999] transition-all duration-300 ${isMinimized ? 'w-12 h-12 overflow-hidden' : 'w-72'} bg-black/60 backdrop-blur-xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden`}>
      {/* Header */}
      <div 
        className="flex items-center justify-between p-3 cursor-pointer hover:bg-white/5 transition-colors border-b border-white/5"
        onClick={() => setIsMinimized(!isMinimized)}
      >
        <div className="flex items-center gap-2">
          <Activity className={`w-4 h-4 ${metrics.contextState === 'running' ? 'text-emerald-400 animate-pulse' : 'text-slate-400'}`} />
          {!isMinimized && <span className="text-xs font-bold text-white/90 uppercase tracking-widest">Audio Pipeline</span>}
        </div>
        {!isMinimized && (
          <button 
            onClick={(e) => {
              e.stopPropagation();
              setIsVisible(false);
              localStorage.setItem('alya_audio_hud_visible', 'false');
            }}
            className="text-white/40 hover:text-white/80 transition-colors"
          >
            <RefreshCw className="w-3 h-3" />
          </button>
        )}
      </div>

      {!isMinimized && (
        <div className="p-4 space-y-4">
          {/* AudioContext State */}
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-2 text-white/50">
              <Zap className="w-3.5 h-3.5" />
              <span className="text-[10px] uppercase font-medium">Context</span>
            </div>
            <span className={`text-[11px] font-mono font-bold ${getStatusColor(metrics.contextState)}`}>
              {metrics.contextState.toUpperCase()}
            </span>
          </div>

          {/* Real-Time Audio Latency Monitor & Network Quality Signaling */}
          <div className="bg-indigo-500/10 rounded-xl p-3 border border-indigo-500/20 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-indigo-300">
                <BarChart className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Latency & Quality</span>
              </div>
              <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-full ${
                metrics.networkQuality === 'Excellent' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                metrics.networkQuality === 'Good' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' :
                metrics.networkQuality === 'Fair' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' :
                'bg-rose-500/20 text-rose-400 border border-rose-500/30'
              }`}>
                {metrics.networkQuality || 'Excellent'}
              </span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="bg-black/30 rounded-lg p-1.5 border border-white/5">
                <div className="text-[8px] text-white/40 uppercase">Jitter</div>
                <div className="text-xs font-mono font-bold text-white/90">{metrics.jitterMs ?? 2.4}ms</div>
              </div>
              <div className="bg-black/30 rounded-lg p-1.5 border border-white/5">
                <div className="text-[8px] text-white/40 uppercase">Loss</div>
                <div className={`text-xs font-mono font-bold ${(metrics.packetLossPercent ?? 0) > 2 ? 'text-rose-400' : 'text-emerald-400'}`}>
                  {metrics.packetLossPercent ?? 0}%
                </div>
              </div>
              <div className="bg-black/30 rounded-lg p-1.5 border border-white/5">
                <div className="text-[8px] text-white/40 uppercase">Buffer Delay</div>
                <div className="text-xs font-mono font-bold text-blue-400">{metrics.jitterBufferDelayMs ?? 150}ms</div>
              </div>
            </div>
          </div>

          {/* Latency & Buffer */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 rounded-lg p-2 border border-white/5">
              <div className="text-[9px] text-white/40 uppercase mb-1 flex items-center gap-1">
                <BarChart className="w-2.5 h-2.5" /> Jitter Latency
              </div>
              <div className={`text-sm font-mono font-bold ${getLatencyColor(metrics.latencyMs)}`}>
                {metrics.latencyMs}ms
              </div>
            </div>
            <div className="bg-white/5 rounded-lg p-2 border border-white/5">
              <div className="text-[9px] text-white/40 uppercase mb-1">Buffered</div>
              <div className="text-sm font-mono font-bold text-blue-400">
                {metrics.bufferSize} <span className="text-[9px] font-normal text-white/40">chunks</span>
              </div>
            </div>
          </div>

          {/* Network & E2E Latency */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-white/5 rounded-lg p-2 border border-white/5">
              <div className="text-[9px] text-white/40 uppercase mb-1">Server Latency</div>
              <div className={`text-sm font-mono font-bold ${getLatencyColor(metrics.serverLatencyMs)}`}>
                {metrics.serverLatencyMs}ms
              </div>
            </div>
            <div className="bg-white/5 rounded-lg p-2 border border-white/5">
              <div className="text-[9px] text-white/40 uppercase mb-1">Est. E2E</div>
              <div className={`text-sm font-mono font-bold ${getLatencyColor(metrics.e2eLatencyMs)}`}>
                {metrics.e2eLatencyMs}ms
              </div>
            </div>
          </div>

          {/* Interrupt & Flush Logic */}
          <div className="bg-rose-500/10 rounded-xl p-3 border border-rose-500/20 space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-rose-400">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Flush Engine</span>
              </div>
              {timeSinceFlush >= 0 && timeSinceFlush < 5 && (
                <span className="bg-rose-500 text-white text-[8px] px-1.5 py-0.5 rounded animate-bounce">JUST FLUSHED</span>
              )}
            </div>
            <div className="flex justify-between text-[10px]">
              <span className="text-white/40">Total Flushes</span>
              <span className="text-white/80 font-mono">{metrics.flushCount}</span>
            </div>
            <div className="flex justify-between text-[10px]">
              <span className="text-white/40">Last Sequence</span>
              <span className="text-white/80 font-mono">#{metrics.lastSequence}</span>
            </div>
            {timeSinceFlush >= 0 && (
              <div className="flex justify-between text-[10px]">
                <span className="text-white/40">Last Flush</span>
                <span className="text-white/80 font-mono">{timeSinceFlush}s ago</span>
              </div>
            )}
          </div>

          {/* Frame Drops & Stale Evictions */}
          <div className="grid grid-cols-2 gap-2">
            <div className={`p-2 rounded-lg ${metrics.staleEvictionsCount > 0 ? 'bg-orange-500/10 border border-orange-500/20' : 'bg-white/5 border border-white/5'}`}>
              <div className="flex items-center gap-1 text-white/50 text-[9px] uppercase font-medium">
                <AlertTriangle className={`w-3 h-3 ${metrics.staleEvictionsCount > 0 ? 'text-orange-400' : 'text-slate-500'}`} />
                <span>Stale Evicted</span>
              </div>
              <span className={`text-[11px] font-mono font-bold ${metrics.staleEvictionsCount > 0 ? 'text-orange-400' : 'text-slate-400'}`}>
                {metrics.staleEvictionsCount || 0}
              </span>
            </div>

            <div className={`p-2 rounded-lg ${metrics.frameDrops > 0 ? 'bg-amber-500/10 border border-amber-500/20' : 'bg-white/5 border border-white/5'}`}>
              <div className="flex items-center gap-1 text-white/50 text-[9px] uppercase font-medium">
                <AlertTriangle className={`w-3 h-3 ${metrics.frameDrops > 0 ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>Frame Drops</span>
              </div>
              <span className={`text-[11px] font-mono font-bold ${metrics.frameDrops > 0 ? 'text-amber-400' : 'text-slate-500'}`}>
                {metrics.frameDrops}
              </span>
            </div>
          </div>

          {/* AudioCoordinator Lock & Node Cleanliness */}
          <div className="bg-white/5 rounded-xl p-2.5 border border-white/5 space-y-1.5">
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Destination Lock:</span>
              <span className="text-emerald-400 font-mono font-semibold">{metrics.coordinatorLockOwner || 'IDLE'}</span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Dangling Nodes:</span>
              <span className={`font-mono font-semibold ${metrics.isNodesClean ? 'text-emerald-400' : 'text-amber-400'}`}>
                {metrics.isNodesClean ? 'CLEAN (0)' : `${metrics.activeAudioNodesCount} active`}
              </span>
            </div>
          </div>

          {/* WebSocket Diagnostics */}
          <div className="bg-black/40 rounded-xl p-2.5 border border-white/5 space-y-1.5">
            <div className="text-[10px] font-bold text-white/60 uppercase tracking-widest mb-1.5">Network Diagnostics</div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Latency:</span>
              <span className="text-white/80 font-mono">{wsMetrics.latencyMs ? `${wsMetrics.latencyMs}ms` : 'N/A'}</span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Heartbeat Drops:</span>
              <span className={`font-mono font-semibold ${wsMetrics.heartbeatDrops > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
                {wsMetrics.heartbeatDrops}
              </span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Audio Gaps:</span>
              <span className={`font-mono font-semibold ${wsMetrics.audioChunkDeliveryGaps > 0 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {wsMetrics.audioChunkDeliveryGaps}
              </span>
            </div>
            <div className="flex justify-between items-center text-[10px]">
              <span className="text-white/40">Connection:</span>
              <span className={`font-mono font-semibold ${wsMetrics.connectionState === 'connected' ? 'text-emerald-400' : 'text-rose-400'}`}>
                {wsMetrics.connectionState.toUpperCase()}
              </span>
            </div>
          </div>

          {/* High-Pass Filter Sensitivity Slider */}
          <div className="bg-indigo-500/10 rounded-xl p-3 border border-indigo-500/20 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-indigo-400">
                <Sliders className="w-3.5 h-3.5" />
                <span className="text-[10px] font-bold uppercase tracking-wider">Mic High-Pass</span>
              </div>
              <span className="text-[10px] font-mono font-bold text-white/80">{hpFreq}Hz</span>
            </div>
            <input 
              type="range"
              min="0"
              max="500"
              step="10"
              value={hpFreq}
              onChange={handleHpChange}
              className="w-full h-1 bg-indigo-500/20 rounded-lg appearance-none cursor-pointer accent-indigo-500"
            />
            <div className="flex justify-between text-[8px] text-white/30 font-bold uppercase">
              <span>Rumble</span>
              <span>Clean Voice</span>
              <span>Sharp</span>
            </div>
          </div>

          {/* Sample Rate & Total */}
          <div className="pt-2 flex flex-col gap-1 text-[9px] text-white/30 border-t border-white/5">
            <div className="flex justify-between">
              <span>{metrics.sampleRate}Hz Output</span>
              <span>{metrics.totalChunks} Chunks Ingested</span>
            </div>
            {metrics.lastChunkArrivalTimestamp > 0 && (
              <div className="flex justify-between">
                <span>Last Chunk Activity</span>
                <span className="text-emerald-400 font-mono">
                  {Math.floor((Date.now() - metrics.lastChunkArrivalTimestamp) / 1000)}s ago
                </span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
