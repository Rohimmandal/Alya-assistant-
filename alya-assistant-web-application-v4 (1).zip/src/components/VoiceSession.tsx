import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Mic, 
  MicOff, 
  Power, 
  Volume2, 
  VolumeX, 
  Sparkles, 
  Flame, 
  ExternalLink, 
  Radio, 
  Activity, 
  RotateCcw,
  Zap,
  X,
  PhoneOff,
  Cpu
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext';
import { AudioStreamer } from '../lib/AudioStreamer';
import { LiveSession, LiveSessionState } from '../services/liveSession';
import { AudioDiagnosticHUD } from './AudioDiagnosticHUD';
import { AudioDiagnosticMetrics } from '../utils/pcmAudioProcessor';
import { setLiveCallActive, stopAlyaVoice } from '../lib/femaleVoiceSynthesizer';
import { VADVisualizer } from './VADVisualizer';
import { ConversationStore, DialogueTurn } from '../lib/ConversationStore';
import { conversationService } from '../services/conversationService';

interface ToolActionNotification {
  id: string;
  toolName: string;
  details: string;
  url?: string;
  timestamp: number;
}

interface VoiceSessionProps {
  isOpen: boolean;
  onClose: () => void;
  voiceName?: string;
}

export function VoiceSession({ isOpen, onClose, voiceName = 'Aoede' }: VoiceSessionProps) {
  const { user } = useAuth();
  const [sessionState, setSessionState] = useState<LiveSessionState>('disconnected');
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [activeToolNotification, setActiveToolNotification] = useState<ToolActionNotification | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [audioBars, setAudioBars] = useState<number[]>(new Array(24).fill(8));
  const [statusText, setStatusText] = useState<string>("Connecting to Alya...");
  const [showDiagnosticHUD, setShowDiagnosticHUD] = useState<boolean>(false);
  const [audioMetrics, setAudioMetrics] = useState<AudioDiagnosticMetrics>({
    contextState: 'uninitialized',
    nativeSampleRate: 48000,
    targetSampleRate: 16000,
    bufferSize: 2048,
    workerActive: true,
    workerProcessingLatencyMs: 0.8,
    rmsEnergy: 0.02,
    chunksProcessed: 0,
    totalBytesStreamed: 0,
    streamingBufferStatus: 'idle',
    lastChunkTimestamp: 0
  });

  // Architecture: Separate AudioStreamer and LiveSession instances
  const audioStreamerRef = useRef<AudioStreamer | null>(null);
  const liveSessionRef = useRef<LiveSession | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const sessionStateRef = useRef(sessionState);

  useEffect(() => {
    sessionStateRef.current = sessionState;
  }, [sessionState]);

  // Initialize AudioStreamer with state syncing & enforce audio exclusivity
  useEffect(() => {
    if (!isOpen) return;

    // Immediately silence any background chat TTS to prevent audio overlap
    stopAlyaVoice();
    setLiveCallActive(true);
    window.dispatchEvent(new CustomEvent('alya:live-call-status', { detail: { inCall: true } }));

    const streamer = new AudioStreamer((isPlaying) => {
      if (isPlaying && liveSessionRef.current?.getState() !== 'speaking') {
        setSessionState('speaking');
      } else if (!isPlaying && liveSessionRef.current?.getState() === 'speaking') {
        setSessionState('listening');
      }
    });

    audioStreamerRef.current = streamer;

    return () => {
      streamer.close();
      audioStreamerRef.current = null;
      setLiveCallActive(false);
      window.dispatchEvent(new CustomEvent('alya:live-call-status', { detail: { inCall: false } }));
    };
  }, [isOpen]);

  const stopLiveSession = useCallback(() => {
    if (liveSessionRef.current) {
      liveSessionRef.current.disconnect();
      liveSessionRef.current = null;
    }
    if (audioStreamerRef.current) {
      audioStreamerRef.current.stop();
    }
    setLiveCallActive(false);
    setSessionState('disconnected');
    setErrorMessage(null);
  }, []);

  const toggleLiveSession = useCallback(async () => {
    if (sessionStateRef.current !== 'disconnected') {
      stopLiveSession();
      return;
    }

    // Silence any previous speech synthesis before connecting live call
    stopAlyaVoice();
    setLiveCallActive(true);
    setErrorMessage(null);
    try {
      if (audioStreamerRef.current) {
        await audioStreamerRef.current.initAudioContext();
      }

      const session = new LiveSession({
        onStateChange: (state) => {
          setSessionState(state);
        },
        onAudioChunk: (base64) => {
          if (isSpeakerOn && audioStreamerRef.current) {
            audioStreamerRef.current.playChunk(base64);
          }
        },
        onInterrupted: () => {
          if (audioStreamerRef.current) {
            audioStreamerRef.current.stop();
          }
        },
        onToolExecuted: (toolName, details, url) => {
          const notif: ToolActionNotification = {
            id: Math.random().toString(),
            toolName,
            details,
            url,
            timestamp: Date.now()
          };
          setActiveToolNotification(notif);
          setTimeout(() => {
            setActiveToolNotification((prev) => (prev?.id === notif.id ? null : prev));
          }, 6000);
        },
        onDiagnosticsUpdate: (metrics) => {
          setAudioMetrics(metrics);
        },
        onError: (err) => {
          setErrorMessage(err);
        },
        onTranscript: (text, role, sequence) => {
          if (!text.trim()) return;
          const msgId = ConversationStore.generateMessageId(role === 'user' ? 'msg_user' : 'msg_ast');
          const now = Date.now();
          const nowIso = new Date(now).toISOString();
          const activeConvId = localStorage.getItem('alya_active_conversation_id') || 'main';

          ConversationStore.getInstance().updateState((prev) => {
            const newSeq = prev.sequenceCounter + 1;
            const turnEntry = {
              id: msgId,
              role,
              content: text,
              mode: 'voice' as const,
              timestamp: now,
              isoTimestamp: nowIso,
              sessionId: activeConvId,
              sequence: newSeq,
              status: 'completed' as const
            };

            const lastTurn = prev.history[prev.history.length - 1];
            let updatedHistory = [...prev.history];
            let targetTurn: DialogueTurn = turnEntry;

            if (lastTurn && lastTurn.role === role && lastTurn.mode === 'voice' && (now - lastTurn.timestamp < 6000)) {
              const updatedTurn = {
                ...lastTurn,
                content: lastTurn.content.includes(text) ? lastTurn.content : `${lastTurn.content} ${text}`.trim()
              };
              updatedHistory[updatedHistory.length - 1] = updatedTurn;
              targetTurn = updatedTurn;

              // Persist chunk to Firestore in background
              if (user) {
                conversationService.addMessage(user.uid, activeConvId, {
                  role: targetTurn.role,
                  content: targetTurn.content,
                  clientTimestamp: targetTurn.timestamp,
                  isoTimestamp: targetTurn.isoTimestamp,
                  sequence: targetTurn.sequence,
                  sessionId: activeConvId,
                  userId: user.uid,
                  conversationId: activeConvId,
                  status: 'sent'
                }, targetTurn.id).catch(err => {
                  console.warn('[VoiceSession] Firestore sync failed:', err);
                });
              }

              return {
                ...prev,
                history: updatedHistory,
                lastMode: 'voice'
              };
            } else {
              updatedHistory.push(turnEntry);
              if (updatedHistory.length > 50) {
                updatedHistory = updatedHistory.slice(-50);
              }

              // Persist chunk to Firestore in background
              if (user) {
                conversationService.addMessage(user.uid, activeConvId, {
                  role: targetTurn.role,
                  content: targetTurn.content,
                  clientTimestamp: targetTurn.timestamp,
                  isoTimestamp: targetTurn.isoTimestamp,
                  sequence: targetTurn.sequence,
                  sessionId: activeConvId,
                  userId: user.uid,
                  conversationId: activeConvId,
                  status: 'sent'
                }, targetTurn.id).catch(err => {
                  console.warn('[VoiceSession] Firestore sync failed:', err);
                });
              }

              return {
                ...prev,
                sequenceCounter: newSeq,
                history: updatedHistory,
                lastMode: 'voice'
              };
            }
          });
        }
      }, user?.uid);

      liveSessionRef.current = session;
      await session.connect();

    } catch (err: any) {
      console.error('[VoiceSession] Connection failed:', err);
      setErrorMessage(err?.message || 'Could not start live session.');
      setSessionState('disconnected');
    }
  }, [isSpeakerOn, stopLiveSession, user?.uid]);

  // Auto-connect directly on open (No wake-up needed - User talks directly)
  useEffect(() => {
    if (isOpen && sessionState === 'disconnected' && !liveSessionRef.current) {
      toggleLiveSession();
    }
  }, [isOpen, toggleLiveSession, sessionState]);

  // Update animated audio visualizer spectrum
  useEffect(() => {
    if (!isOpen) return;

    const freqData = new Uint8Array(32);

    const updateVisualizer = () => {
      let levels: number[] = [];

      if (sessionState === 'speaking' && audioStreamerRef.current) {
        audioStreamerRef.current.getFrequencyData(freqData);
        for (let i = 0; i < 24; i++) {
          const val = freqData[i] || 0;
          levels.push(Math.max(12, Math.min(100, Math.round((val / 255) * 100))));
        }
      } else if (sessionState === 'listening' && liveSessionRef.current) {
        const micLevel = liveSessionRef.current.getMicLevel();
        for (let i = 0; i < 24; i++) {
          const wave = Math.sin((i / 24) * Math.PI) * micLevel * 100;
          levels.push(Math.max(10, Math.min(95, Math.round(wave + Math.random() * 8))));
        }
      } else if (sessionState === 'connecting') {
        const time = Date.now() / 200;
        for (let i = 0; i < 24; i++) {
          const wave = (Math.sin(time + i * 0.4) + 1) * 20 + 10;
          levels.push(Math.round(wave));
        }
      } else {
        levels = new Array(24).fill(10);
      }

      setAudioBars(levels);
      animFrameRef.current = requestAnimationFrame(updateVisualizer);
    };

    animFrameRef.current = requestAnimationFrame(updateVisualizer);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [sessionState, isOpen]);

  useEffect(() => {
    if (!isOpen) return;

    if (sessionState === 'listening') {
      setStatusText("Listening... Speak directly with Alya");
    } else if (sessionState === 'speaking') {
      setStatusText("Alya is speaking...");
    } else if (sessionState === 'connecting') {
      setStatusText("Connecting real-time live session...");
    } else {
      setStatusText("Live call ready. Tap orb to start.");
    }
  }, [sessionState, isOpen]);

  useEffect(() => {
    if (!isOpen) {
      stopLiveSession();
    }
    return () => {
      stopLiveSession();
    };
  }, [isOpen, stopLiveSession]);

  const toggleMute = () => {
    if (liveSessionRef.current) {
      const nextMute = !isMuted;
      liveSessionRef.current.setMute(nextMute);
      setIsMuted(nextMute);
    }
  };

  const toggleSpeaker = () => {
    const nextSpeaker = !isSpeakerOn;
    setIsSpeakerOn(nextSpeaker);
    if (!nextSpeaker && audioStreamerRef.current) {
      audioStreamerRef.current.stop();
    }
  };

  const handleBargeIn = () => {
    if (audioStreamerRef.current) {
      audioStreamerRef.current.stop();
    }
    if (liveSessionRef.current) {
      liveSessionRef.current.triggerInterruption();
    }
    setSessionState('listening');
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          key="voice-session-modal"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between overflow-hidden select-none font-sans"
        >
          {/* Background Ambient Glows */}
          <div 
            className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 rounded-full pointer-events-none transition-all duration-1000 blur-[140px] opacity-40 ${
              sessionState === 'speaking' 
                ? 'w-[520px] h-[520px] bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 scale-125' 
                : sessionState === 'listening'
                  ? 'w-[480px] h-[480px] bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 scale-110'
                  : sessionState === 'connecting'
                    ? 'w-[400px] h-[400px] bg-gradient-to-r from-amber-500 via-orange-600 to-indigo-600 animate-pulse'
                    : 'w-[320px] h-[320px] bg-indigo-900/30'
            }`}
          />

          <div className="absolute inset-0 bg-[linear-gradient(to_right,#1f293710_1px,transparent_1px),linear-gradient(to_bottom,#1f293710_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] pointer-events-none" />

          {/* Top Header */}
          <header className="relative z-20 px-6 py-5 flex items-center justify-between border-b border-white/5 bg-slate-950/60 backdrop-blur-xl">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-600 to-indigo-700 flex items-center justify-center shadow-lg shadow-indigo-500/25">
                <Activity className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-base font-extrabold tracking-tight bg-gradient-to-r from-indigo-400 via-purple-300 to-indigo-200 bg-clip-text text-transparent">
                    Alya Assistant
                  </h1>
                </div>
                <p className="text-[11px] text-slate-400 font-medium">
                  Direct Audio-to-Audio • Gemini 3.1 Flash Preview
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setShowDiagnosticHUD(!showDiagnosticHUD)}
                className={`p-2 rounded-xl border transition-all flex items-center gap-1 text-xs ${
                  showDiagnosticHUD 
                    ? 'bg-indigo-600/30 border-indigo-400 text-indigo-300 shadow-lg shadow-indigo-500/20' 
                    : 'bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border-white/10'
                }`}
                title="Toggle Audio Engine Diagnostic HUD"
              >
                <Cpu className="w-4 h-4 text-cyan-400" />
                <span className="hidden sm:inline font-mono font-bold text-[10px]">DIAG HUD</span>
              </button>

              <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 border border-white/10">
                <span className={`w-2 h-2 rounded-full ${
                  sessionState === 'speaking' 
                    ? 'bg-pink-500 animate-ping' 
                    : sessionState === 'listening'
                      ? 'bg-emerald-400 animate-pulse'
                      : sessionState === 'connecting'
                        ? 'bg-amber-400 animate-bounce'
                        : 'bg-slate-600'
                }`} />
                <span className="text-[11px] font-mono font-bold uppercase tracking-wider text-slate-300">
                  {sessionState}
                </span>
              </div>
              <button 
                onClick={onClose}
                className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white transition-all border border-white/10"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </header>

          {/* Diagnostic Telemetry HUD Overlay */}
          <AnimatePresence>
            {showDiagnosticHUD && (
              <motion.div
                key="voice-session-hud"
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                className="relative z-30 px-6 pt-3 max-w-xl mx-auto w-full"
              >
                <AudioDiagnosticHUD 
                  metrics={audioMetrics}
                  isCapturing={sessionState === 'listening' || sessionState === 'speaking'}
                  defaultExpanded={true}
                />
              </motion.div>
            )}
          </AnimatePresence>

          {/* Main Stage */}
          <main className="relative z-10 flex-1 flex flex-col items-center justify-center p-6 gap-6 max-w-xl mx-auto w-full">
            
            {/* Tool Toast */}
            <AnimatePresence>
              {activeToolNotification && (
                <motion.div
                  key="voice-session-tool-notif"
                  initial={{ opacity: 0, y: -20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  className="w-full max-w-md p-4 rounded-2xl bg-gradient-to-r from-indigo-950/90 via-purple-950/90 to-slate-900/90 border border-purple-500/30 backdrop-blur-xl shadow-2xl flex items-center justify-between gap-3 text-xs"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-purple-500/20 text-purple-300 flex items-center justify-center shrink-0 border border-purple-500/30">
                      <Zap className="w-4 h-4 text-purple-400 animate-pulse" />
                    </div>
                    <div>
                      <span className="font-bold text-white block text-sm">
                        {activeToolNotification.toolName === 'openWebsite' ? 'Website Opened' : 'Action Executed'}
                      </span>
                      <span className="text-purple-200/90 text-xs">
                        {activeToolNotification.details}
                      </span>
                    </div>
                  </div>

                  {activeToolNotification.url && (
                    <a
                      href={activeToolNotification.url}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-1.5 rounded-lg bg-purple-500/30 hover:bg-purple-500/50 text-white font-bold flex items-center gap-1 transition-colors shrink-0"
                    >
                      <span>Visit</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </motion.div>
              )}
            </AnimatePresence>

            {/* Glowing Interactive Central Orb */}
            <div 
              onClick={toggleLiveSession}
              className="relative flex items-center justify-center my-auto cursor-pointer group"
              title={sessionState === 'disconnected' ? 'Tap to start live call' : 'Live call active'}
            >
              <div className={`absolute w-72 h-72 sm:w-96 sm:h-96 rounded-full border border-pink-500/20 transition-all duration-1000 ${
                sessionState === 'speaking' || sessionState === 'listening' ? 'animate-ping' : 'opacity-20'
              }`} />

              <div className={`absolute w-56 h-56 sm:w-80 sm:h-80 rounded-full border border-purple-500/30 transition-all duration-700 ${
                sessionState !== 'disconnected' ? 'animate-pulse' : 'opacity-10'
              }`} />

              <motion.div
                animate={{
                  scale: sessionState === 'speaking' 
                    ? [1, 1.14, 0.96, 1.08, 1] 
                    : sessionState === 'listening'
                      ? [1, 1.06, 1.02, 1.08, 1]
                      : sessionState === 'connecting'
                        ? [1, 1.04, 1]
                        : [1, 1.02, 1],
                  borderRadius: sessionState === 'speaking'
                    ? ["42% 58% 70% 30% / 45% 45% 55% 55%", "65% 35% 45% 55% / 55% 45% 65% 35%", "42% 58% 70% 30% / 45% 45% 55% 55%"]
                    : sessionState === 'listening'
                      ? ["50% 50% 30% 70% / 50% 60% 40% 50%", "30% 70% 70% 30% / 50% 30% 70% 50%", "50% 50% 30% 70% / 50% 60% 40% 50%"]
                      : ["50%"]
                }}
                transition={{
                  repeat: Infinity,
                  duration: sessionState === 'speaking' ? 2.5 : sessionState === 'listening' ? 2.0 : 4.0,
                  ease: "easeInOut"
                }}
                className={`w-36 h-36 sm:w-48 sm:h-48 rounded-full flex items-center justify-center relative z-20 shadow-2xl transition-all duration-700 border-2 group-hover:scale-105 ${
                  sessionState === 'speaking'
                    ? 'bg-gradient-to-tr from-pink-600 via-rose-500 to-purple-600 border-pink-300 shadow-[0_0_80px_rgba(236,72,153,0.5)]'
                    : sessionState === 'listening'
                      ? 'bg-gradient-to-tr from-emerald-600 via-teal-500 to-cyan-500 border-emerald-300 shadow-[0_0_70px_rgba(16,185,129,0.5)]'
                      : sessionState === 'connecting'
                        ? 'bg-gradient-to-tr from-amber-600 via-orange-500 to-indigo-600 border-amber-300 shadow-[0_0_60px_rgba(245,158,11,0.4)]'
                        : 'bg-gradient-to-tr from-slate-900 via-indigo-950 to-slate-900 border-white/20 shadow-[0_0_40px_rgba(99,102,241,0.2)]'
                }`}
              >
                <div className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-slate-950/40 backdrop-blur-md flex flex-col items-center justify-center gap-1 text-white">
                  {sessionState === 'disconnected' ? (
                    <>
                      <Power className="w-8 h-8 sm:w-10 sm:h-10 text-slate-500" />
                      <span className="text-[10px] font-bold tracking-widest uppercase text-slate-500">START</span>
                    </>
                  ) : sessionState === 'connecting' ? (
                    <>
                      <Radio className="w-8 h-8 sm:w-10 sm:h-10 text-amber-300 animate-spin" />
                      <span className="text-[9px] font-bold tracking-widest uppercase text-amber-200">CONNECTING</span>
                    </>
                  ) : sessionState === 'speaking' ? (
                    <>
                      <Sparkles className="w-8 h-8 sm:w-10 sm:h-10 text-pink-200 animate-pulse" />
                      <span className="text-[9px] font-bold tracking-widest uppercase text-pink-100">SPEAKING</span>
                    </>
                  ) : (
                    <>
                      <Mic className="w-8 h-8 sm:w-10 sm:h-10 text-emerald-300" />
                      <span className="text-[9px] font-bold tracking-widest uppercase text-emerald-100">LISTENING</span>
                    </>
                  )}
                </div>
              </motion.div>
            </div>

            {/* Visualizer Spectrum */}
            <div className="w-full max-w-xs flex items-center justify-center gap-1.5 h-12 px-4">
              {audioBars.map((height, i) => (
                <motion.div
                  key={`vsession-bar-${i}`}
                  animate={{ height: `${height}%` }}
                  transition={{ type: 'spring', stiffness: 450, damping: 20 }}
                  className={`w-1.5 rounded-full transition-colors duration-200 ${
                    sessionState === 'speaking'
                      ? 'bg-gradient-to-t from-pink-500 to-purple-400 shadow-[0_0_8px_rgba(236,72,153,0.8)]'
                      : sessionState === 'listening'
                        ? 'bg-gradient-to-t from-emerald-500 to-teal-300 shadow-[0_0_8px_rgba(52,211,153,0.8)]'
                        : sessionState === 'connecting'
                          ? 'bg-amber-400/80'
                          : 'bg-slate-800'
                  }`}
                />
              ))}
            </div>

            {/* Status Text Indicator */}
            <div className="text-center max-w-sm px-4">
              <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed min-h-[2.5rem] flex items-center justify-center">
                {statusText}
              </p>
            </div>

            {/* Voice Activity Detection (VAD) Signal Meter & Waveform */}
            {sessionState !== 'disconnected' && (
              <div className="w-full max-w-full md:max-w-xl px-4">
                <VADVisualizer
                  isActive={true}
                  isListening={sessionState === 'listening'}
                  isMuted={isMuted}
                  barCount={28}
                  sensitivityThreshold={0.035}
                />
              </div>
            )}

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-200 text-xs flex items-center gap-2 max-w-md w-full">
                <span className="font-bold">Notice:</span>
                <span className="flex-1 truncate">{errorMessage}</span>
                <button
                  onClick={() => setErrorMessage(null)}
                  className="text-red-400 hover:text-white font-bold px-2 py-0.5"
                >
                  ✕
                </button>
              </div>
            )}
          </main>

          {/* Footer Controls */}
          <footer className="relative z-20 p-5 sm:p-6 bg-slate-950/80 backdrop-blur-xl border-t border-white/5 flex items-center justify-center gap-6">
            
            <button
              type="button"
              onClick={toggleMute}
              disabled={sessionState === 'disconnected'}
              className={`p-4 rounded-3xl transition-all flex flex-col items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                isMuted 
                  ? 'bg-red-500/20 text-red-400 border border-red-500/40 shadow-lg shadow-red-500/15' 
                  : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
              }`}
            >
              {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
              <span className="text-[10px] font-bold uppercase tracking-wider">
                {isMuted ? 'Muted' : 'Mic On'}
              </span>
            </button>

            {sessionState === 'speaking' && (
              <button
                type="button"
                onClick={handleBargeIn}
                className="px-5 py-4 rounded-3xl bg-pink-500/20 hover:bg-pink-500/30 text-pink-300 border border-pink-500/40 transition-all flex flex-col items-center gap-1.5 cursor-pointer shadow-lg shadow-pink-500/20 active:scale-95"
              >
                <RotateCcw className="w-5 h-5" />
                <span className="text-[10px] font-bold uppercase tracking-wider">
                  Interrupt
                </span>
              </button>
            )}

            <button
              type="button"
              onClick={toggleSpeaker}
              disabled={sessionState === 'disconnected'}
              className={`p-4 rounded-3xl transition-all flex flex-col items-center gap-1.5 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed ${
                !isSpeakerOn 
                  ? 'bg-amber-500/20 text-amber-400 border border-amber-500/40' 
                  : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
              }`}
            >
              {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
              <span className="text-[10px] font-bold uppercase tracking-wider">
                {isSpeakerOn ? 'Speaker' : 'Muted'}
              </span>
            </button>

            <button
              type="button"
              onClick={() => onClose()}
              className="p-4 rounded-3xl bg-red-600 hover:bg-red-700 text-white border border-red-500/40 transition-all flex flex-col items-center gap-1.5 cursor-pointer shadow-lg shadow-red-600/20 active:scale-95"
            >
              <PhoneOff className="w-5 h-5" />
              <span className="text-[10px] font-bold uppercase tracking-wider">
                End Call
              </span>
            </button>

          </footer>

        </motion.div>
      )}
    </AnimatePresence>
  );
}
