import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Phone, Power, Loader2, Volume2, Volume1, Settings, X, Shield, Zap, Sparkles, ChevronLeft, Activity, Monitor, MonitorOff, MapPin, RefreshCw, CloudSun, Newspaper, FileText, Sliders } from 'lucide-react';
import { LiveSessionState } from '../lib/LiveSession';
import { LiveKitDiagnosticsModal } from './LiveKitDiagnosticsModal';
import { VADVisualizer } from './VADVisualizer';
import { secureStorage } from '../lib/secureStorage';
import { SecureApiKeyManager } from './SecureApiKeyManager';
import { useGlobalSettings } from '../lib/GlobalSettingsContext';
import { useAuth } from '../lib/AuthContext';
import { liveSessionManager } from '../lib/LiveSessionManager';
import { screenShareManager } from '../lib/ScreenShareManager';
import { getActiveApiKey, apiKeyManager } from '../lib/ApiKeyManager';
import { locationService, LocationContext } from '../lib/locationService';
import { useAudioOutputRoute } from '../hooks/useAudioOutputRoute';

const ALYA_AVATAR_URL = 'https://res.cloudinary.com/xbks6nu5/image/upload/v1789891823/Alisa.Mikhailova.Kujou.600.4066893_lp4uzw.jpg';

interface AlyaLiveProps {
  onExit?: () => void;
}

export const AlyaLive: React.FC<AlyaLiveProps> = ({ onExit }) => {
  const { preferences: globalPrefs, preferredLanguage, updatePreferences } = useGlobalSettings();
  const { user } = useAuth();
  const [isMuted, setIsMuted] = useState(liveSessionManager.isMicrophoneMuted());
  const {
    isSpeaker: isSpeakerOn,
    toggleRoute: toggleSpeaker,
    attachMediaElement,
    detachMediaElement
  } = useAudioOutputRoute({
    syncWithLiveSession: true
  });
  const [isPaused, setIsPaused] = useState(liveSessionManager.isSessionPaused());
  const [sessionState, setSessionState] = useState<LiveSessionState>(liveSessionManager.getState());
  const [apiKey, setApiKey] = useState('');
  const [showSettings, setShowSettings] = useState(false);
  const [showDiagnostics, setShowDiagnostics] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [micAnalyser, setMicAnalyser] = useState<AnalyserNode | null>(liveSessionManager.getMicAnalyser());
  const [vadSensitivity, setVadSensitivity] = useState<number>(() => {
    const saved = localStorage.getItem('alya_vad_sensitivity');
    return saved ? parseFloat(saved) : 0.040;
  });
  const [isUserSpeaking, setIsUserSpeaking] = useState<boolean>(false);
  const [showVADModal, setShowVADModal] = useState<boolean>(false);
  
  // Real-time GPS Location State
  const [currentLocation, setCurrentLocation] = useState<LocationContext | null>(locationService.getLastKnownLocation());
  const [isLocating, setIsLocating] = useState(false);

  // Screen Sharing State
  const [isScreenSharing, setIsScreenSharing] = useState(screenShareManager.isSharingActive());
  const [screenStream, setScreenStream] = useState<MediaStream | null>(screenShareManager.getCurrentStream());
  const screenVideoRef = useRef<HTMLVideoElement | null>(null);

  // Subscribe to authoritative LiveSessionManager, ScreenShareManager, and LocationService
  useEffect(() => {
    const unsubLive = liveSessionManager.subscribe({
      id: 'alya_live_view',
      onStatusChange: (status) => {
        setSessionState(status);
      },
      onAnalyserReady: (analyser) => {
        setMicAnalyser(analyser);
      },
      onError: (err) => {
        setError(err);
        setTimeout(() => setError(null), 5000);
      }
    });

    const unsubScreen = screenShareManager.subscribe({
      id: 'alya_live_screen',
      onStatusChange: (status, stream) => {
        setIsScreenSharing(status === 'active');
        setScreenStream(stream);
      },
      onError: (err) => {
        setError(err);
        setTimeout(() => setError(null), 4000);
      }
    });

    const unsubLoc = locationService.subscribe((ctx) => {
      setCurrentLocation(ctx);
      if (ctx.latitude && ctx.longitude) {
        liveSessionManager.updateLocation({
          lat: ctx.latitude,
          lon: ctx.longitude,
          city: ctx.locality || ctx.region
        });
      }
    });

    // Sync initial state on mount
    setIsMuted(liveSessionManager.isMicrophoneMuted());
    setIsPaused(liveSessionManager.isSessionPaused());
    setSessionState(liveSessionManager.getState());
    setMicAnalyser(liveSessionManager.getMicAnalyser());
    setIsScreenSharing(screenShareManager.isSharingActive());
    setScreenStream(screenShareManager.getCurrentStream());

    return () => {
      // NOTE: Unmounting AlyaLive does NOT destroy the long-lived session!
      // Only user clicking explicit "End Call" terminates the session.
      unsubLive();
      unsubScreen();
      unsubLoc();
    };
  }, []);

  // Continuous Real-Time Voice Activity Detection (VAD) loop from micAnalyser
  useEffect(() => {
    if (!micAnalyser || isMuted || sessionState === 'disconnected') {
      setIsUserSpeaking(false);
      return;
    }

    let animId: number;
    const bufferLength = micAnalyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    let consecutiveQuietFrames = 0;

    const checkLevel = () => {
      micAnalyser.getByteTimeDomainData(dataArray);
      let sum = 0;
      for (let i = 0; i < bufferLength; i++) {
        const norm = (dataArray[i] - 128) / 128;
        sum += norm * norm;
      }
      const rms = Math.sqrt(sum / bufferLength);
      const threshold = vadSensitivity || 0.025;

      if (rms > threshold) {
        setIsUserSpeaking(true);
        consecutiveQuietFrames = 0;
      } else {
        consecutiveQuietFrames++;
        if (consecutiveQuietFrames > 12) { // ~200ms of quiet
          setIsUserSpeaking(false);
        }
      }

      animId = requestAnimationFrame(checkLevel);
    };

    animId = requestAnimationFrame(checkLevel);
    return () => {
      cancelAnimationFrame(animId);
    };
  }, [micAnalyser, isMuted, sessionState, vadSensitivity]);

  const handleRequestExactLocation = async () => {
    setIsLocating(true);
    try {
      const res = await locationService.requestExactLocation();
      if (res.success && res.context) {
        setCurrentLocation(res.context);
        liveSessionManager.updateLocation({
          lat: res.context.latitude,
          lon: res.context.longitude,
          city: res.context.locality || res.context.region
        });
      }
    } finally {
      setIsLocating(false);
    }
  };

  // Sync video element with active screen stream
  useEffect(() => {
    if (screenVideoRef.current && screenStream) {
      screenVideoRef.current.srcObject = screenStream;
      attachMediaElement(screenVideoRef.current);
    }
  }, [screenStream, isScreenSharing, attachMediaElement]);

  // Sync API Key
  useEffect(() => {
    const updateLocalKey = async () => {
      const activeKey = getActiveApiKey() || await secureStorage.getSecureApiKey();
      setApiKey(activeKey || '');
    };
    
    updateLocalKey();

    const handleKeyUpdate = () => updateLocalKey();
    window.addEventListener('alya:api-key-updated', handleKeyUpdate);
    return () => {
      window.removeEventListener('alya:api-key-updated', handleKeyUpdate);
    };
  }, []);

  const startSession = async () => {
    setError(null);
    setIsPaused(false);
    const userId = user?.uid || localStorage.getItem('alya_user_id') || 'default_user';
    const conversationId = localStorage.getItem('alya_active_conversation_id') || 'main';
    const chosenLang = preferredLanguage || globalPrefs.language || 'auto';

    await liveSessionManager.startSession({
      userId,
      apiKey,
      language: chosenLang,
      conversationId
    });
  };

  const stopSession = () => {
    liveSessionManager.stopSession();
    screenShareManager.stopScreenShare('call_ended');
    setIsPaused(false);
  };

  const togglePause = () => {
    const nextPaused = liveSessionManager.togglePause();
    setIsPaused(nextPaused);
  };

  const toggleMute = () => {
    const nextMuted = liveSessionManager.toggleMute();
    setIsMuted(nextMuted);
  };

  const toggleScreenShare = async () => {
    if (isScreenSharing) {
      screenShareManager.stopScreenShare('user_toggle');
    } else {
      await screenShareManager.startScreenShare();
    }
  };

  const saveApiKey = (key: string) => {
    setApiKey(key);
    apiKeyManager.setApiKey(key).catch(console.error);
  };

  const handleForceReconnect = () => {
    liveSessionManager.forceReconnect();
  };

  return (
    <div className="fixed inset-0 h-[100dvh] max-h-[100dvh] z-50 bg-slate-950 flex flex-col items-center justify-between p-4 sm:p-6 pb-6 sm:pb-8 overflow-hidden text-white font-sans select-none">
      {/* Background Ambience */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-600/10 rounded-full blur-[120px] transition-all duration-1000 ${sessionState !== 'disconnected' ? 'opacity-100 scale-110' : 'opacity-20 scale-90'}`} />
        <div className={`absolute top-1/4 left-1/3 w-[400px] h-[400px] bg-pink-500/5 rounded-full blur-[100px] transition-all duration-1000 delay-300 ${sessionState === 'speaking' ? 'opacity-100' : 'opacity-0'}`} />
      </div>

      {/* Header */}
      <div className="w-full flex items-center justify-between relative z-10">
        <div className="flex items-center gap-3">
          {onExit && (
            <button 
              onClick={onExit}
              className="p-2 -ml-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/5 transition-all active:scale-90"
              title="Exit Live Call"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 flex items-center justify-center border border-indigo-500/30">
            <Sparkles className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h1 className="font-bold text-lg tracking-tight text-white">Alya <span className="text-indigo-400 font-black">LIVE</span></h1>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest font-mono">Neural Nexus v3.2</p>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <button 
            onClick={() => setShowVADModal(true)}
            className="p-3 rounded-2xl bg-white/5 border border-white/10 text-slate-400 hover:text-emerald-400 hover:bg-white/10 transition-all shadow-sm active:scale-95 flex items-center gap-2 text-xs font-semibold"
            title="Voice Activity Detection (VAD) & Sensitivity Tuner"
          >
            <Sliders className="w-5 h-5 text-emerald-400" />
            <span className="hidden sm:inline">VAD Tuner</span>
          </button>

          <button 
            onClick={() => setShowDiagnostics(true)}
            className="p-3 rounded-2xl bg-white/5 border border-white/10 text-slate-400 hover:text-indigo-400 hover:bg-white/10 transition-all shadow-sm active:scale-95 flex items-center gap-2 text-xs font-semibold"
            title="LiveKit WebSocket Diagnostics"
          >
            <Activity className="w-5 h-5 text-indigo-400" />
            <span className="hidden sm:inline">Diagnostics</span>
          </button>

          <button 
            onClick={() => setShowSettings(true)}
            className="p-3 rounded-2xl bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-all shadow-sm active:scale-95"
            title="Session Settings"
          >
            <Settings className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* Live Location & Real-time Grounding Bar */}
      <div className="w-full max-w-md flex items-center justify-between px-3.5 py-2 rounded-2xl bg-white/5 border border-white/10 backdrop-blur-md relative z-10 text-xs mt-2">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="p-1.5 rounded-xl bg-indigo-500/20 text-indigo-400 shrink-0">
            <MapPin className="w-4 h-4" />
          </div>
          <div className="truncate">
            <span className="text-[11px] font-bold text-white block truncate">
              {currentLocation ? (currentLocation.locality ? `${currentLocation.locality}, ${currentLocation.region || currentLocation.country || ''}` : currentLocation.formattedAddress || 'Location Active') : 'Detecting Real Location...'}
            </span>
            <span className="text-[9px] text-slate-400 flex items-center gap-1.5 font-mono">
              <span className={`w-1.5 h-1.5 rounded-full ${currentLocation?.accuracyType === 'precise' ? 'bg-emerald-400 animate-pulse' : 'bg-indigo-400'}`} />
              {currentLocation?.accuracyType === 'precise' ? 'Live GPS Precise' : 'Network Geolocation'}
            </span>
          </div>
        </div>
        <button
          onClick={handleRequestExactLocation}
          disabled={isLocating}
          className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 text-[10px] font-bold border border-indigo-500/30 flex items-center gap-1.5 transition-all shrink-0 active:scale-95 disabled:opacity-50"
          title="Acquire exact GPS fix for real-time weather & news"
        >
          <RefreshCw className={`w-3 h-3 ${isLocating ? 'animate-spin' : ''}`} />
          <span>{currentLocation?.accuracyType === 'precise' ? 'Sync GPS' : 'Enable GPS'}</span>
        </button>
      </div>

      {/* Main Interactive Core */}
      <div className="flex-1 flex flex-col items-center justify-center w-full relative">
        <AnimatePresence mode="wait">
          {error && (
            <motion.div 
              key="alyalive-error-banner"
              initial={{ opacity: 0, y: 20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              className="absolute top-0 px-5 py-3 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-400 text-xs font-bold flex items-center gap-2.5 backdrop-blur-sm z-20 shadow-xl"
            >
              <Shield className="w-4 h-4" />
              {error}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Visual Pulse / Orb */}
        <div className="relative scale-90 md:scale-100">
          <motion.div
            animate={{ 
              scale: sessionState === 'speaking' ? [1, 1.05, 1] : sessionState === 'thinking' ? [1, 1.03, 1] : 1,
            }}
            transition={{ duration: sessionState === 'thinking' ? 1.5 : 1, repeat: Infinity, ease: "easeInOut" }}
            className={`w-64 h-64 rounded-full border-4 transition-all duration-700 flex items-center justify-center relative ${
              sessionState === 'speaking' ? 'border-indigo-500 shadow-[0_0_80px_rgba(99,102,241,0.5)]' :
              sessionState === 'thinking' ? 'border-violet-500 shadow-[0_0_80px_rgba(139,92,246,0.55)]' :
              sessionState === 'listening' ? (isUserSpeaking ? 'border-emerald-400 shadow-[0_0_70px_rgba(52,211,153,0.4)]' : 'border-emerald-500/50 shadow-[0_0_50px_rgba(16,185,129,0.2)]') :
              sessionState === 'connecting' ? 'border-amber-500/50 animate-pulse' : 'border-white/10 shadow-2xl'
            }`}
          >
            <div className="w-52 h-52 rounded-full overflow-hidden border-8 border-slate-900 shadow-inner relative group bg-slate-900">
              <img 
                src={ALYA_AVATAR_URL} 
                alt="Alya Persona" 
                className={`w-full h-full object-cover transition-all duration-1000 ${sessionState === 'disconnected' ? 'grayscale opacity-20 scale-100' : 'grayscale-0 opacity-100 scale-110'}`}
              />
              <div className={`absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent transition-opacity duration-700 ${sessionState === 'disconnected' ? 'opacity-0' : 'opacity-100'}`} />
              
              {/* Speaking Visual Pulse */}
              {sessionState === 'speaking' && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-full h-full border-[10px] border-indigo-500/30 rounded-full animate-[ping_2s_linear_infinite]" />
                  <div className="absolute inset-0 bg-indigo-500/10 animate-pulse rounded-full" />
                </div>
              )}

              {/* Thinking Neural Aura Ring */}
              {sessionState === 'thinking' && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-full h-full border-4 border-dashed border-violet-400/60 rounded-full animate-spin [animation-duration:3s]" />
                  <div className="absolute inset-2 border-2 border-cyan-400/40 rounded-full animate-ping [animation-duration:2.5s]" />
                  <div className="absolute inset-0 bg-violet-600/15 animate-pulse rounded-full" />
                </div>
              )}

              {/* User Speaking Active Ripple */}
              {sessionState === 'listening' && isUserSpeaking && (
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-full h-full border-4 border-emerald-400/40 rounded-full animate-ping [animation-duration:1.5s]" />
                  <div className="absolute inset-0 bg-emerald-500/10 animate-pulse rounded-full" />
                </div>
              )}
            </div>

            <div className={`absolute -bottom-2 left-1/2 -translate-x-1/2 px-5 py-2 rounded-2xl bg-slate-900/95 border border-white/15 flex items-center gap-2.5 shadow-2xl transition-all duration-500 z-10 ${sessionState === 'disconnected' ? 'opacity-0 translate-y-4' : 'opacity-100 translate-y-0'}`}>
              <div className={`w-2.5 h-2.5 rounded-full ${
                isPaused ? 'bg-amber-500 animate-pulse' :
                sessionState === 'speaking' ? 'bg-indigo-400 shadow-[0_0_10px_rgba(129,140,248,0.8)]' :
                sessionState === 'thinking' ? 'bg-violet-400 animate-pulse shadow-[0_0_12px_rgba(167,139,250,1)]' :
                sessionState === 'listening' ? (isUserSpeaking ? 'bg-emerald-400 animate-ping shadow-[0_0_12px_rgba(52,211,153,1)]' : 'bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.8)]') :
                sessionState === 'reconnecting' ? 'bg-amber-400 animate-ping' :
                sessionState === 'connecting' ? 'bg-amber-400 animate-pulse' :
                'bg-amber-400'
              }`} />
              <span className="text-[11px] font-black uppercase tracking-[0.15em] text-white">
                {isPaused ? 'PAUSED' : 
                 sessionState === 'speaking' ? 'ALYA SPEAKING' : 
                 sessionState === 'thinking' ? 'ALYA THINKING...' : 
                 sessionState === 'listening' ? (isUserSpeaking ? 'LISTENING TO YOU' : 'LISTENING') : 
                 sessionState === 'reconnecting' ? 'RECONNECTING...' : 
                 sessionState === 'connecting' ? 'CONNECTING...' : sessionState}
              </span>
            </div>
          </motion.div>

          <AnimatePresence>
            {sessionState !== 'disconnected' && !isPaused && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute -bottom-20 left-1/2 -translate-x-1/2 flex items-end gap-1.5 h-12"
              >
                {[...Array(12)].map((_, i) => (
                  <motion.div
                    key={`alyalive-bar-${i}`}
                    animate={{ 
                      height: sessionState === 'speaking' ? [8, 32, 16, 48, 12, 40, 8][i % 7] :
                              sessionState === 'thinking' ? [6, 18, 10, 24, 8, 14, 6][(i + 2) % 7] :
                              isUserSpeaking ? [10, 28, 14, 38, 12, 32, 10][(i + 1) % 7] : 4,
                      opacity: (sessionState === 'speaking' || sessionState === 'thinking' || isUserSpeaking) ? 1 : 0.3
                    }}
                    transition={{ duration: sessionState === 'thinking' ? 0.6 : 0.35, repeat: Infinity, delay: i * 0.04, ease: "easeInOut" }}
                    className={`w-1.5 rounded-full ${
                      sessionState === 'speaking' ? 'bg-gradient-to-t from-indigo-600 to-indigo-400' :
                      sessionState === 'thinking' ? 'bg-gradient-to-t from-violet-600 to-cyan-400' :
                      isUserSpeaking ? 'bg-gradient-to-t from-emerald-600 to-emerald-400' :
                      'bg-slate-700'
                    }`}
                  />
                ))}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Status context helpers below Avatar Orb */}
        {sessionState === 'thinking' && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-2 text-[11px] text-violet-300 font-bold uppercase tracking-[0.2em] mt-12 mb-2 bg-violet-600/15 border border-violet-500/30 px-5 py-2 rounded-full shadow-lg"
          >
            <Sparkles className="w-3.5 h-3.5 text-violet-400 animate-spin" />
            <span>Alya Neural Intelligence Thinking...</span>
          </motion.div>
        )}

        {sessionState === 'connecting' && (
          <motion.p 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-[10px] text-amber-400/90 font-black uppercase tracking-[0.25em] animate-pulse text-center mt-12 mb-2 bg-amber-500/10 border border-amber-500/20 px-4 py-1.5 rounded-full shadow-sm"
          >
            Establishing Neural Link with Gemini...
          </motion.p>
        )}
      </div>

      {/* Premium Call Controls Layout - MOVED LOWER AS REQUESTED */}
      <div className="w-full max-w-lg flex flex-col gap-10 relative z-10 mb-2 px-4">
        <div className="flex flex-col items-center gap-6">
          <AnimatePresence mode="wait">
            {sessionState === 'disconnected' ? (
              <motion.button
                key="start"
                initial={{ scale: 0.8, opacity: 0, y: 20 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                exit={{ scale: 0.8, opacity: 0, y: 20 }}
                onClick={startSession}
                className="group relative flex items-center gap-5 px-14 py-6 bg-gradient-to-r from-indigo-600 to-violet-700 hover:from-indigo-500 hover:to-violet-600 text-white rounded-[2.5rem] font-black text-xl transition-all shadow-[0_20px_50px_rgba(79,70,229,0.4)] active:scale-95 border-t border-white/20"
              >
                <Zap className="w-7 h-7 fill-amber-300 text-amber-300 drop-shadow-[0_0_8px_rgba(252,211,77,0.8)]" />
                <span>START ALYA CALL</span>
                <div className="absolute inset-0 rounded-[2.5rem] bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.button>
            ) : (
              <motion.div 
                key="active"
                initial={{ y: 60, opacity: 0, scale: 0.9 }}
                animate={{ y: 0, opacity: 1, scale: 1 }}
                className="flex flex-col items-center gap-10 w-full"
              >
                {/* Active Screen Sharing Preview Card */}
                {isScreenSharing && (
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.95, y: 10 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: 10 }}
                    className="w-full max-w-sm rounded-2xl overflow-hidden bg-slate-900/90 border border-emerald-500/40 p-3 shadow-2xl backdrop-blur-md flex flex-col gap-2 relative z-20"
                  >
                    <div className="flex items-center justify-between px-1">
                      <div className="flex items-center gap-2">
                        <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                        <span className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider">Alya is viewing your screen</span>
                      </div>
                      <button 
                        onClick={() => screenShareManager.stopScreenShare('user_stop_card')}
                        className="text-[10px] bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 px-2.5 py-1 rounded-lg font-bold transition-all"
                      >
                        Stop Sharing
                      </button>
                    </div>
                    <div className="relative aspect-video rounded-xl overflow-hidden bg-black/60 border border-white/10">
                      <video 
                        ref={screenVideoRef}
                        autoPlay
                        playsInline
                        muted
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </motion.div>
                )}

                {/* Secondary Control Row (Mute, Pause, Screen Share, Speaker) */}
                <div className="flex items-center justify-around w-full max-w-md">
                  {/* Mute Button */}
                  <div className="flex flex-col items-center gap-2">
                    <button 
                      onClick={toggleMute}
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-3xl flex items-center justify-center transition-all shadow-lg active:scale-90 ${isMuted ? 'bg-rose-500 text-white border-rose-400' : 'bg-white/10 border border-white/10 text-slate-300 hover:bg-white/20'}`}
                      title={isMuted ? "Unmute Microphone" : "Mute Microphone"}
                    >
                      {isMuted ? <MicOff className="w-6 h-6 sm:w-7 sm:h-7" /> : <Mic className="w-6 h-6 sm:w-7 sm:h-7" />}
                    </button>
                    <span className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em]">{isMuted ? 'UNMUTE' : 'MUTE'}</span>
                  </div>

                  {/* Pause/Stop Button */}
                  <div className="flex flex-col items-center gap-2">
                    <button 
                      onClick={togglePause}
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-3xl flex items-center justify-center transition-all shadow-xl active:scale-90 border-2 ${isPaused ? 'bg-amber-500 text-white border-amber-400 shadow-amber-500/40' : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700 hover:border-slate-600'}`}
                      title={isPaused ? "Resume Audio" : "Pause Audio"}
                    >
                      {isPaused ? <Zap className="w-6 h-6 sm:w-7 sm:h-7 fill-current" /> : <Power className="w-6 h-6 sm:w-7 sm:h-7" />}
                    </button>
                    <span className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em]">{isPaused ? 'RESUME' : 'PAUSE'}</span>
                  </div>

                  {/* Screen Share Button */}
                  <div className="flex flex-col items-center gap-2">
                    <button 
                      onClick={toggleScreenShare}
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-3xl flex items-center justify-center transition-all shadow-lg active:scale-90 ${isScreenSharing ? 'bg-emerald-500 text-white border-emerald-400 shadow-emerald-500/40 animate-pulse' : 'bg-white/10 border border-white/10 text-slate-300 hover:bg-white/20'}`}
                      title={isScreenSharing ? "Stop Screen Sharing" : "Share Screen with Alya"}
                    >
                      {isScreenSharing ? <MonitorOff className="w-6 h-6 sm:w-7 sm:h-7" /> : <Monitor className="w-6 h-6 sm:w-7 sm:h-7" />}
                    </button>
                    <span className={`text-[10px] font-black uppercase tracking-[0.2em] ${isScreenSharing ? 'text-emerald-400' : 'text-slate-500'}`}>
                      {isScreenSharing ? 'SCREEN ON' : 'SCREEN'}
                    </span>
                  </div>

                  {/* Speaker Button (Earpiece Mode 40% vs Loud Speaker 100%) */}
                  <div className="flex flex-col items-center gap-2">
                    <button 
                      onClick={toggleSpeaker}
                      className={`w-14 h-14 sm:w-16 sm:h-16 rounded-3xl flex items-center justify-center transition-all shadow-lg active:scale-90 border ${
                        isSpeakerOn 
                          ? 'bg-gradient-to-br from-indigo-500 to-violet-600 text-white border-indigo-400 shadow-[0_0_20px_rgba(99,102,241,0.5)] scale-105' 
                          : 'bg-slate-800/90 text-slate-300 border-slate-700 hover:bg-slate-700'
                      }`}
                      title={
                        isSpeakerOn 
                          ? "Loud Main Speaker Active (100% Volume). Tap to switch to Earpiece Calling Mode (40% Volume)." 
                          : "Earpiece Calling Mode Active (40% Volume). Tap to switch to Main Loud Speaker (100% Volume)."
                      }
                    >
                      {isSpeakerOn ? (
                        <Volume2 className="w-6 h-6 sm:w-7 sm:h-7 text-white animate-pulse" />
                      ) : (
                        <Volume1 className="w-6 h-6 sm:w-7 sm:h-7 text-slate-400" />
                      )}
                    </button>
                    <span className={`text-[10px] font-black uppercase tracking-[0.15em] ${isSpeakerOn ? 'text-indigo-400' : 'text-slate-500'}`}>
                      {isSpeakerOn ? 'SPEAKER 100%' : 'EARPIECE 40%'}
                    </span>
                  </div>
                </div>

                {/* Primary End Call Button */}
                <button
                  onClick={stopSession}
                  className="w-24 h-24 bg-gradient-to-br from-rose-600 to-rose-800 hover:from-rose-500 hover:to-rose-700 rounded-full flex items-center justify-center shadow-[0_15px_40px_rgba(225,29,72,0.5)] transition-all active:scale-90 border-t border-white/20 group"
                >
                  <Phone className="w-10 h-10 text-white rotate-[135deg] group-hover:scale-110 transition-transform" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        
        {!isPaused && sessionState !== 'disconnected' && (
          <p className="text-center text-indigo-400/60 text-[10px] font-bold uppercase tracking-[0.3em] animate-pulse px-8">
            Live Neural Sync Active
          </p>
        )}
        
        <p className="text-center text-slate-500 text-xs px-8">
          Alya's persona is sassy and playful. Conversations are real-time and audio-only.
        </p>
      </div>

      <AnimatePresence>
        {showSettings && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[60] bg-slate-950/90 backdrop-blur-md p-6 flex flex-col"
          >
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-xl font-bold">Session Settings</h2>
              <button onClick={() => setShowSettings(false)} className="p-2 rounded-lg bg-white/5">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <Shield className="w-4 h-4 text-indigo-400" />
                  <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">Global Security Vault</span>
                </div>
                
                <SecureApiKeyManager compact={true} />
                
                <p className="text-[10px] text-slate-500 italic mt-2">
                  Key updated here will apply across the entire Alya system instantly.
                </p>
              </div>

              {/* Live Voice Selection */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Volume2 className="w-4 h-4 text-indigo-400" />
                    <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Alya Live Voice (6 Options)</span>
                  </div>
                  <span className="text-[10px] text-indigo-400 font-mono">Default: Aoede</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {[
                    { id: 'Aoede', name: 'Aoede', desc: 'Standard Natural' },
                    { id: 'Kore', name: 'Kore', desc: 'Warm Human' },
                    { id: 'Ursa', name: 'Ursa', desc: 'Confident & Crisp' },
                    { id: 'Callirrhoe', name: 'Callirrhoe', desc: 'Melodic & Soft' },
                    { id: 'Leda', name: 'Leda', desc: 'Bright & Expressive' },
                    { id: 'Zephyr', name: 'Zephyr', desc: 'Calm & Airy' }
                  ].map((v) => {
                    const activeVoice = globalPrefs.voiceName || localStorage.getItem('alya_voice_name') || 'Aoede';
                    const isSelected = activeVoice === v.id;
                    return (
                      <button
                        key={`call-voice-${v.id}`}
                        type="button"
                        onClick={() => {
                          updatePreferences({ voiceName: v.id });
                          localStorage.setItem('alya_voice_name', v.id);
                          liveSessionManager.setVoice(v.id);
                          window.dispatchEvent(new CustomEvent('alya:voice-changed', { detail: { voiceName: v.id } }));
                        }}
                        className={`p-3 rounded-2xl border text-left transition-all ${
                          isSelected
                            ? 'bg-indigo-600/20 border-indigo-500 text-white shadow-xs'
                            : 'bg-white/5 border-white/10 text-slate-400 hover:border-white/20'
                        }`}
                      >
                        <div className="font-bold text-xs text-white">{v.name}</div>
                        <div className="text-[10px] text-slate-400 leading-tight mt-0.5">{v.desc}</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="p-5 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 space-y-3 shadow-inner">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400 fill-current" />
                  <span className="text-xs font-bold text-indigo-300">Beta Neural Stream</span>
                </div>
                <p className="text-[11px] leading-relaxed text-indigo-200/70">
                  Gemini 3.1 Flash Live allows natural, low-latency interruptions. Simply speak while Alya is talking to barge in—no buttons needed!
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowSettings(false)}
              className="mt-auto w-full py-4 bg-indigo-600 rounded-2xl font-bold"
            >
              Done
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* VAD Sensitivity Tuner Modal */}
      <AnimatePresence>
        {showVADModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 z-[65] bg-slate-950/90 backdrop-blur-md p-6 flex flex-col"
          >
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 flex items-center justify-center border border-emerald-500/30">
                  <Activity className="w-5 h-5 text-emerald-400" />
                </div>
                <div>
                  <h2 className="text-lg font-bold text-white">Voice Activity Detection (VAD) Tuner</h2>
                  <p className="text-[10px] text-slate-400 font-mono">Live Microphone Sensitivity & State Indicator</p>
                </div>
              </div>
              <button onClick={() => setShowVADModal(false)} className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white">
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6 flex-1 overflow-y-auto">
              {/* Visual VAD Status Indicator */}
              <div className="p-5 rounded-3xl bg-slate-900 border border-white/10 flex flex-col items-center gap-4 text-center">
                <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest">Current Neural Pipeline State</span>
                <div className="flex items-center gap-3">
                  <div className={`px-4 py-2 rounded-2xl border flex items-center gap-2 text-xs font-bold transition-all ${
                    sessionState === 'speaking' ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40 shadow-[0_0_15px_rgba(99,102,241,0.3)]' :
                    sessionState === 'thinking' ? 'bg-violet-500/20 text-violet-300 border-violet-500/40 shadow-[0_0_15px_rgba(139,92,246,0.3)] animate-pulse' :
                    isUserSpeaking ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 shadow-[0_0_15px_rgba(16,185,129,0.3)] animate-pulse' :
                    'bg-white/5 text-slate-400 border-white/10'
                  }`}>
                    <span className={`w-2 h-2 rounded-full ${sessionState === 'speaking' ? 'bg-indigo-400' : sessionState === 'thinking' ? 'bg-violet-400' : isUserSpeaking ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                    <span>{sessionState === 'speaking' ? 'ALYA SPEAKING' : sessionState === 'thinking' ? 'ALYA THINKING' : isUserSpeaking ? 'USER SPEAKING (LISTENING)' : 'LISTENING / IDLE'}</span>
                  </div>

                  <div className={`px-4 py-2 rounded-2xl border flex items-center gap-2 text-xs font-bold ${
                    sessionState === 'connecting' || sessionState === 'reconnecting' ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 animate-pulse' : 'bg-white/5 text-slate-400 border-white/10'
                  }`}>
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span>PROCESSING</span>
                  </div>
                </div>

                {/* Live VAD Visualizer Component */}
                <div className="w-full mt-4 p-4 rounded-2xl bg-black/40 border border-white/10">
                  <VADVisualizer
                    analyser={micAnalyser}
                    isActive={true}
                    sensitivityThreshold={vadSensitivity}
                    onSpeechActivityChange={(isSpeech) => setIsUserSpeaking(isSpeech)}
                    variant="hero"
                    showSignalMeter={true}
                    showWaveform={true}
                  />
                </div>
              </div>

              {/* Sensitivity Tuning Slider */}
              <div className="p-5 rounded-3xl bg-slate-900 border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-white uppercase tracking-wider">VAD Threshold Sensitivity</label>
                  <span className="text-xs font-mono text-emerald-400 bg-emerald-500/10 px-3 py-1 rounded-xl border border-emerald-500/20">
                    {vadSensitivity.toFixed(3)} RMS
                  </span>
                </div>
                
                <input
                  type="range"
                  min="0.010"
                  max="0.080"
                  step="0.002"
                  value={vadSensitivity}
                  onChange={(e) => {
                    const val = parseFloat(e.target.value);
                    setVadSensitivity(val);
                    localStorage.setItem('alya_vad_sensitivity', val.toString());
                  }}
                  className="w-full accent-emerald-500 h-2 bg-slate-800 rounded-lg cursor-pointer"
                />

                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>High Sensitivity (0.010) - Picks up whispers</span>
                  <span>Noise Filter (0.080) - Ignores fan/room noise</span>
                </div>
              </div>
            </div>

            <button
              onClick={() => setShowVADModal(false)}
              className="mt-6 w-full py-4 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-bold rounded-2xl shadow-lg transition-all"
            >
              Save & Close
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* LiveKit Diagnostics Modal */}
      <LiveKitDiagnosticsModal
        isOpen={showDiagnostics}
        onClose={() => setShowDiagnostics(false)}
        onForceReconnect={handleForceReconnect}
      />
    </div>
  );
};
