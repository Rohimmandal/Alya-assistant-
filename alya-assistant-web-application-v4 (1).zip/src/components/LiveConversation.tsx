import React, { useState, useEffect, useRef, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, PhoneOff, RefreshCw, AlertTriangle, Activity, Volume2, Shield, Sparkles, Wifi } from 'lucide-react';
import { useMemoizedRoom, RoomConnectionState } from '../hooks/useMemoizedRoom';
import { AudioProcessingQueue } from '../lib/audio/Processor';
import { JitterBuffer } from '../lib/audio/JitterBuffer';
import { AudioStreamer } from '../lib/AudioStreamer';
import { AudioVisualizer } from './AudioVisualizer';
import { liveKitDiagnosticService } from '../lib/LiveKitDiagnosticService';

interface LiveConversationProps {
  userId?: string;
  roomName?: string;
  language?: string;
  onExit?: () => void;
}

export const LiveConversation: React.FC<LiveConversationProps> = ({
  userId = 'default_user',
  roomName = 'alya-live-room',
  language = 'auto',
  onExit
}) => {
  const [isMuted, setIsMuted] = useState(false);
  const [transcripts, setTranscripts] = useState<Array<{ id: string; sender: 'user' | 'assistant'; text: string; timestamp: number }>>([]);
  const [jitterMs, setJitterMs] = useState<number>(0);
  const [audioLatencyMs, setAudioLatencyMs] = useState<number>(0);
  const [analyserNode, setAnalyserNode] = useState<AnalyserNode | null>(null);

  // Audio Pipeline References
  const audioStreamerRef = useRef<AudioStreamer | null>(null);
  const audioQueueRef = useRef<AudioProcessingQueue | null>(null);
  const jitterBufferRef = useRef<JitterBuffer | null>(null);

  // Initialize Audio Queue and Streamer
  useEffect(() => {
    audioQueueRef.current = new AudioProcessingQueue(24000, 40);
    jitterBufferRef.current = new JitterBuffer();
    audioStreamerRef.current = new AudioStreamer();

    const interval = setInterval(() => {
      if (jitterBufferRef.current) {
        setJitterMs(Math.round(jitterBufferRef.current.getEstimatedJitterMs()));
        setAudioLatencyMs(Math.round(jitterBufferRef.current.getDynamicOffsetSeconds() * 1000));
      }
      if (audioStreamerRef.current) {
        setAnalyserNode(audioStreamerRef.current.getAnalyser());
      }
    }, 500);

    return () => {
      clearInterval(interval);
      audioStreamerRef.current?.close();
      audioQueueRef.current?.clear();
    };
  }, []);

  const handleAudioChunk = useCallback((base64Audio: string, sequence?: number, flushFirst?: boolean) => {
    if (!base64Audio) return;

    // Track network packet arrival times
    jitterBufferRef.current?.trackPacketArrival();

    // Stream through AudioStreamer which incorporates high-priority interrupt-and-clear strategy
    audioStreamerRef.current?.playChunk(base64Audio, sequence, flushFirst);
  }, []);

  const handleTextChunk = useCallback((text: string) => {
    if (!text.trim()) return;
    setTranscripts((prev) => [
      ...prev.slice(-20),
      {
        id: 'tx_' + Math.random().toString(36).substring(2, 9),
        sender: 'assistant',
        text,
        timestamp: Date.now()
      }
    ]);
  }, []);

  const handleInterrupted = useCallback(() => {
    audioStreamerRef.current?.stop();
  }, []);

  // Use Stable Memoized Room Service
  const { connectionState, errorMessage, retryAttempt, connect, disconnect, client } = useMemoizedRoom({
    userId,
    roomName,
    language,
    onAudio: handleAudioChunk,
    onText: handleTextChunk,
    onInterrupted: handleInterrupted,
    onError: (err) => {
      liveKitDiagnosticService.log('error', 'lifecycle', `[LiveConversation] Error: ${err}`);
    }
  });

  // Auto-connect on mount
  useEffect(() => {
    connect();
    return () => {
      disconnect();
    };
  }, []);

  const toggleMute = () => {
    setIsMuted(!isMuted);
  };

  const getStatusBadge = (state: RoomConnectionState) => {
    switch (state) {
      case 'connected':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"><span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Live</span>;
      case 'connecting':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30"><RefreshCw className="w-3 h-3 animate-spin" /> Connecting...</span>;
      case 'reconnecting':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/20 text-amber-400 border border-amber-500/30"><RefreshCw className="w-3 h-3 animate-spin" /> Reconnecting ({retryAttempt}/5)...</span>;
      case 'timeout':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-400 border border-red-500/30"><AlertTriangle className="w-3 h-3" /> Watchdog Reset</span>;
      case 'error':
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 text-red-400 border border-red-500/30"><AlertTriangle className="w-3 h-3" /> Error</span>;
      default:
        return <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-slate-500/20 text-slate-400 border border-slate-500/30">Disconnected</span>;
    }
  };

  return (
    <div className="flex flex-col h-full w-full bg-slate-950 text-white p-4 sm:p-6 rounded-3xl relative overflow-hidden select-none border border-slate-800 shadow-2xl">
      {/* Background Glow */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 rounded-full blur-3xl transition-all duration-1000 ${connectionState === 'connected' ? 'bg-indigo-600/20 scale-110' : 'bg-slate-800/20 scale-90'}`} />
      </div>

      {/* Top Bar */}
      <div className="flex items-center justify-between relative z-10 mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 flex items-center justify-center border border-indigo-500/30">
            <Sparkles className="w-5 h-5 text-indigo-400" />
          </div>
          <div>
            <h2 className="text-lg font-bold tracking-tight">Live Conversation</h2>
            <p className="text-xs text-slate-400 font-mono">LiveKit PCM Worklet Engine</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {getStatusBadge(connectionState)}
          {onExit && (
            <button
              onClick={onExit}
              className="p-2.5 rounded-xl bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-400 hover:text-white transition-all active:scale-95"
              title="Close"
            >
              <PhoneOff className="w-5 h-5 text-red-400" />
            </button>
          )}
        </div>
      </div>

      {/* Connection Watchdog Alert / Error Message */}
      <AnimatePresence>
        {errorMessage && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            className="mb-4 p-3.5 rounded-2xl bg-red-950/80 border border-red-800/80 text-red-200 text-xs flex items-center justify-between gap-3 relative z-10 shadow-lg"
          >
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => connect()}
              className="px-3 py-1 rounded-xl bg-red-800 hover:bg-red-700 font-semibold text-xs transition-all active:scale-95"
            >
              Retry
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Real-time Web Audio API Spectrum Visualizer */}
      <div className="mb-4 relative z-10">
        <AudioVisualizer
          analyserNode={analyserNode}
          isActive={connectionState === 'connected'}
          barCount={36}
          height={88}
          colorTheme="indigo"
        />
      </div>

      {/* Latency & Jitter Monitor HUD */}
      <div className="grid grid-cols-2 gap-3 mb-4 relative z-10">
        <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
          <Activity className="w-5 h-5 text-indigo-400" />
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Network Jitter</div>
            <div className="text-sm font-mono font-bold text-slate-200">{jitterMs} ms</div>
          </div>
        </div>
        <div className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800/80 flex items-center gap-3">
          <Wifi className="w-5 h-5 text-emerald-400" />
          <div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider font-semibold">Playback Offset</div>
            <div className="text-sm font-mono font-bold text-slate-200">{audioLatencyMs} ms</div>
          </div>
        </div>
      </div>

      {/* Real-Time Transcript Stream */}
      <div className="flex-1 overflow-y-auto space-y-3 p-4 rounded-2xl bg-slate-900/40 border border-slate-800/60 mb-6 relative z-10 custom-scrollbar min-h-[140px]">
        {transcripts.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center text-slate-500 p-6">
            <Volume2 className="w-8 h-8 mb-2 stroke-[1.5] text-slate-600 animate-pulse" />
            <p className="text-xs">Start speaking to initiate real-time conversational voice.</p>
          </div>
        ) : (
          transcripts.map((t) => (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 5 }}
              animate={{ opacity: 1, y: 0 }}
              className="p-3 rounded-xl bg-indigo-950/40 border border-indigo-900/30 text-slate-200 text-xs"
            >
              <div className="text-[10px] text-indigo-400 font-bold mb-1">Alya Assistant</div>
              <div>{t.text}</div>
            </motion.div>
          ))
        )}
      </div>

      {/* Control Toolbar */}
      <div className="flex items-center justify-center gap-4 relative z-10">
        <button
          onClick={toggleMute}
          className={`p-4 rounded-2xl font-semibold flex items-center justify-center gap-2 transition-all active:scale-95 border ${isMuted ? 'bg-red-500/20 border-red-500/30 text-red-400' : 'bg-slate-900 hover:bg-slate-800 border-slate-800 text-white'}`}
          title={isMuted ? 'Unmute Microphone' : 'Mute Microphone'}
        >
          {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        </button>

        <button
          onClick={connectionState === 'connected' ? disconnect : connect}
          className={`px-6 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 transition-all active:scale-95 shadow-lg ${connectionState === 'connected' ? 'bg-red-600 hover:bg-red-500 text-white' : 'bg-indigo-600 hover:bg-indigo-500 text-white'}`}
        >
          {connectionState === 'connected' ? (
            <>
              <PhoneOff className="w-5 h-5" />
              <span>End Call</span>
            </>
          ) : (
            <>
              <RefreshCw className={`w-5 h-5 ${connectionState === 'connecting' ? 'animate-spin' : ''}`} />
              <span>{connectionState === 'connecting' ? 'Connecting...' : 'Connect Live'}</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};
