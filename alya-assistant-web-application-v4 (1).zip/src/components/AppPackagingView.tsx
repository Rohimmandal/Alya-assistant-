import React, { useState } from 'react';
import { Download, Terminal, Smartphone, Monitor, CheckCircle2, Copy, RefreshCw, Cpu, ShieldAlert, Sparkles } from 'lucide-react';

export function AppPackagingView() {
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);
  const [buildingWin, setBuildingWin] = useState(false);
  const [buildingAndroid, setBuildingAndroid] = useState(false);
  const [buildLogs, setBuildLogs] = useState<string[]>([
    'System ready for Windows .exe & Android APK packaging.',
    'Electron main process configured at /electron.js',
    'Capacitor config initialized at /capacitor.config.json'
  ]);

  const handleCopy = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(cmd);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const simulateBuildWin = () => {
    setBuildingWin(true);
    setBuildLogs(prev => [...prev, 'Starting Vite production build for Windows .exe...']);
    setTimeout(() => {
      setBuildLogs(prev => [
        ...prev,
        'Vite build completed successfully into /dist.',
        'Running electron-builder --win (NSIS & Portable target)...',
        'Windows .exe package generated in /release folder successfully!'
      ]);
      setBuildingWin(false);
    }, 3000);
  };

  const simulateBuildAndroid = () => {
    setBuildingAndroid(true);
    setBuildLogs(prev => [...prev, 'Syncing web assets with Capacitor Android...']);
    setTimeout(() => {
      setBuildLogs(prev => [
        ...prev,
        'Capacitor sync complete. Android project updated at /android.',
        'Ready to open Android Studio for APK debug build (`npx cap open android`).'
      ]);
      setBuildingAndroid(false);
    }, 3000);
  };

  return (
    <div className="h-full overflow-y-auto bg-slate-950 text-slate-100 p-6 lg:p-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-800 pb-6">
          <div>
            <div className="flex items-center gap-2 text-indigo-400 text-sm font-semibold mb-1">
              <Sparkles className="w-4 h-4" />
              <span>Native & Desktop Packaging Engine</span>
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-white">Windows .exe & Android APK Debugger</h1>
            <p className="text-slate-400 mt-1">
              Optimize, package, and test Alya Assistant as a native Windows desktop app (.exe) and Android mobile app (.apk).
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={simulateBuildWin}
              disabled={buildingWin}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl font-medium text-sm transition-all shadow-lg shadow-indigo-600/20"
            >
              {buildingWin ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Monitor className="w-4 h-4" />}
              <span>{buildingWin ? 'Building .exe...' : 'Build Windows .exe'}</span>
            </button>
            <button 
              onClick={simulateBuildAndroid}
              disabled={buildingAndroid}
              className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white px-4 py-2.5 rounded-xl font-medium text-sm transition-all shadow-lg shadow-emerald-600/20"
            >
              {buildingAndroid ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Smartphone className="w-4 h-4" />}
              <span>{buildingAndroid ? 'Syncing APK...' : 'Prepare Android APK'}</span>
            </button>
          </div>
        </div>

        {/* Grid Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Windows .exe Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-indigo-500/10 flex items-center justify-center text-indigo-400">
                  <Monitor className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-lg">Windows Desktop (.exe)</h3>
                  <p className="text-xs text-slate-400">Electron Wrapper & NSIS Installer</p>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-indigo-500/20 text-indigo-300 text-xs font-medium rounded-full border border-indigo-500/30">Ready</span>
            </div>

            <p className="text-sm text-slate-300">
              Alya runs locally inside Electron with full Node.js access, hardware microphone streaming, and zero CORS limitations for debugging.
            </p>

            <div className="space-y-3 pt-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Quick Commands</div>
              
              <div className="flex items-center justify-between bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800">
                <code className="text-xs text-indigo-300 font-mono">npm run electron:dev</code>
                <button 
                  onClick={() => handleCopy('npm run electron:dev')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                  title="Copy command"
                >
                  {copiedCmd === 'npm run electron:dev' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="flex items-center justify-between bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800">
                <code className="text-xs text-indigo-300 font-mono">npm run electron:build</code>
                <button 
                  onClick={() => handleCopy('npm run electron:build')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                  title="Copy command"
                >
                  {copiedCmd === 'npm run electron:build' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="bg-indigo-950/30 border border-indigo-900/50 rounded-xl p-3 text-xs text-indigo-200">
              <span className="font-semibold">Output Directory:</span> Generated executables will appear in the <code className="text-indigo-300 font-mono">/release</code> folder.
            </div>
          </div>

          {/* Android APK Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-semibold text-white text-lg">Android Mobile (.apk)</h3>
                  <p className="text-xs text-slate-400">Capacitor Native Bridge & Android Studio</p>
                </div>
              </div>
              <span className="px-2.5 py-1 bg-emerald-500/20 text-emerald-300 text-xs font-medium rounded-full border border-emerald-500/30">Configured</span>
            </div>

            <p className="text-sm text-slate-300">
              Packaged with Capacitor for seamless microphone permissions, WebSocket Live voice streaming, and WebView optimization on Android devices.
            </p>

            <div className="space-y-3 pt-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Quick Commands</div>
              
              <div className="flex items-center justify-between bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800">
                <code className="text-xs text-emerald-300 font-mono">npm run cap:sync</code>
                <button 
                  onClick={() => handleCopy('npm run cap:sync')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                  title="Copy command"
                >
                  {copiedCmd === 'npm run cap:sync' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="flex items-center justify-between bg-slate-950 px-3.5 py-2.5 rounded-xl border border-slate-800">
                <code className="text-xs text-emerald-300 font-mono">npm run cap:open</code>
                <button 
                  onClick={() => handleCopy('npm run cap:open')}
                  className="text-slate-400 hover:text-white p-1 rounded transition-colors"
                  title="Copy command"
                >
                  {copiedCmd === 'npm run cap:open' ? <CheckCircle2 className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="bg-emerald-950/30 border border-emerald-900/50 rounded-xl p-3 text-xs text-emerald-200">
              <span className="font-semibold">Android Studio:</span> Run <code className="text-emerald-300 font-mono">npx cap open android</code> to build APK or debug on device.
            </div>
          </div>
        </div>

        {/* Build Terminal Logs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-slate-300 font-medium text-sm">
              <Terminal className="w-4 h-4 text-indigo-400" />
              <span>Packaging Console & Debug Logs</span>
            </div>
            <button 
              onClick={() => setBuildLogs(['Console cleared. Ready.'])}
              className="text-xs text-slate-400 hover:text-slate-200 transition-colors"
            >
              Clear Logs
            </button>
          </div>

          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 font-mono text-xs text-slate-300 h-48 overflow-y-auto space-y-1.5">
            {buildLogs.map((log, idx) => (
              <div key={idx} className="flex items-start gap-2">
                <span className="text-indigo-400">›</span>
                <span>{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
