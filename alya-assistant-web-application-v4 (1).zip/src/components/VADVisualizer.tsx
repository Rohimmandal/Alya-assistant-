import React, { useEffect, useRef, useState, useId } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Mic, MicOff, Activity, Radio, Volume2, Sparkles, VolumeX, ShieldAlert } from 'lucide-react';

export interface VADVisualizerProps {
  analyser?: AnalyserNode | null;
  isActive: boolean;
  isListening?: boolean;
  isMuted?: boolean;
  isPaused?: boolean;
  className?: string;
  variant?: 'hero' | 'compact' | 'minimal';
  showSignalMeter?: boolean;
  showWaveform?: boolean;
  barCount?: number;
  sensitivityThreshold?: number; // 0.0 to 1.0 (default 0.035 RMS for speech VAD)
  onSpeechActivityChange?: (isSpeech: boolean, rms: number) => void;
}

export const VADVisualizer: React.FC<VADVisualizerProps> = ({
  analyser,
  isActive,
  isListening = true,
  isMuted = false,
  isPaused = false,
  className = '',
  variant = 'hero',
  showSignalMeter = true,
  showWaveform = true,
  barCount = 28,
  sensitivityThreshold = 0.035,
  onSpeechActivityChange
}) => {
  const [rmsEnergy, setRmsEnergy] = useState<number>(0);
  const [decibels, setDecibels] = useState<number>(-60);
  const [peakLevel, setPeakLevel] = useState<number>(0);
  const [isSpeechDetected, setIsSpeechDetected] = useState<boolean>(false);
  const [waveformBars, setWaveformBars] = useState<number[]>(() => new Array(barCount).fill(6));

  const animFrameRef = useRef<number | null>(null);
  const speechHangoverTimerRef = useRef<NodeJS.Timeout | null>(null);
  const peakDecayTimerRef = useRef<number>(0);
  const gradientId = useId();

  useEffect(() => {
    if (!isActive || isPaused || isMuted) {
      setRmsEnergy(0);
      setDecibels(-60);
      setIsSpeechDetected(false);
      setWaveformBars(new Array(barCount).fill(6));
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      return;
    }

    let rawDataArray: Uint8Array | null = null;
    let timeDomainArray: Uint8Array | null = null;

    if (analyser) {
      try {
        rawDataArray = new Uint8Array(new ArrayBuffer(analyser.frequencyBinCount));
        timeDomainArray = new Uint8Array(new ArrayBuffer(analyser.fftSize));
      } catch (e) {
        console.warn('[VADVisualizer] Analyser buffer alloc error:', e);
      }
    }

    let phase = 0;

    const tick = () => {
      phase += 0.08;
      let calculatedRms = 0;
      let currentDb = -60;
      const newBars: number[] = [];

      if (analyser && rawDataArray && timeDomainArray) {
        // 1. Read Time-Domain waveform for true RMS calculation
        analyser.getByteTimeDomainData(timeDomainArray as any);
        let sumSquares = 0;
        for (let i = 0; i < timeDomainArray.length; i++) {
          const sample = (timeDomainArray[i] - 128) / 128.0;
          sumSquares += sample * sample;
        }
        calculatedRms = Math.sqrt(sumSquares / timeDomainArray.length);

        // Convert RMS to dBFS (-60 dB to 0 dB)
        currentDb = calculatedRms > 0.0001 
          ? Math.max(-60, Math.min(0, Math.round(20 * Math.log10(calculatedRms))))
          : -60;

        // 2. Read Frequency data for spectral waveform bars
        analyser.getByteFrequencyData(rawDataArray as any);
        const binStep = Math.max(1, Math.floor(rawDataArray.length / barCount));

        for (let b = 0; b < barCount; b++) {
          let binAvg = 0;
          const startIdx = b * binStep;
          const endIdx = Math.min(rawDataArray.length, startIdx + binStep);
          for (let j = startIdx; j < endIdx; j++) {
            binAvg += rawDataArray[j];
          }
          binAvg = binAvg / Math.max(1, endIdx - startIdx);
          
          // Normalized height 6% to 100% with vocal bell-curve weighting
          const normalized = (binAvg / 255);
          const centerDist = Math.abs(b - barCount / 2) / (barCount / 2);
          const weight = 1.0 - centerDist * 0.35;
          const barHeight = Math.max(6, Math.min(100, Math.round(normalized * 100 * weight + (calculatedRms * 30))));
          newBars.push(barHeight);
        }
      } else {
        // Fallback simulation if analyser is waiting for stream
        const fallbackWave = Math.sin(phase) * 0.02 + 0.02;
        calculatedRms = fallbackWave;
        currentDb = Math.max(-60, Math.min(0, Math.round(20 * Math.log10(calculatedRms || 0.001))));
        for (let b = 0; b < barCount; b++) {
          const h = Math.sin(phase + b * 0.3) * 10 + 12;
          newBars.push(Math.max(6, h));
        }
      }

      setRmsEnergy(calculatedRms);
      setDecibels(currentDb);
      setWaveformBars(newBars);

      // Peak Hold Logic
      if (calculatedRms > peakDecayTimerRef.current) {
        peakDecayTimerRef.current = calculatedRms;
      } else {
        peakDecayTimerRef.current = Math.max(0, peakDecayTimerRef.current - 0.005);
      }
      setPeakLevel(peakDecayTimerRef.current);

      // 3. Voice Activity Detection (VAD) with 250ms Hangover to prevent speech flickering
      const speechDetectedNow = calculatedRms >= sensitivityThreshold;
      if (speechDetectedNow) {
        if (speechHangoverTimerRef.current) {
          clearTimeout(speechHangoverTimerRef.current);
          speechHangoverTimerRef.current = null;
        }
        setIsSpeechDetected(true);
        onSpeechActivityChange?.(true, calculatedRms);
      } else {
        if (!speechHangoverTimerRef.current && isSpeechDetected) {
          speechHangoverTimerRef.current = setTimeout(() => {
            setIsSpeechDetected(false);
            onSpeechActivityChange?.(false, calculatedRms);
            speechHangoverTimerRef.current = null;
          }, 240);
        }
      }

      animFrameRef.current = requestAnimationFrame(tick);
    };

    animFrameRef.current = requestAnimationFrame(tick);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      if (speechHangoverTimerRef.current) {
        clearTimeout(speechHangoverTimerRef.current);
        speechHangoverTimerRef.current = null;
      }
    };
  }, [isActive, isPaused, isMuted, analyser, barCount, sensitivityThreshold, onSpeechActivityChange]);

  // Meter percentage (from -60dB to 0dB)
  const meterPercent = Math.max(0, Math.min(100, Math.round(((decibels + 60) / 60) * 100)));
  const peakPercent = Math.max(0, Math.min(100, Math.round(peakLevel * 180)));
  const thresholdPercent = Math.max(0, Math.min(100, Math.round(((20 * Math.log10(sensitivityThreshold) + 60) / 60) * 100)));

  // If minimal variant requested
  if (variant === 'minimal') {
    return (
      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/90 border border-white/10 backdrop-blur-md ${className}`}>
        <div className={`w-2 h-2 rounded-full ${
          isMuted ? 'bg-rose-500' : 
          isPaused ? 'bg-amber-400' :
          isSpeechDetected ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse' : 
          'bg-indigo-400/80'
        }`} />
        <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-300">
          {isMuted ? 'Muted' : isPaused ? 'Paused' : isSpeechDetected ? 'Voice Active' : 'Mic Ready'}
        </span>
        {/* Compact Waveform */}
        <div className="flex items-center gap-0.5 h-4 w-16">
          {waveformBars.slice(0, 10).map((h, i) => (
            <div
              key={`${gradientId}-compact-${i}`}
              style={{ height: `${h}%` }}
              className={`w-1 rounded-full transition-all duration-75 ${
                isSpeechDetected ? 'bg-emerald-400' : 'bg-slate-600'
              }`}
            />
          ))}
        </div>
      </div>
    );
  }

  // Hero / Full HUD Variant
  return (
    <div className={`w-full mx-auto relative overflow-hidden transition-all duration-300 ${
      isSpeechDetected ? 'drop-shadow-[0_0_20px_rgba(16,185,129,0.15)]' : ''
    } ${className}`}>
      
      {/* Background Ambient Glow */}
      <div 
        className={`absolute -top-12 -left-12 w-36 h-36 rounded-full blur-3xl pointer-events-none transition-opacity duration-500 ${
          isSpeechDetected ? 'bg-emerald-500/20 opacity-100' : 'bg-indigo-500/10 opacity-40'
        }`} 
      />
      <div 
        className={`absolute -bottom-12 -right-12 w-36 h-36 rounded-full blur-3xl pointer-events-none transition-opacity duration-500 ${
          isSpeechDetected ? 'bg-cyan-500/20 opacity-100' : 'bg-violet-500/10 opacity-30'
        }`} 
      />

      {/* Header Info Row: Level Readout (Sensor text removed as per request) */}
      <div className="flex items-center justify-between gap-3 mb-3 relative z-10 px-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className={`p-1.5 rounded-xl border flex items-center justify-center transition-all ${
            isMuted 
              ? 'bg-rose-500/10 border-rose-500/30 text-rose-400'
              : isPaused
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              : isSpeechDetected
              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.3)]'
              : 'bg-indigo-500/10 border-indigo-500/30 text-indigo-400'
          }`}>
            {isMuted ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5">
              <span className={`px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider border flex items-center gap-1 ${
                isMuted
                  ? 'bg-rose-950/60 text-rose-300 border-rose-500/30'
                  : isPaused
                  ? 'bg-amber-950/60 text-amber-300 border-amber-500/30'
                  : isSpeechDetected
                  ? 'bg-emerald-950/70 text-emerald-300 border-emerald-500/40 shadow-xs'
                  : 'bg-slate-800 text-slate-300 border-slate-700'
              }`}>
                <span className={`w-1.5 h-1.5 rounded-full ${
                  isMuted ? 'bg-rose-500' :
                  isPaused ? 'bg-amber-400' :
                  isSpeechDetected ? 'bg-emerald-400 animate-ping' :
                  'bg-indigo-400'
                }`} />
                {isMuted ? 'MUTED' : isPaused ? 'PAUSED' : isSpeechDetected ? 'SPEECH DETECTED' : 'LISTENING'}
              </span>
            </div>
          </div>
        </div>

        {/* Real-time Level Numerical Badge */}
        <div className="flex flex-col items-end shrink-0">
          <span className="text-[10px] font-mono text-slate-400">SIGNAL LEVEL</span>
          <span className={`text-xs font-mono font-bold ${
            isSpeechDetected ? 'text-emerald-400' : 'text-slate-300'
          }`}>
            {decibels > -60 ? `${decibels} dBFS` : '< -60 dBFS'}
          </span>
        </div>
      </div>

      {/* Dynamic Audio Waveform Equalizer Display - Responsive scaling */}
      {showWaveform && (
        <div className="my-3 py-4 px-2 rounded-2xl bg-slate-950/30 border border-white/5 relative flex items-center justify-between gap-1 h-[25vh] min-h-[120px] max-h-[320px] overflow-hidden">
          {waveformBars.map((height, idx) => (
            <div
              key={`${gradientId}-${idx}`}
              className="flex-1 h-full flex items-center justify-center"
            >
              <div
                style={{ height: `${Math.max(4, height)}%` }}
                className={`w-full max-w-[10px] rounded-full transition-all duration-75 ${
                  isMuted
                    ? 'bg-slate-800'
                    : isSpeechDetected
                    ? 'bg-gradient-to-t from-emerald-500 via-teal-400 to-cyan-300 shadow-[0_0_20px_rgba(52,211,153,0.7)]'
                    : isListening
                    ? 'bg-gradient-to-t from-indigo-600 via-indigo-400 to-purple-400 shadow-[0_0_10px_rgba(99,102,241,0.3)]'
                    : 'bg-slate-700/60'
                }`}
              />
            </div>
          ))}

          {/* Center line guide for zero-level reference */}
          <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-px bg-white/10 pointer-events-none" />
          
          {/* Immersive HUD Overlays */}
          <div className="absolute top-4 left-4 flex gap-1 pointer-events-none">
            <div className="w-1 h-1 bg-white/20 rounded-full" />
            <div className="w-1 h-1 bg-white/20 rounded-full" />
          </div>
          <div className="absolute bottom-4 right-4 text-[8px] font-mono text-white/10 pointer-events-none uppercase tracking-widest">
            Neural Signal Trace v2.0
          </div>
        </div>
      )}

      {/* Signal Level VU Meter with Calibrated Decibel Gradations & Threshold Marker */}
      {showSignalMeter && (
        <div className="space-y-1.5 mt-2">
          {/* Meter Bar Container */}
          <div className="relative h-2.5 w-full bg-slate-950 rounded-full border border-white/10 p-0.5 overflow-hidden">
            {/* Active Level Fill Bar */}
            <div
              style={{ width: `${meterPercent}%` }}
              className={`h-full rounded-full transition-all duration-75 ${
                isMuted
                  ? 'bg-slate-800'
                  : isSpeechDetected
                  ? 'bg-gradient-to-r from-emerald-500 via-teal-400 to-cyan-400 shadow-[0_0_10px_rgba(52,211,153,0.6)]'
                  : 'bg-gradient-to-r from-indigo-600 to-indigo-400'
              }`}
            />

            {/* Peak Level Hold Indicator */}
            {peakPercent > 0 && !isMuted && (
              <div
                style={{ left: `${Math.min(99, peakPercent)}%` }}
                className="absolute top-0 bottom-0 w-1 bg-white/90 shadow-[0_0_6px_#fff] rounded-full pointer-events-none"
              />
            )}

            {/* VAD Sensitivity Threshold Gate Marker */}
            <div
              style={{ left: `${thresholdPercent}%` }}
              className="absolute top-0 bottom-0 w-0.5 bg-amber-400/80 pointer-events-none z-10"
              title="VAD Speech Detection Threshold"
            />
          </div>

          {/* Scale Labels & Threshold Callout */}
          <div className="flex items-center justify-between text-[9px] font-mono text-slate-500 px-0.5">
            <span>-60dB</span>
            <span>-36dB</span>
            <span className="text-amber-400/90 font-bold flex items-center gap-0.5">
              ▲ Gate ({Math.round(20 * Math.log10(sensitivityThreshold))}dB)
            </span>
            <span>-12dB</span>
            <span>0dB</span>
          </div>
        </div>
      )}
    </div>
  );
};
