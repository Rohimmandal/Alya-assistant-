import React, { useState, useRef, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useVirtualizer } from '@tanstack/react-virtual';
import { 
  Send, 
  Sparkles, 
  AlertCircle, 
  Phone, 
  History, 
  Zap, 
  RotateCcw, 
  Mic, 
  Search, 
  X, 
  Download, 
  ArrowDown, 
  Volume2, 
  VolumeX,
  WifiOff,
  Key
} from 'lucide-react';
import { useConversation } from '../hooks/useConversation';
import { conversationService } from '../services/conversationService';
import { userSettingsService } from '../lib/userSettingsService';
import { useAuth } from '../lib/AuthContext';
import { useGlobalSettings } from '../lib/GlobalSettingsContext';
import { ConversationSidebar } from './ConversationSidebar';
import { ChatMessageBubble } from './ChatMessageBubble';
import { ChatSuggestions } from './ChatSuggestions';
import { JarvisHUD, AssistantState } from './JarvisHUD';
import { playAlyaVoice, streamAlyaVoice, stopAlyaVoice, isLiveCallActive } from '../lib/femaleVoiceSynthesizer';
import { AlyaPersonalityEngine } from '../lib/AlyaPersonalityEngine';
import { VoiceEngineDiagnostics } from '../lib/VoiceEngine';
import { NotificationManager } from '../lib/NotificationManager';

export function ChatView() {
  const { preferences: globalPrefs, preferredLanguage } = useGlobalSettings();
  const {
    conversations,
    activeConversationId,
    messages,
    isTyping,
    isOffline,
    error,
    lastLatencyMs,
    sendMessage,
    createNewConversation,
    selectConversation,
    renameConversation,
    deleteConversation,
    clearAllConversations,
    retryLastMessage
  } = useConversation();

  const [input, setInput] = useState('');
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [searchInChat, setSearchInChat] = useState('');
  const [showSearch, setShowSearch] = useState(false);
  const [showScrollBottom, setShowScrollBottom] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [autoReadResponses, setAutoReadResponses] = useState<boolean>(() => localStorage.getItem('alya_auto_read_responses') === 'true');
  const [isPrewarming, setIsPrewarming] = useState(false);
  const [hasPrewarmedAudio, setHasPrewarmedAudio] = useState(false);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const handle = requestAnimationFrame(() => {
      setIsReady(true);
    });
    return () => cancelAnimationFrame(handle);
  }, []);

  // Pre-warms Web Audio Context & verifies microphone permissions on input field focus
  const handleInputFocus = async () => {
    if (hasPrewarmedAudio) return;
    setIsPrewarming(true);
    try {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtxClass();
      if (ctx.state === 'suspended') {
        await ctx.resume().catch(() => {});
      }
      const buffer = ctx.createBuffer(1, 1, ctx.sampleRate);
      const src = ctx.createBufferSource();
      src.buffer = buffer;
      src.connect(ctx.destination);
      src.start(0);

      await VoiceEngineDiagnostics.prewarmTTSGenerator({
        audioCtx: ctx,
        checkMicFocus: true
      });

      setHasPrewarmedAudio(true);
    } catch (e) {
      console.warn('[ChatView] Audio pre-warm note:', e);
    } finally {
      setIsPrewarming(false);
    }
  };

  const scrollRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const recognitionRef = useRef<any>(null);
  const lastSpokenMessageIdRef = useRef<string | null>(null);
  const lastSpokenContentRef = useRef<string | null>(null);
  const lastActivityTimeRef = useRef<number>(Date.now());
  const { user } = useAuth();

  // Update last activity time when messages or typing state changes
  useEffect(() => {
    lastActivityTimeRef.current = Date.now();
  }, [messages, isTyping]);

  // Proactive Conversational Triggers (Idle Nudges)
  useEffect(() => {
    const IDLE_THRESHOLD = 30 * 1000; // 30 seconds as requested
    const CHECK_INTERVAL = 10 * 1000; // Check every 10 seconds

    const idleTimer = setInterval(async () => {
      // Don't nudge if user is typing, listening, or if we're in a live call
      if (isTyping || isListening || isLiveCallActive()) return;
      
      const now = Date.now();
      const idleTime = now - lastActivityTimeRef.current;

      if (idleTime >= IDLE_THRESHOLD) {
        // Reset timer to prevent immediate double nudge
        lastActivityTimeRef.current = now;

        // Only nudge if there's actually a conversation history to react to
        if (messages.length === 0) return;

        // Avoid double nudging if the very last message was already a nudge
        const lastMsg = messages[messages.length - 1];
        if (lastMsg.role === 'assistant' && (lastMsg as any).isProactiveNudge) return;

        const prefs = userSettingsService.getPreferences();
        const nudgeText = AlyaPersonalityEngine.getProactiveNudge(prefs.language || 'en');
        
        // Logically append nudge to conversation via Firestore
        if (user && activeConversationId) {
          try {
            await conversationService.addMessage(user.uid, activeConversationId, {
              role: 'assistant',
              content: nudgeText,
              agentName: 'Alya',
              intent: 'proactive_nudge',
              isProactiveNudge: true, // Special flag to track nudges
              userId: user.uid,
              conversationId: activeConversationId
            } as any);
          } catch (e) {
            console.warn('[ChatView] Failed to send proactive nudge:', e);
          }
        }
      }
    }, CHECK_INTERVAL);

    return () => clearInterval(idleTimer);
  }, [messages, isTyping, isListening, user, activeConversationId]);

  const getHudState = (): AssistantState => {
    if (isListening) return 'Listening';
    if (isTyping) return 'Thinking';
    const lastMsg = messages[messages.length - 1];
    if (lastMsg && lastMsg.role === 'assistant') {
      if (lastMsg.verified === false) return 'Failed';
      if (lastMsg.intent === 'weather_query' || lastMsg.intent === 'web_search') return 'Searching';
      return 'Completed';
    }
    return 'Completed';
  };

  // Filter messages if search active
  const filteredMessages = searchInChat.trim() 
    ? messages.filter(m => m.content.toLowerCase().includes(searchInChat.toLowerCase()))
    : messages;

  // Virtualizer for snappy performance across thousands of messages
  const rowVirtualizer = useVirtualizer({
    count: filteredMessages.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => 110,
    overscan: 12,
    getItemKey: (index) => `${filteredMessages[index]?.id || 'row'}-${index}`,
  });

  // Play gentle subtle feedback audio on message sent/received
  const playFeedbackChime = useCallback((type: 'send' | 'receive') => {
    if (!soundEnabled) return;
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);

      if (type === 'send') {
        osc.frequency.setValueAtTime(440, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.04, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
        osc.start();
        osc.stop(ctx.currentTime + 0.1);
      } else {
        osc.frequency.setValueAtTime(587.33, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.15);
        gain.gain.setValueAtTime(0.05, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.15);
        osc.start();
        osc.stop(ctx.currentTime + 0.15);
      }
    } catch {}
  }, [soundEnabled]);

  // Track message count and first message ID for scroll-anchoring when history loads
  const prevMsgCountRef = useRef(messages.length);
  const firstMsgIdRef = useRef<string | null>(filteredMessages[0]?.id || null);
  const prevScrollHeightRef = useRef<number>(0);

  // Preserve scroll position when older message history is prepended
  useEffect(() => {
    const newFirstId = filteredMessages[0]?.id || null;
    const isPrepended = firstMsgIdRef.current && newFirstId && firstMsgIdRef.current !== newFirstId && filteredMessages.length > prevMsgCountRef.current;

    if (isPrepended && scrollRef.current && prevScrollHeightRef.current > 0) {
      const newScrollHeight = scrollRef.current.scrollHeight;
      const heightDiff = newScrollHeight - prevScrollHeightRef.current;
      scrollRef.current.scrollTop += heightDiff;
    }

    firstMsgIdRef.current = newFirstId;
    if (scrollRef.current) {
      prevScrollHeightRef.current = scrollRef.current.scrollHeight;
    }
  }, [filteredMessages]);

  // Auto-scroll to bottom only on new message arrival when user is at the bottom
  useEffect(() => {
    const isNewMessage = messages.length > prevMsgCountRef.current;
    prevMsgCountRef.current = messages.length;

    if (isNewMessage && filteredMessages.length > 0 && !showScrollBottom) {
      requestAnimationFrame(() => {
        rowVirtualizer.scrollToIndex(filteredMessages.length - 1, { 
          align: 'end', 
          behavior: 'auto' 
        });
      });
    }
    
    if (messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'assistant') {
        if (lastSpokenMessageIdRef.current !== lastMsg.id) {
          console.log(`[ChatView] Triggering audio for new message: ${lastMsg.id}`);
          lastSpokenMessageIdRef.current = lastMsg.id;
          lastSpokenContentRef.current = lastMsg.content;
          playFeedbackChime('receive');
          
          // Trigger Background Notification if hidden
          if (NotificationManager.isBackground()) {
            NotificationManager.showNotification('Alya LIVE', lastMsg.content, {
              conversationId: activeConversationId,
              userId: user?.uid
            });
          }
          
          if (soundEnabled && autoReadResponses && !isLiveCallActive()) {
            const formattedForSpeech = AlyaPersonalityEngine.formatResponse(lastMsg.content, {
              language: preferredLanguage
            });
            playAlyaVoice(formattedForSpeech, { 
              id: lastMsg.id,
              language: preferredLanguage,
              voiceName: globalPrefs.voiceName
            });
          }
        } else if (lastSpokenContentRef.current !== lastMsg.content) {
            const newContent = lastMsg.content.slice(lastSpokenContentRef.current?.length || 0);
            if (newContent.trim()) {
                console.log(`[ChatView] Streaming update for message ${lastMsg.id}: "${newContent.slice(0, 20)}..."`);
                const formattedNewContent = AlyaPersonalityEngine.formatResponse(newContent, {
                    language: preferredLanguage
                });
                lastSpokenContentRef.current = lastMsg.content;
                streamAlyaVoice(formattedNewContent, { 
                    id: lastMsg.id,
                    language: preferredLanguage,
                    voiceName: globalPrefs.voiceName
                });
            }
        }
      }
    }
  }, [messages, filteredMessages.length, isTyping, playFeedbackChime, soundEnabled, autoReadResponses]);

  // Support direct hamburger menu toggling from top bar
  useEffect(() => {
    const handleToggleHistory = () => {
      setIsHistoryOpen(prev => !prev);
    };
    window.addEventListener('toggle-history', handleToggleHistory);
    return () => {
      window.removeEventListener('toggle-history', handleToggleHistory);
    };
  }, []);

  // Track scroll position to display floating jump-to-bottom button
  const handleScroll = () => {
    if (!scrollRef.current) return;
    const { scrollTop, scrollHeight, clientHeight } = scrollRef.current;
    const distanceToBottom = scrollHeight - scrollTop - clientHeight;
    setShowScrollBottom(distanceToBottom > 180);
  };

  const scrollToBottom = () => {
    if (filteredMessages.length > 0) {
      rowVirtualizer.scrollToIndex(filteredMessages.length - 1, { 
        align: 'end', 
        behavior: 'smooth' 
      });
    } else if (scrollRef.current) {
      scrollRef.current.scrollTo({
        top: scrollRef.current.scrollHeight,
        behavior: 'smooth'
      });
    }
    setShowScrollBottom(false);
  };

  // Adjust textarea height dynamically
  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 140)}px`;
    }
  };

  const handleSend = (overrideMsg?: string) => {
    const textToSend = typeof overrideMsg === 'string' ? overrideMsg : input;
    if (!textToSend.trim()) return;

    playFeedbackChime('send');
    setInput('');
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
    sendMessage(textToSend);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  // Speech Recognition / Voice Dictation
  const toggleListening = () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('Speech Recognition is not supported in this browser. Please use Chrome or Edge.');
      return;
    }

    if (isListening) {
      recognitionRef.current?.stop();
      setIsListening(false);
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US';

      recognition.onstart = () => setIsListening(true);
      recognition.onresult = (event: any) => {
        const transcript = Array.from(event.results)
          .map((result: any) => result[0].transcript)
          .join('');
        setInput(transcript);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);

      recognitionRef.current = recognition;
      recognition.start();
    } catch (err) {
      console.error('Speech recognition error:', err);
      setIsListening(false);
    }
  };

  // Export Conversation as Markdown
  const exportConversation = () => {
    if (messages.length === 0) return;
    const currentConv = conversations.find(c => c.id === activeConversationId);
    const title = currentConv?.title || 'Alya-Conversation';
    
    let content = `# ${title}\nExported: ${new Date().toLocaleString()}\n\n---\n\n`;
    messages.forEach(m => {
      content += `### ${m.role === 'user' ? 'User' : (m.agentName || 'Alya')}:\n${m.content}\n\n`;
    });

    const blob = new Blob([content], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.toLowerCase().replace(/[^a-z0-9]/gi, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const currentSession = conversations.find(c => c.id === activeConversationId);
  const virtualItems = rowVirtualizer.getVirtualItems();

  if (!isReady) {
    return (
      <div className="flex items-center justify-center h-full bg-slate-50 dark:bg-slate-950">
        <div className="w-6 h-6 border-3 border-slate-300 border-t-slate-900 rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="flex h-full bg-slate-50/50 dark:bg-slate-950 overflow-hidden relative font-sans">
      {/* Collapsible History Sidebar */}
      <ConversationSidebar
        conversations={conversations}
        currentConversationId={activeConversationId}
        onSelectConversation={(id) => {
          selectConversation(id);
          if (typeof window !== 'undefined' && window.innerWidth < 768) {
            setIsHistoryOpen(false);
          }
        }}
        onNewConversation={() => {
          createNewConversation();
          if (typeof window !== 'undefined' && window.innerWidth < 768) {
            setIsHistoryOpen(false);
          }
        }}
        onRenameConversation={renameConversation}
        onDeleteConversation={deleteConversation}
        onClearAllConversations={clearAllConversations}
        isOpen={isHistoryOpen}
        onToggle={() => setIsHistoryOpen(prev => !prev)}
      />

      {/* Main Chat Interface */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden relative">
        {/* Sub-bar Action Bar for Quick Tools */}
        <div className="px-4 py-2 bg-white/50 dark:bg-slate-900/50 backdrop-blur-sm border-b border-slate-200/50 dark:border-slate-800/50 flex items-center justify-between text-xs font-semibold z-10 shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <span className="truncate text-slate-700 dark:text-slate-300 font-bold">
              {currentSession?.title || 'New Conversation'}
            </span>
            {lastLatencyMs !== null && (
              <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 font-mono text-[10px] font-bold shrink-0">
                <Zap className="w-3 h-3" />
                {lastLatencyMs}ms
              </span>
            )}
          </div>

          <div className="flex items-center gap-1.5 shrink-0">
            <button
              onClick={() => setShowSearch(prev => !prev)}
              className={`p-1.5 rounded-lg transition-colors ${
                showSearch 
                  ? 'bg-indigo-50 dark:bg-indigo-950/50 text-indigo-600 dark:text-indigo-400' 
                  : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200'
              }`}
              title="Search conversation"
            >
              <Search className="w-3.5 h-3.5" />
            </button>

            <button
              onClick={() => {
                const next = !autoReadResponses;
                setAutoReadResponses(next);
                localStorage.setItem('alya_auto_read_responses', String(next));
                if (!next) stopAlyaVoice();
              }}
              className={`px-2 py-1 rounded-lg text-[10px] font-bold transition-all flex items-center gap-1 shrink-0 ${
                autoReadResponses
                  ? 'bg-indigo-600/15 border border-indigo-500/30 text-indigo-600 dark:text-indigo-400'
                  : 'bg-slate-200/50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 hover:text-slate-700'
              }`}
              title={autoReadResponses ? "Auto-speak assistant responses is ON" : "Auto-speak assistant responses is OFF"}
            >
              <Volume2 className="w-3 h-3" />
              <span>{autoReadResponses ? 'Auto-TTS: ON' : 'Auto-TTS: OFF'}</span>
            </button>

            <button
              onClick={() => setSoundEnabled(prev => !prev)}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg transition-colors"
              title={soundEnabled ? "Mute audio cues" : "Enable audio cues"}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={exportConversation}
              disabled={messages.length === 0}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg transition-colors disabled:opacity-30"
              title="Export conversation"
            >
              <Download className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>


        {/* In-Chat Search Bar */}
        <AnimatePresence>
          {showSearch && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="px-4 py-2.5 bg-slate-100 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 flex items-center gap-2 overflow-hidden"
            >
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                type="text"
                autoFocus
                value={searchInChat}
                onChange={(e) => setSearchInChat(e.target.value)}
                placeholder="Search messages in this conversation..."
                className="flex-1 bg-transparent text-xs text-slate-800 dark:text-slate-200 outline-none placeholder:text-slate-400"
              />
              {searchInChat && (
                <span className="text-[11px] text-slate-400 font-mono">
                  {filteredMessages.length} match{filteredMessages.length === 1 ? '' : 'es'}
                </span>
              )}
              <button
                onClick={() => { setSearchInChat(''); setShowSearch(false); }}
                className="p-1 hover:text-slate-800 dark:hover:text-white text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Offline Status indicator */}
        {isOffline && (
          <div className="px-4 pt-3 shrink-0 flex justify-center">
            <div className="bg-slate-100 dark:bg-slate-900 text-slate-500 dark:text-slate-400 text-[10px] font-bold px-3 py-1.5 rounded-full border border-slate-200 dark:border-slate-800 flex items-center gap-2 animate-pulse">
              <WifiOff className="w-3 h-3" />
              OFFLINE MODE • DATA SYNCING IN BACKGROUND
            </div>
          </div>
        )}

        {/* Message Stream with DOM Virtualization */}
        <div 
          ref={scrollRef}
          onScroll={handleScroll}
          className="flex-1 overflow-y-auto p-4 md:p-6 virtual-scroll-container pb-safe"
        >
          {messages.length === 0 ? (
            <ChatSuggestions onSelectPrompt={(prompt) => handleSend(prompt)} />
          ) : (
            <div
              style={{
                height: `${rowVirtualizer.getTotalSize()}px`,
                width: '100%',
                position: 'relative',
              }}
            >
              {virtualItems.map((virtualRow) => {
                const msg = filteredMessages[virtualRow.index];
                if (!msg) return null;

                // ✅ CORRECT: Using virtualRow.key computed by TanStack Virtual with unique item ID & index
                return (
                  <div
                    key={virtualRow.key}
                    data-index={virtualRow.index}
                    ref={rowVirtualizer.measureElement}
                    style={{
                      position: 'absolute',
                      top: 0,
                      left: 0,
                      width: '100%',
                      transform: `translateY(${virtualRow.start}px)`,
                    }}
                    className="pb-5"
                  >
                    <ChatMessageBubble
                      message={msg}
                      onRetry={(text) => handleSend(text)}
                      onExecuteCommand={(cmd) => handleSend(cmd)}
                    />
                  </div>
                );
              })}
            </div>
          )}

          {/* Typing Indicator */}
          <AnimatePresence>
            {isTyping && (
              <motion.div
                key="typing-indicator"
                initial={{ opacity: 0, y: 6, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -4, scale: 0.98 }}
                transition={{ duration: 0.2 }}
                className="flex justify-start items-center gap-3 pl-1 pt-2"
              >
                <div className="w-8 h-8 rounded-2xl bg-gradient-to-tr from-indigo-600 to-violet-600 text-white flex items-center justify-center shrink-0 shadow-md shadow-indigo-500/20">
                  <Sparkles className="w-4 h-4 animate-pulse" />
                </div>

                <div className="bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 rounded-3xl rounded-tl-xs px-5 py-3.5 border border-slate-200/80 dark:border-slate-800/80 shadow-xs flex items-center gap-3">
                  <span className="text-xs font-semibold tracking-tight text-slate-600 dark:text-slate-300">
                    Alya is typing
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce"></span>
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.15s]"></span>
                    <span className="w-1.5 h-1.5 bg-indigo-500 rounded-full animate-bounce [animation-delay:0.3s]"></span>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Global API Error Banner: Catches 401, 403, 429 Gracefully without Crashing Session */}
          {error && (
            <div className="flex justify-center my-4 px-2">
              <div className="max-w-lg w-full bg-amber-50 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200 text-xs font-medium p-3.5 rounded-2xl border border-amber-200/80 dark:border-amber-900/60 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold text-amber-950 dark:text-amber-100">
                      {error.includes('Invalid') ? 'Invalid API Key' : error.includes('Rate') ? 'Rate Limited' : 'Request Notice'}
                    </p>
                    <p className="text-[11px] opacity-90 leading-relaxed mt-0.5">{error}</p>
                  </div>
                </div>

                <div className="flex items-center gap-2 self-end sm:self-auto shrink-0">
                  {error.includes('Invalid') || error.includes('Key') ? (
                    <button
                      onClick={() => window.dispatchEvent(new CustomEvent('alya:open-settings-modal'))}
                      className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-xs cursor-pointer flex items-center gap-1.5"
                    >
                      <Key className="w-3 h-3" />
                      <span>Configure API Key</span>
                    </button>
                  ) : (
                    <button
                      onClick={retryLastMessage}
                      className="px-3 py-1.5 bg-amber-200/80 hover:bg-amber-300 dark:bg-amber-900/60 dark:hover:bg-amber-800 text-amber-950 dark:text-amber-100 rounded-xl text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Retry</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Floating Scroll to Bottom Button */}
        <AnimatePresence>
          {showScrollBottom && (
            <motion.button
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              onClick={scrollToBottom}
              className="absolute bottom-28 right-8 p-3 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-200 rounded-full shadow-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all z-20"
              title="Scroll to latest"
            >
              <ArrowDown className="w-4 h-4" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Rich Input Area */}
        <div className="p-3 md:p-4 bg-white/80 dark:bg-slate-950/80 backdrop-blur-md border-t border-slate-200/80 dark:border-slate-800/80">
          <div className="max-w-4xl mx-auto">
            <div className={`
              relative flex items-end bg-slate-100 dark:bg-slate-900 border rounded-3xl transition-all shadow-xs
              ${isListening 
                ? 'border-red-500 ring-2 ring-red-500/20' 
                : 'border-slate-200 dark:border-slate-800 focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-500/20'}
            `}>
              {/* Voice Dictation Button */}
              <button
                type="button"
                onClick={toggleListening}
                className={`p-3.5 mb-1 ml-1.5 rounded-2xl transition-all shrink-0 ${
                  isListening 
                    ? 'bg-red-500 text-white animate-pulse shadow-md shadow-red-500/30' 
                    : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-200/60 dark:hover:bg-slate-800'
                }`}
                title={isListening ? "Listening... click to stop" : "Voice dictation"}
              >
                <Mic className="w-4 h-4" />
              </button>

              {/* Dynamic Resizing Textarea */}
              <textarea
                ref={textareaRef}
                rows={1}
                value={input}
                onChange={handleInputChange}
                onKeyDown={handleKeyDown}
                onFocus={handleInputFocus}
                placeholder={isListening ? "Listening to your voice..." : "Message Alya (Press Enter to send, Shift+Enter for new line)..."}
                className="flex-1 bg-transparent text-slate-900 dark:text-slate-100 placeholder:text-slate-400 dark:placeholder:text-slate-500 py-3.5 px-2 text-sm outline-none resize-none min-h-[44px] max-h-[140px] font-medium leading-relaxed"
              />

              {/* Send Button */}
              <button
                onClick={() => handleSend()}
                disabled={!input.trim()}
                className={`
                  p-3 mb-1.5 mr-1.5 rounded-2xl transition-all shrink-0 shadow-md
                  ${input.trim() 
                    ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900 hover:opacity-90 scale-100' 
                    : 'bg-slate-200 dark:bg-slate-800 text-slate-400 opacity-40 cursor-not-allowed'}
                `}
                title="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </div>

            {/* Sub-bar status */}
            <div className="flex items-center justify-between px-2 pt-2 text-[10px] text-slate-400 font-medium">
              <span className="flex items-center gap-1.5">
                <span className={`w-1.5 h-1.5 rounded-full ${isPrewarming ? 'bg-amber-400 animate-pulse' : 'bg-emerald-500'}`}></span>
                <span>{isPrewarming ? 'Pre-warming audio engine & verifying mic...' : 'Alya Cognitive Neural Core'}</span>
              </span>
              <span>
                Shift + Enter for new line • Enter to send
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
