import React, { useState, useEffect, useRef } from 'react';
import { Mic, Check, AlertCircle, RefreshCw, Trash2, ShieldCheck, Lock, Play, Pause, Square } from 'lucide-react';
import { speakerVerificationManager, VoiceFeatures } from '../lib/SpeakerVerificationManager.ts';

export function BiometricSpeakerEnrollment() {
  const [isEnrolled, setIsEnrolled] = useState(false);
  const [isEnrolling, setIsEnrollMode] = useState(false);
  const [activeStep, setActiveSampleStep] = useState<1 | 2 | 3>(1);
  const [sampleState, setSampleState] = useState<'idle' | 'recording' | 'success' | 'failed'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [micActive, setMicActive] = useState(false);

  // Web Audio Refs
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const recordingTimerRef = useRef<any>(null);

  // Visualization state
  const [audioLevel, setAudioLevel] = useState(0);

  // Prompt phrases for enrollment
  const PROMPTS = {
    1: '"Alya, activate owner mode and verify my voice."',
    2: '"My voice is my password, only listen to me."',
    3: '"Alya, authorize and secure my companion device."'
  };

  useEffect(() => {
    setIsEnrolled(speakerVerificationManager.isEnrolled());
    return () => {
      stopMicrophone();
    };
  }, []);

  const startMicrophone = async (): Promise<boolean> => {
    try {
      stopMicrophone();
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 16000
        }
      });
      streamRef.current = stream;

      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioCtx = new AudioCtxClass({ sampleRate: 16000 });
      audioContextRef.current = audioCtx;

      const source = audioCtx.createMediaStreamSource(stream);
      const analyser = audioCtx.createAnalyser();
      analyser.fftSize = 512;
      analyserRef.current = analyser;
      source.connect(analyser);

      setMicActive(true);
      return true;
    } catch (e: any) {
      console.error('[BiometricEnrollment] Mic access failed:', e);
      setErrorMessage(e.message || 'Microphone access denied. Please verify system permissions.');
      return false;
    }
  };

  const stopMicrophone = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
      animationFrameRef.current = null;
    }
    if (recordingTimerRef.current) {
      clearTimeout(recordingTimerRef.current);
      recordingTimerRef.current = null;
    }
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
      streamRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    analyserRef.current = null;
    setMicActive(false);
    setAudioLevel(0);
  };

  const handleStartEnrollment = () => {
    speakerVerificationManager.resetEnrollment();
    setIsEnrollMode(true);
    setActiveSampleStep(1);
    setSampleState('idle');
    setErrorMessage(null);
  };

  const handleStartRecording = async () => {
    setErrorMessage(null);
    setSampleState('recording');

    const hasMic = await startMicrophone();
    if (!hasMic) {
      setSampleState('idle');
      return;
    }

    speakerVerificationManager.startSampleCapture();
    
    // Periodically extract features while user is speaking (VAD logic)
    const bufferLength = analyserRef.current!.fftSize;
    const timeData = new Float32Array(bufferLength);
    const freqData = new Uint8Array(bufferLength / 2);

    const checkAudioFrame = () => {
      if (!analyserRef.current) return;
      
      analyserRef.current.getFloatTimeDomainData(timeData);
      analyserRef.current.getByteFrequencyData(freqData);

      // Measure volume level for UI
      let sum = 0;
      for (let i = 0; i < timeData.length; i++) {
        sum += timeData[i] * timeData[i];
      }
      const rms = Math.sqrt(sum / timeData.length);
      setAudioLevel(Math.min(100, Math.floor(rms * 150)));

      // Feed frame to biometric capture
      speakerVerificationManager.recordEnrollmentFrame(timeData, freqData, 16000);

      animationFrameRef.current = requestAnimationFrame(checkAudioFrame);
    };

    animationFrameRef.current = requestAnimationFrame(checkAudioFrame);

    // Record for exactly 2.5 seconds per sample
    recordingTimerRef.current = setTimeout(() => {
      handleStopRecording();
    }, 2500);
  };

  const handleStopRecording = () => {
    stopMicrophone();

    const success = speakerVerificationManager.compileSample();
    if (success) {
      setSampleState('success');
    } else {
      setSampleState('failed');
      setErrorMessage('Could not detect distinct human voice frequencies. Please speak clearly closer to your microphone.');
    }
  };

  const handleNextStep = () => {
    if (activeStep < 3) {
      setActiveSampleStep((activeStep + 1) as any);
      setSampleState('idle');
      setErrorMessage(null);
    } else {
      // Finalize biometric profile
      const enrolled = speakerVerificationManager.finalizeEnrollment();
      if (enrolled) {
        setIsEnrolled(true);
        setIsEnrollMode(false);
      } else {
        setErrorMessage('Failed to compile speaker signature profile. Please try enrolling again.');
        setIsEnrollMode(false);
      }
    }
  };

  const handleResetProfile = () => {
    if (window.confirm('Are you sure you want to securely purge your owner voice biometric signature?')) {
      speakerVerificationManager.resetEnrollment();
      setIsEnrolled(false);
      setIsEnrollMode(false);
    }
  };

  return (
    <div className="space-y-4 text-slate-300">
      <div className="flex items-center justify-between bg-slate-900 border border-white/5 rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border ${isEnrolled ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-amber-500/10 border-amber-500/20 text-amber-400'}`}>
            {isEnrolled ? <ShieldCheck className="w-5 h-5 animate-pulse" /> : <Lock className="w-5 h-5" />}
          </div>
          <div>
            <h5 className="font-bold text-sm text-white">Biometric Voice Status</h5>
            <p className="text-xs text-slate-400 mt-0.5">
              {isEnrolled 
                ? 'Authorized Owner Voice Profile Enrolled & Protected.' 
                : 'Not Enrolled. Alya will process commands from any source.'}
            </p>
          </div>
        </div>

        {isEnrolled ? (
          <button
            onClick={handleResetProfile}
            className="px-3 py-1.5 rounded-xl bg-red-500/10 hover:bg-red-500/20 border border-red-500/20 text-red-400 hover:text-red-300 text-xs font-bold transition-all flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" /> Reset Profile
          </button>
        ) : (
          !isEnrolling && (
            <button
              onClick={handleStartEnrollment}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all shadow-md shadow-indigo-600/10 flex items-center gap-1.5"
            >
              <Mic className="w-3.5 h-3.5" /> Enroll Now
            </button>
          )
        )}
      </div>

      {isEnrolling && (
        <div className="bg-slate-950/40 border border-white/5 rounded-2xl p-4.5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-widest text-indigo-400">Step {activeStep} of 3: Speak Prompt</span>
            <button 
              onClick={() => { stopMicrophone(); setIsEnrollMode(false); }}
              className="text-slate-400 hover:text-white text-xs"
            >
              Cancel
            </button>
          </div>

          <div className="bg-slate-900 border border-white/5 rounded-xl p-4 text-center space-y-2">
            <p className="text-xs text-slate-400 font-medium">Please speak the following phrase clearly:</p>
            <p className="text-base font-extrabold text-white leading-relaxed italic bg-black/20 p-2.5 rounded-lg">
              {PROMPTS[activeStep]}
            </p>
          </div>

          {errorMessage && (
            <div className="flex items-start gap-2 bg-red-500/10 border border-red-500/15 rounded-xl p-3 text-red-400 text-xs leading-normal">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="flex flex-col items-center justify-center py-4 space-y-3">
            {sampleState === 'recording' && (
              <div className="flex items-center gap-1 h-8">
                <div className="w-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ height: `${Math.max(10, audioLevel)}%`, animationDelay: '0ms' }} />
                <div className="w-1.5 bg-indigo-400 rounded-full animate-bounce" style={{ height: `${Math.max(10, audioLevel * 1.3)}%`, animationDelay: '150ms' }} />
                <div className="w-1.5 bg-indigo-500 rounded-full animate-bounce" style={{ height: `${Math.max(10, audioLevel * 0.8)}%`, animationDelay: '300ms' }} />
                <div className="w-1.5 bg-indigo-300 rounded-full animate-bounce" style={{ height: `${Math.max(10, audioLevel * 1.1)}%`, animationDelay: '450ms' }} />
              </div>
            )}

            {sampleState === 'idle' && (
              <button
                onClick={handleStartRecording}
                className="w-14 h-14 rounded-full bg-indigo-600 hover:bg-indigo-500 text-white flex items-center justify-center shadow-lg shadow-indigo-600/20 transition-all active:scale-95 group"
              >
                <Mic className="w-6 h-6 group-hover:scale-110 transition-transform" />
              </button>
            )}

            {sampleState === 'recording' && (
              <button
                onClick={handleStopRecording}
                className="w-14 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center animate-pulse transition-all active:scale-95"
              >
                <Square className="w-5 h-5 fill-current" />
              </button>
            )}

            {sampleState === 'success' && (
              <div className="flex flex-col items-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
                  <Check className="w-6 h-6" />
                </div>
                <p className="text-xs text-emerald-400 font-bold">Sample captured and verified!</p>
                <button
                  onClick={handleNextStep}
                  className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-bold rounded-xl text-xs transition-all shadow-md shadow-indigo-600/10 mt-2"
                >
                  {activeStep < 3 ? 'Proceed to Step ' + (activeStep + 1) : 'Save & Finalize Profile'}
                </button>
              </div>
            )}

            {sampleState === 'failed' && (
              <button
                onClick={handleStartRecording}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" /> Retry Sample
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
