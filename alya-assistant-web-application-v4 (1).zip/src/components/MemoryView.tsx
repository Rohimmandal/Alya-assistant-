import React, { useState, useEffect } from 'react';
import { 
  Database, 
  Plus, 
  Trash2, 
  Edit3, 
  Search, 
  ShieldCheck, 
  User, 
  Smartphone, 
  Bookmark, 
  CheckCircle, 
  X,
  Sparkles,
  Info,
  Pin,
  Star,
  Download,
  Upload,
  HardDrive,
  Cpu,
  Zap,
  Tag,
  Clock,
  Layers,
  BarChart3,
  Filter,
  CheckSquare,
  Square,
  AlertTriangle
} from 'lucide-react';
import { useAuth } from '../lib/AuthContext';
import { db } from '../lib/firebase';
import { 
  collection, 
  addDoc, 
  onSnapshot, 
  query, 
  deleteDoc, 
  doc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';

export type MemoryCategory = 
  | 'personal_fact' 
  | 'preference' 
  | 'routine' 
  | 'project' 
  | 'emotional' 
  | 'smart_home' 
  | 'milestone' 
  | 'general';

interface MemoryItem {
  id: string;
  category: MemoryCategory;
  key: string;
  value: string;
  content?: string;
  importance?: number;
  isPinned?: boolean;
  tags?: string[];
  source?: string;
  sizeBytes?: number;
  createdAt?: any;
}

interface MemoryStats {
  totalCount: number;
  totalSizeBytes: number;
  capacityTB: number;
  usedPercentageTB: number;
  categoryBreakdown: Record<string, number>;
  pinnedCount: number;
  highImportanceCount: number;
}

export function MemoryView() {
  const { user } = useAuth();
  const [memories, setMemories] = useState<MemoryItem[]>([]);
  const [stats, setStats] = useState<MemoryStats>({
    totalCount: 0,
    totalSizeBytes: 0,
    capacityTB: 1000,
    usedPercentageTB: 0.000001,
    categoryBreakdown: {},
    pinnedCount: 0,
    highImportanceCount: 0
  });

  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [showPinnedOnly, setShowPinnedOnly] = useState(false);
  const [selectedMemoryIds, setSelectedMemoryIds] = useState<string[]>([]);

  // Modal & Edit State
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Form Fields
  const [newCategory, setNewCategory] = useState<MemoryCategory>('preference');
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [newImportance, setNewImportance] = useState<number>(7);
  const [newIsPinned, setNewIsPinned] = useState<boolean>(false);
  const [newTagsStr, setNewTagsStr] = useState<string>('');

  // Import / Export State
  const [isImporting, setIsImporting] = useState(false);
  const [importJsonStr, setImportJsonStr] = useState('');
  const [importStatus, setImportStatus] = useState<string | null>(null);

  // Sync memories from Firestore
  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, 'users', user.uid, 'memories'));

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: MemoryItem[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as any;
        list.push({
          id: docSnap.id,
          category: data.category || 'general',
          key: data.key || data.topic || 'Memory Point',
          value: data.value || data.content || '',
          content: data.content || data.value || '',
          importance: typeof data.importance === 'number' ? data.importance : 5,
          isPinned: !!data.isPinned,
          tags: Array.isArray(data.tags) ? data.tags : [],
          source: data.source || 'manual_input',
          sizeBytes: data.sizeBytes || 128,
          createdAt: data.createdAt
        });
      });

      // Sort: Pinned first, then importance, then newest
      list.sort((a, b) => {
        if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
        if ((b.importance || 5) !== (a.importance || 5)) return (b.importance || 5) - (a.importance || 5);
        return 0;
      });

      setMemories(list);

      // Fetch aggregated stats from backend
      fetchMemoryStats(user.uid);
    });

    return () => unsubscribe();
  }, [user]);

  const fetchMemoryStats = async (uid: string) => {
    try {
      const res = await fetch(`/api/memories/stats?userId=${encodeURIComponent(uid)}`);
      if (res.ok) {
        const data = await res.json();
        if (data.stats) setStats(data.stats);
      }
    } catch (e) {
      console.warn('[MemoryView] Stats fetch error:', e);
    }
  };

  const handleSaveMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || (!newKey.trim() && !newValue.trim())) return;

    const parsedTags = newTagsStr
      .split(',')
      .map(t => t.trim().toLowerCase())
      .filter(t => t.length > 0);

    const cleanKey = newKey.trim() || newValue.trim().slice(0, 30);
    const cleanValue = newValue.trim() || newKey.trim();

    try {
      if (editingId) {
        const docRef = doc(db, 'users', user.uid, 'memories', editingId);
        await updateDoc(docRef, {
          category: newCategory,
          key: cleanKey,
          value: cleanValue,
          content: cleanValue,
          importance: newImportance,
          isPinned: newIsPinned,
          tags: parsedTags,
          updatedAt: serverTimestamp()
        });
        setEditingId(null);
      } else {
        await addDoc(collection(db, 'users', user.uid, 'memories'), {
          userId: user.uid,
          category: newCategory,
          key: cleanKey,
          value: cleanValue,
          content: cleanValue,
          importance: newImportance,
          isPinned: newIsPinned,
          tags: parsedTags,
          source: 'manual_input',
          sizeBytes: cleanValue.length + cleanKey.length + 120,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp()
        });
      }

      setNewKey('');
      setNewValue('');
      setNewTagsStr('');
      setIsAdding(false);
    } catch (err) {
      console.error('Error saving memory:', err);
    }
  };

  const togglePinMemory = async (m: MemoryItem) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid, 'memories', m.id);
    await updateDoc(docRef, {
      isPinned: !m.isPinned,
      updatedAt: serverTimestamp()
    });
  };

  const handleDeleteMemory = async (id: string) => {
    if (!user || !confirm('Are you sure you want Alya to erase this memory from Alya\'s Memory Storage?')) return;
    await deleteDoc(doc(db, 'users', user.uid, 'memories', id));
  };

  const handleBulkDelete = async () => {
    if (!user || selectedMemoryIds.length === 0) return;
    if (!confirm(`Permanently delete ${selectedMemoryIds.length} selected memory entries?`)) return;

    try {
      await fetch('/api/memories/bulk-delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.uid, memoryIds: selectedMemoryIds })
      });
      setSelectedMemoryIds([]);
    } catch (e) {
      console.error('Bulk delete error:', e);
    }
  };

  const handleStartEdit = (m: MemoryItem) => {
    setEditingId(m.id);
    setNewCategory(m.category);
    setNewKey(m.key);
    setNewValue(m.value);
    setNewImportance(m.importance || 5);
    setNewIsPinned(!!m.isPinned);
    setNewTagsStr((m.tags || []).join(', '));
    setIsAdding(true);
  };

  const handleExportMemories = () => {
    if (!user) return;
    window.open(`/api/memories/export?userId=${encodeURIComponent(user.uid)}`, '_blank');
  };

  const handleImportMemories = async () => {
    if (!user || !importJsonStr.trim()) return;
    try {
      setImportStatus('Parsing and storing memories in Firestore...');
      const parsed = JSON.parse(importJsonStr);
      const items = Array.isArray(parsed) ? parsed : (parsed.memories || []);

      const res = await fetch('/api/memories/import', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user.uid, memories: items })
      });

      const data = await res.json();
      if (data.success) {
        setImportStatus(`Successfully imported ${data.count} memory points!`);
        setTimeout(() => {
          setIsImporting(false);
          setImportStatus(null);
          setImportJsonStr('');
        }, 1500);
      } else {
        setImportStatus(`Import failed: ${data.error}`);
      }
    } catch (e: any) {
      setImportStatus(`Invalid JSON payload: ${e.message}`);
    }
  };

  const toggleSelectMemory = (id: string) => {
    setSelectedMemoryIds(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const filteredMemories = memories.filter((m) => {
    const matchesCat = activeCategory === 'all' || m.category === activeCategory;
    const matchesPinned = !showPinnedOnly || m.isPinned;
    const q = searchTerm.toLowerCase();
    const matchesSearch = 
      m.key.toLowerCase().includes(q) || 
      m.value.toLowerCase().includes(q) ||
      (m.tags || []).some(t => t.toLowerCase().includes(q));
    return matchesCat && matchesPinned && matchesSearch;
  });

  const CATEGORIES: Array<{ id: string; label: string; icon: any }> = [
    { id: 'all', label: 'All Partition', icon: Layers },
    { id: 'personal_fact', label: 'Personal Facts', icon: User },
    { id: 'preference', label: 'Preferences', icon: Bookmark },
    { id: 'routine', label: 'Routines', icon: Clock },
    { id: 'project', label: 'Projects & Work', icon: Cpu },
    { id: 'emotional', label: 'Insights', icon: Sparkles },
    { id: 'smart_home', label: 'Smart Home', icon: Smartphone },
    { id: 'milestone', label: 'Milestones', icon: Star }
  ];

  return (
    <div className="h-full flex flex-col overflow-y-auto bg-slate-950 text-white p-6 md:p-8 space-y-6 font-sans select-none">
      
      {/* Top Banner - 1000 TB Quantum Memory System Overview */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-950 via-slate-900 to-purple-950 border border-indigo-500/30 p-6 md:p-8 shadow-2xl space-y-6">
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />
        
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-indigo-500 via-purple-600 to-pink-500 flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 shrink-0">
              <HardDrive className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-2xl md:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-indigo-300 via-purple-200 to-pink-300 bg-clip-text text-transparent">
                  Alya's Memory Storage
                </h1>
                <span className="text-[10px] font-mono font-bold uppercase tracking-widest px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  ENTERPRISE POOL
                </span>
              </div>
              <p className="text-xs md:text-sm text-slate-300 mt-1 font-medium">
                Persistent multi-vector user preferences, contextual facts & personal milestones stored in Firestore.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleExportMemories}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/10 hover:bg-white/20 text-slate-200 border border-white/10 rounded-2xl text-xs font-bold transition-all"
            >
              <Download className="w-4 h-4" />
              <span>Export JSON</span>
            </button>

            <button
              onClick={() => setIsImporting(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 rounded-2xl text-xs font-bold transition-all"
            >
              <Upload className="w-4 h-4" />
              <span>Import</span>
            </button>

            <button
              onClick={() => {
                setEditingId(null);
                setNewKey('');
                setNewValue('');
                setNewTagsStr('');
                setIsAdding(true);
              }}
              className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-2xl text-xs font-extrabold shadow-lg shadow-indigo-600/30 transition-all active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Memory Point</span>
            </button>
          </div>
        </div>

        {/* Storage Bar & Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-white/10 relative z-10">
          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Total Capacity</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-indigo-300">Unlimited</span>
              <span className="text-xs font-bold text-slate-400">Alya's Storage</span>
            </div>
            <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden mt-2">
              <div className="bg-gradient-to-r from-indigo-500 to-pink-500 h-full w-[0.01%]" />
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Active Memories</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-white">{memories.length}</span>
              <span className="text-xs font-bold text-slate-400">Records</span>
            </div>
            <span className="text-[10px] text-emerald-400 font-semibold block mt-1">Indexed in Alya Brain</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">Pinned Key Facts</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-amber-300">{memories.filter(m => m.isPinned).length}</span>
              <span className="text-xs font-bold text-slate-400">Pinned</span>
            </div>
            <span className="text-[10px] text-amber-400/80 font-semibold block mt-1">High Priority Context</span>
          </div>

          <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 space-y-1">
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block">High Importance (8-10★)</span>
            <div className="flex items-baseline gap-1">
              <span className="text-xl font-extrabold text-pink-300">{memories.filter(m => (m.importance || 5) >= 8).length}</span>
              <span className="text-xs font-bold text-slate-400">Entries</span>
            </div>
            <span className="text-[10px] text-pink-400/80 font-semibold block mt-1">Grounding Priority</span>
          </div>
        </div>
      </div>

      {/* Import Modal */}
      {isImporting && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-purple-500/40 shadow-2xl space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Upload className="w-4 h-4 text-purple-400" />
              <span>Import Memories JSON</span>
            </h3>
            <button onClick={() => setIsImporting(false)} className="text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <textarea
            rows={5}
            value={importJsonStr}
            onChange={(e) => setImportJsonStr(e.target.value)}
            placeholder={`Paste JSON array of memories, e.g.:\n[\n  { "category": "preference", "key": "coffee", "value": "Espresso with oat milk", "importance": 8 }\n]`}
            className="w-full bg-slate-950 border border-white/10 rounded-2xl p-4 text-xs font-mono text-purple-200 focus:outline-none focus:border-purple-500"
          />

          {importStatus && (
            <p className="text-xs font-semibold text-purple-300 bg-purple-500/10 p-3 rounded-xl border border-purple-500/20">
              {importStatus}
            </p>
          )}

          <div className="flex justify-end gap-3">
            <button
              onClick={() => setIsImporting(false)}
              className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
            >
              Cancel
            </button>
            <button
              onClick={handleImportMemories}
              className="px-5 py-2.5 rounded-xl text-xs font-bold bg-purple-600 hover:bg-purple-500 text-white shadow-lg shadow-purple-600/20"
            >
              Execute Bulk Import
            </button>
          </div>
        </div>
      )}

      {/* Add / Edit Memory Modal */}
      {isAdding && (
        <div className="p-6 rounded-3xl bg-slate-900 border border-indigo-500/40 shadow-2xl space-y-4 animate-in fade-in duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-white/10">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              <span>{editingId ? 'Edit Memory Entry' : 'Add New Entry to Alya\'s Memory Storage'}</span>
            </h3>
            <button onClick={() => setIsAdding(false)} className="text-slate-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSaveMemory} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1.5">Category</label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as MemoryCategory)}
                  className="w-full bg-slate-950 border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                >
                  <option value="personal_fact">Personal Fact (Identity / Location)</option>
                  <option value="preference">User Preference (Food / Style)</option>
                  <option value="routine">Routine & Schedule (Habits)</option>
                  <option value="project">Project & Work (Tasks / Code)</option>
                  <option value="emotional">Emotional Insight (Mood / Vibe)</option>
                  <option value="smart_home">Smart Home Config (Devices)</option>
                  <option value="milestone">Milestone & Goal</option>
                  <option value="general">General Memory</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1.5">Topic / Key Name</label>
                <input
                  type="text"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g. Favorite Food, Home Address, Work Schedule"
                  className="w-full bg-slate-950 border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-400 block mb-1.5">Importance Rating (1 to 10★)</label>
                <div className="flex items-center gap-3 bg-slate-950 border border-white/10 rounded-2xl px-4 py-2">
                  <input
                    type="range"
                    min="1"
                    max="10"
                    value={newImportance}
                    onChange={(e) => setNewImportance(parseInt(e.target.value))}
                    className="flex-1 accent-indigo-500 cursor-pointer"
                  />
                  <span className="text-xs font-mono font-extrabold text-indigo-300 w-8 text-right">
                    {newImportance}★
                  </span>
                </div>
              </div>

              <div className="md:col-span-3">
                <label className="text-xs font-bold text-slate-400 block mb-1.5">Detailed Information / Value</label>
                <textarea
                  rows={3}
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder="e.g. Prefers Biryani from Kolkata; works as a senior software engineer; likes coffee at 9 AM."
                  className="w-full bg-slate-950 border border-white/10 rounded-2xl p-4 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="md:col-span-2">
                <label className="text-xs font-bold text-slate-400 block mb-1.5">Tags (Comma-separated)</label>
                <input
                  type="text"
                  value={newTagsStr}
                  onChange={(e) => setNewTagsStr(e.target.value)}
                  placeholder="e.g. food, kolkata, morning, priority"
                  className="w-full bg-slate-950 border border-white/10 rounded-2xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-end pb-1">
                <label className="flex items-center gap-2 cursor-pointer bg-slate-950 border border-white/10 hover:border-white/20 p-2.5 rounded-2xl w-full text-xs font-bold">
                  <input
                    type="checkbox"
                    checked={newIsPinned}
                    onChange={(e) => setNewIsPinned(e.target.checked)}
                    className="rounded text-indigo-600 focus:ring-0 cursor-pointer"
                  />
                  <Pin className="w-4 h-4 text-amber-400" />
                  <span>Pin to High Priority Context</span>
                </label>
              </div>
            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-white/10">
              <button
                type="button"
                onClick={() => setIsAdding(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-2xl text-xs font-extrabold shadow-lg shadow-indigo-600/30"
              >
                {editingId ? 'Save Changes' : 'Store in Alya\'s Memory Storage'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Filter and Search Bar */}
      <div className="space-y-4">
        <div className="flex flex-col md:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search Alya's Memory Storage memories by keyword, value, or tags..."
              className="w-full bg-slate-900 border border-white/10 rounded-2xl pl-11 pr-4 py-3 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 shadow-inner"
            />
          </div>

          <div className="flex items-center gap-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
            <button
              onClick={() => setShowPinnedOnly(!showPinnedOnly)}
              className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all border whitespace-nowrap ${
                showPinnedOnly 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-500/40' 
                  : 'bg-slate-900 text-slate-400 border-white/10 hover:text-white'
              }`}
            >
              <Pin className="w-3.5 h-3.5 text-amber-400" />
              <span>Pinned Only</span>
            </button>

            {selectedMemoryIds.length > 0 && (
              <button
                onClick={handleBulkDelete}
                className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl text-xs font-bold bg-red-500/20 text-red-300 border border-red-500/40 hover:bg-red-500/30 transition-all whitespace-nowrap"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete Selected ({selectedMemoryIds.length})</span>
              </button>
            )}
          </div>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const count = cat.id === 'all' 
              ? memories.length 
              : memories.filter(m => m.category === cat.id).length;

            return (
              <button
                key={`mem-cat-${cat.id}`}
                onClick={() => setActiveCategory(cat.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-2xl text-xs font-bold transition-all whitespace-nowrap border ${
                  activeCategory === cat.id
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white border-indigo-400 shadow-lg shadow-indigo-600/20'
                    : 'bg-slate-900 text-slate-400 border-white/10 hover:text-white hover:bg-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-mono font-bold ${
                  activeCategory === cat.id ? 'bg-white/20 text-white' : 'bg-slate-800 text-slate-400'
                }`}>
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Memory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredMemories.length === 0 ? (
          <div className="col-span-full py-20 text-center text-slate-500 space-y-3 bg-slate-900/50 rounded-3xl border border-white/5 p-8">
            <Bookmark className="w-12 h-12 mx-auto text-slate-600 animate-pulse" />
            <p className="text-sm font-bold text-slate-300">No memories match your query in Alya's Memory Storage.</p>
            <p className="text-xs text-slate-500 max-w-md mx-auto">
              You can talk to Alya in Chat or Live Call and say "Remember that...", or click "Add Memory Point" above to store information permanently.
            </p>
          </div>
        ) : (
          filteredMemories.map((m, idx) => {
            const isSelected = selectedMemoryIds.includes(m.id);

            return (
              <div
                key={`mem-${m.id || 'm'}-${idx}`}
                className={`p-5 rounded-3xl bg-slate-900 border transition-all duration-200 flex flex-col justify-between space-y-4 group relative overflow-hidden ${
                  m.isPinned
                    ? 'border-amber-500/40 bg-gradient-to-b from-slate-900 via-slate-900 to-amber-950/20 shadow-lg shadow-amber-500/5'
                    : isSelected
                      ? 'border-indigo-500 bg-indigo-950/20'
                      : 'border-white/10 hover:border-indigo-500/40 hover:bg-slate-850'
                }`}
              >
                {m.isPinned && (
                  <div className="absolute top-0 right-0 w-16 h-16 pointer-events-none overflow-hidden">
                    <div className="bg-amber-500 text-slate-950 text-[9px] font-extrabold uppercase font-mono tracking-widest py-0.5 text-center translate-x-4 translate-y-3 rotate-45 shadow-sm">
                      PINNED
                    </div>
                  </div>
                )}

                <div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => toggleSelectMemory(m.id)}
                        className="text-slate-500 hover:text-white transition-colors cursor-pointer"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-indigo-400" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>

                      <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 font-mono font-bold uppercase tracking-wider">
                        {m.category.replace('_', ' ')}
                      </span>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => togglePinMemory(m)}
                        title={m.isPinned ? 'Unpin' : 'Pin to Context'}
                        className={`p-1.5 rounded-xl transition-all cursor-pointer ${
                          m.isPinned ? 'text-amber-400 bg-amber-500/10' : 'text-slate-500 hover:text-amber-400 hover:bg-white/5'
                        }`}
                      >
                        <Pin className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleStartEdit(m)}
                        className="p-1.5 rounded-xl text-slate-500 hover:text-indigo-300 hover:bg-white/5 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>

                      <button
                        onClick={() => handleDeleteMemory(m.id)}
                        className="p-1.5 rounded-xl text-slate-500 hover:text-red-400 hover:bg-white/5 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <h4 className="mt-3 text-sm font-bold text-white tracking-tight flex items-center gap-2">
                    <span>{m.key}</span>
                  </h4>

                  <p className="mt-1.5 text-xs text-slate-300 leading-relaxed font-normal">
                    {m.value || m.content}
                  </p>

                  {/* Tags */}
                  {m.tags && m.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mt-3">
                      {/* ✅ CORRECT: Using unique identifier combining memory ID, tag name, and index */}
                      {m.tags.map((tag, idx) => (
                        <span key={`mem-tag-${m.id || 'mem'}-${tag}-${idx}`} className="text-[9px] font-mono px-2 py-0.5 rounded-lg bg-white/5 text-slate-400 border border-white/5 flex items-center gap-1">
                          <Tag className="w-2.5 h-2.5 text-slate-500" />
                          <span>#{tag}</span>
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div className="pt-3 border-t border-white/5 flex items-center justify-between text-[10px] text-slate-400">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Star className="w-3 h-3 text-amber-400" />
                    <span className="font-mono font-bold">{m.importance || 5}/10 Rating</span>
                  </div>

                  <span className="text-emerald-400 font-semibold flex items-center gap-1">
                    <CheckCircle className="w-3 h-3" /> Grounded in Alya's Memory Storage
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

    </div>
  );
}
