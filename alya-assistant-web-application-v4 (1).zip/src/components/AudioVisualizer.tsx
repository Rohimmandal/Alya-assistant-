import React, { useEffect, useRef } from 'react';

interface AudioVisualizerProps {
  analyserNode?: AnalyserNode | null;
  isActive?: boolean;
  barCount?: number;
  height?: number;
  colorTheme?: 'indigo' | 'emerald' | 'violet';
}

export const AudioVisualizer: React.FC<AudioVisualizerProps> = ({
  analyserNode,
  isActive = true,
  barCount = 32,
  height = 96,
  colorTheme = 'indigo'
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle Hi-DPI scaling
    const dpr = window.devicePixelRatio || 1;
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * dpr;
    canvas.height = height * dpr;
    ctx.scale(dpr, dpr);

    let dataArray: Uint8Array | null = null;
    if (analyserNode) {
      const bufferLength = analyserNode.frequencyBinCount;
      dataArray = new Uint8Array(bufferLength);
    }

    let phase = 0;

    const render = () => {
      ctx.clearRect(0, 0, rect.width, height);

      if (analyserNode && dataArray) {
        analyserNode.getByteFrequencyData(dataArray as any);
      }

      const barWidth = (rect.width / barCount) * 0.7;
      const barGap = (rect.width / barCount) * 0.3;

      // Color Palette Gradients
      let gradient: CanvasGradient;
      if (colorTheme === 'emerald') {
        gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, 'rgba(16, 185, 129, 0.2)');
        gradient.addColorStop(0.5, 'rgba(52, 211, 153, 0.8)');
        gradient.addColorStop(1, 'rgba(110, 231, 183, 1)');
      } else if (colorTheme === 'violet') {
        gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, 'rgba(139, 92, 246, 0.2)');
        gradient.addColorStop(0.5, 'rgba(167, 139, 250, 0.8)');
        gradient.addColorStop(1, 'rgba(244, 114, 182, 1)');
      } else {
        gradient = ctx.createLinearGradient(0, height, 0, 0);
        gradient.addColorStop(0, 'rgba(99, 102, 241, 0.2)');
        gradient.addColorStop(0.5, 'rgba(129, 140, 248, 0.8)');
        gradient.addColorStop(1, 'rgba(192, 132, 252, 1)');
      }

      phase += 0.06;

      for (let i = 0; i < barCount; i++) {
        let barHeightVal = 0;

        if (isActive && analyserNode && dataArray && dataArray.length > 0) {
          // Map bin index to frequency spectrum
          const binIndex = Math.floor((i / barCount) * (dataArray.length * 0.5));
          const freqValue = dataArray[binIndex] || 0;
          barHeightVal = (freqValue / 255) * (height * 0.85);
        } else if (isActive) {
          // Simulated organic idle wave if AnalyserNode is temporarily warming up
          const wave = Math.sin(phase + i * 0.25) * 0.4 + Math.cos(phase * 1.2 + i * 0.15) * 0.3;
          barHeightVal = Math.max(6, Math.abs(wave) * (height * 0.5));
        } else {
          barHeightVal = 4; // Flat resting height
        }

        const x = i * (barWidth + barGap) + barGap / 2;
        const y = (height - barHeightVal) / 2;

        ctx.fillStyle = gradient;
        ctx.beginPath();
        ctx.roundRect(x, y, barWidth, barHeightVal, [barWidth / 2]);
        ctx.fill();

        // Top cap glow dot for active frequencies
        if (barHeightVal > 12) {
          ctx.fillStyle = 'rgba(255, 255, 255, 0.9)';
          ctx.beginPath();
          ctx.arc(x + barWidth / 2, y + 2, barWidth / 3, 0, Math.PI * 2);
          ctx.fill();
        }
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    animFrameRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [analyserNode, isActive, barCount, height, colorTheme]);

  return (
    <div className="w-full flex items-center justify-center py-2 px-1">
      <canvas
        ref={canvasRef}
        className="w-full max-w-lg h-24 rounded-2xl bg-slate-900/50 border border-slate-800/80 shadow-inner"
        style={{ height: `${height}px` }}
      />
    </div>
  );
};
