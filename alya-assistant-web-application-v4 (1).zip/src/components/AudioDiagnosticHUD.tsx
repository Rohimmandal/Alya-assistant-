import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Activity, 
  Cpu, 
  Radio, 
  Volume2, 
  Zap, 
  ShieldCheck, 
  ChevronDown, 
  ChevronUp, 
  Layers, 
  Database,
  CheckCircle2,
  Gauge
} from 'lucide-react';
import { AudioDiagnosticMetrics } from '../utils/pcmAudioProcessor';

interface AudioDiagnosticHUDProps {
  metrics?: AudioDiagnosticMetrics;
  wsMetrics?: {
    status: 'connected' | 'disconnected' | 'connecting';
    latency: number;
    heartbeatsMissed: number;
  };
  isCapturing?: boolean;
  onRunDiagnosticTest?: () => void;
  className?: string;
  defaultExpanded?: boolean;
}

export const AudioDiagnosticHUD: React.FC<AudioDiagnosticHUDProps> = ({
  metrics: externalMetrics,
  wsMetrics,
  isCapturing = false,
  onRunDiagnosticTest,
  className = '',
  defaultExpanded = false
}) => {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const [localMetrics, setLocalMetrics] = useState<AudioDiagnosticMetrics>({
    contextState: 'uninitialized',
    nativeSampleRate: 48000,
    targetSampleRate: 16000,
    bufferSize: 2048,
    workerActive: true,
    workerProcessingLatencyMs: 0.8,
    rmsEnergy: 0.02,
    chunksProcessed: 0,
    totalBytesStreamed: 0,
    streamingBufferStatus: 'idle',
    lastChunkTimestamp: 0
  });

  const activeMetrics = externalMetrics || localMetrics;

  const [latencyHistory, setLatencyHistory] = useState<number[]>([]);

  useEffect(() => {
    if (activeMetrics.workerProcessingLatencyMs > 0) {
      setLatencyHistory(prev => [...prev.slice(-14), activeMetrics.workerProcessingLatencyMs]);
    }
  }, [activeMetrics.workerProcessingLatencyMs, activeMetrics.chunksProcessed]);

  const getContextStatusColor = (state: string) => {
    switch (state) {
      case 'running': return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30';
      case 'suspended': return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'closed': return 'text-slate-400 bg-slate-500/10 border-slate-500/30';
      default: return 'text-slate-500 bg-white/5 border-white/10';
    }
  };

  const getBufferStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30';
      case 'buffering': return 'text-amber-400 bg-amber-500/10 border-amber-500/30';
      case 'stalled': return 'text-rose-400 bg-rose-500/10 border-rose-500/30';
      default: return 'text-slate-400 bg-white/5 border-white/10';
    }
  };

  return (
    <div className={`bg-slate-900/90 backdrop-blur-xl border border-indigo-500/20 rounded-2xl p-4 text-xs font-mono shadow-2xl transition-all ${className}`}>
      <div className="flex items-center justify-between gap-3 pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center border border-indigo-500/30">
            <Activity className="w-3.5 h-3.5 animate-pulse text-indigo-400" />
          </div>
          <div>
            <span className="font-bold text-white text-xs tracking-wide">Audio Engine Diagnostic HUD</span>
            <span className="block text-[10px] text-slate-400 font-sans">LiveContext & PCM Worker Telemetry</span>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className={`px-2 py-0.5 rounded-full border text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 ${getContextStatusColor(activeMetrics.contextState)}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${activeMetrics.contextState === 'running' ? 'bg-emerald-400 animate-ping' : 'bg-slate-500'}`} />
            {activeMetrics.contextState}
          </span>
          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
          >
            {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-3">
        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span>SAMPLE RATE</span>
            <Radio className="w-3 h-3 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-white font-bold text-sm">
              {activeMetrics.nativeSampleRate ? `${(activeMetrics.nativeSampleRate / 1000).toFixed(1)}k` : '16.0k'}
            </span>
            <span className="text-slate-500 text-[10px]">→ {(activeMetrics.targetSampleRate / 1000).toFixed(0)}kHz</span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span>PCM ENCODING</span>
            <Cpu className="w-3 h-3 text-cyan-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="font-bold text-sm text-emerald-400">
              {activeMetrics.workerProcessingLatencyMs ? `${activeMetrics.workerProcessingLatencyMs.toFixed(2)}ms` : '< 1ms'}
            </span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span>BUFFER QUEUE</span>
            <Layers className="w-3 h-3 text-purple-400" />
          </div>
          <div>
            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold uppercase border ${getBufferStatusColor(activeMetrics.streamingBufferStatus)}`}>
              {activeMetrics.streamingBufferStatus}
            </span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span>PAYLOAD</span>
            <Database className="w-3 h-3 text-pink-400" />
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-white font-bold text-sm">
              {activeMetrics.totalBytesStreamed > 1024 * 1024 
                ? `${(activeMetrics.totalBytesStreamed / (1024 * 1024)).toFixed(2)}MB`
                : `${(activeMetrics.totalBytesStreamed / 1024).toFixed(1)}KB`}
            </span>
          </div>
        </div>

        <div className="p-2.5 rounded-xl bg-slate-950/60 border border-white/5 flex flex-col gap-1">
          <div className="flex items-center justify-between text-slate-400 text-[10px]">
            <span>CONNECTION</span>
            <ShieldCheck className="w-3 h-3 text-emerald-400" />
          </div>
          <div className="flex flex-col gap-0.5">
             <span className="text-white text-[10px]">{wsMetrics?.status || 'disconnected'}</span>
             <span className="text-slate-500 text-[10px]">Lat: {wsMetrics?.latency || 0}ms</span>
          </div>
        </div>
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            key="hud-expanded-panel"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="pt-3 border-t border-white/10 mt-3 space-y-3 overflow-hidden"
          >
            <div className="bg-slate-950/80 p-3 rounded-xl border border-white/5 space-y-1.5">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400 flex items-center gap-1.5">
                  <Volume2 className="w-3.5 h-3.5 text-emerald-400" />
                  Microphone Energy RMS:
                </span>
                <span className="text-emerald-300 font-bold font-mono">
                  {(activeMetrics.rmsEnergy * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
