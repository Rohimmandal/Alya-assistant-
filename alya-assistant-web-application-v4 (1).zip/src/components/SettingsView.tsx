import React, { useState, useEffect, useMemo } from 'react';
import { useAuth } from '../lib/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  User, Volume2, Languages, Bell, Moon, Shield, Info, LogOut, 
  Mic, Zap, Cpu, Check, Radio, Play, Smartphone, WifiOff, Sparkles, Search,
  MapPin, CloudSun, Compass, Droplets, Wind, Thermometer, RefreshCw, AlertCircle,
  Database, Sliders, History, Download, Upload, RotateCcw, Lock, CheckCircle2,
  SlidersHorizontal, Eye, ShieldAlert, ArrowRight, CornerDownLeft, Terminal, Wifi, Code2, Copy,
  ChevronDown, ChevronUp, Bot, Brain, ChevronLeft, Square, Activity
} from 'lucide-react';
import { SUPPORTED_LANGUAGES, LanguageDetector } from '../lib/LanguageDetector';
import { locationService, LocationPermissionState } from '../lib/locationService';
import { weatherService, FullWeatherData } from '../services/weatherService';
import { playAlyaVoice, stopAlyaVoice } from '../lib/femaleVoiceSynthesizer';
import { AudioMutex } from '../lib/AudioMutex';
import { audioPlaybackManager } from '../lib/AudioPlaybackManager';
import { 
  userSettingsService, 
  UserPreferences, 
  SettingChangeLogEntry,
  PersonalityType,
  ResponseCadence,
  DeviceControlMode
} from '../lib/userSettingsService';

// Import feature views to display as collapsible modules inside Settings screen
import { VoiceTranscriptView } from './VoiceTranscriptView';
import { BrainView } from './BrainView';
import { MemoryView } from './MemoryView';
import { AutomationsView } from './AutomationsView';
import { AutoReplyView } from './AutoReplyView';
import { DevicesView } from './DevicesView';
import { TestingView } from './TestingView';
import { PermissionsView } from './PermissionsView';
import { SecureApiKeyManager } from './SecureApiKeyManager';
import { BiometricSpeakerEnrollment } from './BiometricSpeakerEnrollment.tsx';

interface SettingsViewProps {
  onBack?: () => void;
}

export function SettingsView({ onBack }: SettingsViewProps = {}) {
  const { profile, logout, user } = useAuth();

  // Settings State initialized from authoritative userSettingsService
  const [preferences, setPreferences] = useState<UserPreferences>(() => userSettingsService.getPreferences());
  const [history, setHistory] = useState<SettingChangeLogEntry[]>(() => userSettingsService.getHistory());
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [langSearch, setLangSearch] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  
  // Accordion Expanded Section State
  const [expandedSection, setExpandedSection] = useState<string | null>(null);

  // Location & Weather Test State
  const [browserPermState, setBrowserPermState] = useState<LocationPermissionState>('prompt');
  const [isTestingLocation, setIsTestingLocation] = useState(false);
  const [weatherPreview, setWeatherPreview] = useState<FullWeatherData | null>(null);
  const [locationTestError, setLocationTestError] = useState<string | null>(null);

  // Unified Neural Voice & Audio Engine Test State
  const [isPlayingVoiceSample, setIsPlayingVoiceSample] = useState(false);
  const [auditioningVoiceId, setAuditioningVoiceId] = useState<string | null>(null);
  const [isResettingAudio, setIsResettingAudio] = useState(false);

  // Modals & History State
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showResetConfirmModal, setShowResetConfirmModal] = useState(false);
  const [showImportModal, setShowImportModal] = useState(false);
  const [importJsonText, setImportJsonText] = useState('');
  const [importError, setImportError] = useState<string | null>(null);

  // Subscribe to persistent settings updates (cloud sync & local changes)
  useEffect(() => {
    userSettingsService.initialize(user?.uid);
    const unsubscribe = userSettingsService.subscribe((updated) => {
      setPreferences(updated);
      setHistory(userSettingsService.getHistory());
    });

    locationService.checkPermissionState().then(setBrowserPermState);

    return () => unsubscribe();
  }, [user]);

  const triggerSaveFeedback = () => {
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2200);
  };

  const handleUpdate = async (updates: Partial<UserPreferences>) => {
    await userSettingsService.updatePreferences(updates, 'web_ui');
    triggerSaveFeedback();
  };

  const handleRevert = async (key: string) => {
    const success = await userSettingsService.revertSetting(key);
    if (success) {
      triggerSaveFeedback();
    }
  };

  const handleResetAll = async () => {
    await userSettingsService.resetAllSettings();
    setShowResetConfirmModal(false);
    triggerSaveFeedback();
  };

  const handleExport = () => {
    const jsonStr = userSettingsService.exportSettingsJson();
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `alya-settings-rev${preferences.revision}-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setImportError(null);
    const res = await userSettingsService.importSettingsJson(importJsonText);
    if (res.success) {
      setShowImportModal(false);
      setImportJsonText('');
      triggerSaveFeedback();
    } else {
      setImportError(res.error || 'Failed to import settings');
    }
  };

  const handleTestLocationAndWeather = async () => {
    setIsTestingLocation(true);
    setLocationTestError(null);
    setWeatherPreview(null);
    try {
      if (preferences.locationPreference === 'disabled') {
        setLocationTestError('Location is currently disabled in your preferences. Select Automatic GPS or Manual City to test.');
        return;
      }
      
      const cityToTest = preferences.locationPreference === 'manual' ? preferences.manualCity : undefined;
      const res = await weatherService.getWeatherForRequest(cityToTest);
      if (res.success && res.data) {
        setWeatherPreview(res.data);
      } else {
        setLocationTestError(res.error || 'Failed to retrieve location/weather.');
      }
      const updatedPerm = await locationService.checkPermissionState();
      setBrowserPermState(updatedPerm);
    } catch (err: any) {
      setLocationTestError(err.message || 'Error executing location test.');
    } finally {
      setIsTestingLocation(false);
    }
  };

  // Automatically stop voice testing on unmount
  useEffect(() => {
    return () => {
      stopAlyaVoice();
    };
  }, []);

  const handleTestVoiceSample = async (voiceIdToTest?: string) => {
    const targetVoice = voiceIdToTest || preferences.voiceName || 'Aoede';

    // If currently playing the same voice, clicking toggles stop
    if (isPlayingVoiceSample && auditioningVoiceId === targetVoice) {
      stopAlyaVoice();
      setIsPlayingVoiceSample(false);
      setAuditioningVoiceId(null);
      return;
    }

    // Stop existing audio playback
    stopAlyaVoice();
    setIsPlayingVoiceSample(true);
    setAuditioningVoiceId(targetVoice);

    const lang = preferences.language || 'auto';
    let sampleText = `Hello! I am Alya, your personal assistant. My 24kHz neural audio engine is fully active and synchronized. How do I sound, Boss?`;

    if (lang === 'hi' || lang.startsWith('hi-')) {
      sampleText = `नमस्ते! मैं आलिया हूँ, आपकी पर्सनल असिस्टेंट। मेरी न्यूरल आवाज़ अब 24kHz ऑडियो इंजन पर पूरी तरह सेट है। सब ठीक लग रहा है?`;
    } else if (lang === 'bn' || lang.startsWith('bn-')) {
      sampleText = `হ্যালো! আমি আলিয়া, তোমার পার্সোনাল অ্যাসিস্ট্যান্ট। আমার ভয়েস ইঞ্জিন এখন পুরোপুরি অ্যাক্টিভ। সব ঠিকঠাক শুনতে পাচ্ছো তো?`;
    } else if (lang === 'raj') {
      sampleText = `নমস্কার! মুই আলিয়া, তুমার পার্সোনাল অ্যাসিস্ট্যান্ট। হামার কথা শুনির পাছেন তো?`;
    } else if (lang === 'ja' || lang.startsWith('ja-')) {
      sampleText = `こんにちは！アーリャです。ニューラルボイスエンジンは正常に同期されています。聞こえていますか？`;
    } else if (lang === 'es' || lang.startsWith('es-')) {
      sampleText = `¡Hola! Soy Alya, tu asistente personal. Mi motor de voz neuronal está completamente sincronizado. ¿Cómo me escuchas?`;
    }

    try {
      await playAlyaVoice(sampleText, {
        id: `voice_sample_${Date.now()}`,
        voiceName: targetVoice,
        pitch: preferences.speechPitch,
        rate: preferences.speechSpeed,
        language: lang,
        onStart: () => {
          setIsPlayingVoiceSample(true);
          setAuditioningVoiceId(targetVoice);
        },
        onEnd: () => {
          setIsPlayingVoiceSample(false);
          setAuditioningVoiceId(null);
        },
        onError: (err) => {
          console.warn('[VoiceSample] Playback completed/fallback:', err);
          setIsPlayingVoiceSample(false);
          setAuditioningVoiceId(null);
        }
      });
    } catch (err) {
      console.warn('[VoiceSample] Error testing voice:', err);
      setIsPlayingVoiceSample(false);
      setAuditioningVoiceId(null);
    }
  };

  const handleResetAudioEngine = async () => {
    setIsResettingAudio(true);
    try {
      stopAlyaVoice();
      AudioMutex.stopAllPlayback();
      AudioMutex.resetAudioElement();
      audioPlaybackManager.cancelAllAudio('manual_reset');
    } catch (e) {
      console.warn('[AudioReset] Error:', e);
    } finally {
      setTimeout(() => {
        setIsResettingAudio(false);
        triggerSaveFeedback();
      }, 500);
    }
  };

  const countries = useMemo(() => LanguageDetector.getAllCountries(), []);

  const filteredLanguages = useMemo(() => {
    return SUPPORTED_LANGUAGES.filter(l => {
      const matchesCountry = selectedCountry === 'All' || l.country === selectedCountry || (l.code === 'auto' && selectedCountry === 'All');
      if (!matchesCountry) return false;
      if (!langSearch.trim()) return true;
      const q = langSearch.toLowerCase().trim();
      return (
        l.name.toLowerCase().includes(q) ||
        l.nativeName.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q) ||
        l.country.toLowerCase().includes(q) ||
        (l.region && l.region.toLowerCase().includes(q))
      );
    });
  }, [selectedCountry, langSearch]);

  return (
    <div className="h-full bg-slate-950 text-slate-100 overflow-y-auto">
      <div className="max-w-4xl mx-auto p-4 md:p-8 space-y-8 pb-28">
        {/* Header & Status Banner */}
        <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-white/10 pb-6">
          <div>
            {onBack && (
              <button
                onClick={onBack}
                className="mb-3 px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-indigo-400 hover:text-indigo-300 border border-slate-800 text-xs font-bold flex items-center gap-1.5 transition-all shadow-sm active:scale-95 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back to Chat</span>
              </button>
            )}
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 text-[10px] font-bold uppercase tracking-wider flex items-center gap-1">
                <Lock className="w-3 h-3" /> Permanent Preference Lock
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[10px] font-mono border border-slate-700">
                Rev #{preferences.revision}
              </span>
              {savedSuccess && (
                <motion.span 
                  initial={{ opacity: 0, scale: 0.9 }} 
                  animate={{ opacity: 1, scale: 1 }} 
                  className="text-xs text-emerald-400 font-semibold flex items-center gap-1 bg-emerald-950/40 px-2 py-0.5 rounded-full border border-emerald-500/30"
                >
                  <Check className="w-3.5 h-3.5" /> Saved & Locked
                </motion.span>
              )}
            </div>
            <h1 className="text-2xl font-bold tracking-tight text-white mt-1.5 flex items-center gap-2">
              Alya Configuration & Preferences
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              All settings are persistent across reboots, sessions, and synchronized across Web & Android.
            </p>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            <button
              onClick={() => setShowHistoryModal(true)}
              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 flex items-center gap-1.5 transition"
              title="View settings change history"
            >
              <History className="w-3.5 h-3.5 text-indigo-400" />
              <span>Audit Log ({history.length})</span>
            </button>
            <button
              onClick={handleExport}
              className="px-3 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl text-xs font-semibold text-slate-300 flex items-center gap-1.5 transition"
              title="Export Settings to JSON"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span>Export</span>
            </button>
          </div>
        </header>

        {/* Account & Cross-Device Cloud Sync Status */}
        <section className="bg-slate-900/90 rounded-3xl border border-white/5 p-6 space-y-4 shadow-lg">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-indigo-600/30 to-violet-600/30 border border-indigo-500/30 flex items-center justify-center text-indigo-400 font-bold text-xl shadow-inner">
                {profile?.displayName?.[0] || 'A'}
              </div>
              <div>
                <h3 className="font-bold text-white text-base">{profile?.displayName || 'Alya User'}</h3>
                <p className="text-xs text-slate-400">{profile?.email || 'Authenticated Account'}</p>
                <div className="flex items-center gap-2 mt-1">
                  <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-[10px] font-bold uppercase text-emerald-400 tracking-wider font-mono">
                    {preferences.cloudSyncEnabled ? 'Cloud Sync Active (Firestore)' : 'Local Storage Mode'}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 bg-slate-950/60 p-3 rounded-2xl border border-white/5">
              <div className="text-right hidden sm:block">
                <div className="text-xs font-bold text-white">Cross-Device Sync</div>
                <div className="text-[10px] text-slate-400">Sync with Android Companion</div>
              </div>
              <button
                type="button"
                onClick={() => handleUpdate({ cloudSyncEnabled: !preferences.cloudSyncEnabled })}
                className={`w-12 h-6 rounded-full p-1 transition-colors ${
                  preferences.cloudSyncEnabled ? 'bg-indigo-600' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  preferences.cloudSyncEnabled ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>
          </div>
        </section>

        {/* Dedicated Top-Level Gemini API Key & Personal Quota Section */}
        <section className="space-y-2">
          <SecureApiKeyManager onKeySaved={triggerSaveFeedback} />
        </section>

        {/* Alya Core Modular Features Accordion */}
        <section className="space-y-4">
          <div className="border-b border-white/10 pb-2">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-400 animate-pulse" /> Alya Core Modules
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">Toggle and configure advanced contextual systems of Alya Assistant.</p>
          </div>

          {[
            { id: 'biometric', label: 'Owner Speaker Biometrics', desc: 'Secure biometric voice profile enrollment for exclusive device control.', icon: ShieldAlert, component: <BiometricSpeakerEnrollment /> },
            { id: 'transcripts', label: 'Voice Transcripts', desc: 'Real-time list of historical voice transcript sessions and recordings.', icon: Mic, component: <VoiceTranscriptView /> },
            { id: 'brain', label: 'Brain & Agents', desc: 'Alya Core cognitive context registry and tool orchestration settings.', icon: Brain, component: <BrainView /> },
            { id: 'memory', label: 'Alya\'s Memory Storage', desc: 'Persistent facts, preferences, and details Alya has learned about you.', icon: Database, component: <MemoryView /> },
            { id: 'automations', label: 'Automations', desc: 'Accessibility and intent orchestration triggers for connected devices.', icon: Zap, component: <AutomationsView /> },
            { id: 'autoreply', label: 'Auto-Reply Manager', desc: 'Automated responses, notifications, and background intent processing.', icon: Bot, component: <AutoReplyView /> },
            { id: 'devices', label: 'Connected Devices', desc: 'Secure status and diagnostic connections to your paired Android devices.', icon: Smartphone, component: <DevicesView /> },
            { id: 'testing', label: 'Developer Testing Suite', desc: 'Run commands, troubleshoot pipelines, and verify raw API data stream.', icon: Terminal, component: <TestingView /> },
            { id: 'permissions', label: 'Security & Permissions', desc: 'Explicit consent registry, location access, and authentication logs.', icon: Shield, component: <PermissionsView /> },
          ].map((item, index) => {
            const isExpanded = expandedSection === item.id;
            const Icon = item.icon;
            return (
              <div 
                key={`setting-sec-${item.id}-${index}`} 
                className="bg-slate-900/95 border border-white/5 rounded-2xl overflow-hidden transition-all duration-200"
              >
                <button
                  type="button"
                  onClick={() => setExpandedSection(isExpanded ? null : item.id)}
                  className="w-full flex items-center justify-between p-4 hover:bg-white/5 transition-all text-left"
                >
                  <div className="flex items-center gap-3.5">
                    <div className={`p-2 rounded-xl bg-slate-950 border border-white/10 text-indigo-400`}>
                      <Icon className="w-4.5 h-4.5" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white leading-tight">{item.label}</h4>
                      <p className="text-[11px] text-slate-400 mt-0.5">{item.desc}</p>
                    </div>
                  </div>
                  {isExpanded ? (
                    <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
                  )}
                </button>
                <AnimatePresence>
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t border-white/5 bg-slate-950/40"
                    >
                      <div className="p-4 max-h-[70vh] overflow-y-auto">
                        {item.component}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </section>

        {/* 1. Identity, Personality Mood & Response Cadence */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-violet-400" /> Assistant Personality & Response Cadence
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Defines Alya's conversational tone, empathy level, and detail density.</p>
            </div>
            {history.some(h => h.key === 'assistantPersonality' || h.key === 'responseCadence') && (
              <button
                onClick={() => handleRevert('assistantPersonality')}
                className="text-[11px] text-indigo-400 hover:underline flex items-center gap-1"
              >
                <CornerDownLeft className="w-3 h-3" /> Revert Personality
              </button>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              {
                id: 'alya_default',
                name: 'Alya Default',
                desc: '18yo female human identity: Warm, expressive, smart & organic.'
              },
              {
                id: 'jarvis_formal',
                name: 'JARVIS Style',
                desc: 'Cinematic AI: Highly efficient, analytical, precise & direct.'
              },
              {
                id: 'warm_companion',
                name: 'Warm Companion',
                desc: 'Empathetic, attentive, friendly, and emotionally supportive.'
              },
              {
                id: 'concise_expert',
                name: 'Concise Expert',
                desc: '1-line answers, code-first, and zero conversational filler.'
              }
            ].map((p, index) => (
              <button
                key={`personality-${p.id}-${index}`}
                type="button"
                onClick={() => handleUpdate({ assistantPersonality: p.id as PersonalityType })}
                className={`p-3.5 rounded-2xl border text-left transition-all ${
                  preferences.assistantPersonality === p.id
                    ? 'bg-violet-600/15 border-violet-500 text-white shadow-xs'
                    : 'bg-slate-950/60 border-white/5 text-slate-400 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white">{p.name}</span>
                  {preferences.assistantPersonality === p.id && <Check className="w-3.5 h-3.5 text-violet-400" />}
                </div>
                <p className="text-[11px] text-slate-400 leading-snug">{p.desc}</p>
              </button>
            ))}
          </div>

          {/* Response Mode Selector */}
          <div className="pt-2 border-t border-white/5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <span className="text-xs font-bold text-slate-200">Assistant Response Mode</span>
              <p className="text-[11px] text-slate-400">Controls the style and length of Alya's replies.</p>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 w-full sm:w-auto">
              {[
                { id: 'SHORT', label: 'Short' },
                { id: 'NORMAL', label: 'Normal' },
                { id: '3-LINE', label: '3-Line' },
                { id: 'DETAILED', label: 'Detailed' }
              ].map((m, index) => (
                <button
                  key={`resp-mode-${m.id}-${index}`}
                  type="button"
                  onClick={() => handleUpdate({ responseMode: m.id as any })}
                  className={`px-3 py-1.5 rounded-xl border text-[10px] md:text-xs font-semibold transition ${
                    preferences.responseMode === m.id
                      ? 'bg-indigo-600 text-white border-indigo-500 shadow-lg shadow-indigo-500/20'
                      : 'bg-slate-950 border-white/5 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* 2. Neural Voice & Audio Engine */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-indigo-500/10 text-indigo-400">
                  <Volume2 className="w-4 h-4" />
                </span>
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  Unified Neural Voice & Audio Engine
                  <span className="px-2 py-0.5 rounded-full text-[10px] bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 font-medium">
                    24kHz Studio
                  </span>
                </h2>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Ultra-realistic female voices with dynamic prosody, non-overlapping AudioMutex, and zero-latency PCM streaming.
              </p>
            </div>
            
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleResetAudioEngine}
                disabled={isResettingAudio}
                title="Flush audio buffer and reset AudioContext locks"
                className="px-2.5 py-1.5 rounded-xl bg-slate-950/80 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-white/5 text-xs font-medium flex items-center gap-1.5 transition"
              >
                <RotateCcw className={`w-3 h-3 ${isResettingAudio ? 'animate-spin text-indigo-400' : ''}`} />
                <span className="hidden sm:inline">{isResettingAudio ? 'Resetting...' : 'Reset Engine'}</span>
              </button>

              <button
                type="button"
                onClick={() => handleTestVoiceSample()}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold flex items-center gap-2 transition shadow-sm ${
                  isPlayingVoiceSample && (!auditioningVoiceId || auditioningVoiceId === preferences.voiceName)
                    ? 'bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 shadow-rose-500/10'
                    : 'bg-indigo-600/20 hover:bg-indigo-600/30 text-indigo-300 border border-indigo-500/30 hover:border-indigo-500/50'
                }`}
              >
                {isPlayingVoiceSample && (!auditioningVoiceId || auditioningVoiceId === preferences.voiceName) ? (
                  <>
                    <Square className="w-3 h-3 fill-rose-400 text-rose-400" />
                    <span>Stop Sample</span>
                    <div className="flex items-center gap-0.5 h-3 ml-0.5">
                      <span className="w-0.5 h-3 bg-rose-400 rounded-full animate-pulse" />
                      <span className="w-0.5 h-2 bg-rose-300 rounded-full animate-pulse delay-75" />
                      <span className="w-0.5 h-3.5 bg-rose-400 rounded-full animate-pulse delay-150" />
                    </div>
                  </>
                ) : (
                  <>
                    <Play className="w-3 h-3 fill-indigo-400 text-indigo-400" />
                    <span>Test Voice Sample</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Voice Presets Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              { 
                id: 'Aoede', 
                label: 'Aoede (Signature Alya)', 
                tag: 'Signature • 24kHz',
                desc: 'Natural, expressive, clear tone with dynamic melodic cadence. The canon voice of Alya.' 
              },
              { 
                id: 'Kore', 
                label: 'Kore (Warm Human)', 
                tag: 'Organic Warmth',
                desc: 'Soft, gentle, conversational rhythm with natural human breath and intimate warmth.' 
              },
              { 
                id: 'Ursa', 
                label: 'Ursa (Confident & Crisp)', 
                tag: 'Resonant & Bold',
                desc: 'Confident, clear, crisp, and resonant delivery with immaculate articulation.' 
              },
              { 
                id: 'Callirrhoe', 
                label: 'Callirrhoe (Bright & Upbeat)', 
                tag: 'Cheerful & Lively',
                desc: 'Bright, cheerful, energetic vocal tone that feels optimistic, friendly, and enthusiastic.' 
              },
              { 
                id: 'Leda', 
                label: 'Leda (Gentle & Soothing)', 
                tag: 'Tranquil & Serene',
                desc: 'Tranquil, peaceful, and gentle cadence. Ideal for calm, late-night conversations.' 
              },
              { 
                id: 'Zephyr', 
                label: 'Zephyr (Modern Neutral)', 
                tag: 'Balanced Acoustic',
                desc: 'Clean, neutral, modern vocal tone with balanced acoustic clarity across languages.' 
              }
            ].map((v, index) => {
              const isSelected = preferences.voiceName === v.id;
              const isAuditioningThis = isPlayingVoiceSample && auditioningVoiceId === v.id;

              return (
                <div
                  key={`voice-${v.id}-${index}`}
                  className={`relative p-3.5 rounded-2xl border transition-all flex flex-col justify-between group ${
                    isSelected
                      ? 'bg-indigo-600/15 border-indigo-500 shadow-md shadow-indigo-500/10'
                      : 'bg-slate-950/60 border-white/5 hover:border-slate-700'
                  }`}
                >
                  <div 
                    onClick={() => handleUpdate({ voiceName: v.id })}
                    className="cursor-pointer"
                  >
                    <div className="flex items-start justify-between gap-1 mb-1.5">
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-xs font-bold text-white group-hover:text-indigo-200 transition">
                            {v.label}
                          </span>
                        </div>
                        <span className="inline-block mt-0.5 text-[10px] font-medium text-indigo-400/90 bg-indigo-500/10 px-1.5 py-0.5 rounded-md border border-indigo-500/20">
                          {v.tag}
                        </span>
                      </div>
                      {isSelected ? (
                        <div className="w-5 h-5 rounded-full bg-indigo-500/20 border border-indigo-400 flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 text-indigo-300" />
                        </div>
                      ) : (
                        <div className="w-5 h-5 rounded-full border border-white/10 group-hover:border-slate-500 shrink-0" />
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 leading-snug line-clamp-2 mt-1">
                      {v.desc}
                    </p>
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-white/5 flex items-center justify-between">
                    <button
                      type="button"
                      onClick={() => handleUpdate({ voiceName: v.id })}
                      className={`text-[11px] font-medium transition ${
                        isSelected ? 'text-indigo-400 font-semibold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {isSelected ? 'Active Voice' : 'Set as Active'}
                    </button>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleTestVoiceSample(v.id);
                      }}
                      className={`px-2 py-1 rounded-lg border text-[10px] font-semibold flex items-center gap-1 transition ${
                        isAuditioningThis
                          ? 'bg-rose-500/20 border-rose-500/40 text-rose-300'
                          : 'bg-slate-900 border-white/10 text-slate-300 hover:text-white hover:border-indigo-500/40'
                      }`}
                    >
                      {isAuditioningThis ? (
                        <>
                          <Square className="w-2.5 h-2.5 fill-rose-400 text-rose-400" />
                          <span>Stop</span>
                          <div className="flex items-center gap-0.5 h-2.5 ml-0.5">
                            <span className="w-0.5 h-2.5 bg-rose-400 rounded-full animate-pulse" />
                            <span className="w-0.5 h-1.5 bg-rose-300 rounded-full animate-pulse delay-75" />
                            <span className="w-0.5 h-2 bg-rose-400 rounded-full animate-pulse delay-150" />
                          </div>
                        </>
                      ) : (
                        <>
                          <Play className="w-2.5 h-2.5 fill-current text-indigo-400" />
                          <span>Audition</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Speed & Pitch Controls */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-3 border-t border-white/5">
            <div className="space-y-2 bg-slate-950/50 p-3.5 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="font-medium flex items-center gap-1.5">
                  <Activity className="w-3.5 h-3.5 text-indigo-400" /> Speaking Rate / Speed
                </span>
                <span className="font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                  {preferences.speechSpeed}x
                </span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.5"
                step="0.05"
                value={preferences.speechSpeed}
                onChange={(e) => handleUpdate({ speechSpeed: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>0.8x (Deliberate)</span>
                <span>1.0x (Natural)</span>
                <span>1.5x (Fast)</span>
              </div>
            </div>

            <div className="space-y-2 bg-slate-950/50 p-3.5 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between text-xs text-slate-300">
                <span className="font-medium flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-indigo-400" /> Voice Pitch Modulation
                </span>
                <span className="font-mono text-indigo-400 font-bold bg-indigo-500/10 px-2 py-0.5 rounded-md border border-indigo-500/20">
                  {preferences.speechPitch > 0 ? `+${preferences.speechPitch}` : preferences.speechPitch}
                </span>
              </div>
              <input
                type="range"
                min="-2"
                max="2"
                step="0.5"
                value={preferences.speechPitch}
                onChange={(e) => handleUpdate({ speechPitch: parseFloat(e.target.value) })}
                className="w-full accent-indigo-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-slate-500">
                <span>-2 (Deeper)</span>
                <span>0 (Default)</span>
                <span>+2 (Higher)</span>
              </div>
            </div>
          </div>

          {/* Engine Pipeline Diagnostics Strip */}
          <div className="pt-2">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px]">
              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shrink-0" />
                <div className="truncate">
                  <p className="text-[10px] text-slate-400">Sample Rate</p>
                  <p className="font-medium text-white">24,000 Hz PCM</p>
                </div>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-indigo-400 shrink-0" />
                <div className="truncate">
                  <p className="text-[10px] text-slate-400">RingBuffer</p>
                  <p className="font-medium text-white">Zero-Allocation</p>
                </div>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-cyan-400 shrink-0" />
                <div className="truncate">
                  <p className="text-[10px] text-slate-400">AudioMutex</p>
                  <p className="font-medium text-white">Non-Overlapping</p>
                </div>
              </div>

              <div className="bg-slate-950/60 p-2.5 rounded-xl border border-white/5 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-amber-400 shrink-0" />
                <div className="truncate">
                  <p className="text-[10px] text-slate-400">Interruption</p>
                  <p className="font-medium text-white">Instant Barge-In</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. Multilingual Support & Selector */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
            <div>
              <div className="flex items-center gap-2">
                <span className="p-1.5 rounded-lg bg-emerald-500/10 text-emerald-400">
                  <Languages className="w-4 h-4" />
                </span>
                <h2 className="text-sm font-bold text-white">
                  Multilingual Understanding & Response
                </h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                  {SUPPORTED_LANGUAGES.length - 1}+ Languages & Dialects
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                Alya understands, processes, and mirrors 170+ regional languages and dialects across 35+ countries with authentic cultural phrasing and native speech synthesis.
              </p>
            </div>

            {/* Currently Active Language Badge */}
            {(() => {
              const currentLang = LanguageDetector.getLanguageInfo(preferences.language);
              return (
                <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-2xl bg-emerald-950/40 border border-emerald-500/30 text-xs shrink-0">
                  <span className="text-lg">{currentLang.flag}</span>
                  <div>
                    <div className="text-[10px] uppercase font-bold text-emerald-400 tracking-wider">Active Language</div>
                    <div className="text-xs font-semibold text-white">{currentLang.name}</div>
                  </div>
                </div>
              );
            })()}
          </div>

          {/* Search & Country Filter Bar */}
          <div className="flex flex-col sm:flex-row items-center gap-2.5 pt-1">
            <div className="relative flex-1 w-full">
              <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by language, dialect, country (e.g. Rajbongshi, Assamese, India, বাংলা)..."
                value={langSearch}
                onChange={(e) => setLangSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500/50"
              />
              {langSearch && (
                <button
                  type="button"
                  onClick={() => setLangSearch('')}
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white text-xs px-1"
                >
                  ✕
                </button>
              )}
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="px-3 py-2 bg-slate-950 border border-white/10 rounded-xl text-xs text-slate-200 focus:outline-none focus:border-emerald-500/50 w-full sm:w-56 cursor-pointer"
              >
                <option value="All">🌐 All Countries ({SUPPORTED_LANGUAGES.length - 1} languages)</option>
                {countries.map((c) => (
                  <option key={c.country} value={c.country}>
                    {c.flag} {c.country} ({c.count})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Popular Country Quick Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-[11px]">
            {['All', 'India', 'Bangladesh', 'Nepal', 'Pakistan', 'Japan', 'China', 'South Korea', 'United States', 'United Kingdom', 'Germany', 'France', 'Spain'].map((cName) => {
              const isSelected = selectedCountry === cName;
              const foundCountry = countries.find(c => c.country === cName);
              const flag = cName === 'All' ? '🌐' : foundCountry ? foundCountry.flag : '';
              const count = cName === 'All' ? SUPPORTED_LANGUAGES.length - 1 : foundCountry ? foundCountry.count : '';
              return (
                <button
                  key={cName}
                  type="button"
                  onClick={() => setSelectedCountry(cName)}
                  className={`px-2.5 py-1 rounded-lg border whitespace-nowrap transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-emerald-500/20 border-emerald-500/50 text-emerald-300 font-semibold'
                      : 'bg-slate-950/60 hover:bg-slate-950 border-white/5 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  <span className="mr-1">{flag}</span>
                  <span>{cName}</span>
                  {count !== '' && <span className="ml-1 opacity-60 text-[10px]">({count})</span>}
                </button>
              );
            })}
          </div>

          {/* Languages Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5 max-h-72 overflow-y-auto pr-1 pt-1">
            {filteredLanguages.map((l, index) => {
              const isSelected = preferences.language === l.code;
              return (
                <button
                  key={`${l.code}-${index}`}
                  onClick={() => handleUpdate({ language: l.code })}
                  className={`p-2.5 rounded-xl border text-left transition-all relative group cursor-pointer ${
                    isSelected 
                      ? 'bg-emerald-500/15 border-emerald-500 text-white shadow-sm ring-1 ring-emerald-500/30' 
                      : 'bg-slate-950/60 hover:bg-slate-950 border-white/5 text-slate-400 hover:border-white/10'
                  }`}
                >
                  <div className="flex items-start justify-between gap-1.5">
                    <div className="flex items-center gap-2 overflow-hidden">
                      <span className="text-base shrink-0">{l.flag}</span>
                      <div className="overflow-hidden">
                        <div className="font-bold text-xs text-white truncate group-hover:text-emerald-300 transition-colors">
                          {l.name}
                        </div>
                        <div className="text-[10px] text-slate-400 truncate">
                          {l.nativeName}
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <span className="text-emerald-400 shrink-0">
                        <Check className="w-3.5 h-3.5" />
                      </span>
                    )}
                  </div>
                  {l.country !== 'Global' && (
                    <div className="mt-1.5 flex items-center justify-between text-[9px] text-slate-500">
                      <span className="truncate">{l.country}</span>
                      <span className="font-mono opacity-60 uppercase">{l.code}</span>
                    </div>
                  )}
                </button>
              );
            })}
            {filteredLanguages.length === 0 && (
              <div className="col-span-full py-8 text-center text-xs text-slate-500">
                No languages found matching "{langSearch}". Try searching by country name or code.
              </div>
            )}
          </div>
          <div className="text-[11px] text-slate-500 flex items-center justify-between pt-1 border-t border-white/5">
            <span>Showing {filteredLanguages.length} of {SUPPORTED_LANGUAGES.length} language options</span>
            <span className="text-emerald-400/80">Permanent preference lock enabled</span>
          </div>
        </section>

        {/* 4. Wake Word Triggers & Sensitivity */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <Mic className="w-4 h-4 text-amber-400" /> Wake Word Triggers (Offline Engine)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Activate Alya hands-free with real offline voice detection.</p>
            </div>
            <span className="px-2.5 py-1 bg-amber-500/20 text-amber-400 border border-amber-500/30 text-[10px] font-bold rounded-lg uppercase">
              Low False Positive
            </span>
          </div>

          <div className="space-y-2">
            {[
              { id: 'alya', label: 'Hey Alya', state: preferences.wakeWords.alya },
              { id: 'alia', label: 'Hey Alia', state: preferences.wakeWords.alia },
              { id: 'seno', label: 'Hey Seno', state: preferences.wakeWords.seno }
            ].map((ww, index) => (
              <div key={`ww-${ww.id}-${index}`} className="flex items-center justify-between p-3.5 bg-slate-950/60 rounded-2xl border border-white/5">
                <span className="text-xs font-bold text-white">"{ww.label}"</span>
                <button
                  type="button"
                  onClick={() => handleUpdate({
                    wakeWords: {
                      ...preferences.wakeWords,
                      [ww.id]: !ww.state
                    }
                  })}
                  className={`w-12 h-6 rounded-full p-1 transition-colors ${
                    ww.state ? 'bg-amber-600' : 'bg-slate-800'
                  }`}
                >
                  <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                    ww.state ? 'translate-x-6' : 'translate-x-0'
                  }`} />
                </button>
              </div>
            ))}
          </div>

          <div className="pt-2">
            <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
              <span>Wake Sensitivity Threshold</span>
              <span className="font-mono text-amber-400 font-bold">{Math.round(preferences.wakeWords.sensitivity * 100)}%</span>
            </div>
            <input 
              type="range" 
              min="0.1" 
              max="1.0" 
              step="0.05"
              value={preferences.wakeWords.sensitivity}
              onChange={(e) => handleUpdate({
                wakeWords: {
                  ...preferences.wakeWords,
                  sensitivity: parseFloat(e.target.value)
                }
              })}
              className="w-full accent-amber-500 bg-slate-800 rounded-lg h-1.5 cursor-pointer"
            />
          </div>
        </section>

        {/* 5. Location Permission & Local Intelligence */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-2xl border border-cyan-500/20">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">Location Preference & Weather Grounding</h2>
                <p className="text-xs text-slate-400">User-controlled geolocation for live weather, nearby places, and local time.</p>
              </div>
            </div>
            <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider border border-white/10">
              {browserPermState === 'granted' ? (
                <span className="text-emerald-400">GPS Granted</span>
              ) : browserPermState === 'denied' ? (
                <span className="text-rose-400">GPS Denied</span>
              ) : (
                <span className="text-amber-400">Permission Prompt</span>
              )}
            </div>
          </div>

          {/* Mode Selector */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              {
                id: 'auto',
                title: 'Automatic GPS',
                desc: 'Requests device/browser location on demand for precise local weather and places.'
              },
              {
                id: 'manual',
                title: 'Manual City Only',
                desc: 'Uses configured city without requesting device coordinates or GPS fixes.'
              },
              {
                id: 'disabled',
                title: 'Privacy Mode (Disabled)',
                desc: 'Completely disables location requests. Alya will ask for city per query.'
              }
            ].map((m, index) => (
              <button
                key={`loc-pref-${m.id}-${index}`}
                type="button"
                onClick={() => handleUpdate({ locationPreference: m.id as any })}
                className={`p-3.5 rounded-2xl border text-left transition-all ${
                  preferences.locationPreference === m.id
                    ? 'bg-cyan-950/40 border-cyan-500/40 text-white shadow-xs'
                    : 'bg-slate-950/40 border-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-bold text-white">{m.title}</span>
                  {preferences.locationPreference === m.id && <Check className="w-3.5 h-3.5 text-cyan-400" />}
                </div>
                <p className="text-[11px] leading-relaxed text-slate-400">{m.desc}</p>
              </button>
            ))}
          </div>

          {/* Manual City Configuration */}
          <div className="p-4 bg-slate-950/60 rounded-2xl border border-white/5 space-y-3">
            <label className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
              <Compass className="w-3.5 h-3.5 text-cyan-400" />
              Default / Fallback City Name
            </label>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={preferences.manualCity}
                onChange={(e) => handleUpdate({ manualCity: e.target.value })}
                placeholder="e.g. Kolkata, Mumbai, Delhi, London, New York..."
                className="flex-1 px-3.5 py-2 bg-slate-900 border border-white/10 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500/50"
              />
            </div>
          </div>

          {/* Test Live Weather & Location */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs text-slate-400">Verify real-time Open-Meteo weather & location fetching:</span>
              <button
                type="button"
                onClick={handleTestLocationAndWeather}
                disabled={isTestingLocation}
                className="px-3 py-1.5 bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/30 rounded-xl text-xs font-bold text-indigo-300 flex items-center gap-1.5 transition-all"
              >
                {isTestingLocation ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <CloudSun className="w-3.5 h-3.5" />}
                {isTestingLocation ? 'Acquiring...' : 'Test Weather & GPS'}
              </button>
            </div>

            {locationTestError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{locationTestError}</span>
              </div>
            )}

            {weatherPreview && (
              <motion.div
                initial={{ opacity: 0, y: 5 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-4 rounded-2xl bg-gradient-to-br from-indigo-950/70 to-slate-950/90 border border-cyan-500/30 shadow-md space-y-3"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <div className="flex items-center gap-2 font-bold text-sm text-white">
                      <MapPin className="w-4 h-4 text-cyan-400" />
                      <span>{weatherPreview.current.locationName}</span>
                    </div>
                    <span className="text-xs text-slate-400">{weatherPreview.current.condition.description}</span>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-black text-white font-mono">{weatherPreview.current.temperature}°C</div>
                    <div className="text-[10px] text-slate-400">Feels like {weatherPreview.current.feelsLike}°C</div>
                  </div>
                </div>

                <div className="grid grid-cols-3 gap-2 pt-2 border-t border-white/5 text-xs text-slate-300">
                  <div className="flex items-center gap-1.5">
                    <Droplets className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                    <span>Humidity: {weatherPreview.current.humidity}%</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Wind className="w-3.5 h-3.5 text-teal-400 shrink-0" />
                    <span>Wind: {weatherPreview.current.windSpeed} km/h</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Thermometer className="w-3.5 h-3.5 text-rose-400 shrink-0" />
                    <span>Pressure: {weatherPreview.current.pressure} hPa</span>
                  </div>
                </div>
              </motion.div>
            )}
          </div>
        </section>

        {/* 6. Device Security & Offline Engine */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
                <Shield className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">Device Control & Offline Capabilities</h2>
                <p className="text-xs text-slate-400">Security policies for executing phone hardware actions and local fallback operations.</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between p-4 bg-slate-950/60 rounded-2xl border border-white/5">
              <div>
                <div className="text-xs font-bold text-white">Offline Capabilities Engine</div>
                <p className="text-[11px] text-slate-400">Execute device controls & local queries without internet.</p>
              </div>
              <button
                type="button"
                onClick={() => handleUpdate({ offlineMode: !preferences.offlineMode })}
                className={`w-12 h-6 rounded-full p-1 transition-colors ${
                  preferences.offlineMode ? 'bg-emerald-600' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  preferences.offlineMode ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            <div className="p-4 bg-slate-950/60 rounded-2xl border border-white/5 space-y-2">
              <label className="text-xs font-bold text-slate-200">Device Action Confirmation Policy</label>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
                {[
                  { id: 'confirm_sensitive', label: 'Confirm Sensitive (Recommended)' },
                  { id: 'always_confirm', label: 'Always Ask Confirmation' },
                  { id: 'auto_execute', label: 'Auto-Execute Authorized' }
                ].map((m, index) => (
                  <button
                    key={`dev-confirm-${m.id}-${index}`}
                    type="button"
                    onClick={() => handleUpdate({ deviceControlConfirmation: m.id as DeviceControlMode })}
                    className={`p-2.5 rounded-xl border text-xs font-semibold text-center transition ${
                      preferences.deviceControlConfirmation === m.id
                        ? 'bg-indigo-600 text-white border-indigo-500'
                        : 'bg-slate-900 border-white/5 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {m.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* 7. Low Internet Consumption & Roo Code / Cline 24/7 Developer Integration */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-2xl border border-cyan-500/20">
                <Wifi className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white flex items-center gap-2">
                  <span>Low Internet Consumption & 24/7 Developer Endpoints</span>
                  <span className="px-2 py-0.5 rounded-full text-[9px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 uppercase">
                    24/7 Active
                  </span>
                </h2>
                <p className="text-xs text-slate-400">Optimize data usage on cellular/mobile connections and connect Roo Code / Cline agent extensions.</p>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            {/* Data Saver Mode Toggle */}
            <div className="flex items-center justify-between p-4 bg-slate-950/60 rounded-2xl border border-white/5">
              <div>
                <div className="text-xs font-bold text-white flex items-center gap-2">
                  <span>Data Saver Mode (Low Bandwidth)</span>
                  {preferences.dataSaver && (
                    <span className="text-[10px] text-cyan-400 font-mono font-bold">~70% Savings</span>
                  )}
                </div>
                <p className="text-[11px] text-slate-400">Strips heavy execution traces, optimizes audio sample rates, and caches replies for instant response.</p>
              </div>
              <button
                type="button"
                onClick={() => handleUpdate({ dataSaver: !preferences.dataSaver })}
                className={`w-12 h-6 rounded-full p-1 transition-colors ${
                  preferences.dataSaver ? 'bg-cyan-600' : 'bg-slate-800'
                }`}
              >
                <div className={`w-4 h-4 rounded-full bg-white transition-transform ${
                  preferences.dataSaver ? 'translate-x-6' : 'translate-x-0'
                }`} />
              </button>
            </div>

            {/* Roo Code & Cline Endpoints Summary */}
            <div className="p-4 bg-slate-950/60 rounded-2xl border border-white/5 space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200 flex items-center gap-2">
                  <Terminal className="w-4 h-4 text-indigo-400" />
                  Roo Code & Cline Integration
                </span>
                <span className="text-[11px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  24/7 Active
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Use Alya Assistant as an MCP Server or OpenAI-compatible backend in your editor.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 font-mono text-xs">
                <div className="p-3 bg-slate-900 rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-bold">MCP Server URL</span>
                    <span className="text-indigo-300 truncate max-w-[200px] block">/api/mcp</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/api/mcp`);
                      triggerSaveFeedback();
                    }}
                    className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                    title="Copy URL"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
                <div className="p-3 bg-slate-900 rounded-xl border border-white/5 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 uppercase block font-bold">OpenAI Base URL</span>
                    <span className="text-indigo-300 truncate max-w-[200px] block">/v1</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      navigator.clipboard.writeText(`${window.location.origin}/v1`);
                      triggerSaveFeedback();
                    }}
                    className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors"
                    title="Copy URL"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 9. About Section & Gemini API Key Settings */}
        <section className="bg-slate-900/85 rounded-3xl border border-white/5 p-6 space-y-4">
          <button
            onClick={() => setExpandedSection(expandedSection === 'about' ? null : 'about')}
            className="w-full flex items-center justify-between text-left focus:outline-none"
          >
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-indigo-500/10 text-indigo-400 rounded-2xl border border-indigo-500/20">
                <Info className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-sm font-bold text-white">About Alya & API Configuration</h2>
                <p className="text-xs text-slate-400">View assistant status, system details and configure custom Google Gemini API Key.</p>
              </div>
            </div>
            {expandedSection === 'about' ? (
              <ChevronUp className="w-4 h-4 text-slate-400 shrink-0" />
            ) : (
              <ChevronDown className="w-4 h-4 text-slate-400 shrink-0" />
            )}
          </button>

          <AnimatePresence>
            {expandedSection === 'about' && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: 'auto', opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="pt-4 border-t border-white/5 space-y-4"
              >
                <div>
                  <h3 className="text-xs font-bold text-slate-200 uppercase tracking-wider">Alya Assistant</h3>
                  <p className="text-xs text-slate-400 mt-1 leading-relaxed text-justify">
                    Alya Assistant is a highly advanced, fast, and intelligent personal digital assistant designed to feel natural and human-like. 
                    Built for the modern era, she understands complex conversational context, manages device hardware with precision, and provides immediate responses through optimized parallel processing.
                  </p>
                  <div className="mt-3 pt-3 border-t border-white/5 space-y-1.5 text-[10px]">
                    <div className="flex justify-between items-center text-slate-400">
                      <span className="font-semibold text-slate-300">Developer</span>
                      <span>Rohim Mandal</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-400">
                      <span className="font-semibold text-slate-300">Studio</span>
                      <span>SUPER BIND SAMSTAR MOBILE 35 GEN-Z Studio</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-400">
                      <span className="font-semibold text-slate-300">Studio Short Name</span>
                      <span>SBSM35G-Z STUDIO</span>
                    </div>
                    <div className="flex justify-between items-center text-slate-400">
                      <span className="font-semibold text-slate-300">Version</span>
                      <span>3.5.0-GEN-Z</span>
                    </div>
                  </div>
                </div>

                <SecureApiKeyManager compact onKeySaved={triggerSaveFeedback} />
              </motion.div>
            )}
          </AnimatePresence>
        </section>

        {/* 8. Backup, Import, Reset & Sign Out */}
        <section className="bg-slate-900/80 rounded-3xl border border-white/5 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-slate-400" /> Preference Backup & Reset
            </h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              onClick={() => setShowImportModal(true)}
              className="p-3.5 bg-slate-950/60 hover:bg-slate-950 border border-white/5 rounded-2xl text-xs font-semibold text-slate-300 flex items-center justify-center gap-2 transition"
            >
              <Upload className="w-4 h-4 text-cyan-400" /> Import Settings from JSON
            </button>
            <button
              onClick={() => setShowResetConfirmModal(true)}
              className="p-3.5 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 rounded-2xl text-xs font-semibold text-rose-300 flex items-center justify-center gap-2 transition"
            >
              <RotateCcw className="w-4 h-4 text-rose-400" /> Reset All Settings to Default
            </button>
          </div>

          <div className="pt-2 border-t border-white/5">
            <button
              onClick={logout}
              className="w-full flex items-center justify-center gap-2 p-3.5 bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 rounded-2xl font-bold transition-all text-xs uppercase tracking-wider"
            >
              <LogOut className="w-4 h-4" />
              Sign Out of Alya Core
            </button>
          </div>
        </section>
      </div>

      {/* History / Audit Log Modal */}
      <AnimatePresence>
        {showHistoryModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 space-y-4 max-h-[80vh] flex flex-col shadow-2xl"
            >
              <div className="flex items-center justify-between pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2 text-sm font-bold text-white">
                  <History className="w-4 h-4 text-indigo-400" />
                  Settings Audit & Change History ({history.length})
                </div>
                <button 
                  onClick={() => setShowHistoryModal(false)}
                  className="text-xs text-slate-400 hover:text-white px-2 py-1 bg-slate-800 rounded-lg"
                >
                  Close
                </button>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2 pr-1">
                {history.length === 0 ? (
                  <div className="text-center py-8 text-slate-500 text-xs">No setting modifications recorded yet.</div>
                ) : (
                  history.map((h) => (
                    <div key={h.id} className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between gap-3 text-xs">
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-white font-mono">{h.key}</span>
                          <span className="text-[10px] px-1.5 py-0.2 bg-slate-800 text-indigo-300 rounded font-mono">
                            {h.source}
                          </span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          <span className="text-rose-400 line-through mr-1">{JSON.stringify(h.oldValue)}</span>
                          <ArrowRight className="inline w-3 h-3 text-slate-500 mx-1" />
                          <span className="text-emerald-400 font-semibold">{JSON.stringify(h.newValue)}</span>
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {new Date(h.timestamp).toLocaleString()}
                        </div>
                      </div>
                      <button
                        onClick={() => handleRevert(h.key)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition shrink-0"
                      >
                        <CornerDownLeft className="w-3 h-3" /> Revert
                      </button>
                    </div>
                  ))
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Reset Confirmation Modal */}
      <AnimatePresence>
        {showResetConfirmModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-rose-500/30 rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl"
            >
              <div className="w-12 h-12 rounded-2xl bg-rose-500/20 border border-rose-500/30 flex items-center justify-center text-rose-400">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Reset All Settings?</h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  This will restore all preferences (language, wake words, personality, voice, and offline options) to their factory defaults. This action cannot be undone automatically.
                </p>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => setShowResetConfirmModal(false)}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-semibold"
                >
                  Cancel
                </button>
                <button
                  onClick={handleResetAll}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-xs font-semibold shadow-md shadow-rose-900/30"
                >
                  Confirm Reset
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Import Modal */}
      <AnimatePresence>
        {showImportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-slate-900 border border-slate-800 rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl"
            >
              <div className="flex items-center justify-between pb-2 border-b border-slate-800">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Upload className="w-4 h-4 text-cyan-400" /> Import Settings JSON
                </h3>
                <button 
                  onClick={() => setShowImportModal(false)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
              </div>

              <form onSubmit={handleImportSubmit} className="space-y-3">
                <textarea
                  rows={8}
                  value={importJsonText}
                  onChange={(e) => setImportJsonText(e.target.value)}
                  placeholder="Paste exported JSON settings here..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs font-mono text-slate-200 focus:outline-none focus:border-cyan-500 resize-none"
                />

                {importError && (
                  <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/20 text-rose-300 text-xs">
                    {importError}
                  </div>
                )}

                <button
                  type="submit"
                  className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-xs rounded-xl transition"
                >
                  Validate & Apply Settings
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
