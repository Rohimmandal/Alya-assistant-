import { liveKitDiagnosticService } from '../lib/LiveKitDiagnosticService';

export interface WebSocketDiagnosticMetrics {
  latencyMs: number | null;
  heartbeatDrops: number;
  audioChunkDeliveryGaps: number;
  connectionState: string;
}

type MetricsListener = (metrics: WebSocketDiagnosticMetrics) => void;

class WebSocketDiagnosticsService {
  private listeners: Set<MetricsListener> = new Set();
  private lastChunkTime: number = 0;
  private gapCount: number = 0;
  private readonly GAP_THRESHOLD_MS = 1000; // 1 second gap considered failure

  constructor() {
    // Monitor heartbeat drops via LiveKitDiagnosticService
    liveKitDiagnosticService.subscribe((logs, metrics) => {
      this.notify();
    });
  }

  public getMetrics(): WebSocketDiagnosticMetrics {
    const lkMetrics = liveKitDiagnosticService.getMetrics();
    
    return {
      latencyMs: lkMetrics.lastLatencyMs,
      heartbeatDrops: lkMetrics.timeoutCount,
      audioChunkDeliveryGaps: this.gapCount,
      connectionState: lkMetrics.connectionState
    };
  }

  public trackAudioChunkArrival() {
    const now = Date.now();
    if (this.lastChunkTime !== 0 && (now - this.lastChunkTime) > this.GAP_THRESHOLD_MS) {
        this.gapCount++;
        console.warn(`[WebSocketDiagnostics] Audio chunk delivery gap detected: ${now - this.lastChunkTime}ms`);
    }
    this.lastChunkTime = now;
    this.notify();
  }

  public subscribe(listener: MetricsListener) {
    this.listeners.add(listener);
    listener(this.getMetrics());
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const metrics = this.getMetrics();
    this.listeners.forEach(l => l(metrics));
  }
}

export const webSocketDiagnosticsService = new WebSocketDiagnosticsService();
