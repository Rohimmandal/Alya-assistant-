/**
 * LocationCapability.ts
 * Dedicated Client-Side Location Capability Service
 * Leverages the browser's Geolocation API to fetch precise, real-time user coordinates.
 */

import { locationService, LocationContext } from '../lib/locationService';

export class LocationCapability {
  /**
   * Fetches precise, real-time GPS coordinates of the user.
   * Prompts the user if permission is needed, reverse-geocodes locality details, and returns the context.
   */
  public static async getPreciseCoordinates(timeoutMs: number = 7000): Promise<LocationContext | null> {
    try {
      const res = await locationService.getCurrentLocation(timeoutMs);
      if (res.success && res.context) {
        console.log('[LocationCapability] Precise coordinates fetched successfully:', res.context);
        return res.context;
      } else {
        console.warn('[LocationCapability] Failed to fetch coordinates:', res.error || 'Unknown error');
      }
    } catch (err) {
      console.error('[LocationCapability] Error in coordinates acquisition:', err);
    }
    return null;
  }
}
