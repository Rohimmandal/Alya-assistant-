/**
 * Gemini 3.1 Flash Live Service (Client-Side SDK Bridge) for Alya Assistant
 * Uses @google/genai SDK concepts for real-time continuous bidirectional audio streaming.
 * Model: gemini-3.1-flash-live-preview
 * Modality: Strictly Audio-to-Audio
 */

import { GoogleGenAI, Modality } from '@google/genai';
import { PCMAudioProcessor, AudioDiagnosticMetrics } from '../utils/pcmAudioProcessor';
import { secureStorage } from '../lib/secureStorage';

export interface GeminiLiveOptions {
  onAudioChunk?: (base64Audio: string) => void;
  onInterrupted?: () => void;
  onToolCall?: (toolCall: any) => void;
  onError?: (error: string) => void;
  onStateChange?: (state: 'disconnected' | 'connecting' | 'listening' | 'speaking') => void;
  onEnergyLevel?: (rms: number) => void;
  onDiagnosticsUpdate?: (metrics: AudioDiagnosticMetrics) => void;
}

export class GeminiLiveService {
  private ws: WebSocket | null = null;
  private pcmProcessor: PCMAudioProcessor | null = null;
  private options: GeminiLiveOptions;
  private state: 'disconnected' | 'connecting' | 'listening' | 'speaking' = 'disconnected';

  constructor(options: GeminiLiveOptions) {
    this.options = options;
  }

  public getState() {
    return this.state;
  }

  private setState(state: 'disconnected' | 'connecting' | 'listening' | 'speaking') {
    this.state = state;
    if (this.options.onStateChange) {
      this.options.onStateChange(state);
    }
  }

  public getDiagnostics(): AudioDiagnosticMetrics | null {
    return this.pcmProcessor ? this.pcmProcessor.getDiagnostics() : null;
  }

  /**
   * Establishes continuous bidirectional audio stream session using Gemini Live API
   */
  public async connect(): Promise<void> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') return;

    this.setState('connecting');

    try {
      // Connect securely via WebSocket bridge to backend Gemini 3.1 Flash Live Service
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const userId = localStorage.getItem('alya_user_id') || 'default_user';
      const localApiKey = await secureStorage.getSecureApiKey();
      const wsUrl = `${protocol}//${window.location.host}/ws/gemini-live?userId=${encodeURIComponent(userId)}&apiKey=${encodeURIComponent(localApiKey)}`;
      
      const ws = new WebSocket(wsUrl);
      this.ws = ws;

      ws.onopen = async () => {
        try {
          this.pcmProcessor = new PCMAudioProcessor({
            sampleRate: 16000,
            bufferSize: 2048,
            onAudioChunk: (base64Audio) => {
              if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({
                  type: 'AUDIO_CHUNK',
                  audio: base64Audio
                }));
              }
            },
            onEnergyLevel: (rms) => {
              if (this.options.onEnergyLevel) {
                this.options.onEnergyLevel(rms);
              }
              // Barge-in detection: user starts speaking while assistant is outputting speech
              if (rms > 0.04 && this.state === 'speaking') {
                this.setState('listening');
                if (this.options.onInterrupted) {
                  this.options.onInterrupted();
                }
              }
            },
            onDiagnosticsUpdate: (metrics) => {
              if (this.options.onDiagnosticsUpdate) {
                this.options.onDiagnosticsUpdate(metrics);
              }
            },
            onError: (err) => {
              console.error('[GeminiLiveService] Audio processor error:', err);
              if (this.options.onError) this.options.onError(err.message);
            }
          });

          await this.pcmProcessor.start();
          this.setState('listening');
        } catch (micErr: any) {
          console.error('[GeminiLiveService] Microphone capture failed:', micErr);
          if (this.options.onError) this.options.onError(micErr?.message || 'Microphone access required.');
          this.disconnect();
        }
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.type === 'LIVE_AUDIO' && msg.audio) {
            this.setState('speaking');
            if (this.options.onAudioChunk) {
              this.options.onAudioChunk(msg.audio);
            }
          }

          if (msg.type === 'LIVE_INTERRUPTED') {
            this.setState('listening');
            if (this.options.onInterrupted) {
              this.options.onInterrupted();
            }
          }

          if (msg.type === 'LIVE_TOOL_CALL' && msg.toolCall) {
            if (this.options.onToolCall) {
              this.options.onToolCall(msg.toolCall);
            }
          }

          if (msg.type === 'LIVE_ERROR') {
            if (this.options.onError) {
              this.options.onError(msg.error);
            }
          }
        } catch (e) {
          console.warn('[GeminiLiveService] Message parse error:', e);
        }
      };

      ws.onerror = (err) => {
        console.error('[GeminiLiveService] WebSocket error:', err);
        if (this.options.onError) this.options.onError('Connection error encountered.');
      };

      ws.onclose = () => {
        this.disconnect();
      };

    } catch (err: any) {
      this.setState('disconnected');
      if (this.options.onError) this.options.onError(err?.message || 'Failed to connect live session.');
    }
  }

  public setMute(mute: boolean): void {
    if (this.pcmProcessor) {
      this.pcmProcessor.setMute(mute);
    }
  }

  public disconnect(): void {
    if (this.pcmProcessor) {
      this.pcmProcessor.stop();
      this.pcmProcessor = null;
    }
    if (this.ws) {
      try {
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    this.setState('disconnected');
  }
}
