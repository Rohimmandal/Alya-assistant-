/**
 * Dedicated LiveSession Service for Alya Assistant
 * Manages WebSocket connection, Worker-accelerated 16kHz microphone PCM streaming,
 * state machine (disconnected, connecting, listening, speaking),
 * instant barge-in interruption, and browser function calling execution.
 * Strictly Audio-to-Audio (Continuous Live Session).
 */

import { PCMAudioProcessor, AudioDiagnosticMetrics } from '../utils/pcmAudioProcessor';
import { locationService } from '../lib/locationService';
import { secureStorage } from '../lib/secureStorage';
import { audioManager } from '../lib/AudioManager';

export type LiveSessionState = 'disconnected' | 'connecting' | 'listening' | 'thinking' | 'speaking';

export interface ToolCallPayload {
  functionCalls?: Array<{
    id: string;
    name: string;
    args: Record<string, any>;
  }>;
}

export interface LiveSessionCallbacks {
  onStateChange: (state: LiveSessionState) => void;
  onAudioChunk: (base64Audio: string) => void;
  onInterrupted: () => void;
  onToolExecuted: (toolName: string, details: string, url?: string) => void;
  onError: (errorMessage: string) => void;
  onDiagnosticsUpdate?: (metrics: AudioDiagnosticMetrics) => void;
  onTranscript?: (text: string, role: 'user' | 'assistant', sequence: number) => void;
}

export class LiveSession {
  private ws: WebSocket | null = null;
  private pcmProcessor: PCMAudioProcessor | null = null;
  private currentMicLevel: number = 0;
  private state: LiveSessionState = 'disconnected';
  private callbacks: LiveSessionCallbacks;
  private isMuted: boolean = false;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private pingInterval: any = null;
  private connectionTimeout: any = null; // Timeout monitor
  private userId: string = 'default_user';
  public wsStatus: 'connected' | 'disconnected' | 'connecting' = 'disconnected';
  public wsLatency: number = 0;
  private lastPingTime: number = 0;

  constructor(callbacks: LiveSessionCallbacks, userId?: string) {
    this.callbacks = callbacks;
    const stored = userId || localStorage.getItem('alya_user_id');
    if (stored) this.userId = stored;
  }

  public getState(): LiveSessionState {
    return this.state;
  }

  private setState(newState: LiveSessionState) {
    if (this.state !== newState) {
      const prevState = this.state;
      this.state = newState;

      // Clear connection watchdog on state change
      if (newState !== 'connecting' && newState !== 'disconnected') {
        this.clearConnectionTimeout();
      }
      
      if (newState === 'speaking') {
        audioManager.onAssistantSpeakingStart();
      } else if (prevState === 'speaking') {
        audioManager.onAssistantSpeakingEnd();
      }

      if (newState === 'thinking' || newState === 'listening') {
        if (this.pcmProcessor) {
          this.pcmProcessor.flushBuffer();
        }
      }

      this.callbacks.onStateChange(newState);
    }
  }

  private startConnectionTimeout() {
    this.clearConnectionTimeout();
    this.connectionTimeout = setTimeout(() => {
      if (this.state === 'connecting') {
        console.warn('[LiveSession] Connection watchdog: timed out in connecting state.');
        this.callbacks.onError('Connection timed out. Resetting session.');
        this.disconnect();
      }
    }, 10000); // 10s
  }

  private clearConnectionTimeout() {
    if (this.connectionTimeout) {
      clearTimeout(this.connectionTimeout);
      this.connectionTimeout = null;
    }
  }

  /**
   * Connects to backend Gemini Live WebSocket server and starts worker-resampled microphone streaming
   */
  public async connect(): Promise<void> {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking') return;

    this.setState('connecting');
    this.startConnectionTimeout();

    try {
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const localApiKey = await secureStorage.getSecureApiKey();
      let loc = locationService.getLastKnownLocation();
      
      // Attempt fresh geolocation lookup if location not cached yet
      if (!loc) {
        try {
          const locRes = await locationService.getCurrentLocation(3000);
          if (locRes.success && locRes.context) {
            loc = locRes.context as any;
          }
        } catch {}
      }

      const prefLang = localStorage.getItem('alya_preferred_lang') || localStorage.getItem('alya_language') || 'auto';
      
      let wsUrl = `${protocol}//${window.location.host}/ws/gemini-live?userId=${encodeURIComponent(this.userId)}&apiKey=${encodeURIComponent(localApiKey)}&language=${encodeURIComponent(prefLang)}`;
      
      if (loc) {
        wsUrl += `&lat=${loc.latitude}&lon=${loc.longitude}`;
        if ((loc as any).cityName) {
          wsUrl += `&city=${encodeURIComponent((loc as any).cityName)}`;
        }
      }

      const ws = new WebSocket(wsUrl);
      this.ws = ws;

      let wasOpened = false;

      ws.onopen = async () => {
        wasOpened = true;
        this.clearConnectionTimeout();
        this.reconnectAttempts = 0;
        this.startHeartbeat();
        try {
          await this.startMicrophoneCapture();
          this.setState('listening');
        } catch (micErr: any) {
          console.error('[LiveSession] Microphone capture error:', micErr);
          this.callbacks.onError(micErr.message || 'Microphone access is required for voice conversation.');
          this.disconnect();
        }
      };


      ws.onmessage = async (event) => {
        try {
          const msg = JSON.parse(event.data);

          // Audio output from model (24kHz PCM)
          if (msg.type === 'LIVE_AUDIO' && msg.audio) {
            this.setState('speaking');
            this.callbacks.onAudioChunk(msg.audio);
          }

          // Interruption event (user barge-in acknowledged by server)
          if (msg.type === 'LIVE_INTERRUPTED' || msg.interrupted) {
            this.setState('listening');
            this.callbacks.onInterrupted();
          }

          // Tool call execution (openWebsite, searchWeb, getWeather, controlDevice)
          if (msg.type === 'LIVE_TOOL_CALL' && msg.toolCall) {
            this.setState('thinking');
            await this.handleToolCall(msg.toolCall);
          }

          if (msg.type === 'LIVE_ERROR') {
            this.callbacks.onError(msg.error || 'Live communication error');
          }

          if (msg.type === 'LIVE_TRANSCRIPT') {
            this.callbacks.onTranscript?.(msg.text, msg.role || 'assistant', msg.sequence || 0);
          }

          if (msg.type === 'PONG') {
            this.wsLatency = Date.now() - this.lastPingTime;
          }
        } catch (parseErr) {
          console.warn('[LiveSession] Message parse error:', parseErr);
        }
      };

      ws.onerror = (e) => {
        console.error('[LiveSession] WebSocket error:', e);
        // Suppress noisy UI error alerts during reconnect / retry states
        if (wasOpened) {
          this.callbacks.onError('Connection to Alya Live server encountered an issue.');
        }
      };

      ws.onclose = () => {
        this.stopHeartbeat();
        this.cleanup();

        // Clear stale connection instance
        if (this.ws === ws) {
          ws.onopen = null;
          ws.onmessage = null;
          ws.onerror = null;
          ws.onclose = null;
          this.ws = null;
        }

        if (!wasOpened) {
          // Catch closed without opened connection initialization errors gracefully
          if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            this.setState('connecting');
            const delay = Math.min(30000, Math.pow(2, this.reconnectAttempts) * 1000 + Math.random() * 500);
            console.warn(`[LiveSession] WebSocket closed without opened. Initiating exponential backoff retry in ${Math.round(delay)}ms... (Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
            setTimeout(() => {
              this.connect();
            }, delay);
          } else {
            this.setState('disconnected');
            this.callbacks.onError('Could not establish connection to live session server. Please check your network and try again.');
          }
          return;
        }

        if (this.reconnectAttempts < this.maxReconnectAttempts) {
          this.reconnectAttempts++;
          this.setState('connecting');
          const delay = Math.min(1000 * Math.pow(1.8, this.reconnectAttempts) + Math.random() * 400, 15000);
          console.log(`[LiveSession] Connection closed. Reconnecting in ${Math.round(delay)}ms... (Attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts})`);
          setTimeout(() => {
            if (this.state === 'connecting') {
              this.connect();
            }
          }, delay);
        } else {
          this.setState('disconnected');
        }
      };
    } catch (err: any) {
      this.stopHeartbeat();
      this.cleanup();
      this.setState('disconnected');
      this.callbacks.onError(err.message || 'Failed to initiate live session');
    }
  }

  private startHeartbeat() {
    this.stopHeartbeat();
    this.pingInterval = setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.lastPingTime = Date.now();
        this.ws.send(JSON.stringify({ type: 'PING', timestamp: Date.now() }));
      }
    }, 10000); // 10s ping
  }

  private stopHeartbeat() {
    if (this.pingInterval) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  /**
   * Starts capturing microphone audio using Worker-based 16kHz resampling
   */
  private async startMicrophoneCapture(): Promise<void> {
    if (this.pcmProcessor) {
      this.pcmProcessor.stop();
      this.pcmProcessor = null;
    }

    this.pcmProcessor = new PCMAudioProcessor({
      sampleRate: 16000,
      bufferSize: 512,
      onAudioChunk: (base64Audio) => {
        if (!this.isMuted && this.ws && this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({
            type: 'AUDIO_CHUNK',
            audio: base64Audio
          }));
          // If user is actively streaming audio and we were listening, transition to thinking after brief speech burst
          if (this.state === 'listening') {
            this.setState('thinking');
          }
        }
      },
      onEnergyLevel: (rms) => {
        this.currentMicLevel = rms;
        // Instant Barge-In detection when user speaks while Alya is talking
        if (rms > 0.045 && (this.state === 'speaking' || this.state === 'thinking')) {
          console.log('[LiveSession] Local Barge-In triggered by user speech!');
          this.triggerInterruption();
          this.setState('listening');
          this.callbacks.onInterrupted();
        }
      },
      onDiagnosticsUpdate: (metrics) => {
        if (this.callbacks.onDiagnosticsUpdate) {
          this.callbacks.onDiagnosticsUpdate(metrics);
        }
      },
      onError: (err) => {
        console.error('[LiveSession] PCM processor error:', err);
      }
    });

    await this.pcmProcessor.start();
  }

  /**
   * Handles browser tool calls and immediately dispatches tool response back to Gemini session
   */
  private async handleToolCall(toolCall: ToolCallPayload) {
    if (!toolCall.functionCalls || toolCall.functionCalls.length === 0) return;

    const functionResponses: any[] = [];

    for (const call of toolCall.functionCalls) {
      console.log(`[LiveSession] Executing tool call: ${call.name}`, call.args);
      let executionResult: any = { success: true };

      if (call.name === 'openWebsite') {
        const targetUrl = call.args.url;
        const siteName = call.args.name || targetUrl;
        try {
          const formattedUrl = targetUrl.startsWith('http') ? targetUrl : `https://${targetUrl}`;
          window.open(formattedUrl, '_blank', 'noopener,noreferrer');
          executionResult = { success: true, message: `Opened ${siteName} in a new tab.` };
          this.callbacks.onToolExecuted('openWebsite', `Opened ${siteName}`, formattedUrl);
        } catch (e: any) {
          executionResult = { success: false, error: 'Popup blocked by browser' };
          this.callbacks.onToolExecuted('openWebsite', `Failed to open ${siteName}`);
        }
      } else if (call.name === 'searchWeb') {
        const query = call.args.query;
        try {
          const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
          window.open(searchUrl, '_blank', 'noopener,noreferrer');
          executionResult = { success: true, query, message: `Searched for "${query}" on Google.` };
          this.callbacks.onToolExecuted('searchWeb', `Searched for: "${query}"`, searchUrl);
        } catch {
          executionResult = { success: false, error: 'Could not open search tab' };
        }
      } else if (call.name === 'getWeather') {
        const city = call.args.city || 'current location';
        try {
          const response = await fetch(`/api/weather?city=${encodeURIComponent(city)}`);
          if (response.ok) {
            const data = await response.json();
            executionResult = {
              success: true,
              city: data.locationName,
              temperature: `${data.temperature}°C`,
              humidity: `${data.humidity}%`,
              condition: data.daily?.[0]?.weatherCode === 0 ? 'Clear and pleasant' : 'Moderate'
            };
          } else {
            executionResult = { success: false, error: 'Weather service unavailable' };
          }
        } catch (e) {
          executionResult = { success: false, error: 'Failed to fetch weather' };
        }
        this.callbacks.onToolExecuted('getWeather', `Checked weather for ${city}`);
      } else if (call.name === 'controlDevice') {
        const command = call.args.command;
        const params = call.args.params || {};
        try {
          const response = await fetch('/api/device/command', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              deviceId: 'auto',
              userId: this.userId,
              command,
              params
            })
          });
          const result = await response.json();
          executionResult = result;
          this.callbacks.onToolExecuted('controlDevice', `Executed ${command} on device`);
        } catch (e) {
          executionResult = { success: false, error: 'Failed to reach device' };
        }
      } else {
        executionResult = { success: true, message: `Action ${call.name} completed.` };
        this.callbacks.onToolExecuted(call.name, `Triggered ${call.name}`);
      }

      functionResponses.push({
        id: call.id,
        name: call.name,
        response: executionResult
      });
    }

    // Immediately send tool response back to Gemini session
    if (this.ws && this.ws.readyState === WebSocket.OPEN && functionResponses.length > 0) {
      this.ws.send(JSON.stringify({
        type: 'TOOL_RESPONSE',
        toolResponse: { functionResponses }
      }));
    }
  }

  public setMute(mute: boolean): void {
    this.isMuted = mute;
    if (this.pcmProcessor) {
      this.pcmProcessor.setMute(mute);
    }
  }

  public getMicLevel(): number {
    return this.currentMicLevel;
  }

  /**
   * Signal user interruption / barge-in to server
   */
  public triggerInterruption(): void {
    audioManager.onUserBargeIn();
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({ type: 'INTERRUPT' }));
    }
  }

  /**
   * Disconnects the session and releases microphone & audio context
   */
  public disconnect(): void {
    this.reconnectAttempts = this.maxReconnectAttempts;
    this.stopHeartbeat();
    this.clearConnectionTimeout();
    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          this.ws.send(JSON.stringify({ type: 'CLOSE' }));
        }
        this.ws.close();
      } catch {}
      this.ws = null;
    }
    this.cleanup();
    this.setState('disconnected');
  }

  private cleanup(): void {
    if (this.pcmProcessor) {
      this.pcmProcessor.stop();
      this.pcmProcessor = null;
    }
  }
}
