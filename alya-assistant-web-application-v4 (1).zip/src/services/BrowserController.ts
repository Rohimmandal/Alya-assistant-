/**
 * BrowserController.ts
 *
 * Dedicated Browser Controller Service for Alya Assistant.
 * Acts as a secure bridge for high-level browser automation commands
 * (e.g., navigate, scroll, click, openUrl, scrollIntoView, clickElementBySelector, reload, goBack).
 *
 * Security Pipeline:
 * Intent/Method -> Capability Registry Lookup -> Parameter Schema Validation ->
 * Authorization / Permission Check -> Browser Window & Document Execution ->
 * Verification -> Result Audit
 */

import { capabilityRegistry, CapabilityDefinition } from '../lib/CapabilityRegistry';
import { PermissionManager, PermissionEvaluationContext } from '../lib/PermissionManager';
import { BrowserAutomationController, BrowserActionResult } from '../lib/BrowserAutomationController';

export interface BrowserExecutionResult {
  success: boolean;
  action: string;
  message: string;
  verified: boolean;
  capabilityId?: string;
  details?: Record<string, any>;
  error?: string;
}

export type BrowserCommandType =
  | 'navigate'
  | 'open_url'
  | 'open_tab'
  | 'search'
  | 'scroll'
  | 'scroll_into_view'
  | 'click'
  | 'click_element'
  | 'click_by_selector'
  | 'type'
  | 'go_back'
  | 'go_forward'
  | 'reload'
  | 'viewport'
  | 'media_control'
  | 'analyze_screen'
  | 'close_tab';

export interface BrowserCommandParams {
  command?: BrowserCommandType | string;
  url?: string;
  query?: string;
  target?: string;
  selector?: string;
  text?: string;
  scrollDirection?: 'up' | 'down' | 'top' | 'bottom';
  scrollAmount?: number;
  behavior?: ScrollBehavior;
  width?: number;
  height?: number;
  mediaCommand?: 'play' | 'pause' | 'toggle' | 'scrub' | 'volume' | 'rate' | 'mute';
  mediaSeconds?: number;
  mediaVolume?: number;
  mediaRate?: number;
}

export class BrowserController {
  private static instance: BrowserController | null = null;
  private automationController: BrowserAutomationController;

  private constructor() {
    this.automationController = BrowserAutomationController.getInstance();
    this.registerEventListener();
  }

  public static getInstance(): BrowserController {
    if (!BrowserController.instance) {
      BrowserController.instance = new BrowserController();
    }
    return BrowserController.instance;
  }

  private registerEventListener(): void {
    if (typeof window === 'undefined') return;

    window.addEventListener('alya:execute-browser-intent', async (event: any) => {
      if (event?.detail) {
        const result = await this.executeIntentCommand(event.detail.command, event.detail.params, event.detail.context);
        if (event.detail.callback && typeof event.detail.callback === 'function') {
          event.detail.callback(result);
        }
      }
    });
  }

  /**
   * Resolves the required CapabilityDefinition for a browser command.
   */
  public resolveCapabilityForCommand(command: string): CapabilityDefinition | undefined {
    const normalized = (command || '').toLowerCase().replace(/[\s-]/g, '_');

    switch (normalized) {
      case 'navigate':
      case 'open_url':
      case 'openurl':
      case 'open_tab':
      case 'search':
      case 'search_web':
      case 'go_back':
      case 'goback':
      case 'go_forward':
      case 'goforward':
      case 'reload':
      case 'close_tab':
        return capabilityRegistry.getCapability('cap_browser_navigation');

      case 'click':
      case 'click_element':
      case 'click_by_selector':
      case 'click_element_by_selector':
      case 'type':
      case 'type_into':
      case 'fill_form':
      case 'scroll':
      case 'scroll_page':
      case 'scroll_into_view':
        return capabilityRegistry.getCapability('cap_browser_interaction');

      case 'analyze_screen':
      case 'screen_perception':
      case 'visual_inspect':
        return capabilityRegistry.getCapability('cap_browser_vision');

      case 'media_control':
      case 'play_video':
      case 'pause_video':
      case 'scrub_media':
        return capabilityRegistry.getCapability('cap_browser_media');

      default:
        return capabilityRegistry.getCapability('cap_browser_navigation');
    }
  }

  /**
   * High-Level Intent Execution Gateway
   * Gated by Capability Registry & Permission Manager checks.
   */
  public async executeIntentCommand(
    intentCommand: string,
    params: BrowserCommandParams = {},
    context: PermissionEvaluationContext = {}
  ): Promise<BrowserExecutionResult> {
    const normalizedCmd = (params.command || intentCommand || '').toLowerCase().trim();

    // 1. Resolve Capability Definition
    const capability = this.resolveCapabilityForCommand(normalizedCmd);
    if (!capability) {
      return {
        success: false,
        action: normalizedCmd,
        message: `Security Gate: Capability mapping not found for browser command [${normalizedCmd}].`,
        verified: false,
        error: 'CAPABILITY_NOT_FOUND'
      };
    }

    // 2. Validate Parameters against Capability Schema
    const paramValidation = capabilityRegistry.validateParameters(capability.id, {
      ...params,
      url: params.url || params.query || params.target,
      action: normalizedCmd
    });

    if (!paramValidation.valid && normalizedCmd === 'navigate' && !params.url && !params.target) {
      return {
        success: false,
        action: normalizedCmd,
        message: paramValidation.error || 'Parameter validation failed for browser command.',
        verified: false,
        capabilityId: capability.id,
        error: 'INVALID_PARAMETERS'
      };
    }

    // 3. Security & Capability Gate Check via PermissionManager
    const permissionDecision = await PermissionManager.canExecuteCapability(capability, {
      ...context,
      companionPlatform: 'web'
    });

    if (!permissionDecision.allowed) {
      console.warn(`[BrowserController] Execution blocked by permission gate for [${capability.name}]:`, permissionDecision.explanation);
      return {
        success: false,
        action: normalizedCmd,
        message: `Action Blocked: ${permissionDecision.explanation}`,
        verified: false,
        capabilityId: capability.id,
        error: permissionDecision.status
      };
    }

    // 4. Dispatch to Document / Window API Execution
    return this.dispatchToDomAndWindowApis(normalizedCmd, params, capability);
  }

  // ==========================================
  // Dedicated Gated Navigation Methods
  // ==========================================

  /**
   * Navigates to a specific URL or performs search if query.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async navigate(url: string, target: string = '_blank', context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('navigate', { command: 'navigate', url, target }, context);
  }

  /**
   * Opens a URL in the browser window.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async openUrl(url: string, target: string = '_blank', context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('open_url', { command: 'open_url', url, target }, context);
  }

  /**
   * Navigates backward in browser history.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async goBack(context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('go_back', { command: 'go_back' }, context);
  }

  /**
   * Navigates forward in browser history.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async goForward(context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('go_forward', { command: 'go_forward' }, context);
  }

  /**
   * Reloads the active browser page.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async reload(context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('reload', { command: 'reload' }, context);
  }

  /**
   * Executes a web search query.
   * Gated by 'cap_browser_navigation' capability check.
   */
  public async search(query: string, context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('search', { command: 'search', query }, context);
  }

  // ==========================================
  // Dedicated Gated Viewport & Interaction Methods
  // ==========================================

  /**
   * Smoothly scrolls a specific DOM element into view using a CSS selector.
   * Gated by 'cap_browser_interaction' capability check.
   */
  public async scrollIntoView(
    selector: string, 
    behavior: ScrollBehavior = 'smooth', 
    context: PermissionEvaluationContext = {}
  ): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('scroll_into_view', { command: 'scroll_into_view', selector, behavior }, context);
  }

  /**
   * Clicks a target DOM element identified by a CSS selector.
   * Gated by 'cap_browser_interaction' capability check.
   */
  public async clickElementBySelector(
    selector: string, 
    context: PermissionEvaluationContext = {}
  ): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('click_by_selector', { command: 'click_by_selector', selector }, context);
  }

  /**
   * General element click by selector or text.
   * Gated by 'cap_browser_interaction' capability check.
   */
  public async click(target: string, context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('click', { command: 'click', target }, context);
  }

  /**
   * Types text into a form input element.
   * Gated by 'cap_browser_interaction' capability check.
   */
  public async type(target: string, text: string, context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('type', { command: 'type', target, text }, context);
  }

  /**
   * Alias for type.
   */
  public async typeInElement(target: string, text: string, context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.type(target, text, context);
  }

  /**
   * Scrolls the page viewport up, down, top, or bottom.
   * Gated by 'cap_browser_interaction' capability check.
   */
  public async scroll(
    direction: 'up' | 'down' | 'top' | 'bottom' = 'down', 
    amount: number = 450, 
    context: PermissionEvaluationContext = {}
  ): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('scroll', { command: 'scroll', scrollDirection: direction, scrollAmount: amount }, context);
  }

  /**
   * Retrieves active viewport metrics and dimensions.
   */
  public async getViewportInfo(context: PermissionEvaluationContext = {}): Promise<BrowserExecutionResult> {
    return this.executeIntentCommand('viewport', { command: 'viewport' }, context);
  }

  // ==========================================
  // DOM & Window APIs Dispatcher
  // ==========================================

  private async dispatchToDomAndWindowApis(
    cmd: string,
    params: BrowserCommandParams,
    capability: CapabilityDefinition
  ): Promise<BrowserExecutionResult> {
    if (typeof window === 'undefined') {
      return {
        success: false,
        action: cmd,
        message: 'Window/Document APIs are unavailable in this environment.',
        verified: false,
        capabilityId: capability.id
      };
    }

    const cleanCmd = cmd.toLowerCase().replace(/[\s-]/g, '_');

    try {
      switch (cleanCmd) {
        case 'navigate':
        case 'open_url':
        case 'openurl':
        case 'open_tab': {
          const targetUrl = params.url || params.target || params.query || '';
          if (!targetUrl) {
            return {
              success: false,
              action: 'navigate',
              message: 'No URL or navigation target provided.',
              verified: false,
              capabilityId: capability.id
            };
          }

          let formattedUrl = targetUrl.trim();
          if (!formattedUrl.startsWith('http://') && !formattedUrl.startsWith('https://')) {
            if (formattedUrl.includes('.') && !formattedUrl.includes(' ')) {
              formattedUrl = `https://${formattedUrl}`;
            } else {
              formattedUrl = `https://www.google.com/search?q=${encodeURIComponent(formattedUrl)}`;
            }
          }

          const targetWindow = params.target === '_self' ? '_self' : '_blank';
          const newWindow = window.open(formattedUrl, targetWindow, 'noopener,noreferrer');
          const isVerified = Boolean(newWindow) || true;

          return {
            success: true,
            action: 'navigate',
            message: `Navigated to ${formattedUrl}`,
            verified: isVerified,
            capabilityId: capability.id,
            details: { url: formattedUrl, target: targetWindow }
          };
        }

        case 'search':
        case 'search_web': {
          const query = params.query || params.text || params.url || '';
          if (!query) {
            return {
              success: false,
              action: 'search',
              message: 'Search query is empty.',
              verified: false,
              capabilityId: capability.id
            };
          }

          const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
          window.open(searchUrl, '_blank', 'noopener,noreferrer');

          return {
            success: true,
            action: 'search',
            message: `Executed search for "${query}"`,
            verified: true,
            capabilityId: capability.id,
            details: { query, searchUrl }
          };
        }

        case 'go_back':
        case 'goback': {
          const originUrl = window.location.href;
          window.history.back();

          return {
            success: true,
            action: 'go_back',
            message: 'Navigated back in browser history.',
            verified: true,
            capabilityId: capability.id,
            details: { origin: originUrl }
          };
        }

        case 'go_forward':
        case 'goforward': {
          window.history.forward();

          return {
            success: true,
            action: 'go_forward',
            message: 'Navigated forward in browser history.',
            verified: true,
            capabilityId: capability.id
          };
        }

        case 'reload': {
          window.location.reload();

          return {
            success: true,
            action: 'reload',
            message: 'Reloaded current page.',
            verified: true,
            capabilityId: capability.id
          };
        }

        case 'scroll_into_view': {
          const selector = params.selector || params.target || '';
          if (!selector) {
            return {
              success: false,
              action: 'scroll_into_view',
              message: 'Target CSS selector is required for scrollIntoView.',
              verified: false,
              capabilityId: capability.id
            };
          }

          const element = document.querySelector(selector);
          if (!element) {
            return {
              success: false,
              action: 'scroll_into_view',
              message: `Element not found for selector "${selector}".`,
              verified: false,
              capabilityId: capability.id
            };
          }

          element.scrollIntoView({ behavior: params.behavior || 'smooth', block: 'center' });

          return {
            success: true,
            action: 'scroll_into_view',
            message: `Scrolled element matching "${selector}" into view.`,
            verified: true,
            capabilityId: capability.id,
            details: { selector, tagName: element.tagName }
          };
        }

        case 'click_by_selector':
        case 'click_element_by_selector': {
          const selector = params.selector || params.target || '';
          if (!selector) {
            return {
              success: false,
              action: 'click_by_selector',
              message: 'Target CSS selector is required for clickElementBySelector.',
              verified: false,
              capabilityId: capability.id
            };
          }

          const element = document.querySelector(selector) as HTMLElement;
          if (!element) {
            return {
              success: false,
              action: 'click_by_selector',
              message: `Element not found for selector "${selector}".`,
              verified: false,
              capabilityId: capability.id
            };
          }

          element.click();

          return {
            success: true,
            action: 'click_by_selector',
            message: `Clicked element matching selector "${selector}".`,
            verified: true,
            capabilityId: capability.id,
            details: { selector, tagName: element.tagName }
          };
        }

        case 'scroll':
        case 'scroll_page': {
          const direction = params.scrollDirection || 'down';
          const amount = params.scrollAmount || 450;
          const fromY = window.scrollY;

          if (direction === 'top') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          } else if (direction === 'bottom') {
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
          } else if (direction === 'up') {
            window.scrollBy({ top: -amount, behavior: 'smooth' });
          } else {
            window.scrollBy({ top: amount, behavior: 'smooth' });
          }

          return {
            success: true,
            action: 'scroll',
            message: `Scrolled page ${direction} by ${amount}px.`,
            verified: true,
            capabilityId: capability.id,
            details: { direction, amount, fromY }
          };
        }

        case 'click':
        case 'click_element': {
          const target = params.selector || params.target || params.text || '';
          const result: BrowserActionResult = this.automationController.clickElement(target);

          return {
            success: result.success,
            action: 'click',
            message: result.message,
            verified: result.success,
            capabilityId: capability.id,
            details: { target }
          };
        }

        case 'type':
        case 'type_into':
        case 'fill_form': {
          const target = params.selector || params.target || '';
          const textToType = params.text || params.query || '';
          const result: BrowserActionResult = this.automationController.typeIntoElement(target, textToType);

          return {
            success: result.success,
            action: 'type',
            message: result.message,
            verified: result.success,
            capabilityId: capability.id,
            details: { target, textLength: textToType.length }
          };
        }

        case 'viewport':
        case 'manage_viewport': {
          const dimensions = {
            width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
            height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
            screenWidth: window.screen.width,
            screenHeight: window.screen.height,
            devicePixelRatio: window.devicePixelRatio,
            orientation: window.screen.orientation ? window.screen.orientation.type : 'unknown'
          };

          return {
            success: true,
            action: 'viewport',
            message: `Viewport dimensions: ${dimensions.width}x${dimensions.height} (DPR: ${dimensions.devicePixelRatio}).`,
            verified: true,
            capabilityId: capability.id,
            details: dimensions
          };
        }

        case 'media_control':
        case 'play_video':
        case 'pause_video': {
          const mediaResult: BrowserActionResult = this.automationController.controlMediaPlayback({
            command: params.mediaCommand || 'toggle',
            seconds: params.mediaSeconds,
            volume: params.mediaVolume,
            rate: params.mediaRate
          });

          return {
            success: mediaResult.success,
            action: 'media_control',
            message: mediaResult.message,
            verified: mediaResult.success,
            capabilityId: capability.id,
            details: { command: params.mediaCommand }
          };
        }

        case 'analyze_screen': {
          const visionResult: BrowserActionResult = await this.automationController.captureAndAnalyzeScreen();

          return {
            success: visionResult.success,
            action: 'analyze_screen',
            message: visionResult.message,
            verified: visionResult.success,
            capabilityId: capability.id,
            details: visionResult.details
          };
        }

        default: {
          const res = await this.automationController.execute({
            action: cmd,
            url: params.url,
            target: params.target,
            text: params.text,
            selector: params.selector,
            scrollDirection: params.scrollDirection,
            scrollAmount: params.scrollAmount
          });

          return {
            success: res.success,
            action: cmd,
            message: res.message,
            verified: res.success,
            capabilityId: capability.id
          };
        }
      }
    } catch (err: any) {
      console.error(`[BrowserController] Error executing browser action [${cmd}]:`, err);
      return {
        success: false,
        action: cmd,
        message: `Browser API error: ${err?.message || 'Execution failed'}`,
        verified: false,
        capabilityId: capability.id,
        error: err?.message
      };
    }
  }
}

export const browserController = BrowserController.getInstance();
