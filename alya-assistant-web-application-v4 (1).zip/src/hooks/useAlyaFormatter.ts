import { useState, useCallback } from 'react';
import { AlyaPersonalityEngine, type AlyaMood } from '../lib/AlyaPersonalityEngine';

export function useAlyaFormatter() {
  const [currentMood, setCurrentMood] = useState<AlyaMood>('auto');

  const formatText = useCallback((text: string, mood?: AlyaMood) => {
    return AlyaPersonalityEngine.injectVocalReflexes(text, mood || currentMood);
  }, [currentMood]);

  return {
    currentMood,
    setCurrentMood,
    formatText,
    getSystemPrompt: AlyaPersonalityEngine.getSystemPrompt
  };
}
