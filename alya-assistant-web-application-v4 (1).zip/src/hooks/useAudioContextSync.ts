/**
 * useAudioContextSync.ts
 *
 * Dedicated React hook integrating AudioContextManager to synchronize microphone source
 * and media playback volume ducking state across the application.
 */

import { useEffect, useState, useCallback } from 'react';
import { audioContextManager } from '../lib/AudioContextManager';
import { globalAudioStateManager } from '../lib/GlobalAudioStateManager';

export function useAudioContextSync() {
  const [isAlyaSpeaking, setIsAlyaSpeaking] = useState<boolean>(() => audioContextManager.isAlyaSpeaking());
  const [masterGain, setMasterGain] = useState<number>(1.0);

  useEffect(() => {
    globalAudioStateManager.startMonitoring();

    const handleSpeechStateChange = (e: Event) => {
      const detail = (e as CustomEvent)?.detail;
      const speaking = Boolean(detail?.speaking);
      setIsAlyaSpeaking(speaking);
      setMasterGain(speaking ? 0.15 : 1.0);
    };

    window.addEventListener('alya:speech-state-changed', handleSpeechStateChange);

    // Initialize shared AudioContext on first user interaction
    const initCtx = async () => {
      try {
        await audioContextManager.getAudioContext(24000);
      } catch (e) {
        console.warn('[useAudioContextSync] AudioContext init notice:', e);
      }
    };

    window.addEventListener('pointerdown', initCtx, { once: true });
    window.addEventListener('keydown', initCtx, { once: true });

    return () => {
      globalAudioStateManager.stopMonitoring();
      window.removeEventListener('alya:speech-state-changed', handleSpeechStateChange);
      window.removeEventListener('pointerdown', initCtx);
      window.removeEventListener('keydown', initCtx);
    };
  }, []);

  const setDuckState = useCallback((duck: boolean) => {
    audioContextManager.setAlyaSpeaking(duck);
  }, []);

  return {
    isAlyaSpeaking,
    masterGain,
    setDuckState,
  };
}
