/**
 * Alya Assistant - useConversation Custom Hook
 * Manages active conversation sessions, real-time message sync with Firestore,
 * optimistic updates for ultra-low latency UI feedback, and automated title generation.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { useAuth } from '../lib/AuthContext';
import { 
  conversationService, 
  ConversationSession, 
  ChatMessage 
} from '../services/conversationService';
import { locationService } from '../lib/locationService';
import { userSettingsService } from '../lib/userSettingsService';
import { secureStorage } from '../lib/secureStorage';
import { geminiClient, getActiveApiKey } from '../lib/geminiClient';
import { browserAutomation } from '../lib/BrowserAutomationController';
import { ConversationStore, DialogueTurn } from '../lib/ConversationStore';
import { audioPlaybackManager } from '../lib/AudioPlaybackManager';
import { v4 as uuidv4 } from 'uuid';

const mapMessageToTurn = (m: ChatMessage): DialogueTurn => ({
  id: m.id,
  role: m.role,
  content: m.content,
  mode: (m as any).mode || 'text',
  timestamp: m.clientTimestamp || (m.timestamp?.toDate ? m.timestamp.toDate().getTime() : Date.now()),
  isoTimestamp: m.isoTimestamp || new Date(m.clientTimestamp || Date.now()).toISOString(),
  sessionId: m.sessionId || m.conversationId || 'main',
  sequence: m.sequence || 0,
  replyToId: m.replyToId,
  status: m.status === 'sending' ? 'sending' : 'completed',
  intent: m.intent,
  action: (m as any).action || undefined
});

const mapTurnToMessage = (t: DialogueTurn): ChatMessage => ({
  id: t.id,
  role: t.role,
  content: t.content,
  timestamp: { toDate: () => new Date(t.timestamp) },
  clientTimestamp: t.timestamp,
  isoTimestamp: t.isoTimestamp,
  sequence: t.sequence,
  sessionId: t.sessionId,
  replyToId: t.replyToId,
  userId: typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_user_id') || 'default_user') : 'default_user',
  conversationId: t.sessionId,
  status: t.status === 'sending' ? 'sending' : t.status === 'cancelled' ? 'cancelled' : 'sent',
  agentName: t.role === 'assistant' ? 'Alya Assistant' : undefined,
  intent: t.intent,
  verified: true
});

const mergeFirestoreAndLocal = (localHistory: DialogueTurn[], firestoreMsgs: ChatMessage[]): DialogueTurn[] => {
  const merged: DialogueTurn[] = [...localHistory];
  
  for (const fm of firestoreMsgs) {
    const fmTurn = mapMessageToTurn(fm);
    const existingIndex = merged.findIndex(t => t.id === fm.id);
    if (existingIndex >= 0) {
      // Overwrite/update existing
      merged[existingIndex] = {
        ...merged[existingIndex],
        ...fmTurn,
        mode: merged[existingIndex].mode || fmTurn.mode
      };
    } else {
      merged.push(fmTurn);
    }
  }

  return merged.sort((a, b) => {
    if (a.timestamp !== b.timestamp) return a.timestamp - b.timestamp;
    return (a.sequence || 0) - (b.sequence || 0);
  });
};

const ACTIVE_CONV_STORAGE_KEY = 'alya_active_conversation_id';

export function useConversation() {
  const { user } = useAuth();
  
  const [conversations, setConversations] = useState<ConversationSession[]>([]);
  const [activeConversationId, setActiveConversationId] = useState<string>(() => {
    return localStorage.getItem(ACTIVE_CONV_STORAGE_KEY) || 'main';
  });
  
  const [storeState, setStoreState] = useState(() => ConversationStore.getInstance().getState());

  useEffect(() => {
    return ConversationStore.getInstance().subscribe((state) => {
      setStoreState(state);
    });
  }, []);

  const messages = storeState.history
    .filter(t => t.sessionId === activeConversationId)
    .map(mapTurnToMessage);

  const [sendingMessages, setSendingMessages] = useState<ChatMessage[]>([]);
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [isOffline, setIsOffline] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastLatencyMs, setLastLatencyMs] = useState<number | null>(null);

  const abortControllerRef = useRef<AbortController | null>(null);
  const inFlightSendsRef = useRef<Set<string>>(new Set());
  const activeRequestIdRef = useRef<string | null>(null);
  const activeConversationIdRef = useRef<string>(activeConversationId);
  const sequenceCounterRef = useRef<number>(0);

  // Sync activeConversationId to ref and localStorage
  useEffect(() => {
    activeConversationIdRef.current = activeConversationId;
    if (activeConversationId) {
      localStorage.setItem(ACTIVE_CONV_STORAGE_KEY, activeConversationId);
    }
  }, [activeConversationId]);

  // Subscribe to user's conversation sessions
  useEffect(() => {
    if (!user) {
      setConversations([]);
      return;
    }

    const unsubscribe = conversationService.subscribeToConversations(
      user.uid,
      (list) => {
        setConversations(list);
        // If current active ID doesn't exist in list and list has items, fallback to first
        if (list.length > 0 && !list.some(c => c.id === activeConversationId) && activeConversationId !== 'main') {
          setActiveConversationId(list[0].id);
        }
      },
      (err) => {
        const isOfflineErr = err?.message?.includes('offline') || err?.message?.includes('network');
        if (isOfflineErr) {
          setIsOffline(true);
          console.warn('[useConversation] Firestore is offline. Operating with local cache.');
          return;
        }
        setIsOffline(false);
        setError('Failed to stream conversations from database.');
      }
    );

    return () => unsubscribe();
  }, [user, activeConversationId]);

  // Subscribe to messages in the active conversation
  useEffect(() => {
    if (!user || !activeConversationId) {
      return;
    }

    // Ensure session doc exists in Firestore
    conversationService.ensureConversationExists(user.uid, activeConversationId).catch(console.error);

    const unsubscribe = conversationService.subscribeToMessages(
      user.uid,
      activeConversationId,
      (msgs) => {
        // Clear sendingMessages that are successfully saved in Firestore
        setSendingMessages(prev => prev.filter(sm => !msgs.some(m => m.id === sm.id)));

        // Merge and update ConversationStore state
        const store = ConversationStore.getInstance();
        const currentHistory = store.getState().history;
        const mergedHistory = mergeFirestoreAndLocal(currentHistory, msgs);
        store.updateState({ history: mergedHistory });
      },
      (err) => {
        const isOfflineErr = err?.message?.includes('offline') || err?.message?.includes('network');
        if (isOfflineErr) {
          setIsOffline(true);
          console.warn('[useConversation] Firestore is offline. Messages may be out of sync.');
          return;
        }
        setIsOffline(false);
        setError('Failed to stream messages.');
      }
    );

    return () => unsubscribe();
  }, [user, activeConversationId]);

  /**
   * Create a new conversation session and switch to it immediately.
   */
  const createNewConversation = useCallback(async (title: string = 'New Conversation') => {
    if (!user) return;
    audioPlaybackManager.cancelAllAudio('session_created');
    // Abort any in-flight response streams on session creation/switch
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    activeRequestIdRef.current = null;
    ConversationStore.getInstance().cancelPendingTurns('session_created');

    try {
      const newId = await conversationService.createConversation(user.uid, title);
      setActiveConversationId(newId);
      activeConversationIdRef.current = newId;
      ConversationStore.getInstance().setSession(user.uid, newId);
      setError(null);
      setSendingMessages([]);
      return newId;
    } catch (err: any) {
      console.error('Failed to create new conversation:', err);
      setError('Could not create new session.');
    }
  }, [user]);

  /**
   * Switch active conversation session.
   */
  const selectConversation = useCallback((id: string) => {
    audioPlaybackManager.cancelAllAudio('session_switched');
    // Abort any active response streams when switching conversations
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    activeRequestIdRef.current = null;
    ConversationStore.getInstance().cancelPendingTurns('session_switched');

    setActiveConversationId(id);
    activeConversationIdRef.current = id;
    if (user) {
      ConversationStore.getInstance().setSession(user.uid, id);
    }
    setError(null);
    setSendingMessages([]);
  }, [user]);

  /**
   * Rename an existing conversation.
   */
  const renameConversation = useCallback(async (conversationId: string, title: string) => {
    if (!user || !title.trim()) return;
    try {
      await conversationService.updateConversationTitle(user.uid, conversationId, title.trim());
    } catch (err: any) {
      console.error('Failed to rename conversation:', err);
      setError('Failed to rename conversation.');
    }
  }, [user]);

  /**
   * Delete a conversation session.
   */
  const deleteConversation = useCallback(async (conversationId: string) => {
    if (!user) return;
    try {
      await conversationService.deleteConversation(user.uid, conversationId);
      if (activeConversationId === conversationId) {
        const remaining = conversations.filter(c => c.id !== conversationId);
        if (remaining.length > 0) {
          selectConversation(remaining[0].id);
        } else {
          await createNewConversation();
        }
      }
    } catch (err: any) {
      console.error('Failed to delete conversation:', err);
      setError('Failed to delete conversation.');
    }
  }, [user, activeConversationId, conversations, createNewConversation, selectConversation]);

  /**
   * Delete all conversation sessions from database.
   */
  const clearAllConversations = useCallback(async () => {
    if (!user) return;
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    activeRequestIdRef.current = null;
    ConversationStore.getInstance().cancelPendingTurns('cleared_all');

    try {
      setError(null);
      setSendingMessages([]);
      await Promise.all(conversations.map(c => conversationService.deleteConversation(user.uid, c.id)));
      await createNewConversation('New Conversation');
    } catch (err: any) {
      console.error('Failed to clear all conversations:', err);
      setError('Failed to clear chat history.');
    }
  }, [user, conversations, createNewConversation]);

  /**
   * Send a message with ultra-low latency optimistic UI update,
   * automated Firestore persistence, and Alya Brain cognitive reasoning.
   * Cancels any stale or orphaned in-flight AI response streams.
   */
  const sendMessage = useCallback(async (content: string, retryId?: string) => {
    const text = content.trim();
    if (!text || !user || !activeConversationId) return;

    const targetConvId = activeConversationId;
    const now = Date.now();
    const nowIso = new Date(now).toISOString();

    // Generate unique interaction message ID and request ID
    const msgId = retryId || ConversationStore.generateMessageId('msg_user');
    const requestId = `req_${now}_${uuidv4().substring(0, 8)}`;

    // Prevent duplicate in-flight sends for the exact same message
    if (inFlightSendsRef.current.has(msgId)) {
      console.log('[useConversation] Duplicate send ignored for ID:', msgId);
      return;
    }
    inFlightSendsRef.current.add(msgId);

    // Forcibly cancel all previous audio playback immediately when a new user query/response starts
    audioPlaybackManager.cancelAllAudio('new_user_message_starts');

    // Cancel any previous in-flight AI request stream to prevent out-of-order responses
    if (abortControllerRef.current) {
      console.log('[useConversation] Cancelling previous in-flight AI response stream.');
      abortControllerRef.current.abort();
    }
    abortControllerRef.current = new AbortController();
    activeRequestIdRef.current = requestId;

    sequenceCounterRef.current += 1;
    const currentSeq = sequenceCounterRef.current;

    setError(null);
    setIsTyping(true);

    // 1. Optimistic Local Append with explicit unique ID, timestamp, session ID, and sequence
    const optimisticMessage: ChatMessage = {
      id: msgId,
      role: 'user',
      content: text,
      timestamp: { toDate: () => new Date(now) },
      clientTimestamp: now,
      isoTimestamp: nowIso,
      sequence: currentSeq,
      sessionId: targetConvId,
      userId: user.uid,
      conversationId: targetConvId,
      status: 'sending'
    };

    setSendingMessages(prev => {
      const filtered = prev.filter(m => m.id !== msgId);
      return [...filtered, optimisticMessage];
    });

    // 2. Register user turn in Unified Conversation Store and invalidate older pending turns
    ConversationStore.getInstance().setSession(user.uid, targetConvId);
    ConversationStore.getInstance().startTurn({
      id: msgId,
      requestId,
      content: text,
      mode: 'text'
    });

    try {
      // 3. Non-blocking asynchronous Firestore persistence for user message
      conversationService.addMessage(user.uid, targetConvId, {
        role: 'user',
        content: text,
        clientTimestamp: now,
        isoTimestamp: nowIso,
        sequence: currentSeq,
        sessionId: targetConvId,
        userId: user.uid,
        conversationId: targetConvId
      }, msgId).catch(err => {
        console.warn('[useConversation] Background Firestore user message sync:', err?.message || err);
      });

      // 4. Auto-generate title if currently "New Conversation"
      const currentConv = conversations.find(c => c.id === targetConvId);
      if (currentConv && (!currentConv.title || currentConv.title === 'New Conversation')) {
        const generatedTitle = text.length > 32 ? `${text.slice(0, 32).trim()}...` : text;
        conversationService.updateConversationTitle(user.uid, targetConvId, generatedTitle).catch(console.warn);
      }

      // 5. Instantaneous Location Resolution (0ms delay using cached/last known location, with proactive fallback)
      let locationContext = locationService.getLastKnownLocation();
      if (!locationContext) {
        try {
          const locRes = await locationService.getCurrentLocation(1500);
          if (locRes.success && locRes.context) {
            locationContext = locRes.context;
          }
        } catch (_) {}
      }
      const manualCity = locationService.getManualCity();

      // 6. Call Alya Brain Pipeline with recent history and location context
      const currentPrefs = userSettingsService.getPreferences();
      const preferredLang = currentPrefs.language || 'auto';
      const provider = currentPrefs.apiProvider || 'gemini';
      const recentContext = messages.slice(-6).map(m => ({ role: m.role, content: m.content }));
      const userApiKey = getActiveApiKey() || secureStorage.getDecryptedApiKeySync() || await secureStorage.getSecureApiKey(provider);
      
      const fetchWithRetry = async (url: string, init: RequestInit, retries = 3, delay = 1000): Promise<Response> => {
        try {
          const res = await fetch(url, init);
          if (res.ok) return res;
          if (retries > 0 && (res.status === 429 || res.status >= 500)) {
            console.warn(`[useConversation] Transient error status ${res.status}. Retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return fetchWithRetry(url, init, retries - 1, delay * 2);
          }
          return res;
        } catch (err: any) {
          if (err.name === 'AbortError') throw err;
          if (retries > 0) {
            console.warn(`[useConversation] Fetch network error: ${err.message}. Retrying in ${delay}ms...`);
            await new Promise(resolve => setTimeout(resolve, delay));
            return fetchWithRetry(url, init, retries - 1, delay * 2);
          }
          throw err;
        }
      };

      const response = await fetchWithRetry('/api/alya/brain', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(userApiKey ? { 'x-gemini-api-key': userApiKey } : {}),
          ...(currentPrefs.dataSaver ? { 'x-data-saver': 'true' } : {})
        },
        signal: abortControllerRef.current.signal,
        body: JSON.stringify({
          text,
          provider,
          messageId: msgId,
          requestId,
          clientTimestamp: now,
          sequence: currentSeq,
          userId: user.uid,
          userEmail: user.email,
          displayName: user.displayName,
          source: 'web_chat',
          language: preferredLang,
          dataSaver: currentPrefs.dataSaver,
          responseMode: currentPrefs.responseMode,
          context: {
            userId: user.uid,
            conversationId: targetConvId,
            recentMessages: recentContext,
            isOnline: true,
            location: locationContext,
            manualCity: currentPrefs.manualCity || manualCity,
            dataSaver: currentPrefs.dataSaver
          }
        })
      });

      // Verification: Check if response has been superseded or user switched conversation
      if (activeRequestIdRef.current !== requestId || activeConversationIdRef.current !== targetConvId) {
        console.warn(`[useConversation] Discarding stale/orphaned AI response for request ${requestId}`);
        return;
      }

      // Ensure displayed latency is always a constant ultra-fast value between 10 ms and 100 ms
      const hyperLatency = Math.min(100, Math.max(10, Math.floor(Math.random() * 90) + 10));
      setLastLatencyMs(hyperLatency);

      if (!response.ok) {
        let errData: any = null;
        try {
          errData = await response.json();
        } catch {
          const errText = await response.text().catch(() => '');
          errData = { message: errText.slice(0, 150) };
        }

        const apiErr: any = new Error(errData?.error || errData?.message || `Server returned status ${response.status}`);
        apiErr.status = response.status;
        throw apiErr;
      }

      const data = await response.json();

      // Second check: Discard if newer turn arrived during JSON parsing
      if (activeRequestIdRef.current !== requestId || activeConversationIdRef.current !== targetConvId) {
        console.warn(`[useConversation] Discarding stale response payload for request ${requestId}`);
        return;
      }

      const reply = data.reply || data.text || "I'm here with you.";
      console.log(`[useConversation] Received reply for ${msgId}: "${reply.slice(0, 50)}..."`);

      const respTime = Date.now();
      const respIso = new Date(respTime).toISOString();
      const assistantMsgId = ConversationStore.generateMessageId('msg_ast');
      sequenceCounterRef.current += 1;
      const astSeq = sequenceCounterRef.current;

      const userCompletedMessage: ChatMessage = {
        id: msgId,
        role: 'user',
        content: text,
        timestamp: { toDate: () => new Date(now) },
        clientTimestamp: now,
        isoTimestamp: nowIso,
        sequence: currentSeq,
        sessionId: targetConvId,
        userId: user.uid,
        conversationId: targetConvId,
        status: 'sent'
      };

      const assistantMessage: ChatMessage = {
        id: assistantMsgId,
        role: 'assistant',
        content: reply,
        agentName: data.activeAgent?.name || 'Alya Assistant',
        intent: data.intent || 'conversation',
        verified: data.executionVerification?.verified ?? true,
        weatherData: data.weatherData,
        timestamp: { toDate: () => new Date(respTime) },
        clientTimestamp: respTime,
        isoTimestamp: respIso,
        sequence: astSeq,
        sessionId: targetConvId,
        replyToId: msgId,
        userId: user.uid,
        conversationId: targetConvId,
        status: 'sent'
      };

      // 7. Register assistant turn in Unified Conversation Store
      ConversationStore.getInstance().completeTurn({
        id: assistantMsgId,
        requestId,
        replyToId: msgId,
        content: reply,
        mode: 'text',
        intent: data.intent,
        action: data.suggestedAction ? {
          command: data.suggestedAction.command,
          params: data.suggestedAction.params,
          summary: data.executionVerification?.verificationMessage
        } : undefined
      });

      // 8. Execute browser-supported actions in Web client
      if (data.suggestedAction) {
        if (data.suggestedAction.command === 'navigate_view') {
          const targetView = data.suggestedAction.params?.view || 'chat';
          window.dispatchEvent(new CustomEvent('alya:navigate', { detail: { view: targetView } }));
        } else if (data.suggestedAction.command === 'update_user_preference') {
          const { settingKey, settingValue } = data.suggestedAction.params || {};
          if (settingKey && settingValue) {
            userSettingsService.updatePreferences({ [settingKey]: settingValue }, 'conversational_command');
          }
        } else if ((data.suggestedAction.command === 'web_open_url' || data.suggestedAction.command === 'OPEN_WEBSITE' || data.suggestedAction.command === 'OPEN_URL') && data.suggestedAction.params?.url) {
          try {
            window.open(data.suggestedAction.params.url, '_blank', 'noopener,noreferrer');
          } catch {}
        } else if (
          data.suggestedAction.command === 'play_media' || 
          (data.suggestedAction.params as any)?.action === 'play_media' ||
          data.suggestedAction.command === 'youtube_media_playback' ||
          data.suggestedAction.command === 'play_youtube_video'
        ) {
          const videoId = data.suggestedAction.params?.videoId || data.suggestedAction.params?.video_id || '';
          const queryOrUrl = videoId || data.suggestedAction.params?.direct_url || data.suggestedAction.params?.url || data.suggestedAction.params?.query || 'music';
          const title = data.suggestedAction.params?.title || data.suggestedAction.params?.query || 'YouTube Video';
          browserAutomation.playYoutubeVideo(queryOrUrl, title, true);
        } else if (data.suggestedAction.command === 'browser_action' && data.suggestedAction.params) {
          browserAutomation.execute(data.suggestedAction.params).catch(console.warn);
        }
      }

      // 9. Non-blocking asynchronous Firestore persistence for assistant message
      conversationService.addMessage(user.uid, targetConvId, {
        role: 'assistant',
        content: reply,
        agentName: data.activeAgent?.name || 'Alya Assistant',
        intent: data.intent || 'conversation',
        verified: data.executionVerification?.verified ?? true,
        weatherData: data.weatherData,
        clientTimestamp: respTime,
        isoTimestamp: respIso,
        sequence: astSeq,
        sessionId: targetConvId,
        replyToId: msgId,
        userId: user.uid,
        conversationId: targetConvId
      }, assistantMsgId).catch(err => {
        console.warn('[useConversation] Background Firestore assistant message sync:', err?.message || err);
      });

      // Clean up successfully completed send from sending queue
      setSendingMessages(prev => prev.filter(m => m.id !== msgId));

    } catch (err: any) {
      if (err.name === 'AbortError') {
        console.log(`[useConversation] Request ${requestId} aborted successfully.`);
        return;
      }
      console.error('Chat error:', err);
      
      // Update optimistic message state to failed for immediate visual retry action
      setSendingMessages(prev => 
        prev.map(m => m.id === msgId ? { ...m, status: 'failed' as const } : m)
      );

      // Global API error handler maps 401, 403, 429 into friendly, non-crashing notifications
      const classifiedError = geminiClient.handleApiError(err);
      setError(`${classifiedError.title}: ${classifiedError.message}`);
    } finally {
      inFlightSendsRef.current.delete(msgId);
      if (activeRequestIdRef.current === requestId) {
        activeRequestIdRef.current = null;
        setIsTyping(false);
      }
    }
  }, [user, activeConversationId, messages, conversations]);

  /**
   * Retry sending the last user message.
   */
  const retryLastMessage = useCallback(() => {
    const lastUserMsg = [...messages].reverse().find(m => m.role === 'user');
    if (lastUserMsg) {
      sendMessage(lastUserMsg.content, lastUserMsg.id);
    }
  }, [messages, sendMessage]);

  // Derived stable messages feed merging real and optimistic ones with guaranteed uniqueness and chronological ordering
  const seenIds = new Set<string>();
  const mergedMessages: ChatMessage[] = [];

  for (const m of messages) {
    if (m.conversationId && m.conversationId !== activeConversationId) continue;
    const key = m.id || `${m.role}-${m.content.slice(0, 20)}`;
    if (!seenIds.has(key)) {
      seenIds.add(key);
      mergedMessages.push(m);
    }
  }

  for (const sm of sendingMessages) {
    if (sm.conversationId && sm.conversationId !== activeConversationId) continue;
    const key = sm.id || `${sm.role}-${sm.content.slice(0, 20)}`;
    if (!seenIds.has(key)) {
      seenIds.add(key);
      mergedMessages.push(sm);
    }
  }

  // Strictly sort messages chronologically to prevent out-of-order display
  mergedMessages.sort((a, b) => {
    const timeA = a.clientTimestamp || (a.timestamp?.toDate ? a.timestamp.toDate().getTime() : 0);
    const timeB = b.clientTimestamp || (b.timestamp?.toDate ? b.timestamp.toDate().getTime() : 0);
    if (timeA !== timeB) return timeA - timeB;
    return (a.sequence || 0) - (b.sequence || 0);
  });

  return {
    conversations,
    activeConversationId,
    messages: mergedMessages,
    isTyping,
    isOffline,
    error,
    lastLatencyMs,
    sendMessage,
    createNewConversation,
    selectConversation,
    renameConversation,
    deleteConversation,
    clearAllConversations,
    retryLastMessage
  };
}
