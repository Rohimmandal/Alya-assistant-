import { useState, useCallback, useMemo } from 'react';
import { LiveSessionState } from '../lib/LiveSession';

export type AudioStatus = 'idle' | 'listening' | 'speaking' | 'processing';

/**
 * Custom hook to manage Alya's live audio state transitions.
 * Exposes methods to update state from external callbacks.
 */
export function useLiveAudio() {
  const [sessionState, setSessionState] = useState<LiveSessionState>('disconnected');
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const status = useMemo<AudioStatus>(() => {
    if (isSpeaking) return 'speaking';
    
    switch (sessionState) {
      case 'connecting':
      case 'thinking':
        return 'processing';
      case 'listening':
        return 'listening';
      case 'speaking':
        return 'speaking';
      default:
        return 'idle';
    }
  }, [sessionState, isSpeaking]);

  const setSpeaking = useCallback((speaking: boolean) => {
    setIsSpeaking(speaking);
  }, []);

  const updateSessionState = useCallback((state: LiveSessionState) => {
    setSessionState(state);
  }, []);

  return { status, setSpeaking, updateSessionState };
}
