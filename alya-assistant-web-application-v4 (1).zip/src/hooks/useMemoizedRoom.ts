import { useRef, useState, useEffect, useCallback, useMemo } from 'react';
import { LiveKitVoiceClient, LiveKitVoiceClientOptions } from '../lib/livekitVoiceClient';
import { liveKitDiagnosticService } from '../lib/LiveKitDiagnosticService';

export type RoomConnectionState = 'disconnected' | 'connecting' | 'connected' | 'reconnecting' | 'timeout' | 'error';

export interface UseMemoizedRoomOptions {
  userId?: string;
  roomName?: string;
  language?: string;
  maxRetries?: number;
  onText?: (text: string) => void;
  onAudio?: (base64Audio: string, sequence?: number, flushFirst?: boolean) => void;
  onInterrupted?: () => void;
  onError?: (error: string) => void;
}

export function useMemoizedRoom(options: UseMemoizedRoomOptions) {
  const [connectionState, setConnectionState] = useState<RoomConnectionState>('disconnected');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [retryAttempt, setRetryAttempt] = useState<number>(0);
  
  const connectionStateRef = useRef<RoomConnectionState>('disconnected');
  connectionStateRef.current = connectionState;

  const isExplicitDisconnectRef = useRef<boolean>(false);
  const retryTimerRef = useRef<NodeJS.Timeout | null>(null);
  const watchdogTimerRef = useRef<NodeJS.Timeout | null>(null);
  const clientRef = useRef<LiveKitVoiceClient | null>(null);

  const maxRetries = options.maxRetries ?? 5;

  // Store options in ref to avoid recreating client on callback changes
  const optionsRef = useRef(options);
  useEffect(() => {
    optionsRef.current = options;
  }, [options]);

  const clearTimers = useCallback(() => {
    if (watchdogTimerRef.current) {
      clearTimeout(watchdogTimerRef.current);
      watchdogTimerRef.current = null;
    }
    if (retryTimerRef.current) {
      clearTimeout(retryTimerRef.current);
      retryTimerRef.current = null;
    }
  }, []);

  const startWatchdog = useCallback(() => {
    if (watchdogTimerRef.current) clearTimeout(watchdogTimerRef.current);
    liveKitDiagnosticService.log('debug', 'timeout', '[useMemoizedRoom] Started 10s connection watchdog.');
    
    watchdogTimerRef.current = setTimeout(() => {
      const current = connectionStateRef.current;
      if (current === 'connecting' || current === 'reconnecting') {
        liveKitDiagnosticService.log('warn', 'timeout', '[useMemoizedRoom] 10s connecting timeout exceeded! Executing state reset and scheduling auto-reconnect.');
        if (clientRef.current) {
          clientRef.current.disconnect();
        }
        setErrorMessage('Connection timed out after 10s. Retrying...');
        setConnectionState('timeout');
        scheduleAutoReconnect('Connection timeout');
      }
    }, 10000);
  }, []);

  const scheduleAutoReconnect = useCallback((reason: string) => {
    clearTimers();
    if (isExplicitDisconnectRef.current) {
      liveKitDiagnosticService.log('info', 'lifecycle', '[useMemoizedRoom] Skipping auto-reconnect: Explicit user disconnect.');
      return;
    }

    setRetryAttempt((currentAttempt) => {
      const nextAttempt = currentAttempt + 1;
      if (nextAttempt > maxRetries) {
        liveKitDiagnosticService.log('error', 'lifecycle', `[useMemoizedRoom] Max retry limit (${maxRetries}) reached. Stopping auto-retry.`);
        setErrorMessage(`Connection failed after ${maxRetries} automatic retry attempts. Please check network.`);
        setConnectionState('error');
        return currentAttempt;
      }

      // Exponential backoff calculation: 1s, 2s, 4s, 8s, 10s + jitter
      const backoffDelay = Math.min(1000 * Math.pow(2, nextAttempt - 1) + Math.random() * 400, 10000);
      liveKitDiagnosticService.log(
        'warn', 
        'network', 
        `[useMemoizedRoom] Temporary flicker [${reason}]. Scheduling exponential backoff retry #${nextAttempt}/${maxRetries} in ${Math.round(backoffDelay)}ms`
      );

      setConnectionState('reconnecting');
      setErrorMessage(`Network flicker detected. Auto-reconnecting in ${Math.round(backoffDelay / 1000)}s (Attempt ${nextAttempt}/${maxRetries})...`);

      retryTimerRef.current = setTimeout(() => {
        retryTimerRef.current = null;
        executeConnect();
      }, backoffDelay);

      return nextAttempt;
    });
  }, [maxRetries, clearTimers]);

  const disconnect = useCallback(() => {
    isExplicitDisconnectRef.current = true;
    clearTimers();
    if (clientRef.current) {
      clientRef.current.disconnect();
      clientRef.current = null;
    }
    setRetryAttempt(0);
    setConnectionState('disconnected');
    setErrorMessage(null);
  }, [clearTimers]);

  const executeConnect = useCallback(async () => {
    const currentState = connectionStateRef.current;
    if (currentState === 'connecting' || currentState === 'connected') {
      liveKitDiagnosticService.log('info', 'lifecycle', '[useMemoizedRoom] Connect request ignored; already active.');
      return;
    }

    clearTimers();
    setConnectionState('connecting');
    startWatchdog();

    // Ensure previous client instance is disposed before creating a new one
    if (clientRef.current) {
      clientRef.current.disconnect();
      clientRef.current = null;
    }

    const clientOptions: LiveKitVoiceClientOptions = {
      userId: optionsRef.current.userId || 'user_' + Math.random().toString(36).substring(2, 7),
      roomName: optionsRef.current.roomName || 'alya-live-room',
      language: optionsRef.current.language || 'auto',
      onText: (text) => optionsRef.current.onText?.(text),
      onAudio: (audio, sequence, flushFirst) => optionsRef.current.onAudio?.(audio, sequence, flushFirst),
      onInterrupted: () => optionsRef.current.onInterrupted?.(),
      onConnected: () => {
        clearTimers();
        setRetryAttempt(0);
        setErrorMessage(null);
        setConnectionState('connected');
        liveKitDiagnosticService.log('info', 'lifecycle', '[useMemoizedRoom] Room connection established.');
      },
      onDisconnected: () => {
        clearTimers();
        if (!isExplicitDisconnectRef.current) {
          scheduleAutoReconnect('Unexpected disconnection');
        } else {
          setConnectionState('disconnected');
        }
      },
      onError: (err) => {
        clearTimers();
        optionsRef.current.onError?.(err);
        if (!isExplicitDisconnectRef.current) {
          scheduleAutoReconnect(`Client error: ${err}`);
        } else {
          setErrorMessage(err);
          setConnectionState('error');
        }
      }
    };

    const client = new LiveKitVoiceClient(clientOptions);
    clientRef.current = client;

    try {
      const success = await client.connect();
      if (!success && !isExplicitDisconnectRef.current) {
        scheduleAutoReconnect('Connection handshake failed');
      }
    } catch (err: any) {
      if (!isExplicitDisconnectRef.current) {
        scheduleAutoReconnect(err.message || 'Connection exception');
      } else {
        setErrorMessage(err.message || 'Room connection failed');
        setConnectionState('error');
      }
    }
  }, [startWatchdog, scheduleAutoReconnect, clearTimers]);

  const connect = useCallback(() => {
    isExplicitDisconnectRef.current = false;
    setRetryAttempt(0);
    return executeConnect();
  }, [executeConnect]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      isExplicitDisconnectRef.current = true;
      clearTimers();
      if (clientRef.current) {
        clientRef.current.disconnect();
        clientRef.current = null;
      }
    };
  }, [clearTimers]);

  return useMemo(() => ({
    connectionState,
    errorMessage,
    retryAttempt,
    connect,
    disconnect,
    client: clientRef.current
  }), [connectionState, errorMessage, retryAttempt, connect, disconnect]);
}
