import { useState, useEffect, useRef, useCallback } from 'react';
import { liveSessionManager } from '../lib/LiveSessionManager';

export type AudioOutputRouteMode = 'earpiece' | 'speaker';

export interface UseAudioOutputRouteOptions {
  initialMode?: AudioOutputRouteMode;
  onModeChange?: (mode: AudioOutputRouteMode) => void;
  syncWithLiveSession?: boolean;
}

export interface AudioOutputRouteState {
  mode: AudioOutputRouteMode;
  isSpeaker: boolean;
  volume: number; // 0.4 (40%) for earpiece, 1.0 (100%) for speaker
  toggleRoute: () => void;
  setRouteMode: (mode: AudioOutputRouteMode) => void;
  setSpeaker: (isSpeaker: boolean) => void;
  attachMediaElement: (element: HTMLMediaElement | null) => void;
  detachMediaElement: (element: HTMLMediaElement | null) => void;
  gainNode: GainNode | null;
  audioContext: AudioContext | null;
}

/**
 * useAudioOutputRoute Hook
 * 
 * Manages audio routing between 'earpiece' (lower volume, 40%) and 'speaker' (max volume, 100%)
 * using the Web Audio API. Dynamically connects and manages GainNodes for media elements and
 * synchronizes with Alya Live session audio output.
 */
export function useAudioOutputRoute(options: UseAudioOutputRouteOptions = {}): AudioOutputRouteState {
  const {
    initialMode,
    onModeChange,
    syncWithLiveSession = true
  } = options;

  // Determine initial state from liveSessionManager if available
  const getInitial = (): AudioOutputRouteMode => {
    if (initialMode) return initialMode;
    if (syncWithLiveSession) {
      return liveSessionManager.isSpeakerActive() ? 'speaker' : 'earpiece';
    }
    return 'speaker';
  };

  const [mode, setMode] = useState<AudioOutputRouteMode>(getInitial);
  const isSpeaker = mode === 'speaker';
  const volume = isSpeaker ? 1.0 : 0.4;

  const audioCtxRef = useRef<AudioContext | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const [gainNodeState, setGainNodeState] = useState<GainNode | null>(null);
  const attachedElementsRef = useRef<Map<HTMLMediaElement, MediaElementAudioSourceNode>>(new Map());

  // Initialize Web Audio Context and Gain Node
  const ensureAudioGraph = useCallback((): { ctx: AudioContext; gain: GainNode } | null => {
    if (typeof window === 'undefined') return null;

    try {
      if (!audioCtxRef.current || audioCtxRef.current.state === 'closed') {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioCtxClass) return null;
        audioCtxRef.current = new AudioCtxClass();
      }

      if (!gainNodeRef.current && audioCtxRef.current) {
        const gain = audioCtxRef.current.createGain();
        const initialVol = isSpeaker ? 1.0 : 0.4;
        gain.gain.setValueAtTime(initialVol, audioCtxRef.current.currentTime);
        gain.connect(audioCtxRef.current.destination);
        gainNodeRef.current = gain;
        setGainNodeState(gain);
      }

      return { ctx: audioCtxRef.current, gain: gainNodeRef.current! };
    } catch (e) {
      console.warn('[useAudioOutputRoute] Web Audio API init note:', e);
      return null;
    }
  }, [isSpeaker]);

  // Apply volume gain and hardware sink to Web Audio graph & connected media elements
  const applyGainAndRouting = useCallback(async (currentMode: AudioOutputRouteMode) => {
    const isLoud = currentMode === 'speaker';
    const targetGain = isLoud ? 1.0 : 0.4;

    // 1. Update Gain Node dynamically
    if (gainNodeRef.current && audioCtxRef.current) {
      const ctx = audioCtxRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume().catch(() => {});
      }
      try {
        gainNodeRef.current.gain.cancelScheduledValues(ctx.currentTime);
        gainNodeRef.current.gain.setValueAtTime(gainNodeRef.current.gain.value, ctx.currentTime);
        gainNodeRef.current.gain.linearRampToValueAtTime(targetGain, ctx.currentTime + 0.08);
      } catch (e) {
        try {
          gainNodeRef.current.gain.setValueAtTime(targetGain, ctx.currentTime);
        } catch {}
      }
    }

    // 2. Sync with liveSessionManager
    if (syncWithLiveSession) {
      liveSessionManager.setSpeaker(isLoud);
    }

    // 3. Update hardware audio sinks if supported
    if (typeof navigator !== 'undefined' && navigator.mediaDevices?.enumerateDevices) {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioOutputs = devices.filter(d => d.kind === 'audiooutput');

        let targetDeviceId: string | null = null;
        if (isLoud) {
          const speaker = audioOutputs.find(d => 
            d.label.toLowerCase().includes('speaker') || 
            d.label.toLowerCase().includes('loudspeaker') ||
            d.deviceId === 'default'
          );
          if (speaker) targetDeviceId = speaker.deviceId;
        } else {
          const earpiece = audioOutputs.find(d => 
            d.label.toLowerCase().includes('earpiece') || 
            d.label.toLowerCase().includes('receiver') ||
            d.label.toLowerCase().includes('phone') ||
            d.label.toLowerCase().includes('telephony')
          );
          if (earpiece) targetDeviceId = earpiece.deviceId;
        }

        if (targetDeviceId) {
          // Route AudioContext destination if supported
          if (audioCtxRef.current && 'setSinkId' in (audioCtxRef.current as any)) {
            await (audioCtxRef.current as any).setSinkId(targetDeviceId).catch(() => {});
          }
          // Route attached media elements
          for (const el of attachedElementsRef.current.keys()) {
            if ('setSinkId' in el && typeof (el as any).setSinkId === 'function') {
              (el as any).setSinkId(targetDeviceId).catch(() => {});
            }
          }
        }
      } catch (e) {
        // Hardware routing fallback
      }
    }

    // 4. Update volume on all attached media elements directly as well
    attachedElementsRef.current.forEach((_, el) => {
      try {
        el.volume = targetGain;
      } catch {}
    });

    onModeChange?.(currentMode);
  }, [syncWithLiveSession, onModeChange]);

  // Handle route change when mode state updates
  useEffect(() => {
    ensureAudioGraph();
    applyGainAndRouting(mode);
  }, [mode, ensureAudioGraph, applyGainAndRouting]);

  // Function to toggle between earpiece and speaker
  const toggleRoute = useCallback(() => {
    setMode(prev => (prev === 'speaker' ? 'earpiece' : 'speaker'));
  }, []);

  const setRouteMode = useCallback((newMode: AudioOutputRouteMode) => {
    setMode(newMode);
  }, []);

  const setSpeaker = useCallback((speakerActive: boolean) => {
    setMode(speakerActive ? 'speaker' : 'earpiece');
  }, []);

  // Attach an HTMLMediaElement to the Web Audio Gain Node
  const attachMediaElement = useCallback((element: HTMLMediaElement | null) => {
    if (!element || typeof window === 'undefined') return;
    if (attachedElementsRef.current.has(element)) return;

    const graph = ensureAudioGraph();
    if (!graph) return;

    try {
      const source = graph.ctx.createMediaElementSource(element);
      source.connect(graph.gain);
      attachedElementsRef.current.set(element, source);
      element.volume = isSpeaker ? 1.0 : 0.4;
    } catch (e) {
      // Element might already be connected to an AudioContext
      element.volume = isSpeaker ? 1.0 : 0.4;
    }
  }, [ensureAudioGraph, isSpeaker]);

  // Detach an HTMLMediaElement
  const detachMediaElement = useCallback((element: HTMLMediaElement | null) => {
    if (!element) return;
    const source = attachedElementsRef.current.get(element);
    if (source) {
      try {
        source.disconnect();
      } catch {}
      attachedElementsRef.current.delete(element);
    }
  }, []);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      attachedElementsRef.current.forEach(source => {
        try { source.disconnect(); } catch {}
      });
      attachedElementsRef.current.clear();
      if (gainNodeRef.current) {
        try { gainNodeRef.current.disconnect(); } catch {}
        gainNodeRef.current = null;
      }
    };
  }, []);

  return {
    mode,
    isSpeaker,
    volume,
    toggleRoute,
    setRouteMode,
    setSpeaker,
    attachMediaElement,
    detachMediaElement,
    gainNode: gainNodeState,
    audioContext: audioCtxRef.current
  };
}
