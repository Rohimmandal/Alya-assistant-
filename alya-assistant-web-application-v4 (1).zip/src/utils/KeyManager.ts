import { GoogleGenAI } from '@google/genai';
import { GeminiKeyRotationService } from './GeminiKeyRotationService.ts';
import { getFirestore, Firestore, Timestamp } from 'firebase-admin/firestore';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import path from 'path';
import fs from 'fs';

export interface KeySlotConfig {
  id: string;
  slotNumber: number;
  label: string;
  timeRange: string;
  startHour: number; // Inclusive (0-23)
  endHour: number;   // Exclusive (0-24)
  apiKey: string;
  apikey?: string;
  isBackup?: boolean;
  cooldownUntil?: number;
  failureCount?: number;
}

export interface KeyStoreStatus {
  activeSlot: {
    slotNumber: number;
    id: string;
    label: string;
    timeRange: string;
    maskedKey: string;
    isPrimaryScheduled: boolean;
    isHardcodedFallback: boolean;
    isBackup?: boolean;
  };
  currentTimeServer: string;
  currentHour: number;
  currentMinute: number;
  timeUntilNextRotationMinutes: number;
  slots: Array<{
    slotNumber: number;
    id: string;
    label: string;
    timeRange: string;
    maskedKey: string;
    isScheduledNow: boolean;
    isActiveNow: boolean;
    isCoolingDown: boolean;
    isBackup?: boolean;
    cooldownRemainingSec?: number;
    failureCount: number;
    isHardcodedFallback: boolean;
  }>;
}

const getEnvSlotKey = (slotNum: number, fallback: string): string => {
  const candidates = [
    process.env[`GEMINI_KEY_SLOT_${slotNum}`],
    process.env[`KEY_SLOT_${slotNum}`],
    process.env[`EY_SLOT_${slotNum}`],
    process.env[`GEMINI_SLOT_${slotNum}`],
    process.env[`SLOT_${slotNum}`]
  ];
  for (const c of candidates) {
    if (c && c.trim().length > 10) return c.trim();
  }
  return fallback;
};

export const DEFAULT_KEY_STORE_CONFIG: KeySlotConfig[] = [
  {
    id: 'SLOT_1',
    slotNumber: 1,
    label: 'Morning Shift',
    timeRange: '06:00 AM - 11:59 AM',
    startHour: 6,
    endHour: 12,
    apiKey: getEnvSlotKey(1, 'AIzaSyCim7XouvlvbI_uJ5yz8WGq8cvrrm5Iqus'),
    apikey: getEnvSlotKey(1, 'AIzaSyCim7XouvlvbI_uJ5yz8WGq8cvrrm5Iqus')
  },
  {
    id: 'SLOT_2',
    slotNumber: 2,
    label: 'Afternoon Shift',
    timeRange: '12:00 PM - 05:59 PM',
    startHour: 12,
    endHour: 18,
    apiKey: getEnvSlotKey(2, 'AIzaSyCiz1089GW8_EyTKiNpS5X8Y9v_d26ovzE'),
    apikey: getEnvSlotKey(2, 'AIzaSyCiz1089GW8_EyTKiNpS5X8Y9v_d26ovzE')
  },
  {
    id: 'SLOT_3',
    slotNumber: 3,
    label: 'Evening Shift',
    timeRange: '06:00 PM - 11:59 PM',
    startHour: 18,
    endHour: 24,
    apiKey: getEnvSlotKey(3, 'AIzaSyCprbseqGQdCx51bRaRB_Jrm3aCoxIJpZY'),
    apikey: getEnvSlotKey(3, 'AIzaSyCprbseqGQdCx51bRaRB_Jrm3aCoxIJpZY')
  },
  {
    id: 'SLOT_4',
    slotNumber: 4,
    label: 'Night Shift',
    timeRange: '12:00 AM - 05:59 AM',
    startHour: 0,
    endHour: 6,
    apiKey: getEnvSlotKey(4, 'AIzaSyDDccy9duSlyDRp7RMULVrsumSM8Ued504'),
    apikey: getEnvSlotKey(4, 'AIzaSyDDccy9duSlyDRp7RMULVrsumSM8Ued504')
  },
  {
    id: 'SLOT_5',
    slotNumber: 5,
    label: 'Backup Slot 5',
    timeRange: '24/7 Backup Failover',
    startHour: 0,
    endHour: 24,
    isBackup: true,
    apiKey: getEnvSlotKey(5, 'AQ.Ab8RN6IVWctrWZzpMBfQp89ta6M_XYbYkyx57xlY1b_wLKiMqw'),
    apikey: getEnvSlotKey(5, 'AQ.Ab8RN6IVWctrWZzpMBfQp89ta6M_XYbYkyx57xlY1b_wLKiMqw')
  },
  {
    id: 'SLOT_6',
    slotNumber: 6,
    label: 'Backup Slot 6',
    timeRange: '24/7 Backup Failover',
    startHour: 0,
    endHour: 24,
    isBackup: true,
    apiKey: getEnvSlotKey(6, 'AQ.Ab8RN6L3hsLIbbISIb2Idnw5FW36Him6Ey_Mx9UNSGA_6TxUXg'),
    apikey: getEnvSlotKey(6, 'AQ.Ab8RN6L3hsLIbbISIb2Idnw5FW36Him6Ey_Mx9UNSGA_6TxUXg')
  },
  {
    id: 'SLOT_7',
    slotNumber: 7,
    label: 'Backup Slot 7',
    timeRange: '24/7 Backup Failover',
    startHour: 0,
    endHour: 24,
    isBackup: true,
    apiKey: getEnvSlotKey(7, 'AQ.Ab8RN6LjgexzF9h906rDkYC3Tkve_2TG9cgE94cq4DR--s8lTg'),
    apikey: getEnvSlotKey(7, 'AQ.Ab8RN6LjgexzF9h906rDkYC3Tkve_2TG9cgE94cq4DR--s8lTg')
  }
];

export const isHardcodedFallbackKey = (key: string): boolean => {
  return false;
};

class KeyManager {
  private slots: KeySlotConfig[];
  private clientCache = new Map<string, GoogleGenAI>();

  constructor(initialConfig: KeySlotConfig[] = DEFAULT_KEY_STORE_CONFIG) {
    this.slots = initialConfig.map(slot => {
      const resolvedKey = (slot.apiKey || slot.apikey || '').trim();
      return {
        ...slot,
        apiKey: resolvedKey,
        apikey: resolvedKey,
        cooldownUntil: 0,
        failureCount: 0
      };
    });
  }

  public maskKey(key: string): string {
    if (!key || key.length < 8) return '****';
    const start = key.slice(0, 9);
    const end = key.slice(-5);
    return `${start}...${end}`;
  }

  public getScheduledSlotIndex(date: Date = new Date()): number {
    return GeminiKeyRotationService.getSlotIndexForHour(date.getHours());
  }

  public getActiveKey(customApiKey?: string): string {
    const cleanCustom = (customApiKey || '').trim();
    if (cleanCustom.length > 20) {
      return cleanCustom;
    }

    const now = Date.now();
    const scheduledIndex = this.getScheduledSlotIndex();
    const scheduledSlot = this.slots[scheduledIndex];

    if (scheduledSlot && scheduledSlot.apiKey && (!scheduledSlot.cooldownUntil || now >= scheduledSlot.cooldownUntil)) {
      return scheduledSlot.apiKey;
    }

    const primarySlots = this.slots.filter(s => !s.isBackup && s.apiKey);
    for (let i = 0; i < primarySlots.length; i++) {
      const candidate = primarySlots[(scheduledIndex + i) % primarySlots.length];
      if (candidate.apiKey && (!candidate.cooldownUntil || now >= candidate.cooldownUntil)) {
        return candidate.apiKey;
      }
    }

    const backupSlots = this.slots.filter(s => s.isBackup && s.apiKey);
    for (const bSlot of backupSlots) {
      if (bSlot.apiKey && (!bSlot.cooldownUntil || now >= bSlot.cooldownUntil)) {
        return bSlot.apiKey;
      }
    }

    const anyHealthy = this.slots.find(s => !!s.apiKey);
    return anyHealthy ? anyHealthy.apiKey : (scheduledSlot?.apiKey || '');
  }

  public markQuotaExhausted(keyOrSlot: string | number, cooldownDurationMs: number = 60 * 60 * 1000): void {
    const now = Date.now();
    for (const slot of this.slots) {
      if (slot.apiKey === keyOrSlot || slot.apikey === keyOrSlot || slot.slotNumber === keyOrSlot || slot.id === keyOrSlot) {
        slot.cooldownUntil = now + cooldownDurationMs;
        slot.failureCount = (slot.failureCount || 0) + 1;
        this.clientCache.delete(slot.apiKey);
      }
    }
  }

  public resetCooldown(slotNumberOrKey?: number | string): void {
    if (slotNumberOrKey === undefined) {
      this.slots.forEach(s => {
        s.cooldownUntil = 0;
        s.failureCount = 0;
      });
      return;
    }

    for (const slot of this.slots) {
      if (slot.slotNumber === slotNumberOrKey || slot.apiKey === slotNumberOrKey || slot.id === slotNumberOrKey) {
        slot.cooldownUntil = 0;
        slot.failureCount = 0;
      }
    }
  }

  public getClient(customApiKey?: string): GoogleGenAI {
    const apiKey = this.getActiveKey(customApiKey);
    let client = this.clientCache.get(apiKey);
    if (!client) {
      client = new GoogleGenAI({
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
      this.clientCache.set(apiKey, client);
    }
    return client;
  }
  public getAllHealthyKeys(customApiKey?: string): string[] {
    const keys: string[] = [];
    const now = Date.now();
    const cleanCustom = (customApiKey || '').trim();

    if (cleanCustom.length > 20) {
      keys.push(cleanCustom);
    }

    const scheduledIndex = this.getScheduledSlotIndex();
    const scheduledSlot = this.slots[scheduledIndex];

    if (scheduledSlot?.apiKey && (!scheduledSlot.cooldownUntil || now >= scheduledSlot.cooldownUntil)) {
      if (!keys.includes(scheduledSlot.apiKey)) keys.push(scheduledSlot.apiKey);
    }

    const otherPrimaries = this.slots.filter(s => !s.isBackup && s.apiKey && s.slotNumber !== scheduledSlot?.slotNumber);
    for (const slot of otherPrimaries) {
      if (!slot.cooldownUntil || now >= slot.cooldownUntil) {
        if (!keys.includes(slot.apiKey)) keys.push(slot.apiKey);
      }
    }

    const backupSlots = this.slots.filter(s => s.isBackup && s.apiKey);
    for (const slot of backupSlots) {
      if (!slot.cooldownUntil || now >= slot.cooldownUntil) {
        if (!keys.includes(slot.apiKey)) keys.push(slot.apiKey);
      }
    }

    if (keys.length === 0) {
      for (const slot of this.slots) {
        if (slot.apiKey && !keys.includes(slot.apiKey)) {
          keys.push(slot.apiKey);
        }
      }
    }

    return keys;
  }

  public getStatus(): KeyStoreStatus {
    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();
    const currentTs = now.getTime();

    const scheduledIndex = this.getScheduledSlotIndex(now);
    const scheduledSlot = this.slots[scheduledIndex];
    const activeKey = this.getActiveKey();

    const activeSlot = this.slots.find(s => s.apiKey === activeKey) || scheduledSlot;

    const minutesIntoCurrentSlot = ((currentHour - scheduledSlot.startHour + 24) % 24) * 60 + currentMinute;
    const totalSlotMinutes = (scheduledSlot.endHour - scheduledSlot.startHour) * 60;
    const timeUntilNextRotationMinutes = Math.max(0, totalSlotMinutes - minutesIntoCurrentSlot);

    return {
      activeSlot: {
        slotNumber: activeSlot.slotNumber,
        id: activeSlot.id,
        label: activeSlot.label,
        timeRange: activeSlot.timeRange,
        maskedKey: this.maskKey(activeKey),
        isPrimaryScheduled: activeSlot.id === scheduledSlot.id,
        isHardcodedFallback: isHardcodedFallbackKey(activeKey)
      },
      currentTimeServer: now.toISOString(),
      currentHour,
      currentMinute,
      timeUntilNextRotationMinutes,
      slots: this.slots.map((slot, index) => {
        const isScheduled = index === scheduledIndex;
        const isActive = slot.apiKey === activeKey;
        const isCoolingDown = !!(slot.cooldownUntil && currentTs < slot.cooldownUntil);
        const cooldownRemainingSec = isCoolingDown ? Math.ceil((slot.cooldownUntil! - currentTs) / 1000) : 0;

        return {
          slotNumber: slot.slotNumber,
          id: slot.id,
          label: slot.label,
          timeRange: slot.timeRange,
          maskedKey: this.maskKey(slot.apiKey),
          isScheduledNow: isScheduled,
          isActiveNow: isActive,
          isCoolingDown,
          cooldownRemainingSec,
          failureCount: slot.failureCount || 0,
          isHardcodedFallback: isHardcodedFallbackKey(slot.apiKey)
        };
      })
    };
  }

  public async testKey(slotOrKey?: number | string): Promise<{
    success: boolean;
    model?: string;
    slotNumber?: number;
    maskedKey: string;
    latencyMs?: number;
    error?: string;
  }> {
    let targetKey = '';
    let targetSlotNumber: number | undefined;

    if (slotOrKey === undefined) {
      targetKey = this.getActiveKey();
      targetSlotNumber = this.slots.find(s => s.apiKey === targetKey)?.slotNumber;
    } else if (typeof slotOrKey === 'number') {
      const slot = this.slots.find(s => s.slotNumber === slotOrKey);
      if (!slot) return { success: false, maskedKey: 'N/A', error: `Slot ${slotOrKey} not found` };
      targetKey = slot.apiKey;
      targetSlotNumber = slot.slotNumber;
    } else {
      const slot = this.slots.find(s => s.id === slotOrKey || s.apiKey === slotOrKey);
      if (slot) {
        targetKey = slot.apiKey;
        targetSlotNumber = slot.slotNumber;
      } else {
        targetKey = slotOrKey;
      }
    }

    const start = Date.now();
    try {
      const testClient = new GoogleGenAI({
        apiKey: targetKey,
        httpOptions: { headers: { 'User-Agent': 'aistudio-build' } }
      });

      let res: any = null;
      let usedModel = 'gemini-3.8-flash';
      try {
        res = await testClient.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: 'ping',
          config: { maxOutputTokens: 5 }
        });
      } catch (firstErr: any) {
        // Fallback to gemini-3.1-flash-lite on transient model-specific limits
        usedModel = 'gemini-3.1-flash-lite';
        res = await testClient.models.generateContent({
          model: 'gemini-3.1-flash-lite',
          contents: 'ping',
          config: { maxOutputTokens: 5 }
        });
      }

      const latencyMs = Date.now() - start;
      if (targetSlotNumber !== undefined) {
        this.resetCooldown(targetSlotNumber);
      }

      return {
        success: true,
        model: usedModel,
        slotNumber: targetSlotNumber,
        maskedKey: this.maskKey(targetKey),
        latencyMs
      };
    } catch (err: any) {
      const latencyMs = Date.now() - start;
      const errMsg = err?.message || 'Authentication or API call failed';
      return {
        success: false,
        slotNumber: targetSlotNumber,
        maskedKey: this.maskKey(targetKey),
        latencyMs,
        error: errMsg
      };
    }
  }

  public updateSlotKey(slotNumber: number, newKey: string): boolean {
    const slot = this.slots.find(s => s.slotNumber === slotNumber);
    if (!slot) return false;
    slot.apiKey = newKey.trim();
    slot.cooldownUntil = 0;
    slot.failureCount = 0;
    this.clientCache.delete(slot.apiKey);
    return true;
  }
}

export const keyManager = new KeyManager();
