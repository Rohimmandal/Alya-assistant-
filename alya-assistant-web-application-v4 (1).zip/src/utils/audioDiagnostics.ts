/**
 * Audio Diagnostics Utility for Alya Assistant Live Voice & PCM Audio-to-Audio Loop
 * Logs Web Audio API state transitions, sample rates, buffer queue health, and PCM chunk metrics to the console.
 */

export interface AudioStreamDiagnosticsReport {
  timestamp: string;
  contextState: AudioContextState | 'uninitialized';
  nativeSampleRate: number;
  targetSampleRate: number;
  activeSourcesCount: number;
  isTurnActive: boolean;
  lastScheduledEndTime: number;
  rmsEnergy: number;
  streamHealth: 'HEALTHY' | 'STALLED' | 'HANGING' | 'MUTED' | 'IDLE';
  note: string;
}

export class AudioDiagnosticsLogger {
  private static lastLogTimestamp: number = 0;
  private static chunkCount: number = 0;
  private static stallThresholdMs: number = 4000;
  private static lastChunkTime: number = Date.now();

  /**
   * Logs Web Audio API state transitions and context metrics
   */
  public static logStateTransition(
    module: 'AudioStreamer' | 'PCMAudioProcessor' | 'LiveSession' | 'AudioCoordinator',
    transition: string,
    details?: Record<string, any>
  ) {
    const time = new Date().toISOString().split('T')[1].slice(0, 12);
    console.log(
      `%c[AlyaAudioDiag][${time}][${module}]%c 🔄 State Transition: %c${transition}`,
      'color: #38bdf8; font-weight: bold;',
      'color: inherit;',
      'color: #34d399; font-weight: bold;',
      details || ''
    );
  }

  /**
   * Logs PCM stream health, RMS energy, and sample rates
   */
  public static logPCMStreamHealth(
    source: 'MicrophoneInput' | 'ModelOutput24kHz',
    metrics: {
      sampleRate: number;
      chunkBytes: number;
      rms: number;
      queueSize?: number;
      latencyMs?: number;
    }
  ) {
    this.chunkCount++;
    this.lastChunkTime = Date.now();

    const health = metrics.rms < 0.0001 ? 'IDLE' : metrics.rms > 0.02 ? 'HEALTHY' : 'LOW_SIGNAL';
    const time = new Date().toISOString().split('T')[1].slice(0, 12);

    console.debug(
      `%c[AlyaAudioHealth][${time}][${source}]%c Chunks: #${this.chunkCount} | SampleRate: ${metrics.sampleRate}Hz | Bytes: ${metrics.chunkBytes} | RMS: ${metrics.rms.toFixed(5)} | Health: ${health}`,
      'color: #a78bfa; font-weight: bold;',
      'color: inherit;'
    );
  }

  /**
   * Diagnostic inspector to detect hanging audio loops
   */
  public static checkHangingStatus(context: AudioContext | null, isPlaying: boolean, activeSources: number): AudioStreamDiagnosticsReport {
    const now = Date.now();
    const timeSinceLastChunk = now - this.lastChunkTime;
    const ctxState = context ? context.state : 'uninitialized';
    const nativeRate = context ? context.sampleRate : 0;

    let health: 'HEALTHY' | 'STALLED' | 'HANGING' | 'MUTED' | 'IDLE' = 'HEALTHY';
    let note = 'Audio loop operating normally.';

    if (ctxState === 'suspended' || ctxState === 'closed') {
      health = 'HANGING';
      note = `AudioContext is ${ctxState}. Browser blocked or closed audio output.`;
    } else if (isPlaying && timeSinceLastChunk > this.stallThresholdMs) {
      health = 'STALLED';
      note = `Playback active but no audio chunk received for ${timeSinceLastChunk}ms. Stream may be stalled.`;
    } else if (!isPlaying && activeSources === 0) {
      health = 'IDLE';
      note = 'No active audio playback in progress.';
    }

    const report: AudioStreamDiagnosticsReport = {
      timestamp: new Date().toISOString(),
      contextState: ctxState,
      nativeSampleRate: nativeRate,
      targetSampleRate: 24000,
      activeSourcesCount: activeSources,
      isTurnActive: isPlaying,
      lastScheduledEndTime: 0,
      rmsEnergy: 0.01,
      streamHealth: health,
      note
    };

    if (health === 'HANGING' || health === 'STALLED') {
      console.warn(`%c[AlyaAudioDiag] ⚠️ Audio Stream Warning: ${health} - ${note}`, 'color: #f87171; font-weight: bold;');
    }

    return report;
  }
}
