/**
 * Alya Assistant - GeminiKeyRotationService
 * 
 * Implements 6-hour interval rotation of Gemini API keys based on environment variables.
 * 
 * Logic:
 * - Rotates keys every 6 hours (0-5, 6-11, 12-17, 18-23).
 * - Selects from GEMINI_KEY_SLOT_1 through GEMINI_KEY_SLOT_4.
 */

import { GoogleGenAI } from '@google/genai';

export class GeminiKeyRotationService {
  public static getSlotIndexForHour(hour: number): number {
    // 6-hour interval rotation: 4 keys cycled every 6 hours (index 0 to 3)
    return Math.floor(hour / 6);
  }

  public static getCurrentKey(): string {
    const hour = new Date().getHours();
    const slotIndex = this.getSlotIndexForHour(hour);
    const slotVar = `GEMINI_KEY_SLOT_${slotIndex + 1}`;
    const primaryKey = process.env[slotVar];
    
    if (primaryKey && primaryKey.trim().length > 10) {
      return primaryKey.trim();
    }
    
    // Failover to backup slots (5, 6, 7)
    const backupKeys = [
      process.env.EY_SLOT_5 || process.env.GEMINI_KEY_SLOT_5 || 'AQ.Ab8RN6IVWctrWZzpMBfQp89ta6M_XYbYkyx57xlY1b_wLKiMqw',
      process.env.EY_SLOT_6 || process.env.GEMINI_KEY_SLOT_6 || 'AQ.Ab8RN6L3hsLIbbISIb2Idnw5FW36Him6Ey_Mx9UNSGA_6TxUXg',
      process.env.EY_SLOT_7 || process.env.GEMINI_KEY_SLOT_7 || 'AQ.Ab8RN6LjgexzF9h906rDkYC3Tkve_2TG9cgE94cq4DR--s8lTg'
    ];

    for (const bKey of backupKeys) {
      if (bKey && bKey.trim().length > 10) {
        return bKey.trim();
      }
    }

    console.warn(`[GeminiKeyRotationService] Missing key for ${slotVar}, falling back to GEMINI_API_KEY`);
    return process.env.GEMINI_API_KEY || '';
  }

  public static getActiveApiKey(): string {
    return this.getCurrentKey();
  }

  public static getClient(): GoogleGenAI {
    return new GoogleGenAI({
      apiKey: this.getActiveApiKey(),
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }
}
