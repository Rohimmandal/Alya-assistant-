/**
 * Ultra-Low Latency Worker-Based PCM16 16kHz AudioContext Stream Processor
 * Offloads resampling, Float32-to-Int16 PCM encoding, and Base64 serialization
 * to a dedicated Web Worker using ArrayBuffer transferables to prevent main thread blocking.
 */

export interface AudioDiagnosticMetrics {
  contextState: AudioContextState | 'uninitialized';
  nativeSampleRate: number;
  targetSampleRate: number;
  bufferSize: number;
  workerActive: boolean;
  workerProcessingLatencyMs: number;
  rmsEnergy: number;
  chunksProcessed: number;
  totalBytesStreamed: number;
  streamingBufferStatus: 'healthy' | 'buffering' | 'stalled' | 'idle';
  lastChunkTimestamp: number;
}

export interface PCMAudioProcessorConfig {
  sampleRate?: number; // Target sample rate (Default: 16000 for Gemini Live API)
  bufferSize?: number; // Buffer frame size (Default: 2048 for sub-50ms latency)
  onAudioChunk?: (base64Audio: string, rawPCM: Int16Array) => void;
  onEnergyLevel?: (rms: number) => void;
  onDiagnosticsUpdate?: (metrics: AudioDiagnosticMetrics) => void;
  onError?: (err: Error) => void;
}

// Inline Worker Code for zero-dependency worker instantiation with stateful phase-accurate resampling
const PCM_WORKER_SCRIPT = `
var lastSample = 0;
var phase = 0;
var x1 = 0;
var y1 = 0;

self.onmessage = function(e) {
  var data = e.data;
  if (!data) return;
  if (data.reset) {
    lastSample = 0;
    phase = 0;
    x1 = 0;
    y1 = 0;
    return;
  }
  if (!data.inputBuffer) return;

  var startTime = performance.now();
  var inputBuffer = new Float32Array(data.inputBuffer);
  var inputRate = data.inputRate;
  var targetRate = data.targetRate;
  var len = inputBuffer.length;

  // 1. Calculate RMS Audio Energy
  var sum = 0;
  for (var i = 0; i < len; i++) {
    sum += inputBuffer[i] * inputBuffer[i];
  }
  var rms = Math.sqrt(sum / len);

  // 2. High-performance Stateful Phase-Accurate Resampling with 110Hz DC Blocker
  var R = Math.max(0.95, 1.0 - (2.0 * Math.PI * 110.0 / inputRate));
  var targetData;
  if (inputRate === targetRate) {
    targetData = new Float32Array(len);
    for (var j = 0; j < len; j++) {
      var raw = inputBuffer[j];
      var filtered = raw - x1 + R * y1;
      x1 = raw;
      y1 = filtered;
      targetData[j] = filtered;
    }
  } else {
    var ratio = inputRate / targetRate;
    var outSamples = [];
    var inIdx = phase;

    while (inIdx < len) {
      var idx = Math.floor(inIdx);
      var frac = inIdx - idx;
      var s0 = idx === 0 ? lastSample : inputBuffer[idx - 1];
      var s1 = inputBuffer[idx];
      var rawSample = s0 + frac * (s1 - s0);

      var filteredSample = rawSample - x1 + R * y1;
      x1 = rawSample;
      y1 = filteredSample;

      outSamples.push(filteredSample);
      inIdx += ratio;
    }

    phase = inIdx - len;
    lastSample = inputBuffer[len - 1] || 0;
    targetData = new Float32Array(outSamples);
  }

  // 3. Convert Float32 to Little-Endian Int16 PCM with strict clamping
  var targetLen = targetData.length;
  var pcm16 = new Int16Array(targetLen);
  for (var k = 0; k < targetLen; k++) {
    var s = Math.max(-1, Math.min(1, targetData[k]));
    pcm16[k] = s < 0 ? Math.floor(s * 0x8000) : Math.floor(s * 0x7FFF);
  }

  // 4. Fast Base64 string encoding
  var bytes = new Uint8Array(pcm16.buffer);
  var byteLen = bytes.byteLength;
  var binary = '';
  var chunkSize = 8192;
  for (var c = 0; c < byteLen; c += chunkSize) {
    var chunk = bytes.subarray(c, Math.min(c + chunkSize, byteLen));
    binary += String.fromCharCode.apply(null, chunk);
  }
  var base64Audio = btoa(binary);
  var processingLatency = performance.now() - startTime;

  self.postMessage({
    base64Audio: base64Audio,
    pcmBuffer: pcm16.buffer,
    rms: rms,
    byteCount: byteLen,
    processingLatencyMs: processingLatency
  }, [pcm16.buffer]);
};
`;

export class PCMAudioProcessor {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private silentGain: GainNode | null = null;
  private worker: Worker | null = null;
  private isCapturing: boolean = false;
  private isMuted: boolean = false;
  private config: Required<PCMAudioProcessorConfig>;

  // Metrics telemetry
  private metrics: AudioDiagnosticMetrics = {
    contextState: 'uninitialized',
    nativeSampleRate: 0,
    targetSampleRate: 16000,
    bufferSize: 2048,
    workerActive: false,
    workerProcessingLatencyMs: 0,
    rmsEnergy: 0,
    chunksProcessed: 0,
    totalBytesStreamed: 0,
    streamingBufferStatus: 'idle',
    lastChunkTimestamp: 0,
  };

  constructor(config: PCMAudioProcessorConfig = {}) {
    this.config = {
      sampleRate: config.sampleRate || 16000,
      bufferSize: config.bufferSize || 512,
      onAudioChunk: config.onAudioChunk || (() => {}),
      onEnergyLevel: config.onEnergyLevel || (() => {}),
      onDiagnosticsUpdate: config.onDiagnosticsUpdate || (() => {}),
      onError: config.onError || ((err) => console.error('[PCMAudioProcessor] Error:', err)),
    };
    this.metrics.targetSampleRate = this.config.sampleRate;
    this.metrics.bufferSize = this.config.bufferSize;
  }

  /**
   * Initializes dedicated Web Worker for off-thread audio transformation
   */
  private initWorker(): void {
    if (this.worker) return;

    try {
      const blob = new Blob([PCM_WORKER_SCRIPT], { type: 'application/javascript' });
      const workerUrl = URL.createObjectURL(blob);
      const worker = new Worker(workerUrl);
      URL.revokeObjectURL(workerUrl);

      worker.onmessage = (e: MessageEvent) => {
        if (!this.isCapturing || this.isMuted) return;

        const { base64Audio, pcmBuffer, rms, byteCount, processingLatencyMs } = e.data;
        const pcm16 = new Int16Array(pcmBuffer);

        // Update real-time metrics
        this.metrics.rmsEnergy = rms;
        this.metrics.workerProcessingLatencyMs = processingLatencyMs;
        this.metrics.chunksProcessed += 1;
        this.metrics.totalBytesStreamed += byteCount;
        this.metrics.lastChunkTimestamp = Date.now();
        this.metrics.streamingBufferStatus = 'healthy';

        // Notify subscribers
        this.config.onEnergyLevel(rms);
        this.config.onAudioChunk(base64Audio, pcm16);
        this.config.onDiagnosticsUpdate({ ...this.metrics });
      };

      worker.onerror = (err) => {
        console.warn('[PCMAudioProcessor] Worker error, falling back:', err);
        this.metrics.workerActive = false;
      };

      this.worker = worker;
      this.metrics.workerActive = true;
    } catch (workerErr) {
      console.warn('[PCMAudioProcessor] Failed to instantiate worker:', workerErr);
      this.metrics.workerActive = false;
    }
  }

  /**
   * Initializes microphone stream and begins worker-accelerated PCM extraction
   */
  public async start(): Promise<void> {
    if (this.isCapturing) return;

    try {
      this.initWorker();

      // 1. Request microphone access with echo cancellation and auto gain
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
          sampleRate: this.config.sampleRate
        }
      });
      this.mediaStream = stream;

      // 2. Initialize AudioContext at target sample rate if possible
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      let ctx: AudioContext;
      try {
        ctx = new AudioCtxClass({ sampleRate: this.config.sampleRate });
      } catch {
        ctx = new AudioCtxClass();
      }

      if (ctx.state === 'suspended') {
        await ctx.resume().catch(() => {});
      }
      this.audioContext = ctx;

      // Update context metrics
      this.metrics.contextState = ctx.state;
      this.metrics.nativeSampleRate = ctx.sampleRate;
      this.metrics.streamingBufferStatus = 'healthy';
      this.config.onDiagnosticsUpdate({ ...this.metrics });

      // 3. Create Audio Graph Pipeline
      const source = ctx.createMediaStreamSource(stream);
      this.sourceNode = source;

      // Add High-pass filter to clean up low-end noise from microphone
      const hpFilter = ctx.createBiquadFilter();
      hpFilter.type = 'highpass';
      hpFilter.frequency.setValueAtTime(150, ctx.currentTime);

      const processor = ctx.createScriptProcessor(this.config.bufferSize, 1, 1);
      this.scriptProcessor = processor;

      source.connect(hpFilter);
      hpFilter.connect(processor);
      processor.connect(ctx.destination); // Required to keep processor alive

      processor.onaudioprocess = (event: AudioProcessingEvent) => {
        if (!this.isCapturing || this.isMuted) return;

        const inputChannelData = event.inputBuffer.getChannelData(0);
        if (!inputChannelData || inputChannelData.length === 0) return;

        // Copy buffer to transferable ArrayBuffer for zero-copy worker dispatch
        const bufferCopy = new Float32Array(inputChannelData.length);
        bufferCopy.set(inputChannelData);

        if (this.worker && this.metrics.workerActive) {
          // Offload to Web Worker with Transferable
          this.worker.postMessage({
            inputBuffer: bufferCopy.buffer,
            inputRate: ctx.sampleRate,
            targetRate: this.config.sampleRate
          }, [bufferCopy.buffer]);
        } else {
          // Fallback in-thread processing if worker unavailable
          this.fallbackProcess(bufferCopy, ctx.sampleRate);
        }
      };

      source.connect(processor);

      // Keep ScriptProcessor active in isolated gain node WITHOUT connecting to ctx.destination
      // This completely prevents microphone loopback and acoustic feedback screeching
      const isolatedGain = ctx.createGain();
      isolatedGain.gain.value = 0;
      processor.connect(isolatedGain);
      // DO NOT connect isolatedGain to ctx.destination!
      this.silentGain = isolatedGain;

      this.isCapturing = true;
      this.metrics.contextState = ctx.state;
      this.config.onDiagnosticsUpdate({ ...this.metrics });
    } catch (err: any) {
      this.stop();
      this.metrics.streamingBufferStatus = 'stalled';
      this.config.onDiagnosticsUpdate({ ...this.metrics });
      this.config.onError(err instanceof Error ? err : new Error(String(err)));
      throw err;
    }
  }

  /**
   * Fallback in-thread processing if worker is blocked
   */
  private fallbackProcess(inputBuffer: Float32Array, inputRate: number): void {
    const t0 = performance.now();
    let sum = 0;
    for (let i = 0; i < inputBuffer.length; i++) {
      sum += inputBuffer[i] * inputBuffer[i];
    }
    const rms = Math.sqrt(sum / inputBuffer.length);
    this.config.onEnergyLevel(rms);

    let targetData: Float32Array;
    const targetRate = this.config.sampleRate;

    if (inputRate === targetRate) {
      targetData = inputBuffer;
    } else {
      const ratio = inputRate / targetRate;
      const targetLength = Math.round(inputBuffer.length / ratio);
      targetData = new Float32Array(targetLength);
      for (let i = 0; i < targetLength; i++) {
        const srcIdx = i * ratio;
        const idx = Math.floor(srcIdx);
        const frac = srcIdx - idx;
        const s0 = inputBuffer[idx] || 0;
        const s1 = inputBuffer[idx + 1] !== undefined ? inputBuffer[idx + 1] : s0;
        targetData[i] = s0 + frac * (s1 - s0);
      }
    }

    const pcm16 = new Int16Array(targetData.length);
    for (let i = 0; i < targetData.length; i++) {
      const s = Math.max(-1, Math.min(1, targetData[i]));
      pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7FFF;
    }

    let binary = '';
    const bytes = new Uint8Array(pcm16.buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    const base64Audio = btoa(binary);

    this.metrics.rmsEnergy = rms;
    this.metrics.workerProcessingLatencyMs = performance.now() - t0;
    this.metrics.chunksProcessed += 1;
    this.metrics.totalBytesStreamed += len;
    this.metrics.lastChunkTimestamp = Date.now();
    this.metrics.streamingBufferStatus = 'healthy';

    this.config.onAudioChunk(base64Audio, pcm16);
    this.config.onDiagnosticsUpdate({ ...this.metrics });
  }

  public setMute(mute: boolean): void {
    this.isMuted = mute;
    if (this.mediaStream) {
      this.mediaStream.getAudioTracks().forEach(track => {
        track.enabled = !mute;
      });
    }
  }

  public getDiagnostics(): AudioDiagnosticMetrics {
    if (this.audioContext) {
      this.metrics.contextState = this.audioContext.state;
    }
    return { ...this.metrics };
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getIsCapturing(): boolean {
    return this.isCapturing;
  }

  public flushBuffer(): void {
    if (this.worker) {
      this.worker.postMessage({ reset: true });
    }
    this.metrics.streamingBufferStatus = 'healthy';
  }

  /**
   * Cleans up audio nodes, worker, and microphone tracks
   */
  public stop(): void {
    this.isCapturing = false;

    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
      this.metrics.workerActive = false;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach(track => track.stop());
      this.mediaStream = null;
    }

    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.scriptProcessor) {
      this.scriptProcessor.disconnect();
      this.scriptProcessor = null;
    }

    if (this.silentGain) {
      this.silentGain.disconnect();
      this.silentGain = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }

    this.metrics.contextState = 'closed';
    this.metrics.streamingBufferStatus = 'idle';
    this.config.onDiagnosticsUpdate({ ...this.metrics });
  }
}
