import { precacheAndRoute } from 'workbox-precaching';
import { registerRoute } from 'workbox-routing';
import { StaleWhileRevalidate, CacheFirst } from 'workbox-strategies';

declare const self: any;

// Precache assets injected by workbox
precacheAndRoute(self.__WB_MANIFEST);

// Implement CacheFirst for speaker verification model
registerRoute(
  ({ url }) => url.origin === 'https://huggingface.co' && url.pathname.includes('wavlm-base-plus-sv'),
  new CacheFirst({
    cacheName: 'speaker-verification-model',
  })
);

// Implement Stale-While-Revalidate for UI assets
registerRoute(
  ({ request }) => 
    request.destination === 'script' || 
    request.destination === 'style' || 
    request.destination === 'image' || 
    request.destination === 'font',
  new StaleWhileRevalidate({
    cacheName: 'core-ui-assets',
  })
);

self.addEventListener('install', () => {
  self.skipWaiting();
});

self.addEventListener('activate', (event: any) => {
  event.waitUntil(self.clients.claim());
});

// Handle push notifications (if any) or messages from main app
self.addEventListener('message', (event: any) => {
  if (event.data && event.data.type === 'SHOW_NOTIFICATION') {
    const { title, body, actions, data } = event.data.payload;
    self.registration.showNotification(title, {
      body,
      icon: '/icon.png',
      badge: '/badge.png',
      vibrate: [100, 50, 100],
      data,
      actions: actions || [
        {
          action: 'reply',
          type: 'text',
          placeholder: 'यहाँ जवाब लिखें...',
          title: 'Reply'
        }
      ]
    });
  }
});

self.addEventListener('notificationclick', (event: any) => {
  event.notification.close();

  if (event.action === 'reply') {
    const userReply = event.reply;
    
    if (!userReply) return;

    // Send the reply to our API
    event.waitUntil(
      fetch('/api/alya-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          message: userReply,
          context: event.notification.data 
        })
      })
      .then(res => res.json())
      .then(data => {
        // Show AI's new response in a notification
        return self.registration.showNotification('Alya LIVE', {
          body: data.reply,
          icon: '/icon.png',
          badge: '/badge.png',
          vibrate: [100, 50, 100],
          actions: [
            {
              action: 'reply',
              type: 'text',
              placeholder: 'उत्तर दें...',
              title: 'Reply'
            }
          ]
        });
      })
      .catch(err => {
        console.error('Failed to send notification reply:', err);
      })
    );
  } else {
    // Focus or open the app on normal click
    event.waitUntil(
      self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList: any[]) => {
        if (clientList.length > 0) {
          return clientList[0].focus();
        }
        return self.clients.openWindow('/');
      })
    );
  }
});
