import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertCircle, RotateCcw, ShieldAlert, LogOut } from 'lucide-react';
import { auth } from './lib/firebase';
import { signOut } from 'firebase/auth';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  errorInfo: any | null;
}

export class PersistenceErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    errorInfo: null
  };

  public static getDerivedStateFromError(error: Error): State {
    // Attempt to parse Firestore error JSON
    let info = null;
    try {
      if (error.message.startsWith('{') && error.message.endsWith('}')) {
        info = JSON.parse(error.message);
      }
    } catch (e) {}
    
    return { hasError: true, errorInfo: info || { error: error.message } };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('PersistenceErrorBoundary caught an error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, errorInfo: null });
    window.location.reload();
  };

  private handleLogout = async () => {
    try {
      await signOut(auth);
      window.location.reload();
    } catch (e) {
      window.location.href = '/';
    }
  };

  public render() {
    if (this.state.hasError) {
      const isPermissionError = this.state.errorInfo?.error?.includes('permission') || 
                               this.state.errorInfo?.error?.includes('insufficient');

      return (
        <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 text-white font-sans">
          <div className="w-full max-w-md bg-slate-900 border border-white/10 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-rose-500 via-amber-500 to-rose-500" />
            
            <div className="flex flex-col items-center text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-rose-500/20 flex items-center justify-center border border-rose-500/30">
                {isPermissionError ? <ShieldAlert className="w-10 h-10 text-rose-400" /> : <AlertCircle className="w-10 h-10 text-rose-400" />}
              </div>

              <div className="space-y-2">
                <h2 className="text-2xl font-black tracking-tight uppercase">
                  {isPermissionError ? 'Access Denied' : 'Data Sync Error'}
                </h2>
                <p className="text-slate-400 text-sm leading-relaxed">
                  {isPermissionError 
                    ? "Your account doesn't have permission to write this data. This might happen if your session expired or rules were updated."
                    : "Something went wrong while saving your data to the cloud. We couldn't complete the operation."}
                </p>
              </div>

              <div className="w-full p-4 rounded-2xl bg-slate-950/50 border border-white/5 text-left space-y-2 overflow-hidden">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Diagnostic Details</p>
                <code className="block text-[10px] font-mono text-rose-300/80 break-all max-h-32 overflow-y-auto">
                  {this.state.errorInfo?.error || 'Unknown Persistence Error'}
                  {this.state.errorInfo?.path && `\nPath: ${this.state.errorInfo.path}`}
                  {this.state.errorInfo?.operationType && `\nOp: ${this.state.errorInfo.operationType}`}
                </code>
              </div>

              <div className="grid grid-cols-2 gap-4 w-full pt-2">
                <button
                  onClick={this.handleReset}
                  className="flex items-center justify-center gap-2 py-4 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-white font-bold transition-all active:scale-95"
                >
                  <RotateCcw className="w-4 h-4" />
                  Retry
                </button>
                <button
                  onClick={this.handleLogout}
                  className="flex items-center justify-center gap-2 py-4 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-bold transition-all shadow-lg shadow-rose-600/20 active:scale-95"
                >
                  <LogOut className="w-4 h-4" />
                  Sign Out
                </button>
              </div>
              
              <p className="text-[10px] text-slate-600 font-medium italic">
                If the problem persists, please check your internet connection.
              </p>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
