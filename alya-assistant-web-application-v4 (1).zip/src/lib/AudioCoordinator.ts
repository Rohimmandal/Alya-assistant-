/**
 * src/lib/AudioCoordinator.ts
 * 
 * Unified AudioCoordinator Service for Alya Assistant
 * 
 * Core Architectural Mandates:
 * 1. Singleton Destination Lock: Manages centralized access to the AudioContext destination node.
 * 2. Hard-Coded Gate: Enforces absolute mutual exclusion. If a primary stream (Alya Live Voice) is active,
 *    all secondary streams/packets are unconditionally gated and dropped to permanently prevent multi-audio overlap.
 * 3. Stale Packet Eviction (>100ms): Inspects packet timestamp deltas against audio clock and discards lag-induced stale frames.
 * 4. Explicit Node Lifecycle & Dangling Node Verification: Tracks active AudioNode/AudioWorklet references,
 *    mandates immediate disconnect + GC deallocation upon stream termination, and exposes node verification checks.
 */

import { audioPipelineDiagnostics } from './AudioPipelineDiagnostics';
import { AudioDiagnosticsLogger } from '../utils/audioDiagnostics';

export type StreamPriority = 'PRIMARY_LIVE_VOICE' | 'TTS_CHAT' | 'MEDIA_PLAYBACK' | 'SOUND_EFFECTS' | 'SYSTEM';

export interface ActiveStreamSession {
  streamId: string;
  streamType: StreamPriority;
  priorityLevel: number;
  acquiredAt: number;
  lastPacketAt: number;
  nodes: Set<AudioNode>;
  bufferSources: Set<AudioBufferSourceNode>;
  currentTimeReference: number;
  consecutiveStalePackets: number;
}

export interface StalePacketEvaluation {
  allowed: boolean;
  deltaMs: number;
  shouldHardReset?: boolean;
  reason?: string;
}

export interface DanglingNodeReport {
  activeStreams: number;
  registeredNodesCount: number;
  registeredBufferSourcesCount: number;
  isClean: boolean;
  danglingNodesByStream: Record<string, number>;
}

export interface HardResetEvent {
  streamId?: string;
  reason: string;
  sequence?: number;
  timestamp: number;
}

export class AudioCoordinator {
  private static instance: AudioCoordinator | null = null;

  // Centralized Master Audio Context & Routing Graph
  private masterAudioCtx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private masterCompressor: DynamicsCompressorNode | null = null;

  // Active Stream Lock
  private activePrimaryLock: ActiveStreamSession | null = null;
  private activeStreams: Map<string, ActiveStreamSession> = new Map();

  // Stale Packet Eviction Configuration
  private readonly MAX_ACCEPTABLE_PACKET_DELTA_MS = 100; // Strict 100ms lag threshold
  private readonly CRITICAL_LAG_HARD_RESET_MS = 300;     // Critical threshold triggering automatic hard-reset
  private readonly CONSECUTIVE_STALE_RESET_THRESHOLD = 3; // 3 consecutive stale packets triggers hard reset
  private staleEvictionsCount: number = 0;

  // Stream Priority Mapping
  private readonly PRIORITY_MAP: Record<StreamPriority, number> = {
    PRIMARY_LIVE_VOICE: 100,
    TTS_CHAT: 50,
    MEDIA_PLAYBACK: 30,
    SOUND_EFFECTS: 20,
    SYSTEM: 10
  };

  // Hard Reset Listeners
  private hardResetListeners: Set<(event: HardResetEvent) => void> = new Set();

  private constructor() {
    this.setupVisibilityListeners();
  }

  public static getInstance(): AudioCoordinator {
    if (!AudioCoordinator.instance) {
      AudioCoordinator.instance = new AudioCoordinator();
    }
    return AudioCoordinator.instance;
  }

  private setupVisibilityListeners(): void {
    if (typeof window === 'undefined') return;

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        // Evict secondary streams on backgrounding; preserve primary Live Voice session
        this.evictAllSecondaryStreams('tab_hidden');
      }
    });
  }

  /**
   * Initializes or returns the shared Master AudioContext configured for 24kHz/48kHz low-latency output
   */
  public async getMasterAudioContext(): Promise<AudioContext> {
    if (!this.masterAudioCtx || this.masterAudioCtx.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      try {
        this.masterAudioCtx = new AudioCtxClass({ sampleRate: 24000, latencyHint: 'interactive' });
      } catch {
        this.masterAudioCtx = new AudioCtxClass();
      }

      this.masterGain = this.masterAudioCtx.createGain();
      this.masterGain.gain.setValueAtTime(1.0, this.masterAudioCtx.currentTime);

      this.masterCompressor = this.masterAudioCtx.createDynamicsCompressor();
      this.masterCompressor.threshold.setValueAtTime(-6, this.masterAudioCtx.currentTime);
      this.masterCompressor.knee.setValueAtTime(8, this.masterAudioCtx.currentTime);
      this.masterCompressor.ratio.setValueAtTime(6, this.masterAudioCtx.currentTime);
      this.masterCompressor.attack.setValueAtTime(0.001, this.masterAudioCtx.currentTime);
      this.masterCompressor.release.setValueAtTime(0.05, this.masterAudioCtx.currentTime);

      this.masterGain.connect(this.masterCompressor);
      this.masterCompressor.connect(this.masterAudioCtx.destination);
    }

    if (this.masterAudioCtx.state === 'suspended') {
      try {
        await this.masterAudioCtx.resume();
      } catch (err) {
        console.warn('[AudioCoordinator] Resume AudioContext notice:', err);
      }
    }

    audioPipelineDiagnostics.reportContextState(this.masterAudioCtx.state, this.masterAudioCtx.sampleRate);
    return this.masterAudioCtx;
  }

  public getMasterDestination(): GainNode | null {
    return this.masterGain;
  }

  /**
   * Hard-Coded Gate: Evaluates whether an incoming stream or chunk is authorized to play.
   * If a PRIMARY_LIVE_VOICE stream is currently active, any non-primary stream is gated off.
   */
  public isStreamAllowed(streamType: StreamPriority, streamId: string): boolean {
    if (this.activePrimaryLock) {
      if (this.activePrimaryLock.streamId === streamId) {
        return true;
      }
      // If primary is active, only equal or higher priority can proceed (with preemption)
      if (this.PRIORITY_MAP[streamType] < this.activePrimaryLock.priorityLevel) {
        return false;
      }
    }
    return true;
  }

  /**
   * Acquires the singleton destination lock for an audio session.
   * Higher priority streams immediately preempt and terminate lower priority streams.
   */
  public acquireDestinationLock(streamType: StreamPriority, streamId: string): boolean {
    const priority = this.PRIORITY_MAP[streamType];

    // If another stream holds the primary lock
    if (this.activePrimaryLock && this.activePrimaryLock.streamId !== streamId) {
      if (priority > this.activePrimaryLock.priorityLevel) {
        console.log(`[AudioCoordinator] Preempting existing stream ${this.activePrimaryLock.streamId} for higher priority ${streamType}`);
        this.triggerHardReset(this.activePrimaryLock.streamId, 'preempted_by_higher_priority');
        this.terminateStream(this.activePrimaryLock.streamId, 'preempted_by_higher_priority');
      } else if (priority < this.activePrimaryLock.priorityLevel) {
        console.warn(`[AudioCoordinator] Destination lock rejected for ${streamId} (${streamType}): Primary stream ${this.activePrimaryLock.streamId} is active`);
        return false;
      }
    }

    // Register or update active session
    let session = this.activeStreams.get(streamId);
    const nowTime = this.masterAudioCtx ? this.masterAudioCtx.currentTime : 0;
    if (!session) {
      session = {
        streamId,
        streamType,
        priorityLevel: priority,
        acquiredAt: Date.now(),
        lastPacketAt: Date.now(),
        nodes: new Set(),
        bufferSources: new Set(),
        currentTimeReference: nowTime,
        consecutiveStalePackets: 0
      };
      this.activeStreams.set(streamId, session);
    } else {
      session.lastPacketAt = Date.now();
    }

    if (streamType === 'PRIMARY_LIVE_VOICE') {
      this.activePrimaryLock = session;
      audioPipelineDiagnostics.reportCoordinatorLock(streamType, streamId);
      AudioDiagnosticsLogger.logStateTransition('AudioCoordinator', 'primary_lock_acquired', { streamId, streamType });
    }

    return true;
  }

  /**
   * Releases the destination lock for a completed or terminated session
   */
  public releaseDestinationLock(streamId: string): void {
    if (this.activePrimaryLock && this.activePrimaryLock.streamId === streamId) {
      this.activePrimaryLock = null;
      audioPipelineDiagnostics.reportCoordinatorLock('IDLE', 'none');
      AudioDiagnosticsLogger.logStateTransition('AudioCoordinator', 'primary_lock_released', { streamId });
    }
    this.cleanupStreamNodes(streamId);
    this.activeStreams.delete(streamId);
  }

  public isPrimaryActive(): boolean {
    return this.activePrimaryLock !== null;
  }

  public getActiveLockOwner(): string | null {
    return this.activePrimaryLock ? this.activePrimaryLock.streamId : null;
  }

  /**
   * Registers an active AudioBufferSourceNode with the coordinator for instant nullification upon interruption.
   */
  public registerBufferSource(streamId: string, source: AudioBufferSourceNode): void {
    let session = this.activeStreams.get(streamId);
    if (!session) {
      this.acquireDestinationLock('PRIMARY_LIVE_VOICE', streamId);
      session = this.activeStreams.get(streamId);
    }
    if (session) {
      session.bufferSources.add(source);
      audioPipelineDiagnostics.reportActiveNodes(this.getTotalActiveNodesCount());
    }
  }

  /**
   * Unregisters a finished AudioBufferSourceNode from the coordinator.
   */
  public unregisterBufferSource(streamId: string, source: AudioBufferSourceNode): void {
    const session = this.activeStreams.get(streamId);
    if (session) {
      session.bufferSources.delete(source);
      audioPipelineDiagnostics.reportActiveNodes(this.getTotalActiveNodesCount());
    }
  }

  /**
   * Resets the AudioContext's currentTime reference point for a stream session to eliminate timeline drift.
   */
  public resetTimeReference(streamId?: string): number {
    const currentAudioTime = this.masterAudioCtx ? this.masterAudioCtx.currentTime : 0;
    if (streamId) {
      const session = this.activeStreams.get(streamId);
      if (session) {
        session.currentTimeReference = currentAudioTime;
        session.consecutiveStalePackets = 0;
      }
    } else {
      this.activeStreams.forEach(s => {
        s.currentTimeReference = currentAudioTime;
        s.consecutiveStalePackets = 0;
      });
    }
    return currentAudioTime;
  }

  /**
   * Packet Timing Validation:
   * Inspects arrival timing while accommodating normal network transit and clock skews.
   * Jitter buffering in AudioStreamer handles smooth playback.
   */
  public validatePacketTiming(
    serverTimestamp?: number, 
    arrivalTimestamp: number = Date.now(),
    streamId?: string
  ): StalePacketEvaluation {
    if (!serverTimestamp || serverTimestamp <= 0) {
      if (streamId) {
        const session = this.activeStreams.get(streamId);
        if (session) session.consecutiveStalePackets = 0;
      }
      return { allowed: true, deltaMs: 0, shouldHardReset: false };
    }

    const deltaMs = Math.max(0, arrivalTimestamp - serverTimestamp);

    // Only flag genuinely stale packets if transit latency is absurdly high (> 8000ms)
    if (deltaMs > 8000) {
      this.staleEvictionsCount++;
      audioPipelineDiagnostics.trackStaleEviction(deltaMs, this.staleEvictionsCount);
      console.warn(`[AudioCoordinator] Stale packet dropped (>8s transit delta: ${deltaMs}ms)`);
      return {
        allowed: false,
        deltaMs,
        shouldHardReset: false,
        reason: `Packet transit delta (${deltaMs}ms) > 8000ms threshold`
      };
    }

    // Packet is valid
    if (streamId) {
      const session = this.activeStreams.get(streamId);
      if (session) session.consecutiveStalePackets = 0;
    }

    return { allowed: true, deltaMs, shouldHardReset: false };
  }

  /**
   * SYNCHRONOUS HARD RESET TRIGGER:
   * Instantly nullifies, stops, and severs all active BufferSources.
   * Resets the AudioContext's currentTime reference point to prevent any lingering audio samples from being processed.
   * Clears all AudioWorklet ring buffers and sync markers immediately.
   */
  public triggerHardReset(streamId?: string, reason: string = 'stream_interruption_signal', sequence?: number): void {
    const currentAudioTime = this.masterAudioCtx ? this.masterAudioCtx.currentTime : 0;
    let nullifiedSourcesCount = 0;

    const executeStreamReset = (session: ActiveStreamSession) => {
      // 1. Instantly nullify, stop, and disconnect all registered AudioBufferSourceNodes
      session.bufferSources.forEach((source) => {
        try {
          source.onended = null;
          source.stop();
          source.disconnect();
          nullifiedSourcesCount++;
        } catch (err) {
          // Node may have already ended or disconnected
        }
      });
      session.bufferSources.clear();

      // 2. Synchronous hard-reset on all AudioWorkletNodes registered in the stream
      session.nodes.forEach((node) => {
        try {
          if ('port' in node && typeof (node as any).port?.postMessage === 'function') {
            (node as any).port.postMessage({ type: 'CLEAR' });
            (node as any).port.postMessage({ type: 'RESET' });
          }
        } catch {}
      });

      // 3. Reset the currentTime reference point to the present audio clock
      session.currentTimeReference = currentAudioTime;
      session.consecutiveStalePackets = 0;
    };

    if (streamId) {
      const session = this.activeStreams.get(streamId);
      if (session) {
        executeStreamReset(session);
      }
    } else {
      // Reset across all active stream sessions
      this.activeStreams.forEach((session) => {
        executeStreamReset(session);
      });
    }

    // 4. Update Diagnostics and Logging
    audioPipelineDiagnostics.logFlushEvent(`Coordinator Hard Reset: ${reason} (Nullified ${nullifiedSourcesCount} sources)`, sequence);
    audioPipelineDiagnostics.reportActiveNodes(this.getTotalActiveNodesCount());
    AudioDiagnosticsLogger.logStateTransition('AudioCoordinator', 'hard_reset_executed', {
      streamId: streamId || 'all',
      reason,
      sequence: sequence || 0,
      nullifiedSourcesCount,
      currentTimeReference: currentAudioTime
    });

    // 5. Notify registered hard reset listeners
    const event: HardResetEvent = {
      streamId,
      reason,
      sequence,
      timestamp: Date.now()
    };
    this.hardResetListeners.forEach((cb) => {
      try {
        cb(event);
      } catch (e) {
        console.warn('[AudioCoordinator] Hard reset listener error:', e);
      }
    });

    console.log(`[AudioCoordinator] ⚡ HARD RESET COMPLETED: Instantly nullified ${nullifiedSourcesCount} BufferSources. AudioContext currentTime reference point reset to ${currentAudioTime.toFixed(4)}s.`);
  }

  /**
   * Registers a listener callback for hard reset events
   */
  public onHardReset(listener: (event: HardResetEvent) => void): () => void {
    this.hardResetListeners.add(listener);
    return () => this.hardResetListeners.delete(listener);
  }

  /**
   * Registers an AudioNode or AudioWorkletNode to a specific stream session for lifetime tracking
   */
  public registerNode(streamId: string, node: AudioNode): void {
    let session = this.activeStreams.get(streamId);
    if (!session) {
      session = {
        streamId,
        streamType: 'PRIMARY_LIVE_VOICE',
        priorityLevel: 100,
        acquiredAt: Date.now(),
        lastPacketAt: Date.now(),
        nodes: new Set(),
        bufferSources: new Set(),
        currentTimeReference: this.masterAudioCtx ? this.masterAudioCtx.currentTime : 0,
        consecutiveStalePackets: 0
      };
      this.activeStreams.set(streamId, session);
    }
    session.nodes.add(node);
    audioPipelineDiagnostics.reportActiveNodes(this.getTotalActiveNodesCount());
  }

  /**
   * Forcibly and synchronously cleans up all AudioNodes registered to a stream,
   * explicitly destroying worklets and severing graph connections to allow instant GC.
   */
  public cleanupStreamNodes(streamId: string): { disconnectedCount: number } {
    const session = this.activeStreams.get(streamId);
    if (!session) return { disconnectedCount: 0 };

    let count = 0;
    // Nullify buffer sources first
    session.bufferSources.forEach((source) => {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
        count++;
      } catch {}
    });
    session.bufferSources.clear();

    session.nodes.forEach((node) => {
      try {
        if ('port' in node && typeof (node as any).port?.postMessage === 'function') {
          // Explicit AudioWorklet deallocation
          (node as any).port.postMessage({ type: 'DESTROY' });
        }
        node.disconnect();
        count++;
      } catch (err) {
        console.warn(`[AudioCoordinator] Notice disconnecting node for ${streamId}:`, err);
      }
    });

    session.nodes.clear();
    audioPipelineDiagnostics.reportActiveNodes(this.getTotalActiveNodesCount());
    return { disconnectedCount: count };
  }

  /**
   * Forcibly terminates a specific stream session
   */
  public terminateStream(streamId: string, reason: string = 'manual_termination'): void {
    this.triggerHardReset(streamId, `terminate_${reason}`);
    this.cleanupStreamNodes(streamId);
    if (this.activePrimaryLock && this.activePrimaryLock.streamId === streamId) {
      this.activePrimaryLock = null;
      audioPipelineDiagnostics.reportCoordinatorLock('IDLE', 'none');
    }
    this.activeStreams.delete(streamId);
    console.log(`[AudioCoordinator] Stream ${streamId} terminated: ${reason}`);
  }

  /**
   * Forcibly terminates all secondary non-primary audio streams
   */
  public evictAllSecondaryStreams(reason: string = 'secondary_eviction'): void {
    const idsToEvict: string[] = [];
    this.activeStreams.forEach((session, id) => {
      if (session.streamType !== 'PRIMARY_LIVE_VOICE') {
        idsToEvict.push(id);
      }
    });

    idsToEvict.forEach(id => this.terminateStream(id, reason));
  }

  /**
   * Verification step: Checks if any dangling audio nodes or orphaned sessions persist in memory.
   */
  public verifyDanglingNodes(): DanglingNodeReport {
    const danglingReport: Record<string, number> = {};
    let totalNodes = 0;
    let totalBufferSources = 0;

    this.activeStreams.forEach((session, id) => {
      const nodeCount = session.nodes.size;
      const bufferCount = session.bufferSources.size;
      totalNodes += nodeCount;
      totalBufferSources += bufferCount;
      if (nodeCount > 0 || bufferCount > 0) {
        danglingReport[id] = nodeCount + bufferCount;
      }
    });

    const isClean = totalNodes === 0 && totalBufferSources === 0;
    audioPipelineDiagnostics.reportDanglingVerification(totalNodes + totalBufferSources, isClean);

    if (!isClean) {
      console.warn(`[AudioCoordinator] Dangling AudioNode verification: ${totalNodes} nodes, ${totalBufferSources} buffer sources active across ${Object.keys(danglingReport).length} sessions.`);
    } else {
      console.log(`[AudioCoordinator] Dangling AudioNode verification: CLEAN (0 dangling nodes).`);
    }

    return {
      activeStreams: this.activeStreams.size,
      registeredNodesCount: totalNodes,
      registeredBufferSourcesCount: totalBufferSources,
      isClean,
      danglingNodesByStream: danglingReport
    };
  }

  public getTotalActiveNodesCount(): number {
    let total = 0;
    this.activeStreams.forEach((session) => {
      total += session.nodes.size + session.bufferSources.size;
    });
    return total;
  }

  public getStaleEvictionsCount(): number {
    return this.staleEvictionsCount;
  }
}

export const audioCoordinator = AudioCoordinator.getInstance();
