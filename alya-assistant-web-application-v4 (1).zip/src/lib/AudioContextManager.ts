/**
 * AudioContextManager.ts
 *
 * Centralized Web Audio 'AudioContext' & Audio Stream Priority Manager for Alya Assistant.
 *
 * Architectural Guarantees:
 * 1. Singleton AudioContext Lifecycle: Manages a single high-priority Web Audio context across speech synthesis,
 *    live WebSockets, and microphone inputs.
 * 2. Strict Stream Priorities:
 *    - ALYA_SPEECH (Priority 100): Preempts lower audio priorities, ducks or pauses background music/media.
 *    - USER_MIC (Priority 90): Active voice capture pipeline with real-time high-pass noise suppression.
 *    - BACKGROUND_MEDIA (Priority 20): Background music, video audio, or sound effects.
 * 3. Real-Time High-Pass Noise Suppression: Filters low-frequency hums (<85Hz–120Hz) from microphone streams.
 * 4. Automatic Ducking & Pause Lifecycle: Automatically lowers or pauses background media when Alya speaks,
 *    and restores original playback levels when speech ends.
 */

import { browserAutomation } from './BrowserAutomationController';
import { JitterBuffer } from './audio/JitterBuffer';
import { PrioritizedCircularBuffer } from './audio/PrioritizedCircularBuffer';
import { audioPipelineDiagnostics } from './AudioPipelineDiagnostics';

export enum StreamPriority {
  ALYA_SPEECH = 100,
  USER_MIC = 90,
  SYSTEM_NOTIFICATION = 50,
  BACKGROUND_MEDIA = 20,
}

export interface ActiveAudioStream {
  id: string;
  name: string;
  priority: StreamPriority;
  audioNode?: AudioNode;
  startedAt: number;
}

export class AudioContextManager {
  private static instance: AudioContextManager | null = null;

  private sharedContext: AudioContext | null = null;
  private masterGainNode: GainNode | null = null;
  private dynamicGainNode: GainNode | null = null;
  private compressorNode: DynamicsCompressorNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private activeStreams: Map<string, ActiveAudioStream> = new Map();
  private isAlyaSpeakingState: boolean = false;
  private micFilterNodes: Map<string, { highpassNode: BiquadFilterNode; lowpassNode: BiquadFilterNode }> = new Map();
  private jitterBuffer: JitterBuffer = new JitterBuffer();
  private circularBuffer: PrioritizedCircularBuffer = new PrioritizedCircularBuffer(32);

  private constructor() {
    this.setupLifecycleListeners();
  }

  public trackAudioPacketArrival(): void {
    this.jitterBuffer.trackPacketArrival();
    audioPipelineDiagnostics.trackJitterMetrics(
      this.jitterBuffer.getEstimatedJitterMs(),
      this.jitterBuffer.getCurrentDelayMs(),
      this.jitterBuffer.getPacketLossPercent()
    );
  }

  public getDynamicJitterOffset(): number {
    return this.jitterBuffer.getDynamicOffsetSeconds();
  }

  public pushAudioPacket(data: Float32Array, sequence: number, currentSequence: number): boolean {
    return this.circularBuffer.push(data, sequence, currentSequence);
  }

  public shiftAudioPacket(): Float32Array | null {
    return this.circularBuffer.shift();
  }

  public purgeStaleAudioPackets(currentSequence: number): number {
    return this.circularBuffer.purgeStale(currentSequence);
  }

  /**
   * Automatically computes optimal buffer chunk size and scheduling lookahead in milliseconds
   * based on current network jitter variance.
   */
  public getAdaptiveBufferSizeAndLookahead(): { bufferSize: number; lookaheadMs: number } {
    const estimatedJitterMs = this.jitterBuffer.getEstimatedJitterMs();
    
    let bufferSize = 320; // ~20ms at 16kHz
    let lookaheadMs = 30;

    if (estimatedJitterMs > 40) {
      bufferSize = 1280; // ~80ms
      lookaheadMs = 180;
    } else if (estimatedJitterMs > 20) {
      bufferSize = 640; // ~40ms
      lookaheadMs = 100;
    } else if (estimatedJitterMs > 10) {
      bufferSize = 480; // ~30ms
      lookaheadMs = 60;
    }

    return { bufferSize, lookaheadMs };
  }

  public static getInstance(): AudioContextManager {
    if (!AudioContextManager.instance) {
      AudioContextManager.instance = new AudioContextManager();
    }
    return AudioContextManager.instance;
  }

  /**
   * Retrieves or initializes the shared high-priority AudioContext
   */
  public async getAudioContext(sampleRate: number = 24000): Promise<AudioContext> {
    if (typeof window === 'undefined') {
      throw new Error('AudioContext is only available in browser environments.');
    }

    if (!this.sharedContext || this.sharedContext.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      try {
        this.sharedContext = new AudioCtxClass({
          sampleRate,
          latencyHint: 'interactive',
        });
      } catch {
        this.sharedContext = new AudioCtxClass({ latencyHint: 'interactive' });
      }

      this.masterGainNode = this.sharedContext.createGain();
      this.masterGainNode.gain.setValueAtTime(1.0, this.sharedContext.currentTime);

      // Tuned compressor for brick-wall limiting protection to prevent digital clipping
      this.compressorNode = this.sharedContext.createDynamicsCompressor();
      this.compressorNode.threshold.setValueAtTime(-10, this.sharedContext.currentTime);
      this.compressorNode.knee.setValueAtTime(12, this.sharedContext.currentTime);
      this.compressorNode.ratio.setValueAtTime(12, this.sharedContext.currentTime); // Higher ratio for limiting
      this.compressorNode.attack.setValueAtTime(0.003, this.sharedContext.currentTime); // Faster attack
      this.compressorNode.release.setValueAtTime(0.25, this.sharedContext.currentTime);

      this.dynamicGainNode = this.sharedContext.createGain();
      this.dynamicGainNode.gain.setValueAtTime(1.0, this.sharedContext.currentTime);

      this.analyserNode = this.sharedContext.createAnalyser();
      this.analyserNode.fftSize = 256;

      this.dynamicGainNode.connect(this.compressorNode);
      this.compressorNode.connect(this.masterGainNode);
      this.masterGainNode.connect(this.sharedContext.destination);

      console.log(`[AudioContextManager] Shared AudioContext initialized at ${this.sharedContext.sampleRate}Hz with Precision Limiter & Dynamic Normalizer.`);
    }

    if (this.sharedContext.state === 'suspended') {
      try {
        await this.sharedContext.resume();
        console.log('[AudioContextManager] Resumed suspended AudioContext.');
      } catch (e) {
        console.warn('[AudioContextManager] Notice resuming AudioContext:', e);
      }
    }

    return this.sharedContext;
  }

  /**
   * Registers or requests priority for an audio stream.
   * If ALYA_SPEECH priority is acquired, automatically ducks background media.
   */
  public registerStreamPriority(id: string, name: string, priority: StreamPriority, node?: AudioNode): void {
    this.activeStreams.set(id, {
      id,
      name,
      priority,
      audioNode: node,
      startedAt: Date.now(),
    });

    console.log(`[AudioContextManager] Stream '${name}' (${id}) registered with priority ${priority}`);

    if (priority === StreamPriority.ALYA_SPEECH) {
      this.setAlyaSpeaking(true);
    }
  }

  /**
   * Unregisters an audio stream priority when playback completes
   */
  public unregisterStreamPriority(id: string): void {
    const stream = this.activeStreams.get(id);
    if (stream) {
      this.activeStreams.delete(id);
      console.log(`[AudioContextManager] Stream '${stream.name}' (${id}) unregistered.`);

      // Check if any ALYA_SPEECH streams remain active
      const hasSpeech = Array.from(this.activeStreams.values()).some(
        (s) => s.priority === StreamPriority.ALYA_SPEECH
      );
      if (!hasSpeech && this.isAlyaSpeakingState) {
        this.setAlyaSpeaking(false);
      }
    }
  }

  /**
   * Synchronizes Alya speaking state across audio context and local background media ducking
   */
  public setAlyaSpeaking(speaking: boolean): void {
    if (this.isAlyaSpeakingState === speaking) return;

    this.isAlyaSpeakingState = speaking;
    console.log(`[AudioContextManager] Alya speaking state changed -> ${speaking ? 'SPEAKING' : 'IDLE/LISTEN'}`);

    // Smoothly duck or restore master gain node for global audio/media ducking
    if (this.masterGainNode && this.sharedContext && this.sharedContext.state === 'running') {
      try {
        const now = this.sharedContext.currentTime;
        this.masterGainNode.gain.cancelScheduledValues(now);
        this.masterGainNode.gain.setValueAtTime(this.masterGainNode.gain.value, now);
        this.masterGainNode.gain.linearRampToValueAtTime(speaking ? 0.15 : 1.0, now + 0.05);
      } catch (e) {
        console.warn('[AudioContextManager] Master gain ramp warning:', e);
      }
    }

    // Duck or pause background music/media when Alya speaks, restore when finished
    try {
      browserAutomation.duckMedia(speaking);
    } catch (err) {
      console.warn('[AudioContextManager] duckMedia notification note:', err);
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:speech-state-changed', { detail: { speaking } }));
    }
  }

  public getMasterGainNode(): GainNode | null {
    return this.masterGainNode;
  }

  public getTTSOutputNode(): AudioNode {
    return this.dynamicGainNode || this.masterGainNode || this.sharedContext?.destination || ({} as any);
  }

  public processDynamicGain(audioData: Float32Array): void {
    if (!this.sharedContext || !this.dynamicGainNode) return;
    try {
      let sum = 0;
      const len = audioData.length;
      if (len === 0) return;
      
      // Calculate RMS Energy
      for (let i = 0; i < len; i++) {
        sum += audioData[i] * audioData[i];
      }
      const rms = Math.sqrt(sum / len);
      const db = rms > 0.0001 ? 20 * Math.log10(rms) : -60;

      // Adaptive Gain Logic:
      // We target -18dBFS for consistent conversational loudness.
      const targetDb = -18;
      let diff = targetDb - db;
      
      // Calculate multiplier based on distance from target
      let targetGain = Math.pow(10, diff / 20);
      
      // Clamp gain to safe bounds to avoid extreme noise floor boost or crushing
      targetGain = Math.max(0.4, Math.min(2.5, targetGain));

      const now = this.sharedContext.currentTime;
      
      // Asymmetric timing: faster attack for loud spikes, slower release for quiet parts
      // This prevents annoying "pumping" sound while keeping audio normalized.
      const timeConstant = db > targetDb ? 0.05 : 0.15;
      this.dynamicGainNode.gain.setTargetAtTime(targetGain, now, timeConstant);

      if (Math.random() < 0.01) {
        console.debug(`[AlyaAudio] RMS: ${db.toFixed(1)}dB, Gain: ${targetGain.toFixed(2)}, state: ${this.sharedContext.state}`);
      }
    } catch (e) {
      // ignore
    }
  }

  public isAlyaSpeaking(): boolean {
    return this.isAlyaSpeakingState;
  }

  /**
   * Clean incoming microphone audio with a dedicated BiquadFilterNode High-Pass Noise Suppression Filter at 100Hz.
   * 100Hz cutoff frequency strips low-frequency rumble, AC background hum, and desk vibration to optimize voice clarity for Speech-To-Text engines.
   */
  public createCleanMicrophoneStream(
    audioCtx: AudioContext,
    mediaStream: MediaStream,
    options: { highpassFreq?: number; lowpassFreq?: number } = {}
  ): {
    destinationStream: MediaStream;
    sourceNode: MediaStreamAudioSourceNode;
    highpassNode: BiquadFilterNode;
    lowpassNode: BiquadFilterNode;
  } {
    const highpassFreq = options.highpassFreq ?? 100; // Default 100Hz high-pass filter cutoff
    const lowpassFreq = options.lowpassFreq ?? 3400;

    const sourceNode = audioCtx.createMediaStreamSource(mediaStream);

    // BiquadFilterNode High-Pass Filter at 100Hz for stripping low-frequency rumble & background hum
    const highpassNode = audioCtx.createBiquadFilter();
    highpassNode.type = 'highpass';
    highpassNode.frequency.setValueAtTime(highpassFreq, audioCtx.currentTime);
    highpassNode.Q.setValueAtTime(0.707, audioCtx.currentTime);

    // Low-pass filter to suppress high-frequency hiss & electromagnetic static
    const lowpassNode = audioCtx.createBiquadFilter();
    lowpassNode.type = 'lowpass';
    lowpassNode.frequency.setValueAtTime(lowpassFreq, audioCtx.currentTime);
    lowpassNode.Q.setValueAtTime(0.707, audioCtx.currentTime);

    // Connect audio graph: source -> highpass -> lowpass -> destination
    const destinationNode = audioCtx.createMediaStreamDestination();
    sourceNode.connect(highpassNode);
    highpassNode.connect(lowpassNode);
    lowpassNode.connect(destinationNode);

    const streamId = mediaStream.id || `mic_${Date.now()}`;
    this.micFilterNodes.set(streamId, { highpassNode, lowpassNode });

    console.log(`[AudioContextManager] Created clean mic stream pipeline with 100Hz BiquadFilterNode highpass cutoff.`);

    return {
      destinationStream: destinationNode.stream,
      sourceNode,
      highpassNode,
      lowpassNode,
    };
  }

  /**
   * Attaches a dedicated 100Hz BiquadFilterNode high-pass filter directly to a source AudioNode in an existing audio graph
   */
  public attachMicrophoneHighPassFilter(
    audioCtx: AudioContext,
    sourceNode: AudioNode,
    cutoffFreq: number = 100
  ): { highpassNode: BiquadFilterNode; outputNode: AudioNode } {
    const highpassNode = audioCtx.createBiquadFilter();
    highpassNode.type = 'highpass';
    highpassNode.frequency.setValueAtTime(cutoffFreq, audioCtx.currentTime);
    highpassNode.Q.setValueAtTime(0.707, audioCtx.currentTime);

    sourceNode.connect(highpassNode);
    console.log(`[AudioContextManager] Attached BiquadFilterNode high-pass filter at ${cutoffFreq}Hz to mic stream node.`);

    return {
      highpassNode,
      outputNode: highpassNode,
    };
  }

  /**
   * Dynamically tunes high-pass filter cutoff on an active mic stream (e.g., when Alya starts speaking)
   */
  public adjustMicHighpassFilter(streamId: string, freqHz: number): void {
    const filters = this.micFilterNodes.get(streamId);
    if (filters && this.sharedContext) {
      filters.highpassNode.frequency.setValueAtTime(freqHz, this.sharedContext.currentTime);
      console.log(`[AudioContextManager] Adjusted high-pass filter cutoff for ${streamId} -> ${freqHz}Hz`);
    }
  }

  private setupLifecycleListeners(): void {
    if (typeof window === 'undefined') return;

    window.addEventListener('alya:audio-duck-request', (e: Event) => {
      const detail = (e as CustomEvent)?.detail;
      this.setAlyaSpeaking(Boolean(detail?.duck));
    });
  }
}

export const audioContextManager = AudioContextManager.getInstance();
