export class NotificationManager {
  private static registration: ServiceWorkerRegistration | null = null;

  static async init() {
    if (typeof window === 'undefined') return;

    if ('serviceWorker' in navigator && 'Notification' in window) {
      try {
        let reg = await navigator.serviceWorker.getRegistration();
        if (!reg) {
          try {
            reg = await navigator.serviceWorker.register('/sw.js');
          } catch (regErr) {
            // In dev mode with injectManifest, registration is handled by Vite plugin
          }
        }
        if (!reg && navigator.serviceWorker.ready) {
          reg = await navigator.serviceWorker.ready.catch(() => undefined);
        }
        this.registration = reg || null;

        if (Notification.permission === 'default') {
          // Request permission safely on user interaction if needed
          await Notification.requestPermission().catch(() => {});
        }
      } catch (err) {
        console.warn('NotificationManager initialization note:', err);
      }
    }
  }

  static async showNotification(title: string, body: string, data: any = {}) {
    if (!this.registration || Notification.permission !== 'granted') {
      await this.init();
    }

    if (this.registration && Notification.permission === 'granted') {
      // Send message to service worker to show notification
      // This ensures the service worker handles the showNotification call
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: 'SHOW_NOTIFICATION',
          payload: {
            title,
            body,
            data
          }
        });
      } else {
        // Fallback to direct call if controller is not available
        (this.registration as any).showNotification(title, {
          body,
          icon: '/icon.png',
          badge: '/badge.png',
          data,
          actions: [
            {
              action: 'reply',
              type: 'text',
              placeholder: 'यहाँ जवाब लिखें...',
              title: 'Reply'
            }
          ]
        });
      }
    }
  }

  static isBackground() {
    return document.visibilityState === 'hidden';
  }
}
