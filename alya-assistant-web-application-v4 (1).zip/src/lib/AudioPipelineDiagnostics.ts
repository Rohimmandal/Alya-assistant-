/**
 * src/lib/AudioPipelineDiagnostics.ts
 * 
 * Advanced diagnostic module for Alya Assistant audio pipeline.
 * Monitors AudioContext state, buffer latency, and tracks queue flushing events in real-time.
 */

export interface AudioDiagnosticMetrics {
  contextState: string;
  sampleRate: number;
  latencyMs: number;
  bufferSize: number;
  totalChunks: number;
  flushCount: number;
  lastFlushTime: number;
  lastSequence: number;
  serverLatencyMs: number;
  e2eLatencyMs: number;
  frameDrops: number;
  staleEvictionsCount: number;
  activeAudioNodesCount: number;
  coordinatorLockOwner: string;
  isNodesClean: boolean;
  lastChunkArrivalTimestamp: number;
  jitterMs: number;
  packetLossPercent: number;
  networkQuality: 'Excellent' | 'Good' | 'Fair' | 'Poor';
  jitterBufferDelayMs: number;
}

export type MetricsListener = (metrics: AudioDiagnosticMetrics) => void;

class AudioPipelineDiagnosticsImpl {
  private totalChunks: number = 0;
  private flushCount: number = 0;
  private lastFlushTime: number = 0;
  private lastSequence: number = 0;
  private frameDrops: number = 0;
  private currentLatencyMs: number = 0;
  private currentBufferSize: number = 0;
  private currentContextState: string = 'unknown';
  private currentSampleRate: number = 0;
  private currentServerLatencyMs: number = 0;
  private currentE2ELatencyMs: number = 0;
  private staleEvictionsCount: number = 0;
  private activeAudioNodesCount: number = 0;
  private coordinatorLockOwner: string = 'IDLE';
  private isNodesClean: boolean = true;
  private lastChunkArrivalTimestamp: number = 0;
  private currentJitterMs: number = 2.4;
  private currentPacketLossPercent: number = 0.0;
  private currentJitterBufferDelayMs: number = 150;
  
  private listeners: Set<MetricsListener> = new Set();

  /**
   * Tracks Coordinator Destination Lock transitions
   */
  public reportCoordinatorLock(streamType: string, streamId: string) {
    this.coordinatorLockOwner = streamType === 'IDLE' ? 'IDLE' : `${streamType}:${streamId.slice(0, 8)}`;
    this.notify();
  }

  /**
   * Tracks Stale Packet Evictions (>100ms delta)
   */
  public trackStaleEviction(deltaMs: number, totalCount: number) {
    this.staleEvictionsCount = totalCount;
    this.frameDrops++;
    this.notify();
  }

  /**
   * Tracks active AudioNodes in memory
   */
  public reportActiveNodes(count: number) {
    this.activeAudioNodesCount = count;
    this.isNodesClean = count === 0;
    this.notify();
  }

  /**
   * Tracks dangling node verification results
   */
  public reportDanglingVerification(nodeCount: number, isClean: boolean) {
    this.activeAudioNodesCount = nodeCount;
    this.isNodesClean = isClean;
    this.notify();
  }

  /**
   * Logs a hard reset / queue flushing event to the console with high-visibility formatting
   */
  public logFlushEvent(reason: string, sequence?: number) {
    this.flushCount++;
    this.lastFlushTime = Date.now();
    this.lastSequence = sequence || 0;
    const time = new Date().toISOString().split('T')[1].slice(0, 12);
    
    console.log(
      `%c[AlyaAudio][FLUSH][${time}]%c 🚨 HARD RESET: %c${reason} %c(Sequence: ${sequence || 'N/A'})`,
      'color: #f87171; font-weight: bold; background: #450a0a; padding: 2px 4px; border-radius: 4px;',
      'color: #fca5a5;',
      'color: #ffffff; font-weight: bold;',
      'color: #94a3b8;'
    );
    this.notify();
  }

  /**
   * Tracks real-time chunk arrival and provides periodic latency reports
   */
  public trackChunkArrival(latencyMs: number, queueSize: number, serverLatencyMs: number = 0, e2eLatencyMs: number = 0) {
    this.totalChunks++;
    this.currentLatencyMs = latencyMs;
    this.currentBufferSize = queueSize;
    this.currentServerLatencyMs = serverLatencyMs;
    this.currentE2ELatencyMs = e2eLatencyMs;
    this.lastChunkArrivalTimestamp = Date.now();

    if (this.totalChunks % 100 === 0) {
      const time = new Date().toISOString().split('T')[1].slice(0, 12);
      console.debug(
        `%c[AlyaAudio][STATS][${time}]%c Latency (Jitter/Srv/E2E): ${latencyMs}ms/${serverLatencyMs}ms/${e2eLatencyMs}ms | Buffered: ${queueSize} chunks`,
        'color: #6366f1; font-weight: bold;',
        'color: #94a3b8;'
      );
    }
    this.notify();
  }

  public trackFrameDrop() {
    this.frameDrops++;
    this.notify();
  }

  /**
   * Monitors and warns about non-running AudioContext states
   */
  public reportContextState(state: string, sampleRate: number) {
    this.currentContextState = state;
    this.currentSampleRate = sampleRate;
    const time = new Date().toISOString().split('T')[1].slice(0, 12);
    if (state !== 'running') {
      console.warn(`%c[AlyaAudio][WARN][${time}]%c AudioContext is %c${state.toUpperCase()}%c (Rate: ${sampleRate}Hz)`, 
        'color: #fbbf24; font-weight: bold;', 
        'color: inherit;', 
        'color: #fbbf24; font-weight: bold; text-decoration: underline;',
        'color: inherit;'
      );
    }
    this.notify();
  }

  public subscribe(listener: MetricsListener): () => void {
    this.listeners.add(listener);
    listener(this.getMetrics());
    return () => this.listeners.delete(listener);
  }

  private notify() {
    const metrics = this.getMetrics();
    this.listeners.forEach(l => l(metrics));
  }

  public trackJitterMetrics(jitterMs: number, delayMs: number, packetLossPercent: number = 0) {
    this.currentJitterMs = Math.round(jitterMs * 10) / 10;
    this.currentJitterBufferDelayMs = Math.round(delayMs);
    this.currentPacketLossPercent = packetLossPercent;
    this.notify();
  }

  public getMetrics(): AudioDiagnosticMetrics {
    const jitter = this.currentJitterMs;
    const loss = this.currentPacketLossPercent;
    
    let quality: 'Excellent' | 'Good' | 'Fair' | 'Poor' = 'Excellent';
    if (jitter > 60 || loss > 8) quality = 'Poor';
    else if (jitter > 30 || loss > 4) quality = 'Fair';
    else if (jitter > 15 || loss > 1) quality = 'Good';

    return {
      contextState: this.currentContextState,
      sampleRate: this.currentSampleRate,
      latencyMs: this.currentLatencyMs,
      bufferSize: this.currentBufferSize,
      totalChunks: this.totalChunks,
      flushCount: this.flushCount,
      lastFlushTime: this.lastFlushTime,
      lastSequence: this.lastSequence,
      serverLatencyMs: this.currentServerLatencyMs,
      e2eLatencyMs: this.currentE2ELatencyMs,
      frameDrops: this.frameDrops,
      staleEvictionsCount: this.staleEvictionsCount,
      activeAudioNodesCount: this.activeAudioNodesCount,
      coordinatorLockOwner: this.coordinatorLockOwner,
      isNodesClean: this.isNodesClean,
      lastChunkArrivalTimestamp: this.lastChunkArrivalTimestamp,
      jitterMs: this.currentJitterMs,
      packetLossPercent: this.currentPacketLossPercent,
      networkQuality: quality,
      jitterBufferDelayMs: this.currentJitterBufferDelayMs
    };
  }

  public getFlushCount(): number {
    return this.flushCount;
  }

  public getLastFlushTime(): number {
    return this.lastFlushTime;
  }
}

export const audioPipelineDiagnostics = new AudioPipelineDiagnosticsImpl();
