/**
 * src/lib/LiveSessionManager.ts
 * 
 * Authoritative Single Long-Lived Live Session Manager for Alya Assistant.
 * 
 * Mandates:
 * 1. Single Long-Lived Session: Maintains ONE continuous Live session across the application.
 *    Does NOT reconnect between turns, messages, interruptions, or component re-renders.
 * 2. Multi-Component Subscription: Allows AlyaLive, VoiceSession, and global headers to observe
 *    and interact with the SAME underlying connection without creating duplicate sessions or WebSockets.
 * 3. Verified Failure-Recovery Only: Reconnects ONLY when an actual network/transport failure occurs,
 *    never due to UI tab changes, state updates, or normal audio completion.
 * 4. Preserves Conversation Context: Retains context across healthy operation and transparently
 *    restores state if recovery is genuinely required.
 */

import { LiveSession, LiveSessionState, LiveSessionCallbacks } from './LiveSession';
import { AudioStreamer } from './AudioStreamer';
import { audioPlaybackManager } from './AudioPlaybackManager';
import { secureStorage } from './secureStorage';
import { locationService } from './locationService';
import { ConversationStore, DialogueTurn } from './ConversationStore';
import { SessionMemoryStore } from './SessionMemoryStore';
import { BrowserAutomationController } from './BrowserAutomationController';
import { userSettingsService } from './userSettingsService';

export interface LiveSessionSubscriber {
  id: string;
  onStatusChange?: (status: LiveSessionState) => void;
  onAudioChunk?: (base64Audio: string, sequence?: number, flushFirst?: boolean, serverTimestamp?: number) => void;
  onTranscript?: (text: string, role: 'user' | 'assistant', sequence: number, metadata?: any) => void;
  onInterrupted?: () => void;
  onToolCall?: (toolCall: any) => void;
  onAnalyserReady?: (analyser: AnalyserNode | null) => void;
  onError?: (error: string) => void;
}

export class LiveSessionManager {
  private static instance: LiveSessionManager | null = null;

  // Single Authoritative LiveSession & AudioStreamer
  private liveSession: LiveSession | null = null;
  private audioStreamer: AudioStreamer | null = null;
  private micAnalyser: AnalyserNode | null = null;

  // Current State
  private currentState: LiveSessionState = 'disconnected';
  private isMuted: boolean = false;
  private isPaused: boolean = false;
  private isSpeakerOn: boolean = false; // Default: Phone Call / Earpiece mode (40% volume level)

  // Subscribers
  private subscribers: Map<string, LiveSessionSubscriber> = new Map();

  // Active Connection Metadata
  private currentUserId: string = 'default_user';
  private currentConversationId: string = 'main';
  private currentLanguage: string = 'auto';

  private constructor() {
    this.initAudioStreamer();
    if (typeof window !== 'undefined') {
      window.addEventListener('alya:voice-changed', (e: any) => {
        const v = e.detail?.voiceName;
        if (v) this.setVoice(v);
      });
    }
  }

  public static getInstance(): LiveSessionManager {
    if (!LiveSessionManager.instance) {
      LiveSessionManager.instance = new LiveSessionManager();
    }
    return LiveSessionManager.instance;
  }

  private initAudioStreamer() {
    this.audioStreamer = new AudioStreamer((isPlaying) => {
      this.liveSession?.setAssistantSpeaking(isPlaying);
      if (this.currentState !== 'disconnected' && this.currentState !== 'connecting') {
        if (isPlaying) {
          this.notifyStatusChange('speaking');
        } else if (this.currentState === 'speaking') {
          this.notifyStatusChange('listening');
        }
      }
    });
    this.audioStreamer.setSpeakerMode(this.isSpeakerOn);
  }

  public getAudioStreamer(): AudioStreamer | null {
    return this.audioStreamer;
  }

  public getState(): LiveSessionState {
    return this.currentState;
  }

  public isSessionActive(): boolean {
    return (
      this.currentState === 'connecting' ||
      this.currentState === 'listening' ||
      this.currentState === 'thinking' ||
      this.currentState === 'speaking' ||
      this.currentState === 'reconnecting'
    );
  }

  public isMicrophoneMuted(): boolean {
    return this.isMuted;
  }

  public isSessionPaused(): boolean {
    return this.isPaused;
  }

  public isSpeakerActive(): boolean {
    return this.isSpeakerOn;
  }

  public getMicAnalyser(): AnalyserNode | null {
    return this.micAnalyser;
  }

  public getHighpassFreq(): number {
    return this.liveSession ? this.liveSession.getHighpassFreq() : 100;
  }

  public setHighpassFreq(freq: number): void {
    this.liveSession?.setHighpassFreq(freq);
  }

  /**
   * Subscribes a component to the single long-lived session.
   * Immediately delivers the current state to the new subscriber.
   */
  public subscribe(subscriber: LiveSessionSubscriber): () => void {
    this.subscribers.set(subscriber.id, subscriber);

    // Synchronously inform new subscriber of current state
    subscriber.onStatusChange?.(this.currentState);
    if (this.micAnalyser) {
      subscriber.onAnalyserReady?.(this.micAnalyser);
    }

    return () => {
      this.subscribers.delete(subscriber.id);
    };
  }

  /**
   * Starts or attaches to the single continuous Live session.
   * If a session is already alive or connecting, it preserves it without reconnecting.
   */
  public async startSession(options?: {
    userId?: string;
    apiKey?: string;
    language?: string;
    conversationId?: string;
    voiceName?: string;
  }): Promise<void> {
    console.log(`[LiveSessionManager] Start session requested. Current state: ${this.currentState}`);

    // If session is already healthy and active, DO NOT create a new session or reconnect!
    if (this.isSessionActive()) {
      console.log(`[LiveSessionManager] Session is already running in state '${this.currentState}'. Preserving single long-lived session.`);
      return;
    }

    this.isPaused = false;
    this.notifyStatusChange('connecting');

    try {
      // Ensure shared audio engine is ready
      if (this.audioStreamer) {
        try {
          await this.audioStreamer.initAudioContext();
        } catch (e) {
          console.warn('[LiveSessionManager] Audio engine init notice:', e);
        }
      }

      const userId = options?.userId || localStorage.getItem('alya_user_id') || 'default_user';
      const conversationId = options?.conversationId || localStorage.getItem('alya_active_conversation_id') || 'main';
      const latestKey = options?.apiKey || (await secureStorage.getSecureApiKey()) || '';
      const chosenLang = options?.language || localStorage.getItem('alya_preferred_lang') || 'auto';

      this.currentUserId = userId;
      this.currentConversationId = conversationId;
      this.currentLanguage = chosenLang;

      // Save memory snapshot before connecting
      await SessionMemoryStore.saveSessionMemory(userId, conversationId, ConversationStore.getInstance().getState());

      // Retrieve location context if permitted
      let loc = locationService.getLastKnownLocation();
      if (!loc) {
        try {
          const locRes = await locationService.getCurrentLocation(4000);
          if (locRes.success && locRes.context) {
            loc = locRes.context;
          }
        } catch {}
      }

      const locPayload = (loc && loc.latitude && loc.longitude) ? {
        lat: loc.latitude,
        lon: loc.longitude,
        city: loc.locality || undefined
      } : undefined;

      // Create Authoritative LiveSession if not instantiated
      if (!this.liveSession) {
        this.liveSession = new LiveSession({
          onAudioChunk: (base64, seq, flushFirst, serverTs) => {
            if (!this.isPaused) {
              this.audioStreamer?.playChunk(base64, seq, flushFirst, serverTs);
            }
            this.subscribers.forEach(sub => sub.onAudioChunk?.(base64, seq, flushFirst, serverTs));
          },
          onInterrupted: () => {
            console.log('[LiveSessionManager] Barge-in detected: Immediately halting assistant playback.');
            this.audioStreamer?.stop();
            audioPlaybackManager.cancelAllAudio('user_barge_in');
            if (this.currentState !== 'disconnected') {
              this.notifyStatusChange('listening');
            }
            this.subscribers.forEach(sub => sub.onInterrupted?.());
          },
          onToolCall: (toolCall) => {
            this.handleLiveToolCall(toolCall);
            this.subscribers.forEach(sub => sub.onToolCall?.(toolCall));
          },
          onTranscript: (text, role, sequence, metadata) => {
            this.handleLiveTranscript(text, role, sequence, metadata);
            this.subscribers.forEach(sub => sub.onTranscript?.(text, role, sequence, metadata));
          },
          onError: (err) => {
            console.warn('[LiveSessionManager] LiveSession notice:', err);
            this.subscribers.forEach(sub => sub.onError?.(err));
          },
          onStatusChange: (status) => {
            this.notifyStatusChange(status);
          },
          onAnalyserReady: (analyser) => {
            this.micAnalyser = analyser;
            this.subscribers.forEach(sub => sub.onAnalyserReady?.(analyser));
          }
        });
      }

      const chosenVoice = options?.voiceName || localStorage.getItem('alya_voice_name') || userSettingsService.getPreferences().voiceName || 'Aoede';

      // Establish persistent WebSocket connection
      this.liveSession.connect(userId, latestKey, chosenLang, locPayload, conversationId, chosenVoice);
    } catch (err: any) {
      console.error('[LiveSessionManager] Failed to start live session:', err);
      this.notifyStatusChange('disconnected');
      this.subscribers.forEach(sub => sub.onError?.(err?.message || 'Failed to start live session'));
    }
  }

  public setVoice(voiceName: string): void {
    if (voiceName) {
      this.liveSession?.setVoice(voiceName);
    }
  }

  /**
   * Forcibly stops the single Live session. ONLY called on explicit user action ("End Call").
   */
  public stopSession(): void {
    console.log('[LiveSessionManager] Explicit user stop requested.');
    this.liveSession?.disconnect();
    this.audioStreamer?.stop();
    audioPlaybackManager.cancelAllAudio('live_session_stopped');
    this.micAnalyser = null;
    this.notifyStatusChange('disconnected');
    this.isPaused = false;
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    this.liveSession?.setMute(this.isMuted);
    return this.isMuted;
  }

  public togglePause(): boolean {
    if (this.isPaused) {
      this.isPaused = false;
      this.liveSession?.resume();
    } else {
      this.isPaused = true;
      this.audioStreamer?.stop();
      this.liveSession?.pause();
    }
    return this.isPaused;
  }

  public setSpeaker(on: boolean): void {
    this.isSpeakerOn = on;
    if (this.audioStreamer) {
      // Speaker ON -> 100% volume level (1.0); Speaker OFF -> 40% volume level (0.4) earpiece mode
      this.audioStreamer.setSpeakerMode(on);
    }
  }

  public updateLocation(loc: { lat?: number; lon?: number; city?: string }): void {
    this.liveSession?.updateLocation(loc);
  }

  public forceReconnect(): void {
    if (this.liveSession) {
      this.liveSession.forceReconnect();
    } else {
      this.startSession({
        userId: this.currentUserId,
        conversationId: this.currentConversationId,
        language: this.currentLanguage
      });
    }
  }

  private notifyStatusChange(status: LiveSessionState) {
    this.currentState = status;
    this.subscribers.forEach(sub => sub.onStatusChange?.(status));
  }

  private handleLiveToolCall(toolCall: any) {
    if (!toolCall.functionCalls) return;

    toolCall.functionCalls.forEach(async (call: any) => {
      try {
        const browser = BrowserAutomationController.getInstance();
        if (call.name === 'open_url' || call.name === 'openWebsite' || call.name === 'navigate_browser') {
          const url = call.args?.url;
          if (url) browser.openUrl(url);
        } else if (call.name === 'openYouTube') {
          browser.openUrl('https://www.youtube.com');
        } else if (call.name === 'youtube_search' || call.name === 'searchYouTube' || call.name === 'search_youtube') {
          const query = call.args?.query;
          if (query) browser.openUrl(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`);
        } else if (
          call.name === 'play_youtube_video' || 
          call.name === 'playYouTubeVideo' || 
          call.name === 'play_media' ||
          call.name === 'youtube_media_playback' ||
          call.name === 'youtube_control'
        ) {
          const videoId = (call.args?.videoId || call.args?.url || '').trim();
          const query = (call.args?.query || call.args?.video_title_or_index || call.args?.title || call.args?.target || videoId || '').trim();
          const action = (call.args?.action || 'SEARCH_AND_PLAY').toUpperCase();
          if (action === 'PAUSE' || action === 'RESUME' || action === 'STOP' || action === 'NEXT' || action === 'PREV') {
            browser.youtubeControl(action, query);
          } else {
            browser.playYoutubeVideo(videoId || query, query, true);
          }
        } else if (call.name === 'pause_media' || call.name === 'control_youtube_player') {
          const action = (call.args?.action || 'PAUSE').toUpperCase();
          browser.youtubeControl(action);
        } else if (call.name === 'searchWeb') {
          const query = call.args?.query;
          if (query) browser.openUrl(`https://www.google.com/search?q=${encodeURIComponent(query)}`);
        } else if (call.name === 'click_element' && call.args?.selector_or_text) {
          browser.clickElement(call.args.selector_or_text);
        } else if (call.name === 'browserAutomation' && call.args?.command) {
          browser.execute({
            action: call.args.command.toLowerCase(),
            url: call.args.url,
            target: call.args.target,
            text: call.args.text,
            scrollDirection: call.args.scrollDirection,
            media: call.args.mediaCommand ? {
              command: call.args.mediaCommand,
              seconds: call.args.mediaParams?.seconds,
              volume: call.args.mediaParams?.volume,
              rate: call.args.mediaParams?.rate
            } : undefined
          });
        }
      } catch (e) {
        console.warn('[LiveSessionManager] Tool execution error:', e);
      }

      ConversationStore.getInstance().addTurn({
        role: 'assistant',
        content: `[Executed ${call.name}]`,
        mode: 'voice',
        action: { command: call.name, params: call.args }
      });
    });
  }

  private handleLiveTranscript(text: string, role: 'user' | 'assistant', sequence: number, metadata?: any) {
    if (!text.trim() || metadata?.isFiller) return;

    const msgId = metadata?.id || ConversationStore.generateMessageId(role === 'user' ? 'msg_user' : 'msg_ast');
    const now = Date.now();
    const nowIso = new Date(now).toISOString();

    ConversationStore.getInstance().updateState((prev) => {
      const newSeq = prev.sequenceCounter + 1;
      const turnEntry: DialogueTurn = {
        id: msgId,
        role,
        content: text,
        mode: 'voice',
        timestamp: now,
        isoTimestamp: nowIso,
        sessionId: prev.conversationId,
        sequence: newSeq,
        status: 'completed'
      };

      const lastTurn = prev.history[prev.history.length - 1];
      let updatedHistory = [...prev.history];

      if (lastTurn && lastTurn.role === role && lastTurn.mode === 'voice' && (now - lastTurn.timestamp < 6000)) {
        updatedHistory[updatedHistory.length - 1] = {
          ...lastTurn,
          content: lastTurn.content.includes(text) ? lastTurn.content : `${lastTurn.content} ${text}`.trim()
        };
      } else {
        updatedHistory.push(turnEntry);
        if (updatedHistory.length > 50) {
          updatedHistory = updatedHistory.slice(-50);
        }
      }

      return {
        ...prev,
        sequenceCounter: newSeq,
        history: updatedHistory,
        lastMode: 'voice'
      };
    });
  }
}

export const liveSessionManager = LiveSessionManager.getInstance();
