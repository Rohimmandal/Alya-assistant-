/**
 * src/lib/AudioPlaybackManager.ts
 * 
 * Centralized AudioPlaybackManager & AudioContext Singleton Lock for Alya Assistant.
 * 
 * Architectural Guarantees:
 * 1. Singleton AudioContext: Only ONE shared AudioContext is created and managed across all components.
 * 2. Strict Mutual Exclusion Lock: Only ONE component or audio source can hold the speaker output lock at a time.
 * 3. Immediate Cancellation: When a new response starts or a new lock is requested, ALL existing audio sources
 *    (HTMLAudioElement, Web Audio BufferSource nodes, speechUtterance, AudioWorklet ring buffers)
 *    are immediately and synchronously cancelled and flushed.
 * 4. Zero Overlapping Speech: Prevents Chat TTS, Live Audio, Voice Assistant popups, and sound effects
 *    from ever playing simultaneously.
 */

import { AudioMutex } from './AudioMutex';
import { audioContextManager, StreamPriority } from './AudioContextManager';

export type AudioSourceType = 'LIVE_AUDIO' | 'TTS_CHAT' | 'VOICE_ASSISTANT' | 'SOUND_EFFECT' | 'SYSTEM';

export interface AudioLockHolder {
  sourceId: string;
  sourceType: AudioSourceType;
  priority: number;
  acquiredAt: number;
}

export type CancelAudioHandler = (reason?: string) => void;

export class AudioPlaybackManager {
  private static instance: AudioPlaybackManager | null = null;

  // Global Singleton AudioContext
  private masterAudioContext: AudioContext | null = null;
  private masterGainNode: GainNode | null = null;

  // Active Lock State
  private currentLockHolder: AudioLockHolder | null = null;
  private isAcquiringLock = false;

  // Registered Active Web Audio Sources & Cancel Handlers
  private activeBufferSources: Set<AudioBufferSourceNode> = new Set();
  private cancelHandlers: Map<string, CancelAudioHandler> = new Map();

  // Priorities: Higher number can preempt lower number
  private readonly PRIORITY_MAP: Record<AudioSourceType, number> = {
    LIVE_AUDIO: 100,
    VOICE_ASSISTANT: 80,
    TTS_CHAT: 50,
    SOUND_EFFECT: 30,
    SYSTEM: 10
  };

  private constructor() {
    this.setupWindowListeners();
  }

  public static getInstance(): AudioPlaybackManager {
    if (!AudioPlaybackManager.instance) {
      AudioPlaybackManager.instance = new AudioPlaybackManager();
    }
    return AudioPlaybackManager.instance;
  }

  /**
   * Initializes or retrieves the global singleton AudioContext.
   * Guarantees all components share the same audio hardware destination.
   */
  public async getSharedAudioContext(sampleRate: number = 24000): Promise<AudioContext> {
    if (typeof window === 'undefined') {
      throw new Error('AudioContext is only available in browser environments.');
    }

    if (!this.masterAudioContext || this.masterAudioContext.state === 'closed') {
      const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
      this.masterAudioContext = new AudioCtxClass({
        sampleRate,
        latencyHint: 'interactive'
      });

      this.masterGainNode = this.masterAudioContext.createGain();
      this.masterGainNode.gain.setValueAtTime(1.0, this.masterAudioContext.currentTime);
      this.masterGainNode.connect(this.masterAudioContext.destination);

      console.log(`[AudioPlaybackManager] Initialized master singleton AudioContext at ${sampleRate}Hz.`);
    }

    if (this.masterAudioContext.state === 'suspended') {
      try {
        await this.masterAudioContext.resume();
        console.log('[AudioPlaybackManager] Resumed suspended master AudioContext.');
      } catch (err) {
        console.warn('[AudioPlaybackManager] Notice resuming AudioContext:', err);
      }
    }

    return this.masterAudioContext;
  }

  /**
   * Returns the master gain node connecting to audio destination
   */
  public getMasterGain(): GainNode | null {
    return this.masterGainNode;
  }

  /**
   * Immediately cancels and stops ALL audio sources across the entire application.
   * Used when a new user query begins, an AI response starts, or barge-in is triggered.
   */
  public cancelAllAudio(reason: string = 'new_response_started', exceptSourceId?: string): void {
    console.log(`[AudioPlaybackManager] ⚡ Cancelling ALL audio sources immediately. Reason: ${reason}`);

    // 1. Release active lock if not excepted
    if (!exceptSourceId || this.currentLockHolder?.sourceId !== exceptSourceId) {
      if (this.currentLockHolder?.sourceId) {
        audioContextManager.unregisterStreamPriority(this.currentLockHolder.sourceId);
      }
      this.currentLockHolder = null;
      audioContextManager.setAlyaSpeaking(false);
    }

    // 2. Forcibly stop and reset singleton HTMLAudioElement
    try {
      AudioMutex.resetAudioElement();
    } catch (e) {
      console.warn('[AudioPlaybackManager] AudioMutex reset error:', e);
    }

    // 3. Forcibly stop all registered Web Audio buffer sources
    this.activeBufferSources.forEach((source) => {
      try {
        source.stop();
        source.disconnect();
      } catch {}
    });
    this.activeBufferSources.clear();

    // 4. Cancel Web Speech API synthesis if in-flight
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }

    // 5. Invoke all registered cancel handlers (e.g. AudioStreamer, femaleVoiceSynthesizer)
    this.cancelHandlers.forEach((handler, id) => {
      if (id !== exceptSourceId) {
        try {
          handler(reason);
        } catch (err) {
          console.warn(`[AudioPlaybackManager] Cancel handler error for ${id}:`, err);
        }
      }
    });

    // 6. Dispatch global cancellation events for UI state sync
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:audio-cancel-all', {
        detail: { reason, exceptSourceId }
      }));
      window.dispatchEvent(new CustomEvent('alya:audio-mutex-stop', {
        detail: { excludeSessionId: exceptSourceId }
      }));
      window.dispatchEvent(new CustomEvent('alya:speech-ended'));
    }
  }

  /**
   * Acquires the singleton audio lock for a component.
   * If another source is active, it is immediately cancelled before granting the lock.
   */
  public async acquireLock(
    sourceId: string, 
    sourceType: AudioSourceType = 'TTS_CHAT'
  ): Promise<boolean> {
    if (this.isAcquiringLock) {
      this.cancelAllAudio('lock_contention');
      await new Promise(r => setTimeout(r, 10));
    }

    this.isAcquiringLock = true;

    try {
      const priority = this.PRIORITY_MAP[sourceType] ?? 50;

      // If another source currently holds the lock, cancel it immediately
      if (this.currentLockHolder && this.currentLockHolder.sourceId !== sourceId) {
        console.log(`[AudioPlaybackManager] Preempting previous audio holder '${this.currentLockHolder.sourceId}' for new source '${sourceId}' (${sourceType})`);
        this.cancelAllAudio('preempted_by_new_source', sourceId);
        // Brief 12ms tick to allow hardware audio buffers to clear
        await new Promise(r => setTimeout(r, 12));
      }

      this.currentLockHolder = {
        sourceId,
        sourceType,
        priority,
        acquiredAt: Date.now()
      };

      // Also sync with AudioMutex and AudioContextManager for priority ducking
      AudioMutex.acquireLock(sourceId);
      audioContextManager.registerStreamPriority(
        sourceId,
        sourceId,
        sourceType === 'LIVE_AUDIO' || sourceType === 'TTS_CHAT' || sourceType === 'VOICE_ASSISTANT'
          ? StreamPriority.ALYA_SPEECH
          : StreamPriority.SYSTEM_NOTIFICATION
      );

      console.log(`[AudioPlaybackManager] Audio lock granted to '${sourceId}' (${sourceType})`);
      return true;
    } finally {
      this.isAcquiringLock = false;
    }
  }

  /**
   * Releases the audio lock if held by sourceId
   */
  public releaseLock(sourceId: string): void {
    if (this.currentLockHolder?.sourceId === sourceId) {
      console.log(`[AudioPlaybackManager] Audio lock released by '${sourceId}'`);
      audioContextManager.unregisterStreamPriority(sourceId);
      this.currentLockHolder = null;
      AudioMutex.releaseLock(sourceId);
    }
  }

  /**
   * Checks if an audio lock is currently held
   */
  public isLocked(): boolean {
    return this.currentLockHolder !== null;
  }

  /**
   * Returns current lock holder info
   */
  public getCurrentLock(): AudioLockHolder | null {
    return this.currentLockHolder;
  }

  /**
   * Registers an active AudioBufferSourceNode to be tracked and cancelled if a new response starts
   */
  public registerBufferSource(source: AudioBufferSourceNode): () => void {
    this.activeBufferSources.add(source);
    const cleanup = () => {
      this.activeBufferSources.delete(source);
    };
    source.addEventListener('ended', cleanup, { once: true });
    return cleanup;
  }

  /**
   * Registers a cancel callback that will be called whenever cancelAllAudio is invoked
   */
  public registerCancelHandler(id: string, handler: CancelAudioHandler): () => void {
    this.cancelHandlers.set(id, handler);
    return () => {
      this.cancelHandlers.delete(id);
    };
  }

  private setupWindowListeners(): void {
    if (typeof window === 'undefined') return;

    // Listen for custom stop events
    window.addEventListener('alya:audio-stop-requested', (e: Event) => {
      const detail = (e as CustomEvent)?.detail;
      this.cancelAllAudio(detail?.reason || 'stop_requested', detail?.exceptSourceId);
    });

    // When tab becomes hidden, pause non-critical media while preserving live voice
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'hidden') {
        if (this.currentLockHolder?.sourceType !== 'LIVE_AUDIO') {
          // Pause transient TTS playback on backgrounding to avoid surprise sound
          this.cancelAllAudio('tab_hidden');
        }
      }
    });
  }
}

export const audioPlaybackManager = AudioPlaybackManager.getInstance();
