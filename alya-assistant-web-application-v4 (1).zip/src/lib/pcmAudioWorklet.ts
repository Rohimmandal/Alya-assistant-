/**
 * Helper utility to initialize and attach AudioWorkletProcessors for both
 * 16kHz PCM microphone capture and lock-free 24kHz AudioWorklet Ring Buffer streaming playback
 * with explicit text-to-audio sync markers.
 * Runs completely off the main UI thread with top audio thread priority.
 */

export interface WorkletStreamOptions {
  audioCtx: AudioContext;
  sourceNode: MediaStreamAudioSourceNode;
  onAudioPCM16: (pcmBuffer: Uint8Array) => void;
  isMuted?: () => boolean;
}

export interface TTSSyncMarker {
  id: string; // e.g. messageId or session id
  markerId: string;
  charIndex: number;
  totalChars: number;
  textSnippet?: string;
  sampleOffset?: number;
  timestamp?: number;
}

export async function attachPCMAudioWorklet(options: WorkletStreamOptions): Promise<AudioWorkletNode> {
  const { audioCtx, sourceNode, onAudioPCM16, isMuted } = options;

  const inlineWorkletCode = `
    class PCM20msWorkletProcessor extends AudioWorkletProcessor {
      constructor() {
        super();
        this.targetSampleRate = 16000;
        this.bufferSize = 320; // Exact 20ms frame at 16000Hz (16000 * 0.020 = 320 samples)
        this.buffer = new Int16Array(this.bufferSize);
        this.bufferIndex = 0;
        this.lastSample = 0;
        this.phase = 0;
        this.x1 = 0;
        this.y1 = 0;
      }

      process(inputs, outputs, parameters) {
        const input = inputs[0];
        if (!input || input.length === 0) return true;
        const channelData = input[0];
        if (!channelData || channelData.length === 0) return true;

        // RMS Noise Gate (Threshold 0.02)
        let sumSquares = 0;
        for (let i = 0; i < channelData.length; i++) sumSquares += channelData[i] * channelData[i];
        const rms = Math.sqrt(sumSquares / channelData.length);
        if (rms < 0.02) return true;

        const inputRate = sampleRate; // Hardware context sample rate
        const ratio = inputRate / this.targetSampleRate;
        const R = Math.max(0.95, 1.0 - (2.0 * Math.PI * 100.0 / inputRate)); // 100Hz high-pass DC blocker

        let inIdx = this.phase;
        const len = channelData.length;

        while (inIdx < len) {
          const idx = Math.floor(inIdx);
          const frac = inIdx - idx;
          const s0 = idx === 0 ? this.lastSample : channelData[idx - 1];
          const s1 = channelData[idx];

          // Phase-accurate linear interpolation
          const raw = s0 + frac * (s1 - s0);
          
          // 100Hz High-Pass Filter
          const filtered = raw - this.x1 + R * this.y1;
          this.x1 = raw;
          this.y1 = filtered;

          // Clamped Int16 Little-Endian conversion with pristine audio fidelity
          const clamped = Math.max(-1.0, Math.min(1.0, filtered));
          const pcm16 = clamped < 0 ? Math.floor(clamped * 0x8000) : Math.floor(clamped * 0x7FFF);
          this.buffer[this.bufferIndex++] = pcm16;

          if (this.bufferIndex >= this.bufferSize) {
            const copy = new Int16Array(this.buffer);
            this.port.postMessage(copy.buffer, [copy.buffer]);
            this.bufferIndex = 0;
          }

          inIdx += ratio;
        }

        this.phase = inIdx - len;
        this.lastSample = channelData[len - 1] || 0;
        return true;
      }
    }

    registerProcessor('pcm-worklet-processor', PCM20msWorkletProcessor);
  `;

  if (!audioCtx.audioWorklet) {
    throw new Error('AudioWorklet is not supported in this browser environment.');
  }

  try {
    await audioCtx.audioWorklet.addModule('/pcm-processor.js');
  } catch {
    const blob = new Blob([inlineWorkletCode], { type: 'application/javascript' });
    const workletUrl = URL.createObjectURL(blob);
    await audioCtx.audioWorklet.addModule(workletUrl);
    URL.revokeObjectURL(workletUrl);
  }

  const workletNode = new AudioWorkletNode(audioCtx, 'pcm-worklet-processor');

  workletNode.port.onmessage = (event: MessageEvent<ArrayBuffer>) => {
    if (isMuted && isMuted()) return;
    const pcmBuffer = new Uint8Array(event.data);
    onAudioPCM16(pcmBuffer);
  };

  sourceNode.connect(workletNode);
  
  const silentGain = audioCtx.createGain();
  silentGain.gain.setValueAtTime(0, audioCtx.currentTime);
  workletNode.connect(silentGain);
  silentGain.connect(audioCtx.destination);

  return workletNode;
}

/**
 * Attaches a low-latency AudioWorklet Ring Buffer streaming playback node
 * directly to the high-priority audio processing thread with explicit sync markers.
 */
export async function attachPlaybackRingBufferWorklet(
  audioCtx: AudioContext,
  onSyncMarkerConsumed?: (marker: TTSSyncMarker) => void,
  onPlaybackStateChange?: (isPlaying: boolean) => void
): Promise<AudioWorkletNode> {
  const inlinePlaybackWorkletCode = `
    class RingBufferPlaybackProcessor extends AudioWorkletProcessor {
      constructor() {
        super();
        this.capacity = 192000; // ~8 seconds at 24kHz
        this.ringBuffer = new Float32Array(this.capacity);
        this.writeIndex = 0;
        this.readIndex = 0;
        this.availableSamples = 0;
        this.totalSamplesProcessed = 0;
        this.markerQueue = [];

        // Linearization & Jitter cushion
        this.isPrebuffering = true;
        this.minPrebufferSamples = 1920; // ~80ms cushion at 24kHz to eliminate voice stuttering
        this.drainPending = false;
        this.isPlayingState = false;

        this.port.onmessage = (event) => {
          const data = event.data;
          if (!data) return;

          if (data.type === 'CLEAR' || data.type === 'RESET') {
            this.writeIndex = 0;
            this.readIndex = 0;
            this.availableSamples = 0;
            this.isPrebuffering = true;
            this.drainPending = false;
            if (this.ringBuffer && this.ringBuffer.length === this.capacity) {
              this.ringBuffer.fill(0);
            } else {
              this.ringBuffer = new Float32Array(this.capacity);
            }
            this.markerQueue = [];
            if (this.isPlayingState) {
              this.isPlayingState = false;
              this.port.postMessage({ type: 'PLAYBACK_STATE', isPlaying: false });
            }
            return;
          }

          if (data.type === 'FLUSH_TURN' || data.type === 'DRAIN') {
            this.drainPending = true;
            this.isPrebuffering = false;
            return;
          }

          if (data.type === 'DESTROY' || data.type === 'DEALLOCATE') {
            this.writeIndex = 0;
            this.readIndex = 0;
            this.availableSamples = 0;
            this.isPrebuffering = true;
            this.drainPending = false;
            this.ringBuffer = new Float32Array(0);
            this.markerQueue = [];
            if (this.isPlayingState) {
              this.isPlayingState = false;
              this.port.postMessage({ type: 'PLAYBACK_STATE', isPlaying: false });
            }
            return;
          }

          if (data.type === 'WRITE' && data.samples) {
            if (!this.ringBuffer || this.ringBuffer.length !== this.capacity) {
              this.ringBuffer = new Float32Array(this.capacity);
            }
            const samples = new Float32Array(data.samples);
            const len = samples.length;
            const toWrite = Math.min(len, this.capacity);
            const sourceOffset = len - toWrite;

            const startSamplePos = this.totalSamplesProcessed + this.availableSamples;

            if (data.markers && Array.isArray(data.markers)) {
              for (let i = 0; i < data.markers.length; i++) {
                const m = data.markers[i];
                this.markerQueue.push({
                  triggerSamplePos: startSamplePos + (m.sampleOffset || 0),
                  marker: m
                });
              }
            } else if (data.marker) {
              this.markerQueue.push({
                triggerSamplePos: startSamplePos + (data.marker.sampleOffset || 0),
                marker: data.marker
              });
            }

            for (let i = 0; i < toWrite; i++) {
              this.ringBuffer[this.writeIndex] = samples[sourceOffset + i];
              this.writeIndex = (this.writeIndex + 1) % this.capacity;
            }
            this.availableSamples = Math.min(this.capacity, this.availableSamples + toWrite);

            // Buffer cushion met -> enable contiguous linear playback
            if (this.isPrebuffering && (this.availableSamples >= this.minPrebufferSamples || this.drainPending)) {
              this.isPrebuffering = false;
            }
          }
        };
      }

      process(inputs, outputs, parameters) {
        const output = outputs[0];
        if (!output || output.length === 0) return true;
        const channel = output[0];
        if (!channel) return true;

        const frameCount = channel.length;
        let samplesRead = 0;

        // Prebuffering jitter cushion: output silence until continuous sequence is ready
        if (this.isPrebuffering && !this.drainPending) {
          for (let i = 0; i < frameCount; i++) {
            channel[i] = 0;
          }
          return true;
        }

        if (this.availableSamples >= frameCount) {
          for (let i = 0; i < frameCount; i++) {
            channel[i] = this.ringBuffer[this.readIndex];
            this.readIndex = (this.readIndex + 1) % this.capacity;
          }
          samplesRead = frameCount;
          this.availableSamples -= frameCount;

          if (!this.isPlayingState) {
            this.isPlayingState = true;
            this.port.postMessage({ type: 'PLAYBACK_STATE', isPlaying: true });
          }
        } else if (this.availableSamples > 0) {
          // Play remaining samples with subtle smoothing
          const avail = this.availableSamples;
          for (let i = 0; i < avail; i++) {
            channel[i] = this.ringBuffer[this.readIndex];
            this.readIndex = (this.readIndex + 1) % this.capacity;
          }
          for (let i = avail; i < frameCount; i++) {
            channel[i] = 0;
          }
          samplesRead = avail;
          this.availableSamples = 0;

          if (this.drainPending) {
            this.drainPending = false;
            this.isPrebuffering = true;
            if (this.isPlayingState) {
              this.isPlayingState = false;
              this.port.postMessage({ type: 'PLAYBACK_STATE', isPlaying: false });
            }
          } else {
            this.isPrebuffering = true;
            this.port.postMessage({ type: 'BUFFER_UNDERRUN' });
          }
        } else {
          for (let i = 0; i < frameCount; i++) {
            channel[i] = 0;
          }
          samplesRead = 0;

          if (this.isPlayingState && !this.isPrebuffering) {
            this.isPlayingState = false;
            this.isPrebuffering = true;
            this.port.postMessage({ type: 'PLAYBACK_STATE', isPlaying: false });
          }
        }

        if (samplesRead > 0) {
          const nextSamplesProcessed = this.totalSamplesProcessed + samplesRead;

          while (this.markerQueue.length > 0 && this.markerQueue[0].triggerSamplePos <= nextSamplesProcessed) {
            const item = this.markerQueue.shift();
            this.port.postMessage({
              type: 'SYNC_MARKER_CONSUMED',
              marker: item.marker,
              samplePos: nextSamplesProcessed
            });
          }

          this.totalSamplesProcessed = nextSamplesProcessed;
        }

        return true;
      }
    }

    registerProcessor('ring-buffer-playback-processor', RingBufferPlaybackProcessor);
  `;

  if (!audioCtx.audioWorklet) {
    throw new Error('AudioWorklet is not supported in this browser environment.');
  }

  const blob = new Blob([inlinePlaybackWorkletCode], { type: 'application/javascript' });
  const workletUrl = URL.createObjectURL(blob);
  await audioCtx.audioWorklet.addModule(workletUrl);
  URL.revokeObjectURL(workletUrl);

  const workletNode = new AudioWorkletNode(audioCtx, 'ring-buffer-playback-processor');

  workletNode.port.onmessage = (e: MessageEvent) => {
    if (e.data) {
      if (e.data.type === 'SYNC_MARKER_CONSUMED' && e.data.marker && onSyncMarkerConsumed) {
        onSyncMarkerConsumed(e.data.marker);
      } else if (e.data.type === 'PLAYBACK_STATE' && onPlaybackStateChange) {
        onPlaybackStateChange(Boolean(e.data.isPlaying));
      }
    }
  };

  return workletNode;
}
