/**
 * LiveKitDiagnosticService.ts
 *
 * Comprehensive log-based diagnostic service for LiveKit & Gemini Live WebSocket connections.
 * Features:
 * - Structured log capture with categories, levels, and metadata
 * - High-precision connection state machine tracking
 * - Real-time network latency, ping/pong, and packet throughput metrics
 * - Robust 10-second connecting timeout monitor with automatic state reset & cleanup
 * - Explicit lifecycle cleanup tracking to eliminate WebSocket memory leaks
 * - Event bus subscription and JSON export for live telemetry inspection
 */

export type DiagnosticLogLevel = 'debug' | 'info' | 'warn' | 'error' | 'metric' | 'state_change' | 'cleanup';

export type DiagnosticCategory =
  | 'lifecycle'
  | 'network'
  | 'timeout'
  | 'cleanup'
  | 'heartbeat'
  | 'audio'
  | 'security'
  | 'webrtc';

export interface DiagnosticLogEntry {
  id: string;
  timestamp: number;
  isoTime: string;
  level: DiagnosticLogLevel;
  category: DiagnosticCategory;
  message: string;
  socketId?: string;
  data?: Record<string, any>;
}

export type LiveKitConnectionState =
  | 'disconnected'
  | 'connecting'
  | 'connected'
  | 'reconnecting'
  | 'timeout'
  | 'failed';

export interface DiagnosticMetrics {
  connectionState: LiveKitConnectionState;
  previousState: LiveKitConnectionState;
  connectingStartTime: number | null;
  connectingDurationMs: number;
  totalAttempts: number;
  successCount: number;
  failureCount: number;
  timeoutCount: number;
  cleanupsPerformed: number;
  activeSocketId: string | null;
  activeSocketsCount: number;
  lastPingTime: number | null;
  lastPongTime: number | null;
  lastLatencyMs: number | null;
  audioPacketsSent: number;
  audioPacketsReceived: number;
  bytesSent: number;
  bytesReceived: number;
  lastError: string | null;
  lastErrorTime: number | null;
}

export type DiagnosticListener = (logs: DiagnosticLogEntry[], metrics: DiagnosticMetrics) => void;

export class LiveKitDiagnosticService {
  private static instance: LiveKitDiagnosticService | null = null;
  private logs: DiagnosticLogEntry[] = [];
  private maxLogs: number = 400;
  private listeners: Set<DiagnosticListener> = new Set();
  
  private metrics: DiagnosticMetrics = {
    connectionState: 'disconnected',
    previousState: 'disconnected',
    connectingStartTime: null,
    connectingDurationMs: 0,
    totalAttempts: 0,
    successCount: 0,
    failureCount: 0,
    timeoutCount: 0,
    cleanupsPerformed: 0,
    activeSocketId: null,
    activeSocketsCount: 0,
    lastPingTime: null,
    lastPongTime: null,
    lastLatencyMs: null,
    audioPacketsSent: 0,
    audioPacketsReceived: 0,
    bytesSent: 0,
    bytesReceived: 0,
    lastError: null,
    lastErrorTime: null,
  };

  private constructor() {
    this.log('info', 'lifecycle', 'LiveKitDiagnosticService initialized.');
  }

  public static getInstance(): LiveKitDiagnosticService {
    if (!LiveKitDiagnosticService.instance) {
      LiveKitDiagnosticService.instance = new LiveKitDiagnosticService();
    }
    return LiveKitDiagnosticService.instance;
  }

  /**
   * Records a structured diagnostic log
   */
  public log(
    level: DiagnosticLogLevel,
    category: DiagnosticCategory,
    message: string,
    data?: Record<string, any>,
    socketId?: string
  ): DiagnosticLogEntry {
    const entry: DiagnosticLogEntry = {
      id: Math.random().toString(36).substring(2, 10),
      timestamp: Date.now(),
      isoTime: new Date().toISOString(),
      level,
      category,
      message,
      socketId: socketId || this.metrics.activeSocketId || undefined,
      data
    };

    this.logs.push(entry);
    if (this.logs.length > this.maxLogs) {
      this.logs.shift(); // Evict oldest log to maintain circular ring
    }

    // Console logging with formatting
    const prefix = `[LiveKitDiagnostic][${category.toUpperCase()}][${level.toUpperCase()}]`;
    if (level === 'error') {
      console.error(`${prefix} ${message}`, data || '');
    } else if (level === 'warn') {
      console.warn(`${prefix} ${message}`, data || '');
    } else {
      console.log(`${prefix} ${message}`, data || '');
    }

    this.notifyListeners();
    this.dispatchCustomEvent(entry);
    return entry;
  }

  /**
   * Tracks connection state transitions and updates duration timers
   */
  public trackStateChange(
    newState: LiveKitConnectionState,
    metadata?: Record<string, any>,
    socketId?: string
  ): void {
    const prev = this.metrics.connectionState;
    if (prev === newState && newState !== 'connecting' && newState !== 'reconnecting') return;

    this.metrics.previousState = prev;
    this.metrics.connectionState = newState;

    if (newState === 'connecting' || newState === 'reconnecting') {
      this.metrics.connectingStartTime = Date.now();
      this.metrics.totalAttempts++;
    } else if (newState === 'connected') {
      if (this.metrics.connectingStartTime) {
        this.metrics.connectingDurationMs = Date.now() - this.metrics.connectingStartTime;
        this.metrics.connectingStartTime = null;
      }
      this.metrics.successCount++;
    } else if (newState === 'failed' || newState === 'timeout' || newState === 'disconnected') {
      if (this.metrics.connectingStartTime) {
        this.metrics.connectingDurationMs = Date.now() - this.metrics.connectingStartTime;
        this.metrics.connectingStartTime = null;
      }
      if (newState === 'failed') this.metrics.failureCount++;
      if (newState === 'timeout') this.metrics.timeoutCount++;
    }

    this.log('state_change', 'lifecycle', `Connection state changed: ${prev} -> ${newState}`, {
      from: prev,
      to: newState,
      connectingDurationMs: this.metrics.connectingDurationMs,
      totalAttempts: this.metrics.totalAttempts,
      ...metadata
    }, socketId);
  }

  /**
   * Tracks socket instance creation and ensures active socket count is consistent
   */
  public trackSocketCreated(socketId: string, url: string, type: 'livekit_webrtc' | 'websocket_worker' | 'ws_fallback'): void {
    this.metrics.activeSocketId = socketId;
    this.metrics.activeSocketsCount++;

    this.log('info', 'lifecycle', `Socket instance created: [${type}] ID: ${socketId}`, {
      socketId,
      url: url.replace(/apiKey=[^&]+/, 'apiKey=***'),
      activeSocketsCount: this.metrics.activeSocketsCount,
      type
    }, socketId);
  }

  /**
   * Tracks explicit socket cleanup and verification
   */
  public trackCleanup(
    component: string,
    resourcesFreed: string[],
    socketId?: string
  ): void {
    this.metrics.cleanupsPerformed++;
    if (this.metrics.activeSocketsCount > 0) {
      this.metrics.activeSocketsCount = Math.max(0, this.metrics.activeSocketsCount - 1);
    }
    if (socketId && this.metrics.activeSocketId === socketId) {
      this.metrics.activeSocketId = null;
    }

    this.log('cleanup', 'cleanup', `Explicit cleanup executed for [${component}]. Resources freed: ${resourcesFreed.join(', ')}`, {
      component,
      resourcesFreed,
      remainingSocketsCount: this.metrics.activeSocketsCount,
      totalCleanupsPerformed: this.metrics.cleanupsPerformed
    }, socketId);
  }

  /**
   * Tracks connecting timeout trigger (>10 seconds)
   */
  public trackTimeoutTriggered(
    durationMs: number,
    attemptNumber: number,
    socketId?: string
  ): void {
    this.metrics.timeoutCount++;
    this.metrics.connectionState = 'timeout';

    this.log('warn', 'timeout', `WebSocket connection timeout triggered (>10s threshold: ${durationMs}ms in connecting state). Triggering state reset & auto-reconnect.`, {
      durationMs,
      attemptNumber,
      totalTimeouts: this.metrics.timeoutCount
    }, socketId);
  }

  /**
   * Tracks ping/pong and roundtrip latency
   */
  public trackPing(timestamp: number = Date.now()): void {
    this.metrics.lastPingTime = timestamp;
  }

  public trackPong(timestamp: number = Date.now()): void {
    this.metrics.lastPongTime = timestamp;
    if (this.metrics.lastPingTime) {
      const latency = Math.max(0, timestamp - this.metrics.lastPingTime);
      this.metrics.lastLatencyMs = latency;
      this.log('metric', 'heartbeat', `Heartbeat PONG received. Latency: ${latency}ms`, {
        latencyMs: latency,
        pingTime: this.metrics.lastPingTime,
        pongTime: timestamp
      });
    }
  }

  /**
   * Tracks audio packet throughput
   */
  public trackAudioSent(byteLength: number): void {
    this.metrics.audioPacketsSent++;
    this.metrics.bytesSent += byteLength;
  }

  public trackAudioReceived(byteLength: number): void {
    this.metrics.audioPacketsReceived++;
    this.metrics.bytesReceived += byteLength;
  }

  /**
   * Tracks connection error
   */
  public trackError(errorMessage: string, errorObj?: any, socketId?: string): void {
    this.metrics.lastError = errorMessage;
    this.metrics.lastErrorTime = Date.now();

    this.log('error', 'network', `WebSocket connection error: ${errorMessage}`, {
      error: errorMessage,
      details: errorObj ? (errorObj.message || String(errorObj)) : undefined
    }, socketId);
  }

  public getRecentLogs(limit?: number): DiagnosticLogEntry[] {
    if (!limit || limit >= this.logs.length) {
      return [...this.logs];
    }
    return this.logs.slice(-limit);
  }

  public getMetrics(): DiagnosticMetrics {
    return { ...this.metrics };
  }

  public subscribe(listener: DiagnosticListener): () => void {
    this.listeners.add(listener);
    // Initial call
    listener(this.getRecentLogs(50), this.getMetrics());
    return () => {
      this.listeners.delete(listener);
    };
  }

  public clearLogs(): void {
    this.logs = [];
    this.log('info', 'lifecycle', 'Diagnostic log buffer cleared by user.');
    this.notifyListeners();
  }

  public exportDiagnosticReport(): string {
    return JSON.stringify({
      generatedAt: new Date().toISOString(),
      userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Node/Unknown',
      metrics: this.metrics,
      logs: this.logs
    }, null, 2);
  }

  private notifyListeners(): void {
    if (this.listeners.size === 0) return;
    const recent = this.getRecentLogs(60);
    const metrics = this.getMetrics();
    this.listeners.forEach((listener) => {
      try {
        listener(recent, metrics);
      } catch (err) {
        console.error('[LiveKitDiagnostic] Listener error:', err);
      }
    });
  }

  private dispatchCustomEvent(entry: DiagnosticLogEntry): void {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:livekit-diagnostic', {
        detail: { entry, metrics: this.metrics }
      }));
    }
  }
}

export const liveKitDiagnosticService = LiveKitDiagnosticService.getInstance();
