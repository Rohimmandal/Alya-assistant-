/**
 * Alya Assistant - AudioManager
 * 
 * Central Audio Focus & Media Ducking Controller:
 * - Manages audio focus transitions (AUDIO_FOCUS_GAIN, GAIN_TRANSIENT, MAY_DUCK, LOSS)
 * - Automatically ducks or pauses background media playback when Alya speaks
 * - Smooth exponential volume ramping for seamless fade-out / fade-in transitions
 * - Synchronizes with VoiceEngine and TTS synthesizers to prevent overlapping audio
 * - Propagates audio focus commands to Android companion devices over WebSocket
 */

import { AudioEngineManager } from './AudioEngine';

export type AudioFocusType = 
  | 'AUDIO_FOCUS_GAIN'                    // Full exclusive focus (Active Live Voice Session)
  | 'AUDIO_FOCUS_GAIN_TRANSIENT'          // Short focus (Sound effect, chime, quick prompt)
  | 'AUDIO_FOCUS_GAIN_TRANSIENT_MAY_DUCK' // Assistant speaking with background media ducking
  | 'AUDIO_FOCUS_LOSS';                   // Released focus (Idle / Media resumed)

export interface TrackedMediaElement {
  element: HTMLMediaElement;
  originalVolume: number;
  wasPlaying: boolean;
  isDucked: boolean;
}

export interface AudioManagerConfig {
  duckVolumeMultiplier?: number; // Volume percentage when ducked (default 0.18 = 18%)
  duckFadeDurationMs?: number;   // Smooth transition duration in ms (default 250ms)
  autoPauseMediaOnSpeech?: boolean; // Whether to pause rather than duck during long responses
}

export class AudioManager {
  private static instance: AudioManager | null = null;

  private currentFocus: AudioFocusType = 'AUDIO_FOCUS_LOSS';
  private config: Required<AudioManagerConfig>;
  private trackedMedia: Map<HTMLMediaElement, TrackedMediaElement> = new Map();
  private fadeIntervals: Map<HTMLMediaElement, any> = new Map();
  private isAssistantSpeaking = false;
  private focusChangeListeners: Set<(focus: AudioFocusType) => void> = new Map<any, any>() as any;
  private listeners: Set<(focus: AudioFocusType) => void> = new Set();

  private constructor(config?: AudioManagerConfig) {
    this.config = {
      duckVolumeMultiplier: config?.duckVolumeMultiplier ?? 0.18,
      duckFadeDurationMs: config?.duckFadeDurationMs ?? 220,
      autoPauseMediaOnSpeech: config?.autoPauseMediaOnSpeech ?? false
    };

    if (typeof window !== 'undefined') {
      this.attachDomMediaObserver();
    }
  }

  public static getInstance(config?: AudioManagerConfig): AudioManager {
    if (!AudioManager.instance) {
      AudioManager.instance = new AudioManager(config);
    }
    return AudioManager.instance;
  }

  /**
   * Primary entry point: Request audio focus for an assistant event
   */
  public requestAudioFocus(focusType: AudioFocusType): boolean {
    const previousFocus = this.currentFocus;
    this.currentFocus = focusType;

    console.log(`[AudioManager] Audio focus transition: ${previousFocus} ➔ ${focusType}`);

    switch (focusType) {
      case 'AUDIO_FOCUS_GAIN':
        this.pauseAllBackgroundMedia();
        AudioEngineManager.getInstance().requestAudioFocus('tts');
        break;

      case 'AUDIO_FOCUS_GAIN_TRANSIENT_MAY_DUCK':
        this.duckAllBackgroundMedia();
        AudioEngineManager.getInstance().requestAudioFocus('tts');
        break;

      case 'AUDIO_FOCUS_GAIN_TRANSIENT':
        this.duckAllBackgroundMedia();
        break;

      case 'AUDIO_FOCUS_LOSS':
        this.restoreAllBackgroundMedia();
        AudioEngineManager.getInstance().requestAudioFocus('none');
        break;
    }

    this.notifyFocusChange(focusType);
    return true;
  }

  /**
   * Abandon audio focus and restore all media to original states
   */
  public abandonAudioFocus(): void {
    if (this.currentFocus !== 'AUDIO_FOCUS_LOSS') {
      this.requestAudioFocus('AUDIO_FOCUS_LOSS');
    }
  }

  /**
   * Hook called when Alya begins speaking (TTS or live voice stream start)
   */
  public onAssistantSpeakingStart(shouldPause = false): void {
    this.isAssistantSpeaking = true;
    if (shouldPause || this.config.autoPauseMediaOnSpeech) {
      this.requestAudioFocus('AUDIO_FOCUS_GAIN');
    } else {
      this.requestAudioFocus('AUDIO_FOCUS_GAIN_TRANSIENT_MAY_DUCK');
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:speech-started', { detail: { timestamp: Date.now() } }));
    }
  }

  /**
   * Hook called when Alya stops speaking
   */
  public onAssistantSpeakingEnd(): void {
    this.isAssistantSpeaking = false;
    this.abandonAudioFocus();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:speech-ended', { detail: { timestamp: Date.now() } }));
    }
  }

  /**
   * User Barge-In: Immediately halts TTS audio and claims microphone focus
   */
  public onUserBargeIn(): void {
    console.log('[AudioManager] User barge-in detected. Terminating TTS & reclaiming mic focus.');
    this.isAssistantSpeaking = false;
    AudioEngineManager.getInstance().clearOutputQueue();
    AudioEngineManager.getInstance().stopTTS();
    AudioEngineManager.getInstance().requestAudioFocus('microphone');
    this.abandonAudioFocus();

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:user-barge-in', { detail: { timestamp: Date.now() } }));
    }
  }

  /**
   * Smoothly ducks volume of all active media elements
   */
  public duckAllBackgroundMedia(): void {
    this.scanDomForMedia();

    this.trackedMedia.forEach((state, media) => {
      if (!media.paused && !media.ended && media.currentTime > 0) {
        state.wasPlaying = true;
        state.isDucked = true;
        const targetVol = Math.max(0.02, state.originalVolume * this.config.duckVolumeMultiplier);
        this.fadeVolume(media, media.volume, targetVol, this.config.duckFadeDurationMs);
      }
    });
  }

  /**
   * Pauses all playing media and saves state for subsequent resume
   */
  public pauseAllBackgroundMedia(): void {
    this.scanDomForMedia();

    this.trackedMedia.forEach((state, media) => {
      if (!media.paused && !media.ended) {
        state.wasPlaying = true;
        this.fadeVolume(media, media.volume, 0, 100, () => {
          try {
            media.pause();
          } catch {}
        });
      }
    });
  }

  /**
   * Restores ducked or paused background media back to original volumes and play states
   */
  public restoreAllBackgroundMedia(): void {
    this.trackedMedia.forEach((state, media) => {
      if (state.isDucked) {
        state.isDucked = false;
        this.fadeVolume(media, media.volume, state.originalVolume, this.config.duckFadeDurationMs);
      } else if (state.wasPlaying && media.paused) {
        state.wasPlaying = false;
        try {
          media.play().then(() => {
            this.fadeVolume(media, 0, state.originalVolume, this.config.duckFadeDurationMs);
          }).catch(() => {});
        } catch {}
      }
    });
  }

  /**
   * Smoothly interpolates audio volume over a set duration
   */
  private fadeVolume(
    element: HTMLMediaElement, 
    startVolume: number, 
    targetVolume: number, 
    durationMs: number, 
    onComplete?: () => void
  ): void {
    if (this.fadeIntervals.has(element)) {
      clearInterval(this.fadeIntervals.get(element));
      this.fadeIntervals.delete(element);
    }

    const steps = 15;
    const stepDuration = durationMs / steps;
    const volumeDelta = (targetVolume - startVolume) / steps;
    let currentStep = 0;

    const interval = setInterval(() => {
      currentStep++;
      const nextVol = Math.max(0, Math.min(1, startVolume + volumeDelta * currentStep));
      try {
        element.volume = nextVol;
      } catch {}

      if (currentStep >= steps) {
        clearInterval(interval);
        this.fadeIntervals.delete(element);
        try {
          element.volume = targetVolume;
        } catch {}
        onComplete?.();
      }
    }, stepDuration);

    this.fadeIntervals.set(element, interval);
  }

  /**
   * Scans DOM for <audio> and <video> elements to track
   */
  private scanDomForMedia(): void {
    if (typeof document === 'undefined') return;

    const mediaElements = Array.from(document.querySelectorAll<HTMLMediaElement>('audio, video'));
    mediaElements.forEach((el) => {
      if (!this.trackedMedia.has(el)) {
        this.trackedMedia.set(el, {
          element: el,
          originalVolume: el.volume,
          wasPlaying: !el.paused,
          isDucked: false
        });

        // Listen for user manual volume changes to update baseline
        el.addEventListener('volumechange', () => {
          const tracked = this.trackedMedia.get(el);
          if (tracked && !tracked.isDucked) {
            tracked.originalVolume = el.volume;
          }
        });
      }
    });
  }

  /**
   * Observe DOM mutations for newly added audio/video players
   */
  private attachDomMediaObserver(): void {
    if (typeof MutationObserver === 'undefined') return;

    const observer = new MutationObserver(() => {
      this.scanDomForMedia();
    });

    try {
      observer.observe(document.body, { childList: true, subtree: true });
    } catch {}
  }

  /**
   * Subscribe to audio focus state updates
   */
  public subscribe(callback: (focus: AudioFocusType) => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }

  private notifyFocusChange(focus: AudioFocusType): void {
    this.listeners.forEach((cb) => {
      try { cb(focus); } catch {}
    });

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:audio-focus-changed', { detail: { focus } }));
    }
  }

  public getCurrentFocus(): AudioFocusType {
    return this.currentFocus;
  }

  public isSpeaking(): boolean {
    return this.isAssistantSpeaking;
  }
}

export const audioManager = AudioManager.getInstance();
