/**
 * IntentEngine.ts
 *
 * Provides robust, low-latency natural language intent classification.
 * It transforms raw user utterances into actionable, structured intent objects
 * prior to dispatching them to the Capability Registry for permission validation
 * and subsequent execution.
 */

import { CapabilityDefinition, capabilityRegistry } from './CapabilityRegistry';

export type IntentCategory = 
  | 'GENERAL_CONVERSATION'
  | 'WEB_SEARCH'
  | 'DEVICE_CONTROL'
  | 'BROWSER_ACTION'
  | 'SYSTEM_QUERY'
  | 'MEDIA_PLAYBACK'
  | 'APP_LAUNCHER'
  | 'AWARENESS';

export interface ParsedIntent {
  raw: string;
  intent: IntentCategory;
  capability?: CapabilityDefinition;
  parameters: Record<string, any>;
  confidence: number;
}

export class IntentEngine {
  // Simple heuristic-based classification for local execution fallback,
  // while offloading complex synthesis to the backend Gemini-powered agent.
  public async classify(utterance: string): Promise<ParsedIntent> {
    const normalized = utterance.toLowerCase().trim();

    // 0. Real-Time Web Search & Grounded Factual Queries
    if (
      normalized.includes('who is') || 
      normalized.includes('what is the latest') || 
      normalized.includes('current price') || 
      normalized.includes('news about') || 
      normalized.includes('search web') || 
      normalized.includes('search for') || 
      normalized.includes('latest news') || 
      normalized.includes('kya hua') || 
      normalized.includes('ki hoyeche')
    ) {
      const queryText = utterance
        .replace(/^(search web for|search for|search|find out about|tell me about)/i, '')
        .trim();
      return {
        raw: utterance,
        intent: 'WEB_SEARCH',
        parameters: { query: queryText || utterance, groundingRequired: true },
        confidence: 0.98
      };
    }

    // 0. Awareness / System Time
    if (normalized.includes('time') || normalized.includes('date') || normalized.includes('what day') || normalized.includes('what time') || normalized.includes('samay') || normalized.includes('kitne baje')) {
      return {
        raw: utterance,
        intent: 'AWARENESS',
        parameters: { queryType: 'current_time', timestamp: Date.now(), localString: new Date().toLocaleString() },
        confidence: 0.99
      };
    }

    // 1. Browser Navigation & Automation Actions
    if (
      normalized.startsWith('open ') || 
      normalized.includes('open website') || 
      normalized.includes('open url') || 
      normalized.includes('go to ') || 
      normalized.includes('search on google') || 
      normalized.includes('search for ') ||
      normalized.includes('scroll down') || 
      normalized.includes('scroll up') || 
      normalized.includes('click on ') || 
      normalized.includes('type ')
    ) {
      let cmd = 'open_url';
      let params: Record<string, any> = {};

      if (normalized.includes('scroll down')) {
        cmd = 'scroll';
        params = { scrollDirection: 'down', scrollAmount: 450 };
      } else if (normalized.includes('scroll up')) {
        cmd = 'scroll';
        params = { scrollDirection: 'up', scrollAmount: 450 };
      } else if (normalized.startsWith('search') || normalized.includes('search for')) {
        cmd = 'search';
        const queryText = normalized.replace(/^(search for|search on google for|search on web for|search)/i, '').trim();
        params = { query: queryText || utterance };
      } else if (normalized.includes('click on') || normalized.startsWith('click ')) {
        cmd = 'click';
        const target = normalized.replace(/^(click on|click button|click link|click)/i, '').trim();
        params = { target };
      } else if (normalized.includes('type ') || normalized.includes('fill form')) {
        cmd = 'type';
        params = { text: utterance };
      } else if (normalized.startsWith('open ') || normalized.startsWith('go to ')) {
        cmd = 'open_url';
        const urlCandidate = normalized.replace(/^(open website|open url|open link|open|go to)/i, '').trim();
        params = { url: urlCandidate };
      }

      const cap = capabilityRegistry.getCapability(
        cmd === 'scroll' || cmd === 'click' || cmd === 'type' ? 'cap_browser_interaction' : 'cap_browser_navigation'
      );

      return {
        raw: utterance,
        intent: 'BROWSER_ACTION',
        capability: cap,
        parameters: { command: cmd, ...params },
        confidence: 0.95
      };
    }

    // 2. Device Control (Android Companion)
    if (normalized.includes('flashlight') || normalized.includes('torch')) {
      return {
        raw: utterance,
        intent: 'DEVICE_CONTROL',
        parameters: { action: 'toggle_flashlight' },
        confidence: 0.95
      };
    }

    if (normalized.includes('volume') || normalized.includes('brightness')) {
      return {
        raw: utterance,
        intent: 'DEVICE_CONTROL',
        parameters: { 
          target: normalized.includes('volume') ? 'media_volume' : 'screen_brightness',
          action: 'adjust'
        },
        confidence: 0.9
      };
    }

    // 2. Media Playback
    if (normalized.includes('play') || normalized.includes('pause') || normalized.includes('music')) {
      return {
        raw: utterance,
        intent: 'MEDIA_PLAYBACK',
        parameters: { action: normalized.includes('play') ? 'play' : 'pause' },
        confidence: 0.85
      };
    }

    // 3. System Queries
    if (normalized.includes('time') || normalized.includes('weather') || normalized.includes('battery')) {
      return {
        raw: utterance,
        intent: 'SYSTEM_QUERY',
        parameters: { topic: normalized.includes('time') ? 'time' : normalized.includes('weather') ? 'weather' : 'battery' },
        confidence: 0.95
      };
    }

    // Default to conversational assistant
    return {
      raw: utterance,
      intent: 'GENERAL_CONVERSATION',
      parameters: {},
      confidence: 1.0
    };
  }
}

export const intentEngine = new IntentEngine();
