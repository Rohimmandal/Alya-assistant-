/**
 * Centralized High-Fidelity Non-Overlapping Audio Queue for Alya Assistant
 * Powered by Singleton HTMLAudioElement for low-latency playback,
 * source reset via AudioMutex, and explicit text-to-audio sync markers.
 * Distributes speaking state & sync marker changes via custom events for stutter-free UI sync.
 */

import { LanguageDetector } from './LanguageDetector';
import { audioManager } from './AudioManager';
import { AlyaPersonalityEngine } from './AlyaPersonalityEngine';
import { VoiceEngineDiagnostics } from './VoiceEngine';
import { secureStorage } from './secureStorage';
import { userSettingsService } from './userSettingsService';
import { TTSSyncMarker } from './pcmAudioWorklet';
import { AudioMutex } from './AudioMutex';
import { audioCoordinator } from './AudioCoordinator';
import { audioPlaybackManager } from './AudioPlaybackManager';
import { getActiveApiKey } from './ApiKeyManager';

export type AlyaMood = 'happy' | 'excited' | 'curious' | 'calm' | 'playful' | 'thoughtful' | 'focused' | 'sassy' | 'auto';

export interface VoiceOptions {
  id?: string; // Optional unique identifier for state synchronization across components
  mood?: AlyaMood;
  language?: string;
  voiceName?: string;
  pitch?: number;
  rate?: number;
  onStart?: () => void;
  onEnd?: () => void;
  onProgress?: (progress: number, charIndex: number) => void;
  onError?: (err?: any) => void;
}

export interface TTSProgressEventDetail {
  id: string;
  progress: number; // 0.0 to 1.0
  charIndex: number;
  totalChars: number;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  textSnippet?: string;
}

const MOOD_PROSODY: Record<string, { pitch: number; rate: number }> = {
  happy: { pitch: 1.05, rate: 1.02 },
  excited: { pitch: 1.08, rate: 1.06 },
  curious: { pitch: 1.02, rate: 1.00 },
  calm: { pitch: 0.96, rate: 0.92 },
  playful: { pitch: 1.06, rate: 1.03 },
  thoughtful: { pitch: 0.94, rate: 0.92 },
  focused: { pitch: 1.00, rate: 1.02 },
  sassy: { pitch: 1.06, rate: 1.04 },
  auto: { pitch: 0.98, rate: 0.96 },
};

let liveCallActive = false;
let cachedVoices: SpeechSynthesisVoice[] = [];

function loadVoices(): SpeechSynthesisVoice[] {
  if (typeof window === 'undefined' || !('speechSynthesis' in window)) return [];
  try {
    cachedVoices = window.speechSynthesis.getVoices();
  } catch {
    cachedVoices = [];
  }
  return cachedVoices;
}

if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
  loadVoices();
  if (window.speechSynthesis.onvoiceschanged !== undefined) {
    window.speechSynthesis.onvoiceschanged = () => {
      loadVoices();
    };
  }
}

export function setLiveCallActive(active: boolean): void {
  liveCallActive = active;
  if (active) {
    AlyaAudioQueueManager.getInstance().stop();
  }
}

export function isLiveCallActive(): boolean {
  return liveCallActive;
}

if (typeof window !== 'undefined') {
  window.addEventListener('alya:live-call-status', (e: any) => {
    setLiveCallActive(!!e.detail?.inCall);
  });
}

/**
 * Finds the most natural female voice for any given language code on the client browser
 */
function getBestFemaleVoiceForLang(langCode: string): SpeechSynthesisVoice | null {
  if (!('speechSynthesis' in window)) return null;

  const voices = cachedVoices.length > 0 ? cachedVoices : loadVoices();
  if (!voices || voices.length === 0) return null;

  const shortCode = langCode.split('-')[0].toLowerCase();

  const preferredFemaleNames = [
    'google hi', 'google hindi', 'google english', 'google uk english female', 'google us english',
    'natural', 'neural', 'female', 'woman', 'siri',
    'jenny', 'aria', 'swara', 'zira', 'samantha', 'victoria', 'karen', 'moira', 'fiona', 'tessa',
    'madhur', 'ananya', 'priya', 'manisha', 'hi-in', 'bn-bd', 'bn-in',
    'kyoko', 'yuna', 'heami', 'xiaoxiao', 'sabina', 'denise', 'elena', 'paola', 'lucia', 'fatima'
  ];

  const langVoices = voices.filter(v => v.lang.toLowerCase().startsWith(shortCode));

  if (langVoices.length > 0) {
    for (const name of preferredFemaleNames) {
      const match = langVoices.find(v => v.name.toLowerCase().includes(name));
      if (match) return match;
    }
    return langVoices[0];
  }

  for (const name of preferredFemaleNames) {
    const found = voices.find(v => v.name.toLowerCase().includes(name));
    if (found) return found;
  }

  return voices.find(v => v.lang.startsWith('en')) || voices[0] || null;
}

function convertNumbersToWords(str: string): string {
  const ones = ['', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten', 'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
  const tens = ['', '', 'twenty', 'thirty', 'forty', 'fifty', 'sixty', 'seventy', 'eighty', 'ninety'];

  function numToWords(n: number): string {
    if (n === 0) return 'zero';
    if (n < 0) return 'minus ' + numToWords(-n);
    if (n < 20) return ones[n];
    if (n < 100) return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' ' + ones[n % 10] : '');
    if (n < 1000) return ones[Math.floor(n / 100)] + ' hundred' + (n % 100 !== 0 ? ' ' + numToWords(n % 100) : '');
    if (n < 1000000) return numToWords(Math.floor(n / 1000)) + ' thousand' + (n % 1000 !== 0 ? ' ' + numToWords(n % 1000) : '');
    return n.toString();
  }

  return str
    .replace(/\b(\d{1,2}):(\d{2})\b/g, (_, h, m) => {
      const hours = numToWords(parseInt(h, 10));
      const mins = parseInt(m, 10) === 0 ? "o'clock" : (parseInt(m, 10) < 10 ? 'oh ' + numToWords(parseInt(m, 10)) : numToWords(parseInt(m, 10)));
      return `${hours} ${mins}`;
    })
    .replace(/\b(\d+)\s*%/g, (_, n) => `${numToWords(parseInt(n, 10))} percent`)
    .replace(/\b\d+\b/g, (match) => {
      const val = parseInt(match, 10);
      if (!isNaN(val) && val <= 999999) return numToWords(val);
      return match;
    });
}

class AlyaAudioQueueManager {
  private static instance: AlyaAudioQueueManager;
  private queue: Array<{ 
    text: string; 
    options: VoiceOptions; 
    detectedLang: string; 
    charOffset: number; 
    totalTextLength: number; 
  }> = [];
  private isPlaying = false;
  private currentSpeakingId: string | null = null;
  
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private playbackAbortController: AbortController | null = null;
  
  // Re-sync & Pacing Tracking
  private syncAnimationId: number | null = null;
  private currentSegmentStartTime = 0;
  private currentSegmentDuration = 0;
  private currentSegmentCharOffset = 0;
  private currentSegmentTextLength = 0;
  private totalSpokenLength = 0;

  private constructor() {
    AudioMutex.registerStopHandler(() => this.stopInternal());
    audioPlaybackManager.registerCancelHandler('tts_chat', () => this.stopInternal());
  }

  public static getInstance(): AlyaAudioQueueManager {
    if (!AlyaAudioQueueManager.instance) {
      AlyaAudioQueueManager.instance = new AlyaAudioQueueManager();
    }
    return AlyaAudioQueueManager.instance;
  }

  public getCurrentSpeakingId(): string | null {
    return this.currentSpeakingId;
  }

  public stream(rawText: string, options?: VoiceOptions) {
    if (liveCallActive) return;
    
    const opts = options || {};
    const targetSessionId = opts.id || `session_${Date.now()}`;
    opts.id = targetSessionId;

    if (!this.currentSpeakingId) {
        this.currentSpeakingId = targetSessionId;
        this.totalSpokenLength = 0;
        this.dispatchStateChange(this.currentSpeakingId, true);
    } else if (this.currentSpeakingId !== targetSessionId) {
        this.stopInternal();
        this.currentSpeakingId = targetSessionId;
        this.totalSpokenLength = 0;
        this.dispatchStateChange(this.currentSpeakingId, true);
    }

    const activeMood = (opts.mood || localStorage.getItem('alya_current_mood') || 'auto') as AlyaMood;
    const targetLang = opts.language || localStorage.getItem('alya_preferred_lang') || 'auto';

    const formattedText = AlyaPersonalityEngine.formatResponse(rawText, {
      mood: activeMood,
      language: targetLang
    });

    const cleanSpokenText = convertNumbersToWords(
      formattedText
        .replace(/```[\s\S]*?```/g, ' Code snippet omitted. ')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/https?:\/\/[^\s]+/g, 'link')
        .replace(/\[[^\]]*\]/g, '')
        .replace(/[*#_~>]/g, '')
        .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '. ')
        .trim()
    );

    if (!cleanSpokenText) return;

    // Split text into conversational acoustic chunks
    const maxChunkLength = 400;
    const chunks: string[] = [];

    if (cleanSpokenText.length <= maxChunkLength) {
      chunks.push(cleanSpokenText);
    } else {
      const rawSentences = cleanSpokenText.match(/[^.!?]+[.!?]*/g) || [cleanSpokenText];
      let currentChunk = '';
      for (const s of rawSentences) {
        if ((currentChunk + ' ' + s).length > maxChunkLength && currentChunk.trim()) {
          chunks.push(currentChunk.trim());
          currentChunk = s;
        } else {
          currentChunk = currentChunk ? `${currentChunk} ${s}` : s;
        }
      }
      if (currentChunk.trim()) {
        chunks.push(currentChunk.trim());
      }
    }

    const detectedLangInfo = targetLang === 'auto' 
      ? LanguageDetector.detectLanguage(cleanSpokenText)
      : LanguageDetector.getLanguageInfo(targetLang);

    chunks.forEach(chunk => {
      this.queue.push({
        text: chunk,
        options: { ...opts, mood: activeMood },
        detectedLang: detectedLangInfo.code,
        charOffset: this.totalSpokenLength,
        totalTextLength: this.totalSpokenLength + cleanSpokenText.length
      });
      this.totalSpokenLength += chunk.length;
    });

    if (!this.isPlaying) {
        this.playbackAbortController = new AbortController();
        this.startPlaybackLoop(this.playbackAbortController.signal);
    }
  }

  /**
   * Adds text to queue, immediately interrupts any active streams across the app via AudioMutex,
   * and plays with natural pacing pauses.
   */
  public async play(rawText: string, options?: VoiceOptions) {
    if (liveCallActive || audioCoordinator.isPrimaryActive()) {
      console.log('[QueueManager] Primary Live Voice stream active — blocking main chat TTS.');
      return;
    }

    const opts = options || {};
    const targetSessionId = opts.id || `session_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
    opts.id = targetSessionId;

    // Acquire lock with AudioCoordinator
    if (!audioCoordinator.acquireDestinationLock('TTS_CHAT', targetSessionId)) {
      console.log('[QueueManager] AudioCoordinator destination lock rejected for TTS_CHAT');
      return;
    }

    // Acquire exclusive AudioMutex and AudioPlaybackManager lock (synchronously terminates all active sessions across the app)
    await AudioMutex.acquireLock(targetSessionId);
    await audioPlaybackManager.acquireLock(targetSessionId, 'TTS_CHAT');

    const activeMood = (opts.mood || localStorage.getItem('alya_current_mood') || 'auto') as AlyaMood;
    const targetLang = opts.language || localStorage.getItem('alya_preferred_lang') || 'auto';

    // Pass all incoming LLM text through AlyaPersonalityEngine.formatResponse() before synthesis
    const formattedText = AlyaPersonalityEngine.formatResponse(rawText, {
      mood: activeMood,
      language: targetLang
    });

    const cleanSpokenText = convertNumbersToWords(
      formattedText
        .replace(/```[\s\S]*?```/g, ' Code snippet omitted. ')
        .replace(/`([^`]+)`/g, '$1')
        .replace(/https?:\/\/[^\s]+/g, 'link')
        .replace(/\[[^\]]*\]/g, '') // remove bracket annotations
        .replace(/[*#_~>]/g, '')
        .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{1FA70}-\u{1FAFF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
        .replace(/\s+/g, ' ')
        .replace(/\n+/g, '. ')
        .trim()
    );

    if (!cleanSpokenText) return;

    this.currentSpeakingId = targetSessionId;
    this.totalSpokenLength = cleanSpokenText.length;
    
    // Dispatch speaking state change
    this.dispatchStateChange(this.currentSpeakingId, true);

    // Split text into conversational acoustic chunks (up to 400 chars) while preserving sentence boundaries
    const maxChunkLength = 400;
    const chunks: string[] = [];

    if (cleanSpokenText.length <= maxChunkLength) {
      chunks.push(cleanSpokenText);
    } else {
      const rawSentences = cleanSpokenText.match(/[^.!?]+[.!?]*/g) || [cleanSpokenText];
      let currentChunk = '';
      for (const s of rawSentences) {
        if ((currentChunk + ' ' + s).length > maxChunkLength && currentChunk.trim()) {
          chunks.push(currentChunk.trim());
          currentChunk = s;
        } else {
          currentChunk = currentChunk ? `${currentChunk} ${s}` : s;
        }
      }
      if (currentChunk.trim()) {
        chunks.push(currentChunk.trim());
      }
    }

    const detectedLangInfo = targetLang === 'auto' 
      ? LanguageDetector.detectLanguage(cleanSpokenText)
      : LanguageDetector.getLanguageInfo(targetLang);

    // Queue chunk(s) with precise character offset tracking for the re-sync pipeline
    let charOffsetAccumulator = 0;
    chunks.forEach(chunk => {
      this.queue.push({
        text: chunk,
        options: { ...opts, mood: activeMood },
        detectedLang: detectedLangInfo.code,
        charOffset: charOffsetAccumulator,
        totalTextLength: cleanSpokenText.length
      });
      charOffsetAccumulator += chunk.length;
    });

    this.playbackAbortController = new AbortController();
    this.startPlaybackLoop(this.playbackAbortController.signal);
  }

  /**
   * Natural conversational loop that plays back each sentence segment
   */
  private async startPlaybackLoop(signal: AbortSignal) {
    if (this.isPlaying) return;
    this.isPlaying = true;

    audioManager.onAssistantSpeakingStart();

    while (this.queue.length > 0) {
      if (signal.aborted || liveCallActive) break;

      const item = this.queue.shift();
      if (!item) continue;

      if (item.options.onStart) item.options.onStart();

      try {
        console.log(`[QueueManager] Processing segment: "${item.text.slice(0, 30)}..."`);
        await this.playSegment(
          item.text, 
          item.options, 
          item.detectedLang, 
          item.charOffset, 
          item.totalTextLength, 
          signal
        );
        console.log(`[QueueManager] Segment successfully finished.`);
      } catch (err: any) {
        if (signal.aborted || err?.message === 'Playback aborted') {
          // Playback was cleanly stopped/reset; exit loop without false error
          break;
        }
        console.error(`[QueueManager] Segment failed:`, err);
        if (item.options.onError) item.options.onError(err);
      }

      if (item.options.onEnd) item.options.onEnd();

      // Conversational pacing: 150ms pause between sentence blocks
      if (this.queue.length > 0 && !signal.aborted) {
        await new Promise(resolve => setTimeout(resolve, 150));
      }
    }

    this.isPlaying = false;
    this.stopSyncLoop();
    audioManager.onAssistantSpeakingEnd();
    
    if (!signal.aborted) {
      const finishedId = this.currentSpeakingId;
      this.currentSpeakingId = null;
      if (finishedId) {
        AudioMutex.releaseLock(finishedId);
        audioPlaybackManager.releaseLock(finishedId);
        this.dispatchProgress(finishedId, 1.0, this.totalSpokenLength, this.totalSpokenLength, 0, 0, false);
        this.dispatchStateChange(finishedId, false);
      }
    }
  }

  /**
   * High-resolution requestAnimationFrame backup timer for smooth visual progress
   */
  private startSyncLoop(
    speakingId: string, 
    charOffset: number, 
    chunkLength: number, 
    totalChars: number, 
    onProgress?: (progress: number, charIndex: number) => void
  ) {
    this.stopSyncLoop();
    
    const startTime = Date.now();

    const tick = () => {
      if (!this.isPlaying || this.currentSpeakingId !== speakingId) {
        this.stopSyncLoop();
        return;
      }

      const audio = AudioMutex.getAudioElement();
      if (!audio || !audio.src || audio.paused) {
         this.syncAnimationId = requestAnimationFrame(tick);
         return;
      }

      const elapsed = audio.currentTime;
      const duration = audio.duration || 1;
      const segmentProgress = Math.min(1.0, elapsed / duration);
      
      const currentChar = Math.min(totalChars, Math.round(charOffset + (segmentProgress * chunkLength)));
      const overallProgress = totalChars > 0 ? Math.min(1.0, currentChar / totalChars) : segmentProgress;

      this.dispatchProgress(speakingId, overallProgress, currentChar, totalChars, elapsed, duration, true);

      if (onProgress) {
        onProgress(overallProgress, currentChar);
      }

      if (segmentProgress < 1.0) {
        this.syncAnimationId = requestAnimationFrame(tick);
      }
    };

    this.syncAnimationId = requestAnimationFrame(tick);
  }

  private stopSyncLoop() {
    if (this.syncAnimationId !== null) {
      cancelAnimationFrame(this.syncAnimationId);
      this.syncAnimationId = null;
    }
  }

  /**
   * Plays a sentence segment using the singleton HTMLAudioElement from AudioMutex.
   * Guarantees that any existing playback is programmatically paused and reset before the new stream.
   */
  private playSegment(
    text: string, 
    opts: VoiceOptions, 
    langCode: string, 
    charOffset: number,
    totalLength: number,
    signal: AbortSignal
  ): Promise<void> {
    return new Promise(async (resolve, reject) => {
      if (signal.aborted) return reject(new Error('Playback aborted'));

      const moodProsody = MOOD_PROSODY[opts.mood || 'auto'] || MOOD_PROSODY.auto;
      const basePitch = opts.pitch ?? Number(localStorage.getItem('alya_voice_pitch') || moodProsody.pitch);
      const baseRate = opts.rate ?? Number(localStorage.getItem('alya_voice_rate') || moodProsody.rate);

      try {
        const prefs = userSettingsService.getPreferences();
        const rawVoice = opts.voiceName || prefs.voiceName || localStorage.getItem('alya_voice_name') || 'Aoede';
        const validVoices = ['Aoede', 'Kore', 'Ursa', 'Callirrhoe', 'Leda', 'Zephyr', 'Puck'];
        const voicePreference = validVoices.includes(rawVoice) ? rawVoice : 'Aoede';
        const rawUserKey = getActiveApiKey() || secureStorage.getDecryptedApiKeySync() || await secureStorage.getSecureApiKey();
        const userKey = (rawUserKey && (rawUserKey.startsWith('AIza') || rawUserKey.startsWith('AQ.')) && rawUserKey.length > 20) ? rawUserKey : '';

        const headers: Record<string, string> = { 
          'Content-Type': 'application/json',
          'X-Requested-Bitrate': '384000',
          'X-Requested-SampleRate': '24000'
        };
        if (userKey) {
          headers['x-gemini-api-key'] = userKey;
        }

        // Fetch high-fidelity audio stream from neural voice TTS endpoint
        const response = await fetch('/api/tts', {
          method: 'POST',
          headers,
          body: JSON.stringify({ 
            text, 
            mood: opts.mood || 'auto',
            voiceName: voicePreference,
            language: langCode || prefs.language || 'auto',
            apiKey: userKey || undefined,
            preferredBitrate: 384000
          }),
          signal
        });

        if (signal.aborted) return reject(new Error('Playback aborted'));

        if (!response.ok) {
          throw new Error(`Gemini Live TTS Generation failed with status ${response.status}`);
        }

        const arrayBuffer = await response.arrayBuffer();
        if (signal.aborted) return reject(new Error('Playback aborted'));

        // 1. Buffer Integrity Inspection
        const verification = VoiceEngineDiagnostics.verifyAudioBufferIntegrity(arrayBuffer, `TTS segment "${text.slice(0, 20)}..."`);
        if (!verification.isValid) {
          throw new Error(`Corrupt audio buffer received: ${verification.reason}`);
        }

        // 2. Singleton HTMLAudioElement Implementation
        const audio = AudioMutex.getAudioElement();
        
        // programmatically pause and reset source before starting new stream
        AudioMutex.resetAudioElement();

        let finalBuffer = arrayBuffer;
        const u8 = new Uint8Array(arrayBuffer);
        const hasRiff = u8.length >= 12 && u8[0] === 0x52 && u8[1] === 0x49 && u8[2] === 0x46 && u8[3] === 0x46; // 'RIFF'
        if (!hasRiff && u8.length > 0) {
          // Wrap raw PCM in standard 24kHz 16-bit mono WAV header for instant browser decoding
          const sampleRate = 24000;
          const numChannels = 1;
          const bitsPerSample = 16;
          const byteRate = sampleRate * numChannels * (bitsPerSample / 8);
          const blockAlign = numChannels * (bitsPerSample / 8);
          const dataLength = u8.length;
          const wavHeader = new ArrayBuffer(44);
          const view = new DataView(wavHeader);

          // RIFF
          view.setUint8(0, 0x52); view.setUint8(1, 0x49); view.setUint8(2, 0x46); view.setUint8(3, 0x46);
          view.setUint32(4, 36 + dataLength, true);
          view.setUint8(8, 0x57); view.setUint8(9, 0x41); view.setUint8(10, 0x56); view.setUint8(11, 0x45);

          // fmt
          view.setUint8(12, 0x66); view.setUint8(13, 0x6d); view.setUint8(14, 0x74); view.setUint8(15, 0x20);
          view.setUint32(16, 16, true);
          view.setUint16(20, 1, true);
          view.setUint16(22, numChannels, true);
          view.setUint32(24, sampleRate, true);
          view.setUint32(28, byteRate, true);
          view.setUint16(32, blockAlign, true);
          view.setUint16(34, bitsPerSample, true);

          // data
          view.setUint8(36, 0x64); view.setUint8(37, 0x61); view.setUint8(38, 0x74); view.setUint8(39, 0x61);
          view.setUint32(40, dataLength, true);

          const combined = new Uint8Array(44 + dataLength);
          combined.set(new Uint8Array(wavHeader), 0);
          combined.set(u8, 44);
          finalBuffer = combined.buffer;
        }

        const blob = new Blob([finalBuffer], { type: 'audio/wav' });
        const blobUrl = URL.createObjectURL(blob);
        
        audio.src = blobUrl;
        
        const speakingId = this.currentSpeakingId || 'default';

        // 3. Setup cleanup and resolve handlers
        const cleanup = () => {
          audio.onended = null;
          audio.onerror = null;
          audio.ontimeupdate = null;
          URL.revokeObjectURL(blobUrl);
          this.stopSyncLoop();
        };

        audio.onended = () => {
          cleanup();
          VoiceEngineDiagnostics.log('audio_buffer', 'info', 'HTMLAudio segment playback completed cleanly');
          resolve();
        };

        audio.onerror = (e) => {
          cleanup();
          reject(e);
        };

        // UI Progress Sync using HTMLAudioElement timeupdate
        audio.ontimeupdate = () => {
          if (!audio.duration) return;
          const segmentProgress = audio.currentTime / audio.duration;
          const currentChar = Math.min(totalLength, Math.round(charOffset + (segmentProgress * text.length)));
          const overallProgress = totalLength > 0 ? Math.min(1.0, currentChar / totalLength) : segmentProgress;
          
          this.dispatchProgress(speakingId, overallProgress, currentChar, totalLength, audio.currentTime, audio.duration, true);
          if (opts.onProgress) opts.onProgress(overallProgress, currentChar);
        };

        // Start requestAnimationFrame backup for smoother visual progress
        this.startSyncLoop(
          speakingId, 
          charOffset, 
          text.length, 
          totalLength, 
          opts.onProgress
        );

        await audio.play();
      } catch (err) {
        if (signal.aborted) return reject(new Error('Playback aborted'));

        // High-fidelity Multilingual Local Browser Speech Synthesis Fallback
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          const utterance = new SpeechSynthesisUtterance(text);
          this.currentUtterance = utterance;

          const femaleVoice = getBestFemaleVoiceForLang(langCode);
          if (femaleVoice) {
            utterance.voice = femaleVoice;
            utterance.lang = femaleVoice.lang;
          } else {
            utterance.lang = langCode;
          }

          utterance.pitch = Math.max(0.5, Math.min(2.0, basePitch));
          utterance.rate = Math.max(0.5, Math.min(2.0, baseRate));

          const speakingId = this.currentSpeakingId || 'default';

          utterance.onboundary = (e) => {
            if (e.name === 'word' || e.name === 'sentence') {
              const charIndex = charOffset + (e.charIndex || 0);
              const progress = totalLength > 0 ? charIndex / totalLength : 0.5;
              
              const marker: TTSSyncMarker = {
                id: speakingId,
                markerId: `boundary_${speakingId}_${charIndex}`,
                charIndex,
                totalChars: totalLength,
                textSnippet: text.slice(e.charIndex || 0, (e.charIndex || 0) + 15),
                timestamp: Date.now()
              };

              if (typeof window !== 'undefined') {
                window.dispatchEvent(new CustomEvent<TTSSyncMarker>('alya:tts-sync-marker', { detail: marker }));
              }

              this.dispatchProgress(speakingId, progress, charIndex, totalLength, 0, 0, true);
              if (opts.onProgress) opts.onProgress(progress, charIndex);
            }
          };

          utterance.onend = () => {
            if (this.currentUtterance === utterance) this.currentUtterance = null;
            this.dispatchProgress(speakingId, 1.0, totalLength, totalLength, 0, 0, false);
            resolve();
          };
          utterance.onerror = (e) => {
            if (this.currentUtterance === utterance) this.currentUtterance = null;
            reject(e);
          };

          window.speechSynthesis.speak(utterance);
        } else {
          reject(err);
        }
      }
    });
  }

  /**
   * Triggers global AudioMutex stop to halt all active playback sessions across the app.
   */
  public stop() {
    AudioMutex.stopAllPlayback();
  }

  /**
   * Internal stop logic executed by AudioMutex or local queue resets.
   */
  private stopInternal() {
    const previousId = this.currentSpeakingId;
    this.currentSpeakingId = null;

    this.stopSyncLoop();

    if (this.playbackAbortController) {
      this.playbackAbortController.abort();
      this.playbackAbortController = null;
    }

    this.queue = [];
    this.isPlaying = false;

    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch {}
    }
    this.currentUtterance = null;
    audioManager.onAssistantSpeakingEnd();

    if (previousId) {
      AudioMutex.releaseLock(previousId);
      audioPlaybackManager.releaseLock(previousId);
      this.dispatchProgress(previousId, 0, 0, this.totalSpokenLength, 0, 0, false);
      this.dispatchStateChange(previousId, false);
    }
  }

  private dispatchStateChange(id: string, speaking: boolean) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:tts-state-change', {
        detail: { id, speaking }
      }));
    }
  }

  private dispatchProgress(
    id: string, 
    progress: number, 
    charIndex: number, 
    totalChars: number, 
    currentTime: number, 
    duration: number, 
    isPlaying: boolean,
    textSnippet?: string
  ) {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent<TTSProgressEventDetail>('alya:tts-progress', {
        detail: {
          id,
          progress,
          charIndex,
          totalChars,
          currentTime,
          duration,
          isPlaying,
          textSnippet
        }
      }));
    }
  }
}

/**
 * Singleton Audio Player class maintaining a single active audio player instance across the application
 */
export class SingletonAudioPlayer {
  private static instance: SingletonAudioPlayer;

  public static getInstance(): SingletonAudioPlayer {
    if (!SingletonAudioPlayer.instance) {
      SingletonAudioPlayer.instance = new SingletonAudioPlayer();
    }
    return SingletonAudioPlayer.instance;
  }

  public async play(rawText: string, options?: VoiceOptions): Promise<void> {
    return AlyaAudioQueueManager.getInstance().play(rawText, options);
  }

  public stop(): void {
    AlyaAudioQueueManager.getInstance().stop();
  }

  public getCurrentSpeakingId(): string | null {
    return AlyaAudioQueueManager.getInstance().getCurrentSpeakingId();
  }
}

export async function playAlyaVoice(rawText: string, options?: VoiceOptions) {
  return SingletonAudioPlayer.getInstance().play(rawText, options);
}

export function streamAlyaVoice(rawText: string, options?: VoiceOptions) {
  return AlyaAudioQueueManager.getInstance().stream(rawText, options);
}

export function stopAlyaVoice() {
  SingletonAudioPlayer.getInstance().stop();
}

export function getCurrentSpeakingId(): string | null {
  return SingletonAudioPlayer.getInstance().getCurrentSpeakingId();
}
