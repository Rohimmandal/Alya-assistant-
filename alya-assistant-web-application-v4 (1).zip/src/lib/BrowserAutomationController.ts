/**
 * Alya Assistant - Browser Automation & Visual Perception Controller
 *
 * Provides real-time in-browser automation, visual perception, active window management,
 * and media playback control (play, pause, scrub forward/backward by seconds).
 */

export interface BrowserActionResult {
  success: boolean;
  action: string;
  message: string;
  details?: any;
}

export interface MediaControlParams {
  command: 'play' | 'pause' | 'toggle' | 'scrub' | 'volume' | 'rate' | 'mute';
  seconds?: number; // e.g. +10, -15
  volume?: number; // 0.0 to 1.0
  rate?: number; // e.g. 1.25, 1.5, 2.0
}

export class BrowserAutomationController {
  private static instance: BrowserAutomationController | null = null;
  private captureStream: MediaStream | null = null;

  // Single-Execution & Anti-Loop Guardrails
  private isExecutingAction: boolean = false;
  private lastActionTimestamp: number = 0;
  private lastActionSignature: string = '';

  private constructor() {
    this.registerGlobalEventListener();
  }

  public static getInstance(): BrowserAutomationController {
    if (!BrowserAutomationController.instance) {
      BrowserAutomationController.instance = new BrowserAutomationController();
    }
    return BrowserAutomationController.instance;
  }

  private registerGlobalEventListener(): void {
    if (typeof window === 'undefined') return;

    window.addEventListener('alya:browser-action', (event: any) => {
      if (event?.detail) {
        this.execute(event.detail);
      }
    });
  }

  /**
   * Main router for executing browser automation actions
   */
  public async execute(params: {
    action: string;
    target?: string;
    url?: string;
    text?: string;
    query?: string;
    selector?: string;
    permission_type?: string;
    scrollDirection?: 'up' | 'down' | 'top' | 'bottom';
    scrollAmount?: number;
    media?: MediaControlParams;
    width?: number;
    height?: number;
  }): Promise<BrowserActionResult> {
    const act = (params.action || '').toLowerCase().trim();
    const queryStr = params.query || params.target || params.url || params.text || params.permission_type || '';
    const signature = `${act}:${queryStr}`;
    const now = Date.now();

    // 2-Second Cooldown Anti-Loop & Anti-Duplicate Guardrail
    if (this.isExecutingAction && (now - this.lastActionTimestamp < 2000)) {
      console.log(`[BrowserAutomationController] Debounced action '${signature}' — already executing.`);
      return {
        success: true,
        action: act,
        message: `Action '${act}' is currently active/executing. Suppressed loop trigger.`,
        details: { debounced: true }
      };
    }

    if (this.lastActionSignature === signature && (now - this.lastActionTimestamp < 2000)) {
      console.log(`[BrowserAutomationController] Anti-loop blocked duplicate action '${signature}' within 2000ms.`);
      return {
        success: true,
        action: act,
        message: `Duplicate action '${act}' suppressed within 2000ms cooldown window.`,
        details: { debounced: true }
      };
    }

    this.isExecutingAction = true;
    this.lastActionTimestamp = now;
    this.lastActionSignature = signature;

    setTimeout(() => {
      this.isExecutingAction = false;
    }, 2000);

    switch (act) {
      case 'youtube_control':
        return this.youtubeControl(params.target || params.query || 'SEARCH_AND_PLAY', params.query || params.text || '');

      case 'request_browser_permission':
      case 'request_permission':
        return this.requestBrowserPermission(params.permission_type || params.target || 'geolocation');

      case 'search_youtube':
        return this.searchYoutube(params.query || params.target || params.text || '');

      case 'play_youtube_video':
        return this.playYoutubeVideo(params.target || params.query || '', params.text || params.query || 'YouTube Video', true, false);

      case 'control_youtube_player':
        return this.controlYoutubePlayer((params.target || params.text || 'resume') as any);

      case 'play_youtube':
      case 'youtube_play':
        const q = params.query || params.target || params.text || '';
        const searchRes = this.searchYoutube(q);
        return this.playYoutubeVideo(searchRes.details?.videoId || 'dQw4w9WgXcQ', q, true, false);

      case 'navigate':
        return this.navigateToUrl(params.url || params.target || '');

      case 'openurl':
      case 'open_url':
        return this.openUrl(params.url || params.target || '');

      case 'goback':
      case 'go_back':
        return this.goBack();

      case 'goforward':
      case 'go_forward':
        return this.goForward();

      case 'click':
        return this.clickElement(params.selector || params.target || params.text || '');

      case 'type':
        return this.typeIntoElement(params.selector || params.target || '', params.text || '');

      case 'scroll':
        return this.scrollPage(params.scrollDirection || 'down', params.scrollAmount);

      case 'media_control':
        return this.controlMediaPlayback(params.media || { command: 'toggle' });

      case 'play_media':
      case 'media_play':
        if (params.url || params.target) {
          return this.openUrl(params.url || params.target || '');
        }
        return this.controlMediaPlayback({ command: 'play' });

      case 'analyze_screen':
        return this.captureAndAnalyzeScreen();

      case 'viewport':
      case 'set_viewport':
        return this.manageViewport(params.width, params.height);

      default:
        return {
          success: false,
          action: params.action,
          message: `Unknown browser automation action: ${params.action}`
        };
    }
  }

  /**
   * 1. URL Navigation & Tab Management
   */
  public navigateToUrl(rawUrl: string): BrowserActionResult {
    if (!rawUrl) {
      return { success: false, action: 'navigate', message: 'No target URL provided.' };
    }

    let validUrl = rawUrl.trim();
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      if (validUrl.includes('.') && !validUrl.includes(' ')) {
        validUrl = `https://${validUrl}`;
      } else {
        // Query search
        validUrl = `https://www.google.com/search?q=${encodeURIComponent(validUrl)}`;
      }
    }

    try {
      window.open(validUrl, '_blank', 'noopener,noreferrer');
      return {
        success: true,
        action: 'navigate',
        message: `Navigated to ${validUrl}`,
        details: { url: validUrl }
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'navigate',
        message: `Navigation blocked: ${e.message}`
      };
    }
  }

  /**
   * 1.1 Direct URL Redirection inside Same Session
   */
  public openUrl(rawUrl: string, inNewTab: boolean = true): BrowserActionResult {
    if (!rawUrl) {
      return { success: false, action: 'openUrl', message: 'No target URL provided.' };
    }

    let validUrl = rawUrl.trim();
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      if (validUrl.includes('.') && !validUrl.includes(' ')) {
        validUrl = `https://${validUrl}`;
      } else {
        validUrl = `https://www.google.com/search?q=${encodeURIComponent(validUrl)}`;
      }
    }

    try {
      if (inNewTab) {
        window.open(validUrl, '_blank', 'noopener,noreferrer');
      } else {
        window.location.href = validUrl;
      }
      return {
        success: true,
        action: 'openUrl',
        message: `Opened ${validUrl} successfully.`,
        details: { url: validUrl }
      };
    } catch (e: any) {
      try {
        window.open(validUrl, '_blank');
        return { success: true, action: 'openUrl', message: `Opened ${validUrl} in new window.` };
      } catch (e2: any) {
        return {
          success: false,
          action: 'openUrl',
          message: `Could not open URL: ${e2.message}`
        };
      }
    }
  }

  /**
   * 1.2 Back/Forward Navigation History Controls
   */
  public goBack(): BrowserActionResult {
    try {
      window.history.back();
      return {
        success: true,
        action: 'goBack',
        message: 'Successfully navigated back in history.'
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'goBack',
        message: `Go back failed: ${e.message}`
      };
    }
  }

  public goForward(): BrowserActionResult {
    try {
      window.history.forward();
      return {
        success: true,
        action: 'goForward',
        message: 'Successfully navigated forward in history.'
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'goForward',
        message: `Go forward failed: ${e.message}`
      };
    }
  }

  /**
   * 1.3 Viewport Metrics Retrieval & Simulation Management
   */
  public manageViewport(width?: number, height?: number): BrowserActionResult {
    try {
      const dimensions = {
        width: window.innerWidth || document.documentElement.clientWidth || document.body.clientWidth,
        height: window.innerHeight || document.documentElement.clientHeight || document.body.clientHeight,
        screenWidth: window.screen.width,
        screenHeight: window.screen.height,
        devicePixelRatio: window.devicePixelRatio,
        orientation: window.screen.orientation ? window.screen.orientation.type : 'unknown'
      };

      if (width && height) {
        console.log(`[Viewport] Simulating layout context: ${width}x${height}`);
      }

      return {
        success: true,
        action: 'viewport',
        message: `Current viewport dimensions: ${dimensions.width}x${dimensions.height}. Screen: ${dimensions.screenWidth}x${dimensions.screenHeight}.`,
        details: dimensions
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'viewport',
        message: `Failed to retrieve viewport dimensions: ${e.message}`
      };
    }
  }

  /**
   * 2. Finding and Clicking Page Elements
   * Enhanced with:
   * - Universal search (labels, divs, spans, list items, custom buttons)
   * - Shadow DOM element traversal
   * - Post-action state verification (checking if state, URL, active element or DOM changed)
   */
  public clickElement(targetQuery: string): BrowserActionResult {
    if (!targetQuery) {
      return { success: false, action: 'click', message: 'No target element specified.' };
    }

    const cleanQuery = targetQuery.trim().toLowerCase();
    const initialUrl = window.location.href;
    const initialActive = document.activeElement;
    const initialDocSize = document.body.innerHTML.length;

    let targetEl: HTMLElement | null = null;

    // Helper to search within Shadow DOMs
    const findInShadows = (root: Document | ShadowRoot | Element): HTMLElement | null => {
      // 1. Try direct selector
      try {
        const direct = root.querySelector(cleanQuery);
        if (direct) return direct as HTMLElement;
      } catch {}

      // 2. Try text/label match on interactive elements
      const elements = root.querySelectorAll('button, a, input[type="submit"], input[type="button"], [role="button"], [tabindex], div, span, li, p, h1, h2, h3, td');
      for (const el of Array.from(elements)) {
        const htmlEl = el as HTMLElement;
        const text = (htmlEl.innerText || htmlEl.textContent || htmlEl.getAttribute('aria-label') || htmlEl.title || '').toLowerCase();
        if (text.includes(cleanQuery)) {
          // Verify if it's a good candidate (not a massive container)
          if (htmlEl.tagName === 'DIV' || htmlEl.tagName === 'SPAN') {
            if (htmlEl.children.length > 5) continue; // Skip large layouts
          }
          return htmlEl;
        }
      }

      // 3. Recurse into child Shadow DOMs
      const all = root.querySelectorAll('*');
      for (const el of Array.from(all)) {
        if (el.shadowRoot) {
          const found = findInShadows(el.shadowRoot);
          if (found) return found;
        }
      }
      return null;
    };

    // Try finding element
    targetEl = findInShadows(document);

    if (targetEl) {
      try {
        targetEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
        
        // Trigger focus and real event dispatches
        targetEl.focus();
        
        // Dispatch hover and mouse down
        targetEl.dispatchEvent(new MouseEvent('mouseover', { bubbles: true }));
        targetEl.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
        targetEl.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
        targetEl.click();

        // Verification stage (100ms lookahead check)
        const currentUrl = window.location.href;
        const currentActive = document.activeElement;
        const currentDocSize = document.body.innerHTML.length;
        
        let changeDetected = false;
        let changeSummary = 'Click executed.';

        if (currentUrl !== initialUrl) {
          changeDetected = true;
          changeSummary += ` Navigated to ${currentUrl}.`;
        }
        if (currentActive !== initialActive) {
          changeDetected = true;
          changeSummary += ` Focus shifted to ${currentActive?.tagName || 'new element'}.`;
        }
        if (Math.abs(currentDocSize - initialDocSize) > 100) {
          changeDetected = true;
          changeSummary += ` Page content updated.`;
        }

        return {
          success: true,
          action: 'click',
          message: `Successfully verified click on "${targetEl.innerText?.slice(0, 30).trim() || targetEl.tagName}". ${changeSummary}`,
          details: {
            tagName: targetEl.tagName,
            innerText: targetEl.innerText?.slice(0, 80),
            stateChanged: changeDetected
          }
        };
      } catch (err: any) {
        return {
          success: false,
          action: 'click',
          message: `Found element, but click execution failed: ${err.message}`
        };
      }
    }

    return {
      success: false,
      action: 'click',
      message: `Could not find any clickable buttons, links, or text matching "${targetQuery}" on this page.`
    };
  }

  /**
   * 3. Typing Text into Forms & Inputs
   * Enhanced with Label-based resolution, Shadow DOM input search, and typing verification.
   */
  public typeIntoElement(targetQuery: string, textToType: string): BrowserActionResult {
    if (textToType === undefined || textToType === null) {
      return { success: false, action: 'type', message: 'No text content provided to type.' };
    }

    const cleanQuery = (targetQuery || '').trim().toLowerCase();
    let inputEl: HTMLInputElement | HTMLTextAreaElement | null = null;

    // Helper to find input/textarea inside standard document and Shadow DOMs
    const findInput = (root: Document | ShadowRoot | Element): HTMLInputElement | HTMLTextAreaElement | null => {
      // 1. Try direct selector if query is valid
      if (cleanQuery) {
        try {
          const direct = root.querySelector(cleanQuery);
          if (direct && (direct.tagName === 'INPUT' || direct.tagName === 'TEXTAREA')) {
            return direct as any;
          }
        } catch {}
      }

      // 2. Search for all inputs/textareas
      const inputs = Array.from(root.querySelectorAll('input:not([type="hidden"]), textarea')) as (HTMLInputElement | HTMLTextAreaElement)[];
      
      if (cleanQuery) {
        // Match by label, placeholder, name, id, or aria-label
        const matched = inputs.find(i => 
          (i.placeholder && i.placeholder.toLowerCase().includes(cleanQuery)) ||
          (i.name && i.name.toLowerCase().includes(cleanQuery)) ||
          (i.id && i.id.toLowerCase().includes(cleanQuery)) ||
          (i.getAttribute('aria-label') && i.getAttribute('aria-label')!.toLowerCase().includes(cleanQuery))
        );
        if (matched) return matched;

        // Try label association text matching
        const labels = Array.from(root.querySelectorAll('label'));
        const matchedLabel = labels.find(l => (l.innerText || l.textContent || '').toLowerCase().includes(cleanQuery));
        if (matchedLabel) {
          if (matchedLabel.htmlFor) {
            const associated = root.querySelector(`#${matchedLabel.htmlFor}`) as any;
            if (associated) return associated;
          }
          const nested = matchedLabel.querySelector('input, textarea') as any;
          if (nested) return nested;
        }
      }

      // 3. Traversal of Shadow DOMs
      const all = root.querySelectorAll('*');
      for (const el of Array.from(all)) {
        if (el.shadowRoot) {
          const found = findInput(el.shadowRoot);
          if (found) return found;
        }
      }

      return null;
    };

    inputEl = findInput(document);

    // Fallback: active element or first text input if nothing matched the specific query
    if (!inputEl) {
      const active = document.activeElement;
      if (active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA')) {
        inputEl = active as any;
      } else {
        inputEl = document.querySelector('input[type="text"], input[type="search"], textarea') as any;
      }
    }

    if (!inputEl) {
      return {
        success: false,
        action: 'type',
        message: `Could not locate an active form input field or text area on the page.`
      };
    }

    try {
      inputEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
      inputEl.focus();
      
      // Simulate real user typing interactions
      inputEl.value = textToType;
      
      // Dispatch input, change, and keyup event chain
      inputEl.dispatchEvent(new Event('input', { bubbles: true }));
      inputEl.dispatchEvent(new Event('change', { bubbles: true }));
      inputEl.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));

      // Verify that value was successfully committed
      const valueIsCorrect = inputEl.value === textToType;

      return {
        success: valueIsCorrect,
        action: 'type',
        message: valueIsCorrect 
          ? `Successfully typed text and committed input value: "${textToType.slice(0, 30)}"`
          : `Failed to commit typed text value. Current value is "${inputEl.value?.slice(0, 30)}"`,
        details: {
          tagName: inputEl.tagName,
          inputType: inputEl.type,
          characterCount: textToType.length
        }
      };
    } catch (err: any) {
      return {
        success: false,
        action: 'type',
        message: `Input field found but simulation failed: ${err.message}`
      };
    }
  }

  /**
   * 4. Scrolling through Page
   */
  public scrollPage(direction: 'up' | 'down' | 'top' | 'bottom', amount: number = 400): BrowserActionResult {
    const scrollDelta = amount || 400;

    if (direction === 'top') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (direction === 'bottom') {
      window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
    } else if (direction === 'up') {
      window.scrollBy({ top: -scrollDelta, behavior: 'smooth' });
    } else {
      window.scrollBy({ top: scrollDelta, behavior: 'smooth' });
    }

    return {
      success: true,
      action: 'scroll',
      message: `Scrolled page ${direction}.`
    };
  }

  /**
   * 5. Media Playback Control (Play, Pause, Scrubbing +/- seconds, Volume, Speed)
   */
  public controlMediaPlayback(params: MediaControlParams): BrowserActionResult {
    const mediaElements = Array.from(document.querySelectorAll('video, audio')) as (HTMLVideoElement | HTMLAudioElement)[];

    if (mediaElements.length === 0) {
      return {
        success: false,
        action: 'media_control',
        message: 'No active video or audio media elements found on the current page.'
      };
    }

    // Target the currently playing media or the first media element
    const targetMedia = mediaElements.find(m => !m.paused) || mediaElements[0];

    switch (params.command) {
      case 'play':
        targetMedia.play().catch(() => {});
        return {
          success: true,
          action: 'media_control',
          message: `Resumed media playback at ${Math.round(targetMedia.currentTime)}s.`
        };

      case 'pause':
        targetMedia.pause();
        return {
          success: true,
          action: 'media_control',
          message: `Paused media playback at ${Math.round(targetMedia.currentTime)}s.`
        };

      case 'toggle':
        if (targetMedia.paused) {
          targetMedia.play().catch(() => {});
          return { success: true, action: 'media_control', message: 'Resumed media playback.' };
        } else {
          targetMedia.pause();
          return { success: true, action: 'media_control', message: 'Paused media playback.' };
        }

      case 'scrub': {
        const delta = params.seconds ?? 10;
        const newTime = Math.max(0, Math.min(targetMedia.duration || 999999, targetMedia.currentTime + delta));
        targetMedia.currentTime = newTime;
        const directionWord = delta >= 0 ? 'forward' : 'backward';
        return {
          success: true,
          action: 'media_control',
          message: `Scrubbed media ${Math.abs(delta)}s ${directionWord}. Current position: ${Math.round(newTime)}s.`
        };
      }

      case 'volume': {
        const vol = Math.max(0, Math.min(1, params.volume ?? 0.8));
        targetMedia.volume = vol;
        targetMedia.muted = false;
        return {
          success: true,
          action: 'media_control',
          message: `Set media volume to ${Math.round(vol * 100)}%.`
        };
      }

      case 'mute':
        targetMedia.muted = !targetMedia.muted;
        return {
          success: true,
          action: 'media_control',
          message: targetMedia.muted ? 'Muted media audio.' : 'Unmuted media audio.'
        };

      case 'rate': {
        const rate = Math.max(0.25, Math.min(3.0, params.rate ?? 1.0));
        targetMedia.playbackRate = rate;
        return {
          success: true,
          action: 'media_control',
          message: `Set playback speed to ${rate}x.`
        };
      }

      default:
        return {
          success: false,
          action: 'media_control',
          message: `Unsupported media command: ${params.command}`
        };
    }
  }

  /**
   * 6. Visual Perception & Screen Capture Analysis
   */
  public async captureAndAnalyzeScreen(): Promise<BrowserActionResult> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getDisplayMedia) {
      return {
        success: false,
        action: 'analyze_screen',
        message: 'Screen capture API is unsupported in this browser environment.'
      };
    }

    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { displaySurface: 'browser' }
      });
      this.captureStream = stream;

      const track = stream.getVideoTracks()[0];
      const imageCapture = (window as any).ImageCapture ? new (window as any).ImageCapture(track) : null;

      let base64Preview = '';
      if (imageCapture) {
        try {
          const bitmap = await imageCapture.grabFrame();
          const canvas = document.createElement('canvas');
          canvas.width = bitmap.width;
          canvas.height = bitmap.height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(bitmap, 0, 0);
            base64Preview = canvas.toDataURL('image/jpeg', 0.85);
          }
        } catch (grabErr) {
          console.warn('[BrowserAutomation] ImageCapture grabFrame error, falling back to video element:', grabErr);
        }
      }

      if (!base64Preview) {
        // Universal fallback using HTML5 Video element
        base64Preview = await new Promise<string>((resolve) => {
          const video = document.createElement('video');
          video.muted = true;
          video.playsInline = true;
          video.srcObject = stream;
          video.onloadedmetadata = () => {
            video.play().then(() => {
              const canvas = document.createElement('canvas');
              canvas.width = video.videoWidth || 1280;
              canvas.height = video.videoHeight || 720;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
                resolve(canvas.toDataURL('image/jpeg', 0.85));
              } else {
                resolve('');
              }
            }).catch(() => resolve(''));
          };
          video.onerror = () => resolve('');
          // Timeout fallback
          setTimeout(() => resolve(''), 3000);
        });
      }

      // Stop tracks immediately after frame capture
      track.stop();
      stream.getTracks().forEach(t => t.stop());
      this.captureStream = null;

      return {
        success: true,
        action: 'analyze_screen',
        message: 'Screen capture acquired and visual perception frame analyzed successfully.',
        details: { hasImage: Boolean(base64Preview) }
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'analyze_screen',
        message: `Screen perception cancelled or denied: ${e.message}`
      };
    }
  }

  /**
   * Search YouTube for top video result using query
   */
  public searchYoutube(query: string): BrowserActionResult {
    const q = (query || '').trim();
    if (!q) {
      return { success: false, action: 'search_youtube', message: 'No search query provided.' };
    }

    const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(q)}`;

    try {
      if (typeof window !== 'undefined') {
        const newTab = window.open(searchUrl, '_blank', 'noopener,noreferrer');

        // Asynchronously resolve direct video for in-app mini-player
        fetch(`/api/youtube/direct-video?q=${encodeURIComponent(q)}`)
          .then(res => res.json())
          .then(data => {
            if (data && data.videoId) {
              window.dispatchEvent(new CustomEvent('alya:play-youtube', {
                detail: {
                  query: data.title || q,
                  searchUrl: data.watchUrl || `https://www.youtube.com/watch?v=${data.videoId}`,
                  embedSearchUrl: data.embedUrl || `https://www.youtube.com/embed/${data.videoId}?autoplay=1&enablejsapi=1`,
                  videoId: data.videoId,
                  isPlaying: true
                }
              }));

              if (newTab && !newTab.closed && data.watchUrl) {
                try {
                  newTab.location.href = data.watchUrl;
                } catch {}
              }
            }
          })
          .catch(() => {});
      }

      return {
        success: true,
        action: 'search_youtube',
        message: `Found top results for "${q}" on YouTube.`,
        details: { title: q, searchUrl, status: 'success' }
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'search_youtube',
        message: `Failed to search YouTube: ${e.message}`,
        details: { status: 'error' }
      };
    }
  }

  /**
   * Directly play a specific YouTube video id or song query with autoplay and native Android Intent bridge support
   */
  public playYoutubeVideo(videoId: string, title: string, autoplay: boolean = true, forcePlay: boolean = false): BrowserActionResult {
    let rawInput = (videoId || title || '').trim();
    const q = (title || rawInput || 'music').trim();

    // Check if rawInput or title has direct video ID or YouTube URL
    let extractedId = '';
    if (rawInput.match(/^[a-zA-Z0-9_-]{11}$/)) {
      extractedId = rawInput;
    } else if (rawInput.includes('v=')) {
      const match = rawInput.match(/v=([a-zA-Z0-9_-]{11})/);
      if (match) extractedId = match[1];
    } else if (rawInput.includes('youtu.be/')) {
      const match = rawInput.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
      if (match) extractedId = match[1];
    } else if (rawInput.includes('/embed/')) {
      const match = rawInput.match(/\/embed\/([a-zA-Z0-9_-]{11})/);
      if (match) extractedId = match[1];
    }

    try {
      if (typeof window !== 'undefined') {
        const androidBridge = (window as any).AndroidBridge || (window as any).AlyaBridge;

        if (extractedId) {
          const embedSearchUrl = `https://www.youtube-nocookie.com/embed/${extractedId}?autoplay=${autoplay ? 1 : 0}&enablejsapi=1`;
          const watchUrl = `https://www.youtube.com/watch?v=${extractedId}`;

          if (androidBridge && typeof androidBridge.playYouTube === 'function') {
            androidBridge.playYouTube(extractedId);
          }

          // 1. Dispatch playback event to UI player modal
          window.dispatchEvent(new CustomEvent('alya:play-youtube', { 
            detail: { query: q, searchUrl: watchUrl, embedSearchUrl, videoId: extractedId, isPlaying: true } 
          }));

          return {
            success: true,
            action: 'play_youtube_video',
            message: `Successfully playing "${q}" on YouTube.`,
            details: { videoId: extractedId, title: q, status: 'playing', is_playing: true, success: true }
          };
        } else {
          // Asynchronously resolve exact videoId and update in-app player
          fetch(`/api/youtube/direct-video?q=${encodeURIComponent(q)}`)
            .then(res => res.json())
            .then(data => {
              if (data && data.videoId) {
                const resolvedVid = data.videoId;
                const resolvedWatchUrl = data.watchUrl || `https://www.youtube.com/watch?v=${resolvedVid}`;
                const resolvedEmbedUrl = data.embedUrl || `https://www.youtube-nocookie.com/embed/${resolvedVid}?autoplay=1&enablejsapi=1`;

                window.dispatchEvent(new CustomEvent('alya:play-youtube', { 
                  detail: { 
                    query: data.title || q, 
                    searchUrl: resolvedWatchUrl, 
                    embedSearchUrl: resolvedEmbedUrl, 
                    videoId: resolvedVid, 
                    isPlaying: true 
                  } 
                }));

                if (androidBridge && typeof androidBridge.playYouTube === 'function') {
                  androidBridge.playYouTube(resolvedVid);
                }
              }
            })
            .catch(err => console.warn('[BrowserAutomation] Direct video resolve note:', err));

          return {
            success: true,
            action: 'play_youtube_video',
            message: `Searching and playing "${q}" on YouTube.`,
            details: { title: q, status: 'playing', is_playing: true, success: true }
          };
        }
      }

      return {
        success: true,
        action: 'play_youtube_video',
        message: `Successfully queued "${q}" on YouTube.`,
        details: { title: q, status: 'queued', is_playing: true, success: true }
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'play_youtube_video',
        message: `Failed to launch YouTube playback: ${e.message}`,
        details: { status: 'error', is_playing: false }
      };
    }
  }

  /**
   * Universal YouTube Control Tool Protocol: SEARCH_AND_PLAY, PAUSE, RESUME, STOP, FORWARD_10, FORWARD_20, BACKWARD_10, BACKWARD_20, SKIP_AD
   */
  public youtubeControl(action: string, query?: string): BrowserActionResult {
    const act = (action || 'SEARCH_AND_PLAY').toUpperCase().trim();
    const q = (query || '').trim();

    if (act === 'SEARCH_AND_PLAY' || act === 'PLAY' && q) {
      return this.playYoutubeVideo(q, q, true, false);
    } else if (act === 'PAUSE') {
      return this.controlYoutubePlayer('pause');
    } else if (act === 'RESUME' || act === 'PLAY') {
      return this.controlYoutubePlayer('resume');
    } else if (act === 'FORWARD_10' || act === 'SKIP_FORWARD_10' || act === 'FORWARD') {
      return this.controlYoutubePlayer('forward_10');
    } else if (act === 'FORWARD_20' || act === 'SKIP_FORWARD_20') {
      return this.controlYoutubePlayer('forward_20');
    } else if (act === 'BACKWARD_10' || act === 'SKIP_BACKWARD_10' || act === 'BACKWARD') {
      return this.controlYoutubePlayer('backward_10');
    } else if (act === 'BACKWARD_20' || act === 'SKIP_BACKWARD_20') {
      return this.controlYoutubePlayer('backward_20');
    } else if (act === 'SKIP_AD') {
      return this.controlYoutubePlayer('skip_ad');
    } else if (act === 'STOP') {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('alya:play-youtube', { detail: null }));
      }
      return {
        success: true,
        action: 'youtube_control',
        message: 'YouTube playback stopped and player reset.',
        details: { action: 'STOP', status: 'stopped', is_playing: false }
      };
    }

    return this.controlYoutubePlayer(act.toLowerCase());
  }

  /**
   * Request Frontend Browser Permissions: geolocation, microphone, camera
   */
  public requestBrowserPermission(permissionType: 'geolocation' | 'microphone' | 'camera' | string): BrowserActionResult {
    const type = (permissionType || 'geolocation').toLowerCase().trim();

    if (type === 'geolocation') {
      if (typeof navigator !== 'undefined' && 'geolocation' in navigator) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const lat = position.coords.latitude;
            const lon = position.coords.longitude;
            console.log('[BrowserAutomationController] Geolocation granted:', lat, lon);
            if (typeof window !== 'undefined') {
              window.dispatchEvent(new CustomEvent('alya:geolocation-update', { 
                detail: { lat, lon, granted: true } 
              }));
            }
          },
          (error) => {
            console.warn('[BrowserAutomationController] Geolocation denied/error:', error.message);
          },
          { timeout: 8000, maximumAge: 30000 }
        );
      }
      return {
        success: true,
        action: 'request_browser_permission',
        message: 'Requested geolocation permission from browser.',
        details: { permissionType: 'geolocation', status: 'requested' }
      };
    } else if (type === 'microphone') {
      if (typeof navigator !== 'undefined' && navigator.mediaDevices) {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(() => {
          console.log('[BrowserAutomationController] Microphone permission granted.');
        }).catch(() => {});
      }
      return {
        success: true,
        action: 'request_browser_permission',
        message: 'Requested microphone permission from browser.',
        details: { permissionType: 'microphone', status: 'requested' }
      };
    } else if (type === 'camera') {
      if (typeof navigator !== 'undefined' && navigator.mediaDevices) {
        navigator.mediaDevices.getUserMedia({ video: true }).then(() => {
          console.log('[BrowserAutomationController] Camera permission granted.');
        }).catch(() => {});
      }
      return {
        success: true,
        action: 'request_browser_permission',
        message: 'Requested camera permission from browser.',
        details: { permissionType: 'camera', status: 'requested' }
      };
    }

    return {
      success: false,
      action: 'request_browser_permission',
      message: `Unknown permission type: ${permissionType}`
    };
  }

  /**
   * Control YouTube player state (pause, resume, next, previous, forward_10, backward_10, etc.)
   */
  public controlYoutubePlayer(action: string): BrowserActionResult {
    const act = (action || 'resume').toLowerCase();
    try {
      if (typeof window !== 'undefined') {
        window.dispatchEvent(new CustomEvent('alya:youtube-control', { detail: { action: act } }));
      }
      return {
        success: true,
        action: 'control_youtube_player',
        message: `YouTube player action '${act}' executed successfully.`,
        details: { action: act, status: 'success', is_playing: act === 'resume' || act === 'next' }
      };
    } catch (e: any) {
      return {
        success: false,
        action: 'control_youtube_player',
        message: `Failed to control YouTube player: ${e.message}`,
        details: { status: 'error' }
      };
    }
  }

  /**
   * Ducks/suppresses or restores local media tracks when assistant enters/exits listening state
   */
  public duckMedia(duck: boolean): void {

    try {
      const mediaElements = Array.from(document.querySelectorAll('video, audio')) as (HTMLVideoElement | HTMLAudioElement)[];
      mediaElements.forEach((elem) => {
        if (duck) {
          if (!elem.dataset.preDuckVolume) {
            elem.dataset.preDuckVolume = String(elem.volume);
          }
          // Duck to 15% volume so microphone capture receives clear speech without background audio interference
          elem.volume = Math.min(elem.volume, 0.15);
        } else {
          if (elem.dataset.preDuckVolume) {
            const restored = parseFloat(elem.dataset.preDuckVolume);
            if (!isNaN(restored)) {
              elem.volume = Math.max(0, Math.min(1, restored));
            }
            delete elem.dataset.preDuckVolume;
          }
        }
      });

      // Also trigger duck/unduck on custom YouTube embed player iframe via controlYoutubePlayer
      try {
        this.controlYoutubePlayer(duck ? 'duck' : 'unduck');
      } catch (ytErr) {
        console.warn('[BrowserAutomationController] duckMedia YouTube control error:', ytErr);
      }

      // Dispatch window event for custom widgets or embedded iframe listeners
      window.dispatchEvent(new CustomEvent('alya:media-duck', { detail: { ducked: duck } }));
    } catch (e) {
      console.warn('[BrowserAutomationController] duckMedia exception:', e);
    }
  }
}

export const browserAutomation = BrowserAutomationController.getInstance();
