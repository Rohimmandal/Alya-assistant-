import React, { createContext, useContext, useEffect, useState, useMemo, useCallback } from 'react';
import { z } from 'zod';
import { 
  userSettingsService, 
  UserPreferences, 
  SettingChangeLogEntry 
} from './userSettingsService';
import { useAuth } from './AuthContext';
import { secureStorage } from './secureStorage';
import { geminiClient, getActiveApiKey } from './geminiClient';
import { apiKeyManager } from './ApiKeyManager';

// Zod Schema to safely validate Google Gemini API key format
export const geminiApiKeySchema = z.string().trim().refine((key) => {
  if (!key) return true; // empty keys are allowed for shared server fallbacks
  return (key.startsWith('AIza') || key.startsWith('AQ.')) && key.length >= 25 && key.length <= 70;
}, {
  message: "Invalid Gemini API Key format. Key should start with 'AIza' or 'AQ.' and be a valid length."
});

export interface GlobalSettingsContextType {
  preferences: UserPreferences;
  history: SettingChangeLogEntry[];
  updatePreferences: (
    updates: Partial<UserPreferences>, 
    source?: 'web_ui' | 'android_companion' | 'conversational_command' | 'cloud_sync'
  ) => Promise<{ success: boolean; preferences: UserPreferences; error?: string }>;
  resetAllSettings: () => Promise<UserPreferences>;
  preferredLanguage: string;
  
  // Zod-validated Gemini API key state & safer mutation actions
  geminiApiKey: string;
  updateGeminiApiKey: (newKey: string) => Promise<{ success: boolean; error?: string }>;
}

export const GlobalSettingsContext = createContext<GlobalSettingsContextType | null>(null);

export function GlobalSettingsProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [preferences, setPreferences] = useState<UserPreferences>(() => userSettingsService.getPreferences());
  const [history, setHistory] = useState<SettingChangeLogEntry[]>(() => userSettingsService.getHistory());
  
  // API Key State from localStorage baseline
  const [geminiApiKey, setGeminiApiKey] = useState<string>(() => {
    return getActiveApiKey();
  });

  useEffect(() => {
    if (user?.uid) {
      userSettingsService.initialize(user.uid);
    }
  }, [user?.uid]);

  useEffect(() => {
    const unsub = userSettingsService.subscribe((updated) => {
      setPreferences(updated);
      setHistory(userSettingsService.getHistory());
    });
    return unsub;
  }, []);

  // Sync API Key state and safely validate with Zod when changed elsewhere in application
  useEffect(() => {
    const handleKeyChange = async () => {
      try {
        const rawKey = await secureStorage.getSecureApiKey();
        const parsed = geminiApiKeySchema.parse(rawKey || '');
        setGeminiApiKey(parsed);
      } catch (err) {
        console.warn('[GlobalSettings] API Key storage validation warning:', err);
      }
    };

    window.addEventListener('alya:api-key-updated', handleKeyChange);
    // Initial fetch
    handleKeyChange();

    return () => window.removeEventListener('alya:api-key-updated', handleKeyChange);
  }, []);

  const updatePrefs = useCallback(async (
    updates: Partial<UserPreferences>, 
    source?: 'web_ui' | 'android_companion' | 'conversational_command' | 'cloud_sync'
  ) => {
    return userSettingsService.updatePreferences(updates, source);
  }, []);

  const resetPrefs = useCallback(async () => {
    return userSettingsService.resetAllSettings();
  }, []);

  // Update Gemini API key securely with Zod schema validation and safe client re-initialization
  const updateGeminiApiKey = useCallback(async (newKey: string) => {
    try {
      const cleanKey = (newKey || '').trim();
      const validatedKey = geminiApiKeySchema.parse(cleanKey);

      // Safe client re-initialization - persists to user_gemini_api_key, localStorage, and secure storage
      await geminiClient.setApiKey(validatedKey);
      
      setGeminiApiKey(validatedKey);
      
      // Broadcast update
      window.dispatchEvent(new CustomEvent('alya:api-key-updated'));
      
      return { success: true };
    } catch (err: any) {
      console.warn('[GlobalSettings] API Key validation failed:', err);
      return { 
        success: false, 
        error: err instanceof z.ZodError ? err.issues[0]?.message : (err.message || 'Validation failed') 
      };
    }
  }, []);

  const preferredLanguage = useMemo(() => {
    return preferences.language || 'auto';
  }, [preferences.language]);

  const value = useMemo(() => ({
    preferences,
    history,
    updatePreferences: updatePrefs,
    resetAllSettings: resetPrefs,
    preferredLanguage,
    geminiApiKey,
    updateGeminiApiKey
  }), [preferences, history, updatePrefs, resetPrefs, preferredLanguage, geminiApiKey, updateGeminiApiKey]);

  return (
    <GlobalSettingsContext.Provider value={value}>
      {children}
    </GlobalSettingsContext.Provider>
  );
}

export function useGlobalSettings(): GlobalSettingsContextType {
  const context = useContext(GlobalSettingsContext);
  if (!context) {
    // Graceful fallback to raw userSettingsService and secureStorage if accessed outside provider
    const fallbackPrefs = userSettingsService.getPreferences();
    return {
      preferences: fallbackPrefs,
      history: userSettingsService.getHistory(),
      updatePreferences: (updates, source) => userSettingsService.updatePreferences(updates, source),
      resetAllSettings: () => userSettingsService.resetAllSettings(),
      preferredLanguage: fallbackPrefs.language || 'auto',
      geminiApiKey: getActiveApiKey(),
      updateGeminiApiKey: async (newKey) => {
        try {
          const cleanKey = (newKey || '').trim();
          const parsed = geminiApiKeySchema.parse(cleanKey);
          await geminiClient.setApiKey(parsed);
          return { success: true };
        } catch (err: any) {
          return { 
            success: false, 
            error: err instanceof z.ZodError ? err.issues[0]?.message : (err?.message || 'Validation failed') 
          };
        }
      }
    };
  }
  return context;
}
