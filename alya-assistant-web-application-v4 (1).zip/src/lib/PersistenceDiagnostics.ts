/**
 * PersistenceDiagnostics.ts
 * Monitors and logs all database read/write lifecycle events in the persistence layer.
 * Specifically checks for correct association with authenticated user ID and session ID.
 */

export type DBEventAction = 'READ' | 'WRITE' | 'DELETE' | 'SUBSCRIBE' | 'FLUSH';

export interface PersistenceEvent {
  id: string;
  timestamp: number;
  action: DBEventAction;
  path: string;
  userId: string;
  sessionId: string;
  status: 'STARTED' | 'COMPLETED' | 'FAILED';
  payload?: any;
  error?: string;
  durationMs?: number;
}

export class PersistenceDiagnostics {
  private static events: PersistenceEvent[] = [];
  private static listeners: ((event: PersistenceEvent) => void)[] = [];

  public static log(params: Omit<PersistenceEvent, 'id' | 'timestamp' | 'status'>): string {
    const eventId = `db_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const event: PersistenceEvent = {
      ...params,
      id: eventId,
      timestamp: Date.now(),
      status: 'STARTED'
    };

    // Critical check: Ensure userId and sessionId are present for conversation turns
    if (params.path.includes('messages') || params.path.includes('conversations')) {
      if (!params.userId || params.userId === 'unknown' || params.userId === 'default_user') {
        console.warn(`[PersistenceDiagnostics] Warning: Potential orphaned DB operation detected at ${params.path}. userId is "${params.userId}"`);
      }
      if (!params.sessionId || params.sessionId === 'unknown') {
        console.warn(`[PersistenceDiagnostics] Warning: Missing sessionId for operation at ${params.path}`);
      }
    }

    this.pushEvent(event);
    return eventId;
  }

  public static complete(eventId: string, details?: { payload?: any; durationMs?: number }) {
    const index = this.events.findIndex(e => e.id === eventId);
    if (index !== -1) {
      this.events[index] = {
        ...this.events[index],
        status: 'COMPLETED',
        ...details
      };
      this.notify(this.events[index]);
    }
  }

  public static fail(eventId: string, error: string) {
    const index = this.events.findIndex(e => e.id === eventId);
    if (index !== -1) {
      this.events[index] = {
        ...this.events[index],
        status: 'FAILED',
        error
      };
      this.notify(this.events[index]);
      console.error(`[PersistenceDiagnostics] DB Operation Failed: ${error}`, this.events[index]);
    }
  }

  private static pushEvent(event: PersistenceEvent) {
    this.events.push(event);
    if (this.events.length > 500) this.events.shift();
    this.notify(event);
  }

  private static notify(event: PersistenceEvent) {
    this.listeners.forEach(l => l(event));
  }

  public static subscribe(listener: (event: PersistenceEvent) => void) {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter(l => l !== listener);
    };
  }

  public static getHistory() {
    return [...this.events];
  }
}
