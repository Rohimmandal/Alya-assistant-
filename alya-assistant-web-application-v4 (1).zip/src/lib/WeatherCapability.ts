/**
 * WeatherCapability.ts
 * Weather Capability Module for Alya Assistant.
 * Fetches real-time local weather data using reliable Open-Meteo APIs based on current user coordinates
 * and integrates with natural language querying.
 */

import { weatherService, FullWeatherData, WeatherFetchResult } from '../services/weatherService';
import { locationManager } from './LocationManager';

export class WeatherCapability {
  /**
   * Fetches real-time local weather based on the current user coordinates or city query
   */
  public static async fetchCurrentWeather(cityQuery?: string): Promise<WeatherFetchResult> {
    try {
      if (!cityQuery) {
        const currentLoc = locationManager.getCurrentContext();
        if (currentLoc && currentLoc.latitude && currentLoc.longitude) {
          const name = [currentLoc.locality, currentLoc.region, currentLoc.country].filter(Boolean).join(', ');
          return await weatherService.getWeatherByCoordinates(currentLoc.latitude, currentLoc.longitude, name);
        }
      }

      return await weatherService.getWeatherForRequest(cityQuery);
    } catch (err: any) {
      return {
        success: false,
        error: `Weather capability failure: ${err.message || err}`
      };
    }
  }

  /**
   * Generates a natural language summary of current weather conditions
   */
  public static formatWeatherSummary(data: FullWeatherData): string {
    const { current, locationContext } = data;
    const locationStr = locationContext.locality || locationContext.country || 'your area';
    return `Right now in ${locationStr}, it is ${current.condition.description} with a temperature of ${current.temperature}°C (feels like ${current.feelsLike}°C). Humidity is ${current.humidity}%, and wind speed is ${current.windSpeed} km/h.`;
  }
}
