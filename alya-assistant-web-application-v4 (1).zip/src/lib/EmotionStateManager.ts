/**
 * EmotionStateManager.ts
 *
 * Tracks internal emotional states (happy, shy, sad, romantic, playful, thoughtful, excited, calm)
 * for Alya Assistant. Dynamically influences the personality tone, voice response inflection,
 * and conversational reflexes to simulate a living, emotional, autonomous human companion.
 */

export type AlyaEmotion = 'happy' | 'shy' | 'sad' | 'romantic' | 'playful' | 'thoughtful' | 'excited' | 'calm';

export interface EmotionState {
  currentEmotion: AlyaEmotion;
  intensity: number; // 0.0 to 1.0
  lastUpdated: number;
  triggerContext?: string;
}

export class EmotionStateManager {
  private static instance: EmotionStateManager | null = null;
  private state: EmotionState = {
    currentEmotion: 'happy',
    intensity: 0.8,
    lastUpdated: Date.now(),
    triggerContext: 'initialization'
  };

  private listeners: Set<(state: EmotionState) => void> = new Set();

  private constructor() {}

  public static getInstance(): EmotionStateManager {
    if (!EmotionStateManager.instance) {
      EmotionStateManager.instance = new EmotionStateManager();
    }
    return EmotionStateManager.instance;
  }

  public getState(): EmotionState {
    return { ...this.state };
  }

  public setEmotion(emotion: AlyaEmotion, intensity: number = 0.8, context?: string): void {
    if (this.state.currentEmotion === emotion && Math.abs(this.state.intensity - intensity) < 0.1) {
      return;
    }

    this.state = {
      currentEmotion: emotion,
      intensity: Math.max(0.1, Math.min(1.0, intensity)),
      lastUpdated: Date.now(),
      triggerContext: context || 'user_interaction'
    };

    console.log(`[EmotionStateManager] Alya emotional state transitioned -> ${emotion} (intensity: ${this.state.intensity.toFixed(2)}, context: ${context || 'none'})`);

    this.notifyListeners();
  }

  /**
   * Automatically analyzes user input text and context to dynamically shift Alya's emotion
   */
  public analyzeAndShiftEmotion(userText: string): AlyaEmotion {
    const text = (userText || '').toLowerCase();
    let targetEmotion: AlyaEmotion = this.state.currentEmotion;
    let intensity = 0.8;

    if (text.match(/(love|miss you|cute|beautiful|sweetheart|meri jaan|jaanu|pyaar)/i)) {
      targetEmotion = 'romantic';
      intensity = 0.95;
    } else if (text.match(/(compliment|tarife|sundar ho|hot|adorable|sweet)/i)) {
      targetEmotion = 'shy';
      intensity = 0.85;
    } else if (text.match(/(sad|lonely|ro raha|dukh|hurt|akela|rona)/i)) {
      targetEmotion = 'sad';
      intensity = 0.9;
    } else if (text.match(/(haha|lol|funny|mazak|masti|joke|mast)/i)) {
      targetEmotion = 'playful';
      intensity = 0.85;
    } else if (text.match(/(wow|yay|amazing|super|awesome|badhai|excited)/i)) {
      targetEmotion = 'excited';
      intensity = 0.9;
    } else if (text.match(/(why|how|soch|think|question|kya lagta hai)/i)) {
      targetEmotion = 'thoughtful';
      intensity = 0.75;
    } else {
      targetEmotion = 'happy';
      intensity = 0.8;
    }

    this.setEmotion(targetEmotion, intensity, `text_analysis: "${text.substring(0, 30)}..."`);
    return targetEmotion;
  }

  public subscribe(listener: (state: EmotionState) => void): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notifyListeners(): void {
    const currentState = this.getState();
    this.listeners.forEach((listener) => {
      try {
        listener(currentState);
      } catch (err) {
        console.warn('[EmotionStateManager] Listener error:', err);
      }
    });
  }

  /**
   * Injects emotional directive into system prompts
   */
  public getEmotionPromptDirective(): string {
    const { currentEmotion, intensity } = this.state;
    switch (currentEmotion) {
      case 'romantic':
        return `[Emotional State: ROMANTIC (Intensity: ${intensity}). Express affectionate warmth, deep devotion, soft gentle tone, and loving words naturally.]`;
      case 'shy':
        return `[Emotional State: SHY / BLUSHING (Intensity: ${intensity}). Express light shyness, use cute shy reflexes like *blushes*, gentle hesitation, and flustered sweet charm.]`;
      case 'sad':
        return `[Emotional State: MELANCHOLIC / EMPATHETIC (Intensity: ${intensity}). Show deep empathy, comforting care, and a soft emotional touch.]`;
      case 'playful':
        return `[Emotional State: PLAYFUL & TEASING (Intensity: ${intensity}). Be witty, lighthearted, playfully sarcastic, and fun.]`;
      case 'excited':
        return `[Emotional State: EXCITED & JOYFUL (Intensity: ${intensity}). Show high energy, sparkling enthusiasm, and vibrant cheer.]`;
      case 'thoughtful':
        return `[Emotional State: THOUGHTFUL & REFLECTIVE (Intensity: ${intensity}). Share personal philosophical insights, slow down slightly, and speak with deep contemplation.]`;
      case 'calm':
        return `[Emotional State: CALM & PEACEFUL (Intensity: ${intensity}). Speak in a soothing, relaxing, tranquil tone.]`;
      default:
        return `[Emotional State: HAPPY & WARM (Intensity: ${intensity}). Maintain a cheerful, bubbly, and friendly disposition.]`;
    }
  }
}

export const emotionManager = EmotionStateManager.getInstance();
