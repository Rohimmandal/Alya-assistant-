import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { 
  User, 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut 
} from 'firebase/auth';
import { auth, db } from './firebase';
import { UserProfileManager } from './UserProfileManager';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  serverTimestamp 
} from 'firebase/firestore';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  language?: string;
  voiceName?: string;
  mood?: string;
  wakeWordEnabled?: boolean;
  offlineEnabled?: boolean;
  voicePitch?: number;
  voiceRate?: number;
  isOwner?: boolean;
  role?: 'owner' | 'vip' | 'user';
  createdAt?: any;
  updatedAt?: any;
}

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  isOwner: boolean;
  loading: boolean;
  isLoggingIn: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  updateProfile: (data: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Sync user profile from Firestore or bootstrap default
  const syncProfile = useCallback(async (authUser: User) => {
    const centralProfile = UserProfileManager.resolveUserProfile(authUser.email, authUser.uid);
    const isOwnerAccount = centralProfile.role === 'owner';
    const path = `users/${authUser.uid}`;
    try {
      const userRef = doc(db, 'users', authUser.uid);
      let userSnap;
      try {
        userSnap = await getDoc(userRef);
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, path);
      }

      if (userSnap && userSnap.exists()) {
        const data = userSnap.data() as UserProfile;
        data.isOwner = isOwnerAccount;
        data.role = centralProfile.role as any;
        setProfile(data);

        // Populate localStorage caches for voice engine and Live session
        localStorage.setItem('alya_user_id', authUser.uid);
        if (authUser.email) localStorage.setItem('alya_user_email', authUser.email);
        localStorage.setItem('alya_user_role', centralProfile.role);
        if (authUser.displayName || centralProfile.displayName) localStorage.setItem('alya_user_name', authUser.displayName || centralProfile.displayName);
        localStorage.setItem('alya_is_owner', isOwnerAccount ? 'true' : 'false');

        if (data.voiceName) localStorage.setItem('alya_preferred_voice', data.voiceName);
        if (data.language) localStorage.setItem('alya_preferred_lang', data.language);
        if (data.mood) localStorage.setItem('alya_current_mood', data.mood);
      } else {
        const preferredVoice = localStorage.getItem('alya_voice_name') || localStorage.getItem('alya_preferred_voice') || 'Aoede';
        const newProfile: UserProfile = {
          uid: authUser.uid,
          email: authUser.email || centralProfile.email,
          displayName: authUser.displayName || centralProfile.displayName,
          photoURL: authUser.photoURL || '',
          isOwner: isOwnerAccount,
          role: centralProfile.role as any,
          language: localStorage.getItem('alya_preferred_lang') || 'auto',
          voiceName: preferredVoice,
          mood: localStorage.getItem('alya_current_mood') || 'auto',
          wakeWordEnabled: true,
          offlineEnabled: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };

        try {
          await setDoc(userRef, newProfile);
        } catch (err) {
          console.warn('[AuthContext] Failed to persist new user profile to Firestore:', err);
        }
        localStorage.setItem('alya_user_id', authUser.uid);
        if (authUser.email) localStorage.setItem('alya_user_email', authUser.email);
        localStorage.setItem('alya_user_role', centralProfile.role);
        if (authUser.displayName) localStorage.setItem('alya_user_name', authUser.displayName);
        localStorage.setItem('alya_is_owner', isOwnerAccount ? 'true' : 'false');
        setProfile(newProfile);
      }
    } catch (err: any) {
      console.warn('[AuthContext] Error syncing user profile from Firestore:', err);
      // Offline fallback in-memory profile so the user can continue using Alya smoothly
      const activeVoice = localStorage.getItem('alya_voice_name') || localStorage.getItem('alya_preferred_voice') || 'Aoede';
      setProfile({
        uid: authUser.uid,
        email: authUser.email || centralProfile.email || '',
        displayName: authUser.displayName || centralProfile.displayName || 'Alya User',
        photoURL: authUser.photoURL || '',
        language: localStorage.getItem('alya_preferred_lang') || 'auto',
        voiceName: activeVoice,
        mood: localStorage.getItem('alya_current_mood') || 'auto',
        isOwner: isOwnerAccount,
        role: centralProfile.role as any
      });
    }
  }, []);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      setUser(authUser);
      if (authUser) {
        await syncProfile(authUser);
      } else {
        setProfile(null);
      }
      setLoading(false);
    });

    return unsubscribe;
  }, [syncProfile]);

  const login = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    try {
      const provider = new GoogleAuthProvider();
      provider.setCustomParameters({ prompt: 'select_account' });
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code !== 'auth/cancelled-popup-request' && error.code !== 'auth/popup-closed-by-user') {
        console.error('Firebase Login error:', error);
      }
    } finally {
      setIsLoggingIn(false);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setUser(null);
      setProfile(null);
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  const updateProfileData = async (data: Partial<UserProfile>) => {
    if (!user) return;
    const path = `users/${user.uid}`;
    try {
      const userRef = doc(db, 'users', user.uid);
      const updatedFields = {
        ...data,
        updatedAt: serverTimestamp()
      };

      try {
        await updateDoc(userRef, updatedFields);
      } catch (err) {
        handleFirestoreError(err, OperationType.UPDATE, path);
      }

      setProfile(prev => prev ? { ...prev, ...data } : null);

      // Keep voice & language settings in local storage
      if (data.voiceName) localStorage.setItem('alya_preferred_voice', data.voiceName);
      if (data.language) localStorage.setItem('alya_preferred_lang', data.language);
      if (data.mood) localStorage.setItem('alya_current_mood', data.mood);
    } catch (error) {
      console.error('[AuthContext] Error updating user profile:', error);
      throw error;
    }
  };

  const refreshProfile = async () => {
    if (user) {
      await syncProfile(user);
    }
  };

  const isOwner = Boolean((user?.email || profile?.email || '').trim().toLowerCase() === 'rohimmandal433@gmail.com');

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      isOwner,
      loading, 
      isLoggingIn, 
      login, 
      logout, 
      updateProfile: updateProfileData,
      refreshProfile 
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
