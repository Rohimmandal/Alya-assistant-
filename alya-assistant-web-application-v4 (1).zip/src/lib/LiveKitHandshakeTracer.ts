/**
 * LiveKitHandshakeTracer.ts
 * 
 * Diagnostic utility that logs the full WebSocket handshake sequence for LiveKit,
 * including connection parameters, request/response headers representation,
 * and high-precision timing (ms) to identify silent failures during connection.
 */

import { liveKitDiagnosticService } from './LiveKitDiagnosticService';

export interface HandshakeTraceEvent {
  step: 'INIT' | 'TOKEN_FETCH' | 'WS_CONNECTING' | 'WS_OPEN' | 'WS_ERROR' | 'WS_CLOSE' | 'TIMEOUT';
  timestamp: number;
  elapsedMs: number;
  details?: Record<string, any>;
}

export class LiveKitHandshakeTracer {
  private static activeTraces: Map<string, { startTime: number; events: HandshakeTraceEvent[]; url: string }> = new Map();

  /**
   * Starts tracing a new LiveKit or WebSocket fallback handshake sequence
   */
  public static startTrace(traceId: string, url: string, metadata?: Record<string, any>): void {
    const startTime = performance.now();
    const event: HandshakeTraceEvent = {
      step: 'INIT',
      timestamp: Date.now(),
      elapsedMs: 0,
      details: { url: url.replace(/apiKey=[^&]+/, 'apiKey=***'), ...metadata }
    };

    this.activeTraces.set(traceId, {
      startTime,
      events: [event],
      url
    });

    liveKitDiagnosticService.log('info', 'network', `[HandshakeTracer] [${traceId}] Handshake initiated for URL: ${url}`, { traceId, ...metadata }, traceId);
  }

  /**
   * Records a milestone step in the handshake sequence with precise timing
   */
  public static recordStep(
    traceId: string, 
    step: HandshakeTraceEvent['step'], 
    details?: Record<string, any>
  ): void {
    const trace = this.activeTraces.get(traceId);
    if (!trace) return;

    const elapsedMs = Math.round((performance.now() - trace.startTime) * 100) / 100;
    const event: HandshakeTraceEvent = {
      step,
      timestamp: Date.now(),
      elapsedMs,
      details
    };

    trace.events.push(event);

    const level = step === 'WS_ERROR' || step === 'TIMEOUT' ? 'error' : step === 'WS_CLOSE' ? 'warn' : 'info';
    liveKitDiagnosticService.log(level, 'network', `[HandshakeTracer] [${traceId}] Step [${step}] at +${elapsedMs}ms`, {
      traceId,
      step,
      elapsedMs,
      ...details
    }, traceId);

    if (step === 'WS_OPEN' || step === 'WS_ERROR' || step === 'WS_CLOSE' || step === 'TIMEOUT') {
      // Log summary
      console.log(`[LiveKitHandshakeTracer] Trace summary for ${traceId}:`, {
        totalDurationMs: elapsedMs,
        eventsCount: trace.events.length,
        events: trace.events
      });
    }
  }

  /**
   * Retrieves full trace history for diagnostics inspection
   */
  public static getTrace(traceId: string): { startTime: number; events: HandshakeTraceEvent[]; url: string } | undefined {
    return this.activeTraces.get(traceId);
  }

  public static getAllTraces(): Record<string, any> {
    const obj: Record<string, any> = {};
    this.activeTraces.forEach((val, key) => {
      obj[key] = val;
    });
    return obj;
  }
}
