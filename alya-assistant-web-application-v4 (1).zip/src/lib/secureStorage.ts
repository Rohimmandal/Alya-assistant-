/**
 * Alya Assistant - Secure Client-Side Encrypted Storage
 * 
 * Provides AES-GCM 256-bit hardware/WebCrypto encryption for sensitive credentials (e.g. Gemini API Keys).
 * Ensures that private API keys are never stored in plaintext on disk, and are only decrypted in-memory
 * when authenticating active Gemini Live WebSocket streams or REST requests.
 */

const STORAGE_KEY_ENCRYPTED_GEMINI = 'alya_sec_enc_gemini_key_v1';
const STORAGE_KEY_ENCRYPTED_OPENAI = 'alya_sec_enc_openai_key_v1';
const STORAGE_KEY_SALT = 'alya_sec_salt_v1';
const STORAGE_KEY_LEGACY = 'alya_gemini_api_key';

interface EncryptedPayload {
  iv: string; // Base64
  cipherText: string; // Base64
  timestamp: number;
}

export interface ApiKeyVerificationResult {
  valid: boolean;
  message: string;
  modelsCount?: number;
  latencyMs?: number;
}

export type Provider = 'gemini' | 'openai';

class SecureStorageService {
  private inMemoryDecryptedKeys: Record<Provider, string | null> = { gemini: null, openai: null };
  private isInitialized = false;
  private initPromise: Promise<void> | null = null;

  constructor() {
    if (typeof window !== 'undefined') {
      this.initPromise = this.initialize();
    }
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;
    try {
      // Check for legacy unencrypted Gemini key and migrate if present
      const legacyKey = localStorage.getItem(STORAGE_KEY_LEGACY);
      const hasEncryptedGemini = !!localStorage.getItem(STORAGE_KEY_ENCRYPTED_GEMINI);

      if (legacyKey && !hasEncryptedGemini) {
        console.log('[SecureStorage] Migrating legacy unencrypted Gemini API key...');
        await this.saveSecureApiKey('gemini', legacyKey);
        localStorage.removeItem(STORAGE_KEY_LEGACY);
      }
      this.isInitialized = true;
    } catch (err) {
      console.warn('[SecureStorage] Initialization / migration warning:', err);
    }
  }

  private getStorageKey(provider: Provider): string {
    return provider === 'gemini' ? STORAGE_KEY_ENCRYPTED_GEMINI : STORAGE_KEY_ENCRYPTED_OPENAI;
  }

  private async getDerivationKey(salt: Uint8Array): Promise<CryptoKey> {
    const encoder = new TextEncoder();
    const entropyMaterial = `${window.location.host}-alya-device-vault-${salt.join('.')}`;
    const baseKey = await window.crypto.subtle.importKey(
      'raw',
      encoder.encode(entropyMaterial),
      { name: 'PBKDF2' },
      false,
      ['deriveKey']
    );

    return window.crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt as any,
        iterations: 100000,
        hash: 'SHA-256'
      },
      baseKey,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  private getOrCreateSalt(): Uint8Array {
    const saved = localStorage.getItem(STORAGE_KEY_SALT);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return new Uint8Array(parsed);
      } catch { }
    }
    const newSalt = window.crypto.getRandomValues(new Uint8Array(16));
    localStorage.setItem(STORAGE_KEY_SALT, JSON.stringify(Array.from(newSalt)));
    return newSalt;
  }

  public async saveSecureApiKey(providerOrKey: Provider | string, optionalKey?: string): Promise<boolean> {
    let provider: Provider = 'gemini';
    let rawKey = '';

    if (optionalKey !== undefined) {
      provider = providerOrKey as Provider;
      rawKey = optionalKey;
    } else {
      rawKey = providerOrKey;
    }

    const trimmed = (rawKey || '').trim();
    if (!trimmed) {
      await this.clearSecureApiKey(provider);
      return true;
    }

    try {
      const salt = this.getOrCreateSalt();
      const cryptoKey = await this.getDerivationKey(salt);
      const iv = window.crypto.getRandomValues(new Uint8Array(12));
      const encoded = new TextEncoder().encode(trimmed);

      const cipherBuffer = await window.crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv as any },
        cryptoKey,
        encoded
      );

      const payload: EncryptedPayload = {
        iv: this.arrayBufferToBase64(iv.buffer),
        cipherText: this.arrayBufferToBase64(cipherBuffer),
        timestamp: Date.now()
      };

      localStorage.setItem(this.getStorageKey(provider), JSON.stringify(payload));
      this.inMemoryDecryptedKeys[provider] = trimmed;

      window.dispatchEvent(new CustomEvent(`alya:api-key-updated:${provider}`, { detail: { hasKey: true } }));
      return true;
    } catch (err) {
      console.error(`[SecureStorage] Failed to encrypt/save ${provider} API key:`, err);
      throw new Error(`Encryption failure. Could not secure ${provider} API key.`);
    }
  }

  private arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = window.atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  public getDecryptedApiKeySync(provider: Provider = 'gemini'): string {
    return this.inMemoryDecryptedKeys[provider] || '';
  }

  public async getSecureApiKey(provider: Provider = 'gemini'): Promise<string> {
    if (this.inMemoryDecryptedKeys[provider]) {
      return this.inMemoryDecryptedKeys[provider]!;
    }

    const rawPayload = localStorage.getItem(this.getStorageKey(provider));
    if (!rawPayload) return '';

    try {
      const payload: EncryptedPayload = JSON.parse(rawPayload);
      const salt = this.getOrCreateSalt();
      const cryptoKey = await this.getDerivationKey(salt);
      const iv = new Uint8Array(this.base64ToArrayBuffer(payload.iv));
      const cipherBuffer = this.base64ToArrayBuffer(payload.cipherText);

      const decryptedBuffer = await window.crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: iv as any },
        cryptoKey,
        cipherBuffer
      );

      const decrypted = new TextDecoder().decode(decryptedBuffer);
      this.inMemoryDecryptedKeys[provider] = decrypted;
      return decrypted;
    } catch (err) {
      console.warn(`[SecureStorage] Failed to decrypt ${provider} API key:`, err);
      return '';
    }
  }

  public async clearSecureApiKey(provider: Provider = 'gemini'): Promise<void> {
    localStorage.removeItem(this.getStorageKey(provider));
    this.inMemoryDecryptedKeys[provider] = null;
    window.dispatchEvent(new CustomEvent(`alya:api-key-updated:${provider}`, { detail: { hasKey: false } }));
  }

  public hasSecureApiKey(provider: Provider = 'gemini'): boolean {
    return (
      !!this.inMemoryDecryptedKeys[provider] ||
      !!localStorage.getItem(this.getStorageKey(provider))
    );
  }

  public async verifyApiKeyQuota(key: string, provider: Provider = 'gemini'): Promise<ApiKeyVerificationResult> {
    const trimmed = key.trim();
    if (!trimmed) {
      return { valid: false, message: 'API key is empty.' };
    }

    const start = Date.now();
    try {
      if (provider === 'gemini') {
        const url = `https://generativelanguage.googleapis.com/v1beta/models?key=${trimmed}`;
        const res = await fetch(url);
        const latencyMs = Date.now() - start;

        if (res.ok) {
          const data = await res.json();
          const count = Array.isArray(data?.models) ? data.models.length : 0;
          return { valid: true, message: `Active & Validated (${count} models available)`, modelsCount: count, latencyMs };
        } else if (res.status === 400 || res.status === 403 || res.status === 401) {
          return { valid: false, message: 'Invalid API key or unauthorized access.' };
        } else if (res.status === 429) {
          return { valid: false, message: 'Rate limit or quota exhausted for this key (HTTP 429).' };
        } else {
          return { valid: false, message: `Validation returned status ${res.status}.` };
        }
      } else {
        const res = await fetch('https://api.openai.com/v1/models', {
          headers: { Authorization: `Bearer ${trimmed}` }
        });
        const latencyMs = Date.now() - start;
        if (res.ok) {
          const data = await res.json();
          const count = Array.isArray(data?.data) ? data.data.length : 0;
          return { valid: true, message: `Active & Validated (${count} models available)`, modelsCount: count, latencyMs };
        } else if (res.status === 401) {
          return { valid: false, message: 'Incorrect or invalid OpenAI API key.' };
        } else if (res.status === 429) {
          return { valid: false, message: 'OpenAI quota exceeded or rate limited (HTTP 429).' };
        } else {
          return { valid: false, message: `Validation returned status ${res.status}.` };
        }
      }
    } catch (err: any) {
      return { valid: false, message: err.message || 'Network error during key verification.' };
    }
  }

  public maskApiKey(key: string): string {
    if (!key) return '';
    if (key.length <= 10) return '••••••••••';
    const start = key.slice(0, 6);
    const end = key.slice(-4);
    const middleDots = '•'.repeat(Math.max(6, key.length - 10));
    return `${start}${middleDots}${end}`;
  }

  public validateApiKeyFormat(providerOrKey: Provider | string, optionalKey?: string): { valid: boolean; reason?: string } {
    let provider: Provider = 'gemini';
    let key = '';

    if (optionalKey !== undefined) {
      provider = providerOrKey as Provider;
      key = optionalKey;
    } else {
      key = providerOrKey;
    }

    const trimmed = (key || '').trim();
    if (!trimmed) return { valid: false, reason: 'Key is empty' };
    
    if (provider === 'gemini') {
      if (!trimmed.startsWith('AIza') && !trimmed.startsWith('AQ.')) return { valid: false, reason: 'Gemini keys usually begin with "AIza" or "AQ."' };
      if (trimmed.length < 25 || trimmed.length > 70) return { valid: false, reason: 'Invalid Gemini key length' };
    } else if (provider === 'openai') {
      if (!trimmed.startsWith('sk-')) return { valid: false, reason: 'OpenAI keys usually begin with "sk-"' };
    }
    
    return { valid: true };
  }
}

export const secureStorage = new SecureStorageService();

