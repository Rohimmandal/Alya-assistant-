/**
 * Alya Assistant - Google Generative AI Client Manager & Global API Error Handler
 *
 * Responsibilities:
 * 1. Securely manages user-provided Gemini API key in localStorage & encrypted storage.
 * 2. Dynamically instantiates and re-instantiates GoogleGenAI client upon key update.
 * 3. Provides global error classification and handling for 401 (Invalid Key),
 *    403 (Permission Denied), and 429 (Rate Limited / Quota Exceeded) errors.
 * 4. Dispatches global events to notify UI components (ChatView, Settings, LoginView).
 */

import { GoogleGenAI } from '@google/genai';
import { apiKeyManager, getActiveApiKey, GEMINI_API_KEY_STORAGE_KEY } from './ApiKeyManager';
import { secureStorage } from './secureStorage';

export { GEMINI_API_KEY_STORAGE_KEY, getActiveApiKey };

export interface GeminiApiErrorInfo {
  status: 401 | 403 | 429 | 500 | number;
  type: 'invalid_key' | 'rate_limited' | 'permission_denied' | 'server_error' | 'network_error';
  title: string;
  message: string;
  timestamp: number;
}

class GeminiClientManager {
  private static instance: GeminiClientManager | null = null;
  private aiClient: GoogleGenAI | null = null;
  private lastUsedKey: string = '';
  private lastError: GeminiApiErrorInfo | null = null;

  private constructor() {
    this.initClient();
  }

  public static getInstance(): GeminiClientManager {
    if (!GeminiClientManager.instance) {
      GeminiClientManager.instance = new GeminiClientManager();
    }
    return GeminiClientManager.instance;
  }

  private initClient(): void {
    const key = getActiveApiKey();
    if (key) {
      this.instantiateClient(key);
    }
  }

  private instantiateClient(apiKey: string): GoogleGenAI {
    this.lastUsedKey = apiKey;
    this.aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: { 'User-Agent': 'aistudio-build' }
      }
    });
    return this.aiClient;
  }

  public getClient(): GoogleGenAI {
    const currentKey = getActiveApiKey();
    if (!this.aiClient || this.lastUsedKey !== currentKey) {
      this.instantiateClient(currentKey || 'default');
    }
    return this.aiClient!;
  }

  public getApiKey(): string {
    return getActiveApiKey();
  }

  public async setApiKey(newKey: string): Promise<void> {
    await apiKeyManager.setApiKey(newKey);
    const updatedKey = getActiveApiKey();
    this.instantiateClient(updatedKey);
    this.lastError = null;
  }


  /**
   * Global Error Classifier & Handler for Gemini API Requests
   * Categorizes 401, 403, 429, and network errors, providing structured user feedback.
   */
  public handleApiError(error: any, context?: string): GeminiApiErrorInfo {
    let status = 500;
    let type: GeminiApiErrorInfo['type'] = 'server_error';
    let title = 'AI Engine Notice';
    let message = error?.message || 'An unexpected error occurred while communicating with Gemini.';

    const rawMsg = String(error?.message || error || '').toLowerCase();
    const statusCode = error?.status || error?.statusCode || error?.response?.status;

    if (statusCode === 401 || rawMsg.includes('401') || rawMsg.includes('api_key_invalid') || rawMsg.includes('unauthenticated')) {
      status = 401;
      type = 'invalid_key';
      title = 'Invalid Gemini API Key';
      message = 'Your Gemini API key appears invalid or expired. Please update it in Settings or Login screen.';
    } else if (statusCode === 403 || rawMsg.includes('403') || rawMsg.includes('permission_denied')) {
      status = 403;
      type = 'permission_denied';
      title = 'Permission Denied';
      message = 'Your Gemini API key lacks required permissions or project access. Check your Google AI Studio project settings.';
    } else if (statusCode === 429 || rawMsg.includes('429') || rawMsg.includes('resource_exhausted') || rawMsg.includes('quota exceeded')) {
      status = 429;
      type = 'rate_limited';
      title = 'Rate Limited / Quota Exceeded';
      message = 'You have reached the Gemini API rate limit or free tier quota. Please wait a moment or use a paid/custom API key in Settings.';
    } else if (rawMsg.includes('fetch') || rawMsg.includes('network') || error?.name === 'TypeError') {
      status = 0;
      type = 'network_error';
      title = 'Connection Blip';
      message = 'Could not reach the server. Please check your internet connection and try again.';
    }

    const errorInfo: GeminiApiErrorInfo = {
      status,
      type,
      title,
      message,
      timestamp: Date.now()
    };

    this.lastError = errorInfo;

    // Dispatch global event for UI components to display graceful toast/banner
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('alya:api-error', { detail: errorInfo }));
    }

    return errorInfo;
  }

  public getLastError(): GeminiApiErrorInfo | null {
    return this.lastError;
  }

  public clearLastError(): void {
    this.lastError = null;
  }
}

export const geminiClient = GeminiClientManager.getInstance();
