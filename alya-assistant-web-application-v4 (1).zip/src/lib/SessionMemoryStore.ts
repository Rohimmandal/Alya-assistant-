/**
 * SessionMemoryStore.ts
 * Persists conversation context into Firestore and local cache,
 * ensuring seamless re-joining of live rooms with full past context and state retention.
 */

import { db } from './firebase';
import { doc, setDoc, getDoc, collection, getDocs, query, orderBy, limit } from 'firebase/firestore';
import { ConversationStore, UnifiedConversationState } from './ConversationStore';

export interface SessionMemoryRecord {
  userId: string;
  conversationId: string;
  state: Partial<UnifiedConversationState>;
  lastUpdated: number;
}

export class SessionMemoryStore {
  private static STORAGE_PREFIX = 'alya_session_memory_';

  /**
   * Persists active session state to Firestore and local fallback cache.
   */
  public static async saveSessionMemory(userId: string, conversationId: string, state: Partial<UnifiedConversationState>): Promise<void> {
    const record: SessionMemoryRecord = {
      userId,
      conversationId,
      state,
      lastUpdated: Date.now()
    };

    // 1. Cache locally
    if (typeof window !== 'undefined') {
      try {
        localStorage.setItem(`${this.STORAGE_PREFIX}_${userId}_${conversationId}`, JSON.stringify(record));
        localStorage.setItem(`alya_active_conversation_id`, conversationId);
      } catch (e) {
        console.warn('[SessionMemoryStore] LocalStorage cache save warning:', e);
      }
    }

    // 2. Persist to Firestore
    try {
      if (db) {
        const sessionRef = doc(db, 'users', userId, 'sessions', conversationId);
        await setDoc(sessionRef, {
          userId,
          conversationId,
          state: JSON.stringify(state),
          lastUpdated: new Date()
        }, { merge: true });
      }
    } catch (e) {
      console.warn('[SessionMemoryStore] Firestore session persist warning (using local fallback):', e);
    }
  }

  /**
   * Loads session memory from Firestore or local cache.
   */
  public static async loadSessionMemory(userId: string, conversationId: string): Promise<Partial<UnifiedConversationState> | null> {
    // 1. Attempt Firestore fetch
    try {
      if (db) {
        const sessionRef = doc(db, 'users', userId, 'sessions', conversationId);
        const snap = await getDoc(sessionRef);
        if (snap.exists()) {
          const data = snap.data();
          if (data && data.state) {
            const parsedState = typeof data.state === 'string' ? JSON.parse(data.state) : data.state;
            ConversationStore.getInstance().updateState(parsedState);
            return parsedState;
          }
        }
      }
    } catch (e) {
      console.warn('[SessionMemoryStore] Firestore load session warning:', e);
    }

    // 2. Fallback to LocalStorage cache
    if (typeof window !== 'undefined') {
      try {
        const localData = localStorage.getItem(`${this.STORAGE_PREFIX}_${userId}_${conversationId}`);
        if (localData) {
          const record: SessionMemoryRecord = JSON.parse(localData);
          if (record && record.state) {
            ConversationStore.getInstance().updateState(record.state);
            return record.state;
          }
        }
      } catch (e) {
        console.warn('[SessionMemoryStore] LocalStorage cache load warning:', e);
      }
    }

    return null;
  }

  /**
   * Retrieves the most recent active session for a user across room rejoins.
   */
  public static async getLatestActiveSession(userId: string): Promise<{ conversationId: string; state: Partial<UnifiedConversationState> } | null> {
    try {
      if (db) {
        const sessionsRef = collection(db, 'users', userId, 'sessions');
        const q = query(sessionsRef, orderBy('lastUpdated', 'desc'), limit(1));
        const querySnap = await getDocs(q);
        if (!querySnap.empty) {
          const docSnap = querySnap.docs[0];
          const data = docSnap.data();
          if (data && data.state) {
            const parsedState = typeof data.state === 'string' ? JSON.parse(data.state) : data.state;
            return {
              conversationId: data.conversationId || docSnap.id,
              state: parsedState
            };
          }
        }
      }
    } catch (e) {
      console.warn('[SessionMemoryStore] Get latest active session warning:', e);
    }

    // Local fallback
    if (typeof window !== 'undefined') {
      try {
        const activeConvId = localStorage.getItem('alya_active_conversation_id');
        if (activeConvId) {
          const localData = localStorage.getItem(`${this.STORAGE_PREFIX}_${userId}_${activeConvId}`);
          if (localData) {
            const record: SessionMemoryRecord = JSON.parse(localData);
            return {
              conversationId: activeConvId,
              state: record.state
            };
          }
        }
      } catch (e) {}
    }

    return null;
  }
}
