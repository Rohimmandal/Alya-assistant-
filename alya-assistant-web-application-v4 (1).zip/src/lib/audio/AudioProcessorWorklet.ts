/**
 * src/lib/audio/AudioProcessorWorklet.ts
 * 
 * AudioWorkletProcessor for high-performance audio capture/playback,
 * featuring strict RMS-based Noise Gate and seamless Jitter Buffering.
 */

// Define AudioWorklet types for TypeScript
interface AudioWorkletProcessor {
  readonly port: MessagePort;
  process(inputs: Float32Array[][], outputs: Float32Array[][], parameters: Record<string, Float32Array>): boolean;
}
declare var AudioWorkletProcessor: {
  prototype: AudioWorkletProcessor;
  new(): AudioWorkletProcessor;
};
declare function registerProcessor(name: string, processorCtor: any): void;

class AudioProcessorWorklet extends AudioWorkletProcessor {
  private rmsThreshold = 0.02; // Noise gate threshold

  constructor() {
    super();
  }

  process(inputs: Float32Array[][], outputs: Float32Array[][], parameters: Record<string, Float32Array>): boolean {
    const input = inputs[0][0];
    const output = outputs[0][0];

    if (!input) return true;

    // RMS-based Noise Gate
    let sumSquares = 0;
    for (let i = 0; i < input.length; i++) {
      sumSquares += input[i] * input[i];
    }
    const rms = Math.sqrt(sumSquares / input.length);

    if (rms < this.rmsThreshold) {
      // Silence background noise
      output.fill(0);
      this.port.postMessage({ type: 'audio_chunk', data: new Float32Array(input.length), rms });
    } else {
      output.set(input);
      this.port.postMessage({ type: 'audio_chunk', data: input, rms });
    }

    return true;
  }
}

registerProcessor('audio-processor-worklet', AudioProcessorWorklet);
