/**
 * src/lib/audio/Processor.ts
 * 
 * High-performance AudioProcessingQueue utilizing a high-precision circular sample buffer
 * with a 40ms target threshold to absorb layout rendering or network-induced main thread blockages.
 */

export class AudioProcessingQueue {
  private buffer: Float32Array;
  private capacity: number;
  private writePtr: number = 0;
  private readPtr: number = 0;
  private size: number = 0;
  
  private sampleRate: number;
  private targetDurationMs: number;
  private targetSize: number;

  constructor(sampleRate: number = 24000, targetDurationMs: number = 40) {
    this.sampleRate = sampleRate;
    this.targetDurationMs = targetDurationMs;
    // Calculate precise target size (e.g. 40ms at 24kHz is 960 samples)
    this.targetSize = Math.round(sampleRate * (targetDurationMs / 1000));
    
    // Allocate 4x the target size for ample headroom during high-latency jitter events
    this.capacity = this.targetSize * 4;
    this.buffer = new Float32Array(this.capacity);
  }

  /**
   * Writes Float32 PCM samples into the circular audio queue
   */
  public write(samples: Float32Array): void {
    const len = samples.length;
    if (len === 0) return;

    // Overrun prevention: if incoming write exceeds capacity, flush old samples
    if (this.size + len > this.capacity) {
      const excess = (this.size + len) - this.capacity;
      this.readPtr = (this.readPtr + excess) % this.capacity;
      this.size = Math.max(0, this.size - excess);
    }

    for (let i = 0; i < len; i++) {
      this.buffer[this.writePtr] = samples[i];
      this.writePtr = (this.writePtr + 1) % this.capacity;
    }

    this.size += len;
  }

  /**
   * Reads samples from the circular audio queue into the output array
   */
  public read(outBuffer: Float32Array): number {
    const toRead = Math.min(outBuffer.length, this.size);
    if (toRead === 0) return 0;

    for (let i = 0; i < toRead; i++) {
      outBuffer[i] = this.buffer[this.readPtr];
      this.readPtr = (this.readPtr + 1) % this.capacity;
    }

    this.size -= toRead;
    return toRead;
  }

  /**
   * Checks if we have met the target buffering threshold (40ms target)
   */
  public hasTargetThreshold(): boolean {
    return this.size >= this.targetSize;
  }

  public getBufferedSize(): number {
    return this.size;
  }

  public getBufferedDurationMs(): number {
    return (this.size / this.sampleRate) * 1000;
  }

  public clear(): void {
    this.writePtr = 0;
    this.readPtr = 0;
    this.size = 0;
    this.buffer.fill(0);
  }
}
