/**
 * src/lib/audio/JitterBuffer.ts
 * 
 * High-precision JitterBuffer manager that tracks network packet arrival times,
 * dynamically estimates network jitter/delay variance using RFC 3550-inspired algorithm,
 * and automatically adjusts play latency offsets to prevent audio starvation or buffer latency build-up.
 */

export class JitterBuffer {
  private lastArrivalTimestamp: number | null = null;
  private estimatedJitterMs: number = 0;
  private readonly alpha = 0.125; // EWMA filter constant (RTP standard)
  
  // Median filter for jitter estimation to ignore outliers
  private jitterHistory: number[] = [];
  private readonly MAX_HISTORY = 20;

  // Dynamic Latency bounds (in milliseconds)
  private readonly MIN_DELAY_MS = 80;    // Adjusted slightly higher for stability
  private readonly MAX_DELAY_MS = 450;   // Increased headroom for mobile networks
  private currentDelayMs: number = 150;  // Higher initial baseline

  private packetCount: number = 0;
  private totalInterArrivalTimeMs: number = 0;

  /**
   * Tracks a new network packet arrival and computes inter-arrival jitter
   */
  public trackPacketArrival(): void {
    const now = performance.now();
    this.packetCount++;

    if (this.lastArrivalTimestamp !== null) {
      const interArrivalTime = now - this.lastArrivalTimestamp;
      this.totalInterArrivalTimeMs += interArrivalTime;

      // 1. Calculate Instantaneous Jitter
      const averageArrival = this.totalInterArrivalTimeMs / this.packetCount;
      const difference = Math.abs(interArrivalTime - averageArrival);
      
      // 2. Apply EWMA Filter
      this.estimatedJitterMs = this.estimatedJitterMs + (difference - this.estimatedJitterMs) * this.alpha;

      // 3. Track History for Median calculation (Resilience against network spikes)
      this.jitterHistory.push(difference);
      if (this.jitterHistory.length > this.MAX_HISTORY) {
        this.jitterHistory.shift();
      }

      const medianJitter = this.calculateMedian(this.jitterHistory);

      // 4. Compute Target Delay with Safety Buffer
      // We use a combination of EWMA and Median for robustness
      const stableJitter = Math.max(this.estimatedJitterMs, medianJitter);
      
      const targetDelay = Math.max(
        this.MIN_DELAY_MS,
        Math.min(this.MAX_DELAY_MS, stableJitter * 2.8 + 60)
      );

      // 5. Smooth Adaptation (Asymmetric: faster increase to prevent starvation, slower decrease)
      const adaptationRate = targetDelay > this.currentDelayMs ? 0.2 : 0.05;
      this.currentDelayMs = this.currentDelayMs + (targetDelay - this.currentDelayMs) * adaptationRate;
    }

    this.lastArrivalTimestamp = now;
  }

  private calculateMedian(values: number[]): number {
    if (values.length === 0) return 0;
    const sorted = [...values].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;
  }

  /**
   * Returns the dynamically adjusted playback offset in seconds
   */
  public getDynamicOffsetSeconds(): number {
    return this.currentDelayMs / 1000;
  }

  public getCurrentDelayMs(): number {
    return this.currentDelayMs;
  }

  public getPacketLossPercent(): number {
    if (this.packetCount < 10) return 0;
    // Estimate packet loss based on inter-arrival spikes exceeding threshold (> 120ms gap)
    const recentSpikes = this.jitterHistory.filter(j => j > 120).length;
    const loss = (recentSpikes / Math.max(1, this.jitterHistory.length)) * 2.5;
    return Math.min(15, Math.round(loss * 10) / 10);
  }

  public getEstimatedJitterMs(): number {
    return this.estimatedJitterMs;
  }

  public reset(): void {
    this.lastArrivalTimestamp = null;
    this.estimatedJitterMs = 0;
    this.packetCount = 0;
    this.totalInterArrivalTimeMs = 0;
    this.currentDelayMs = 150;
    this.jitterHistory = [];
  }
}
