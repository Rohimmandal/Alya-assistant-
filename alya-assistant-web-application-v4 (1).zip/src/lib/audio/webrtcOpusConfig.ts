/**
 * src/lib/audio/webrtcOpusConfig.ts
 * 
 * WebRTC Opus Codec and DTX (Discontinuous Transmission) Configuration Utility.
 * Prioritizes Opus codec and enables usedtx=1 and useinbandfec=1 in SDP string 
 * to minimize bandwidth usage and latency during quiet periods in live conversations.
 */

export class WebRTCOpusConfig {
  /**
   * Configures an active RTCPeerConnection to prioritize Opus and enable DTX.
   */
  public static configureConnection(pc: RTCPeerConnection): void {
    try {
      const transceivers = pc.getTransceivers();
      for (const transceiver of transceivers) {
        if (transceiver.sender && transceiver.sender.track && transceiver.sender.track.kind === 'audio') {
          const params = transceiver.sender.getParameters();
          if (params.codecs) {
            // Prioritize Opus codec if available
            params.codecs.sort((a, b) => {
              if (a.mimeType.toLowerCase().includes('opus')) return -1;
              if (b.mimeType.toLowerCase().includes('opus')) return 1;
              return 0;
            });
            transceiver.sender.setParameters(params).catch(() => {});
          }
        }
      }
      console.log('[WebRTCOpusConfig] Opus codec prioritized on peer connection audio transceivers.');
    } catch (err) {
      console.warn('[WebRTCOpusConfig] Error configuring transceiver parameters:', err);
    }
  }

  /**
   * Modifies an SDP string to force Opus DTX (usedtx=1) and inband FEC (useinbandfec=1)
   */
  public static enableOpusDTXInSDP(sdp: string): string {
    if (!sdp) return sdp;

    const lines = sdp.split('\r\n');
    let opusPayloadType: string | null = null;

    // 1. Find Opus payload type from rtpmap
    for (const line of lines) {
      if (line.startsWith('a=rtpmap:') && line.toLowerCase().includes('opus/')) {
        const parts = line.substring(9).split(' ');
        opusPayloadType = parts[0];
        break;
      }
    }

    if (!opusPayloadType) {
      return sdp; // Opus not found in SDP
    }

    const fmtpString = `a=fmtp:${opusPayloadType} minptime=10;useinbandfec=1;usedtx=1`;
    let fmtpFound = false;

    const newLines = lines.map(line => {
      if (line.startsWith(`a=fmtp:${opusPayloadType}`)) {
        fmtpFound = true;
        // Append usedtx=1 and useinbandfec=1 if not already present
        let updated = line;
        if (!updated.includes('usedtx=1')) {
          updated += ';usedtx=1';
        }
        if (!updated.includes('useinbandfec=1')) {
          updated += ';useinbandfec=1';
        }
        return updated;
      }
      return line;
    });

    // If fmtp line for opus wasn't found, insert it right after rtpmap for opus
    if (!fmtpFound) {
      const finalLines: string[] = [];
      for (const line of newLines) {
        finalLines.push(line);
        if (line.startsWith('a=rtpmap:') && line.toLowerCase().includes('opus/')) {
          finalLines.push(fmtpString);
        }
      }
      return finalLines.join('\r\n');
    }

    return newLines.join('\r\n');
  }
}
