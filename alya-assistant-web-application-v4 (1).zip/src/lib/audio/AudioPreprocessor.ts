/**
 * AudioPreprocessor.ts
 * Real-time audio preprocessing module for user voice detection,
 * vocal band focusing, noise reduction, and gain normalization.
 */

export interface PreprocessorOptions {
  sampleRate?: number;
  highpassFreq?: number;
  lowpassFreq?: number;
  enableNoiseGate?: boolean;
  enableAGC?: boolean;
  targetRMS?: number;
}

export class AudioPreprocessor {
  private sampleRate: number;
  private highpassFreq: number;
  private lowpassFreq: number;
  private enableNoiseGate: boolean;
  private enableAGC: boolean;
  private targetRMS: number;
  private estimatedNoiseFloor: number = 0.005;
  private currentGateGain: number = 1.0;

  private mode: 'speaking' | 'listening' | 'idle' = 'idle';

  constructor(options: PreprocessorOptions = {}) {
    this.sampleRate = options.sampleRate || 16000;
    this.highpassFreq = options.highpassFreq || 100;
    this.lowpassFreq = options.lowpassFreq || 3200;
    this.enableNoiseGate = options.enableNoiseGate ?? true;
    this.enableAGC = options.enableAGC ?? true;
    this.targetRMS = options.targetRMS || 0.12;
  }

  /**
   * Dynamically adjusts preprocessor filters and noise reduction threshold based on assistant state
   */
  public setMode(mode: 'speaking' | 'listening' | 'idle'): void {
    this.mode = mode;
    if (mode === 'speaking') {
      // While assistant is speaking, tighten bandpass to 120Hz-3000Hz and increase gate threshold
      // to eliminate speaker room feedback while preserving clear human vocal barge-in
      this.highpassFreq = 120;
      this.lowpassFreq = 3000;
    } else if (mode === 'listening') {
      // While listening to user, expand bandpass to 85Hz-3400Hz and enable optimal AGC gain
      this.highpassFreq = 85;
      this.lowpassFreq = 3400;
    } else {
      this.highpassFreq = 85;
      this.lowpassFreq = 3200;
    }
  }

  /**
   * Constructs Web Audio BiquadFilterNode chain for WebAudio pipelines
   */
  public attachFilterNodes(audioCtx: AudioContext, sourceNode: AudioNode): {
    inputNode: AudioNode;
    outputNode: AudioNode;
    highpassNode: BiquadFilterNode;
    lowpassNode: BiquadFilterNode;
    compressorNode: DynamicsCompressorNode;
  } {
    const highpass = audioCtx.createBiquadFilter();
    highpass.type = 'highpass';
    highpass.frequency.setValueAtTime(this.highpassFreq, audioCtx.currentTime);
    highpass.Q.setValueAtTime(0.707, audioCtx.currentTime);

    const lowpass = audioCtx.createBiquadFilter();
    lowpass.type = 'lowpass';
    lowpass.frequency.setValueAtTime(this.lowpassFreq, audioCtx.currentTime);
    lowpass.Q.setValueAtTime(0.707, audioCtx.currentTime);

    // Voice dynamics compressor for gain normalization and vocal focus
    const compressor = audioCtx.createDynamicsCompressor();
    compressor.threshold.setValueAtTime(-24, audioCtx.currentTime);
    compressor.knee.setValueAtTime(12, audioCtx.currentTime);
    compressor.ratio.setValueAtTime(4, audioCtx.currentTime);
    compressor.attack.setValueAtTime(0.003, audioCtx.currentTime);
    compressor.release.setValueAtTime(0.25, audioCtx.currentTime);

    sourceNode.connect(highpass);
    highpass.connect(lowpass);
    lowpass.connect(compressor);

    return {
      inputNode: highpass,
      outputNode: compressor,
      highpassNode: highpass,
      lowpassNode: lowpass,
      compressorNode: compressor
    };
  }

  /**
   * Preprocesses raw PCM Float32 audio samples: applies adaptive noise gate,
   * spectral noise floor subtraction, and automatic gain control.
   */
  public processFloat32Chunk(inputSamples: Float32Array): Float32Array {
    const len = inputSamples.length;
    if (len === 0) return inputSamples;

    const output = new Float32Array(len);

    // 1. Calculate RMS Energy of frame
    let sumSquares = 0;
    for (let i = 0; i < len; i++) {
      sumSquares += inputSamples[i] * inputSamples[i];
    }
    const currentRMS = Math.sqrt(sumSquares / len);

    // 2. Update noise floor estimation adaptively during quiet frames
    if (currentRMS < this.estimatedNoiseFloor * 2) {
      this.estimatedNoiseFloor = 0.95 * this.estimatedNoiseFloor + 0.05 * currentRMS;
    } else {
      // Slow upward tracking to adapt to continuous background noise (e.g., fans or background music)
      this.estimatedNoiseFloor = 0.999 * this.estimatedNoiseFloor + 0.001 * currentRMS;
    }

    // 3. Compute Adaptive Gain Factor for AGC
    let agcGain = 1.0;
    if (this.enableAGC && currentRMS > this.estimatedNoiseFloor * 1.5) {
      agcGain = Math.min(4.0, Math.max(0.5, this.targetRMS / (currentRMS + 1e-6)));
    }

    // 4. Process samples with aggressive noise gate threshold and spectral noise suppression
    const gateMultiplier = this.mode === 'speaking' ? 4.0 : this.mode === 'listening' ? 2.2 : 2.5;
    const gateThreshold = this.estimatedNoiseFloor * gateMultiplier;

    // Harder expansion/attenuation factor for complete silence during background noise intervals
    const targetGateGain = (this.enableNoiseGate && currentRMS < gateThreshold) ? 0.0 : 1.0;
    
    // Smooth gate gain with fast attack and natural release coefficients
    if (targetGateGain > this.currentGateGain) {
      this.currentGateGain = 0.8 * this.currentGateGain + 0.2 * targetGateGain;
    } else {
      this.currentGateGain = 0.92 * this.currentGateGain + 0.08 * targetGateGain;
    }

    // Adaptive spectral noise floor estimation for subtraction
    const noiseSubFactor = this.estimatedNoiseFloor * 1.2;

    for (let i = 0; i < len; i++) {
      let sample = inputSamples[i];

      // Spectral Noise Subtraction: subtract estimated noise floor component from sample amplitude
      if (Math.abs(sample) > noiseSubFactor) {
        sample = (Math.abs(sample) - noiseSubFactor) * Math.sign(sample);
      } else {
        sample = 0;
      }

      // Attenuate with noise gate gain and AGC
      sample = sample * this.currentGateGain * agcGain;

      // Apply professional soft-limiting (dynamic wave shaping saturation)
      // to completely eliminate harsh digital clipping, cracks, and audio glitches
      if (sample > 0.8) {
        sample = 0.8 + 0.2 * Math.tanh((sample - 0.8) / 0.2);
      } else if (sample < -0.8) {
        sample = -0.8 + 0.2 * Math.tanh((sample + 0.8) / 0.2);
      }

      // Hard safety guard
      output[i] = Math.max(-1.0, Math.min(1.0, sample));
    }

    return output;
  }

  public getHighpassFreq(): number {
    return this.highpassFreq;
  }

  public setHighpassFreq(freq: number): void {
    this.highpassFreq = freq;
  }
}

export const defaultAudioPreprocessor = new AudioPreprocessor();
