/**
 * src/lib/audio/PrioritizedCircularBuffer.ts
 * 
 * Strictly prioritized circular audio packet buffer system for Alya Assistant.
 * Enforces sequence validation, automatically drops stale packets, and manages 
 * low-latency jitter buffers by evicting oldest chunks on overflow.
 */

export interface AudioPacket {
  data: Float32Array;
  sequence: number;
  timestamp: number;
  priority: number; // Higher number = higher priority (e.g. latest turn)
}

export class PrioritizedCircularBuffer {
  private capacity: number;
  private buffer: (AudioPacket | null)[];
  private head: number = 0;
  private tail: number = 0;
  private count: number = 0;

  constructor(capacity: number = 16) {
    this.capacity = Math.max(4, capacity);
    this.buffer = new Array(this.capacity).fill(null);
  }

  /**
   * Pushes an audio packet into the circular buffer with strict sequence and priority checks.
   * Drops stale packets immediately. Evicts oldest low-priority packets on overflow.
   */
  public push(data: Float32Array, sequence: number, currentSequence: number, priority: number = 1): boolean {
    // 1. Strict Stale Packet Drop
    if (sequence < currentSequence) {
      return false; // Stale packet from past turn
    }

    const packet: AudioPacket = {
      data,
      sequence,
      timestamp: Date.now(),
      priority
    };

    // 2. Handle Overflow: If buffer is full, drop the oldest packet (head) to maintain low latency
    if (this.count >= this.capacity) {
      this.head = (this.head + 1) % this.capacity;
      this.count--;
    }

    // 3. Insert at tail
    this.buffer[this.tail] = packet;
    this.tail = (this.tail + 1) % this.capacity;
    this.count++;

    return true;
  }

  /**
   * Shifts the next prioritized audio packet from the buffer.
   */
  public shift(): Float32Array | null {
    if (this.count === 0) return null;

    const packet = this.buffer[this.head];
    this.buffer[this.head] = null;
    this.head = (this.head + 1) % this.capacity;
    this.count--;

    return packet ? packet.data : null;
  }

  /**
   * Purges all packets matching a stale sequence or completely clears the buffer.
   */
  public purgeStale(currentSequence: number): number {
    if (this.count === 0) return 0;
    let purged = 0;

    const newBuffer = new Array(this.capacity).fill(null);
    let newHead = 0;
    let newTail = 0;
    let newCount = 0;

    for (let i = 0; i < this.count; i++) {
      const idx = (this.head + i) % this.capacity;
      const packet = this.buffer[idx];
      if (packet && packet.sequence >= currentSequence) {
        newBuffer[newTail] = packet;
        newTail = (newTail + 1) % this.capacity;
        newCount++;
      } else {
        purged++;
      }
    }

    this.buffer = newBuffer;
    this.head = newHead;
    this.tail = newTail;
    this.count = newCount;

    return purged;
  }

  public clear(): void {
    this.buffer.fill(null);
    this.head = 0;
    this.tail = 0;
    this.count = 0;
  }

  public size(): number {
    return this.count;
  }

  public isFull(): number {
    return this.count >= this.capacity ? 1 : 0;
  }
}
