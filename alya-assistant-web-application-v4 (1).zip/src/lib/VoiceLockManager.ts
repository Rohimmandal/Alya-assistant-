/**
 * src/lib/VoiceLockManager.ts
 * 
 * Client-side Voice Lock (Speaker Enrollment + Verification) module.
 * Runs Xenova/wavlm-base-plus-sv in a Web Worker for secure, local speaker verification.
 */

export class VoiceLockManager {
  private static instance: VoiceLockManager | null = null;
  private worker: Worker | null = null;
  private profile: number[] | null = null;
  private threshold: number = 0.80;
  private _isEnabled: boolean = false;
  private status: string = 'Not enrolled';
  private similarityScore: number = 0;
  
  // Diagnostic metrics
  public rollingRms: number = 0;
  public lastSimilarity: number = 0;
  
  // Verification promise management
  private resolveVerification: ((embedding: number[]) => void) | null = null;

  private constructor() {
    this.initWorker();
    this.loadProfile();
  }

  public static getInstance(): VoiceLockManager {
    if (!VoiceLockManager.instance) {
      VoiceLockManager.instance = new VoiceLockManager();
    }
    return VoiceLockManager.instance;
  }

  private initWorker() {
    const workerCode = `
      import { pipeline } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2';
      let extractor: any;

      self.onmessage = async (e) => {
        const { type, audio } = e.data;
        if (type === 'init') {
          extractor = await pipeline('feature-extraction', 'Xenova/wavlm-base-plus-sv', { quantized: true });
          self.postMessage({ type: 'ready' });
        } else if (type === 'extract') {
          const result = await extractor(audio);
          self.postMessage({ type: 'embedding', embedding: Array.from(result.data) });
        }
      };
    `;
    const blob = new Blob([workerCode], { type: 'text/javascript' });
    this.worker = new Worker(URL.createObjectURL(blob), { type: 'module' });
    this.worker.postMessage({ type: 'init' });
    
    this.worker.onmessage = (e) => {
      if (e.data.type === 'embedding') {
        if (this.resolveVerification) {
          this.resolveVerification(e.data.embedding);
          this.resolveVerification = null;
        }
      }
    };
  }

  private loadProfile() {
    const saved = localStorage.getItem('alya_voice_profile');
    if (saved) {
      this.profile = JSON.parse(saved);
      this.status = 'Verified';
    }
  }

  public setEnabled(enabled: boolean) { this._isEnabled = enabled; }
  public setThreshold(t: number) { this.threshold = t; }
  public getStatus() { return this.status; }
  public getScore() { return Math.round(this.similarityScore * 100); }
  public get isEnabled() { return this._isEnabled; }
  public set isEnabled(val: boolean) { this._isEnabled = val; }

  private cosineSimilarity(a: number[], b: number[]): number {
    let dot = 0, normA = 0, normB = 0;
    for (let i = 0; i < a.length; i++) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    return dot / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  public async enroll(): Promise<void> {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      let seconds = 0;
      this.status = 'Recording: 0/20s';
      
      const embeddings: number[][] = [];
      const mediaRecorder = new MediaRecorder(stream);
      
      mediaRecorder.ondataavailable = async (e) => {
        const arrayBuffer = await e.data.arrayBuffer();
        const float32 = new Float32Array(arrayBuffer);
        const rms = Math.sqrt(float32.reduce((s, x) => s + x * x, 0) / float32.length);
        this.rollingRms = rms;
        
        if (rms > 0.02) {
          this.worker!.postMessage({ type: 'extract', audio: float32 });
        }
      };
      
      this.worker!.onmessage = (e) => {
        if (e.data.type === 'embedding') {
          embeddings.push(e.data.embedding);
        }
      };

      mediaRecorder.start(1000); 
      
      const timer = setInterval(() => {
        seconds++;
        this.status = `Recording: ${seconds}/20s`;
        if (seconds >= 20) clearInterval(timer);
      }, 1000);
      
      setTimeout(async () => {
        mediaRecorder.stop();
        stream.getTracks().forEach(t => t.stop());
        
        if (embeddings.length < 4) {
          this.status = 'Not enrolled';
          throw new Error('Not enough voice data captured.');
        }

        // Quality Check: Stability (Variance)
        const avg = embeddings[0].map((_, i) => embeddings.reduce((s, e) => s + e[i], 0) / embeddings.length);
        let variance = 0;
        for (const emb of embeddings) {
          variance += emb.reduce((s, x, i) => s + Math.pow(x - avg[i], 2), 0);
        }
        variance /= embeddings.length;

        if (variance > 0.05) { // Stability Threshold
          this.status = 'Not enrolled';
          throw new Error('Voice data too unstable. Please ensure background noise is low and speak consistently.');
        }

        const norm = Math.sqrt(avg.reduce((sum, x) => sum + x * x, 0));
        this.profile = avg.map(x => x / norm);
        
        localStorage.setItem('alya_voice_profile', JSON.stringify(this.profile));
        this.status = 'Verified';
      }, 20000);
      
    } catch (err: any) {
      this.status = 'Not enrolled';
      throw err;
    }
  }

  public async verify(audio: Float32Array): Promise<boolean> {
    if (!this._isEnabled || !this.profile) return true;

    this.rollingRms = Math.sqrt(audio.reduce((s, x) => s + x * x, 0) / audio.length);
    if (this.rollingRms < 0.02) return false;

    const embedding = await new Promise<number[]>((resolve) => {
      this.resolveVerification = resolve;
      this.worker!.postMessage({ type: 'extract', audio });
    });

    const similarity = this.cosineSimilarity(embedding, this.profile);
    this.similarityScore = similarity;
    this.lastSimilarity = similarity;
    
    if (similarity >= this.threshold) {
      this.status = 'Verified';
      return true;
    } else {
      this.status = 'Other voice ignored';
      return false;
    }
  }
}
export const voiceLockManager = VoiceLockManager.getInstance();
