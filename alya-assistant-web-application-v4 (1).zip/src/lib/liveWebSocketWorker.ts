/**
 * Dedicated High-Priority WebWorker for WebSocket Live Voice Traffic
 * Offloads Base64 PCM encoding, WebSocket framing, keep-alive heartbeats,
 * timeout watchdog, and JSON serialization/parsing completely off the main UI thread.
 * 
 * Features:
 * - 10-second connection timeout monitor
 * - Explicit previous WebSocket cleanup before re-initializing to avoid resource leaks
 * - Integration with LiveKitDiagnosticService
 */

import { liveKitDiagnosticService } from './LiveKitDiagnosticService';

export const WORKER_SCRIPT = `
let ws = null;
let directAudioPort = null;
let pingInterval = null;
let connectTimeoutTimer = null;
let isConnected = false;
let lastActivityTime = Date.now();
let lastPongTime = Date.now();
let currentSocketId = null;

// Fast Base64 encoder for ArrayBuffer
function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  let binary = '';
  const chunkSize = 8192;
  for (let i = 0; i < len; i += chunkSize) {
    const chunk = bytes.subarray(i, Math.min(i + chunkSize, len));
    binary += String.fromCharCode.apply(null, chunk);
  }
  return self.btoa(binary);
}

function stopPing() {
  if (pingInterval) {
    clearInterval(pingInterval);
    pingInterval = null;
  }
}

function clearConnectTimeout() {
  if (connectTimeoutTimer) {
    clearTimeout(connectTimeoutTimer);
    connectTimeoutTimer = null;
  }
}

function cleanupPreviousSocket(reason) {
  clearConnectTimeout();
  stopPing();
  if (ws) {
    try {
      ws.onopen = null;
      ws.onmessage = null;
      ws.onerror = null;
      ws.onclose = null;
      if (ws.readyState === 0 || ws.readyState === 1) { // CONNECTING or OPEN
        ws.close(1000, reason || 'Cleanup before re-init');
      }
    } catch (_) {}
    ws = null;
  }
  isConnected = false;
}

function startPing() {
  stopPing();
  lastActivityTime = Date.now();
  lastPongTime = Date.now();

  pingInterval = setInterval(() => {
    if (ws && ws.readyState === 1) {
      const now = Date.now();
      // If no PONG or active frame received in 30s, detect silent drop and force reconnection
      if (now - lastPongTime > 30000 && now - lastActivityTime > 30000) {
        self.postMessage({ 
          type: 'WS_HEARTBEAT_TIMEOUT', 
          socketId: currentSocketId, 
          message: 'Heartbeat timeout: no response in 30s' 
        });
        cleanupPreviousSocket('Heartbeat timeout');
        self.postMessage({ type: 'WS_CLOSE', socketId: currentSocketId });
        return;
      }
      self.postMessage({ type: 'WS_PING_SENT', timestamp: now, socketId: currentSocketId });
      ws.send(JSON.stringify({ type: 'PING', timestamp: now }));
    }
  }, 8000);
}

self.onmessage = function(e) {
  const { type, payload } = e.data || {};

  if (type === 'INIT_PORT') {
    // Receive direct MessagePort from AudioWorklet
    if (e.ports && e.ports[0]) {
      if (directAudioPort) {
        try { directAudioPort.close(); } catch (_) {}
      }
      directAudioPort = e.ports[0];
      directAudioPort.onmessage = function(portEvent) {
        if (!ws || ws.readyState !== 1) return;
        const pcmBuffer = portEvent.data; // 20ms ArrayBuffer (640 bytes)
        if (pcmBuffer && pcmBuffer.byteLength > 0) {
          const base64Audio = arrayBufferToBase64(pcmBuffer);
          ws.send(JSON.stringify({
            type: 'AUDIO_CHUNK',
            audio: base64Audio,
            realtimeInput: {
              mediaChunks: [
                {
                  mimeType: 'audio/pcm;rate=16000',
                  data: base64Audio
                }
              ]
            }
          }));
          self.postMessage({ 
            type: 'WS_AUDIO_SENT', 
            byteLength: pcmBuffer.byteLength, 
            socketId: currentSocketId 
          });
        }
      };
    }
  }

  if (type === 'CONNECT') {
    const { url, socketId } = payload || {};
    currentSocketId = socketId || ('ws_' + Math.random().toString(36).substring(2, 9));
    
    // Explicitly clean up previous WebSocket instance before creating a new one
    cleanupPreviousSocket('Pre-connect cleanup');

    try {
      self.postMessage({ 
        type: 'WS_CLEANUP_DONE', 
        socketId: currentSocketId, 
        message: 'Previous WebSocket instance wiped and cleaned' 
      });

      ws = new WebSocket(url);

      // Start 10-Second Connecting State Timeout Monitor
      clearConnectTimeout();
      connectTimeoutTimer = setTimeout(() => {
        if (ws && ws.readyState === 0) { // Still CONNECTING after 10,000 ms
          self.postMessage({ 
            type: 'WS_CONNECT_TIMEOUT', 
            socketId: currentSocketId, 
            durationMs: 10000, 
            message: 'WebSocket stuck in connecting state for >10s' 
          });
          cleanupPreviousSocket('Connecting timeout >10s');
        }
      }, 10000);

      ws.onopen = function() {
        clearConnectTimeout();
        isConnected = true;
        startPing();
        self.postMessage({ 
          type: 'WS_OPEN', 
          socketId: currentSocketId, 
          timestamp: Date.now() 
        });
      };

      ws.onmessage = function(event) {
        try {
          const data = JSON.parse(event.data);
          lastActivityTime = Date.now();
          if (data && (data.type === 'PONG' || data.type === 'pong')) {
            lastPongTime = Date.now();
            self.postMessage({ 
              type: 'WS_PONG_RECEIVED', 
              timestamp: lastPongTime, 
              socketId: currentSocketId 
            });
            return;
          }
          if (data && data.type === 'LIVE_AUDIO' && data.audio) {
            self.postMessage({ 
              type: 'WS_AUDIO_RECEIVED', 
              byteLength: data.audio.length, 
              socketId: currentSocketId 
            });
          }
          self.postMessage({ 
            type: 'WS_MESSAGE', 
            data, 
            socketId: currentSocketId 
          });
        } catch (err) {
          self.postMessage({ 
            type: 'WS_PARSE_ERROR', 
            error: err.message, 
            socketId: currentSocketId 
          });
        }
      };

      ws.onerror = function(err) {
        clearConnectTimeout();
        self.postMessage({ 
          type: 'WS_ERROR', 
          error: 'WebSocket transport error', 
          socketId: currentSocketId 
        });
      };

      ws.onclose = function(closeEvt) {
        clearConnectTimeout();
        isConnected = false;
        stopPing();
        self.postMessage({ 
          type: 'WS_CLOSE', 
          code: closeEvt?.code, 
          reason: closeEvt?.reason, 
          wasClean: closeEvt?.wasClean,
          socketId: currentSocketId 
        });
      };
    } catch (connErr) {
      clearConnectTimeout();
      self.postMessage({ 
        type: 'WS_ERROR', 
        error: connErr.message || 'Failed to open WebSocket', 
        socketId: currentSocketId 
      });
    }
  }

  if (type === 'SEND') {
    if (ws && ws.readyState === 1) {
      try {
        ws.send(JSON.stringify(payload));
      } catch (sendErr) {
        self.postMessage({ 
          type: 'WS_SEND_ERROR', 
          error: sendErr.message, 
          socketId: currentSocketId 
        });
      }
    }
  }

  if (type === 'DISCONNECT') {
    cleanupPreviousSocket('Explicit disconnect');
    if (directAudioPort) {
      try { directAudioPort.close(); } catch (_) {}
      directAudioPort = null;
    }
    self.postMessage({ 
      type: 'WS_CLOSED_CLEANLY', 
      socketId: currentSocketId 
    });
  }
};
`;

export type WebSocketWorkerStatus = 'open' | 'closed' | 'error' | 'timeout' | 'cleaned';

export class LiveWebSocketWorker {
  private worker: Worker | null = null;
  private messageChannel: MessageChannel | null = null;
  private onMessageCallback: (data: any) => void;
  private onStatusCallback: (status: WebSocketWorkerStatus, details?: any) => void;
  private currentSocketId: string = '';

  constructor(
    onMessage: (data: any) => void,
    onStatus: (status: WebSocketWorkerStatus, details?: any) => void
  ) {
    this.onMessageCallback = onMessage;
    this.onStatusCallback = onStatus;
  }

  public init(): void {
    if (this.worker) return;

    const blob = new Blob([WORKER_SCRIPT], { type: 'application/javascript' });
    const url = URL.createObjectURL(blob);
    this.worker = new Worker(url);
    URL.revokeObjectURL(url);

    liveKitDiagnosticService.log('info', 'lifecycle', 'Spawned dedicated high-priority WebSocket worker.');

    this.worker.onmessage = (e: MessageEvent) => {
      const { type, data, error, socketId, durationMs, byteLength, timestamp } = e.data || {};
      
      switch (type) {
        case 'WS_OPEN':
          liveKitDiagnosticService.trackStateChange('connected', { socketId, timestamp }, socketId);
          this.onStatusCallback('open', { socketId, timestamp });
          break;

        case 'WS_MESSAGE':
          this.onMessageCallback(data);
          break;

        case 'WS_CONNECT_TIMEOUT':
          liveKitDiagnosticService.trackTimeoutTriggered(durationMs || 10000, 1, socketId);
          liveKitDiagnosticService.trackStateChange('timeout', { durationMs, socketId }, socketId);
          this.onStatusCallback('timeout', { durationMs: durationMs || 10000, socketId });
          break;

        case 'WS_PING_SENT':
          liveKitDiagnosticService.trackPing(timestamp);
          break;

        case 'WS_PONG_RECEIVED':
          liveKitDiagnosticService.trackPong(timestamp);
          break;

        case 'WS_AUDIO_SENT':
          liveKitDiagnosticService.trackAudioSent(byteLength || 640);
          break;

        case 'WS_AUDIO_RECEIVED':
          liveKitDiagnosticService.trackAudioReceived(byteLength || 0);
          break;

        case 'WS_CLEANUP_DONE':
          liveKitDiagnosticService.trackCleanup('LiveWebSocketWorker', ['previous_ws_instance', 'ping_interval', 'connect_timer'], socketId);
          break;

        case 'WS_CLOSE':
        case 'WS_CLOSED_CLEANLY':
          liveKitDiagnosticService.trackStateChange('disconnected', { socketId }, socketId);
          this.onStatusCallback('closed', { socketId });
          break;

        case 'WS_ERROR':
        case 'WS_SEND_ERROR':
          liveKitDiagnosticService.trackError(error || 'WebSocket error', { socketId }, socketId);
          this.onStatusCallback('error', { error, socketId });
          break;

        default:
          break;
      }
    };

    this.worker.onerror = (err) => {
      liveKitDiagnosticService.trackError(`Worker runtime error: ${err.message}`, err);
      this.onStatusCallback('error', { error: err.message });
    };
  }

  /**
   * Connects direct MessageChannel between AudioWorklet and WebSocket Worker
   */
  public bindAudioWorkletPort(workletPort: MessagePort): void {
    if (!this.worker) return;
    
    // Clean up old message channel if exists
    if (this.messageChannel) {
      try { this.messageChannel.port1.close(); } catch (_) {}
      try { this.messageChannel.port2.close(); } catch (_) {}
      this.messageChannel = null;
    }

    this.messageChannel = new MessageChannel();

    // Port1 stays on workletNode, Port2 sent to WebWorker
    workletPort.postMessage({ type: 'INIT_PORT', port: this.messageChannel.port1 }, [this.messageChannel.port1]);
    this.worker.postMessage({ type: 'INIT_PORT' }, [this.messageChannel.port2]);

    liveKitDiagnosticService.log('info', 'audio', 'Bound direct AudioWorklet MessagePort to WebSocket WebWorker.');
  }

  public connect(url: string): void {
    this.init();
    this.currentSocketId = 'soc_' + Math.random().toString(36).substring(2, 9);
    
    liveKitDiagnosticService.trackSocketCreated(this.currentSocketId, url, 'websocket_worker');
    liveKitDiagnosticService.trackStateChange('connecting', { socketId: this.currentSocketId, url }, this.currentSocketId);
    
    this.worker?.postMessage({ 
      type: 'CONNECT', 
      payload: { url, socketId: this.currentSocketId } 
    });
  }

  public send(payload: any): void {
    this.worker?.postMessage({ type: 'SEND', payload });
  }

  /**
   * Explicitly cleans up and resets the WebSocket connection without terminating the Worker
   */
  public reset(): void {
    liveKitDiagnosticService.trackCleanup('LiveWebSocketWorker', ['socket', 'ports', 'timers'], this.currentSocketId);
    this.worker?.postMessage({ type: 'DISCONNECT' });
  }

  public disconnect(): void {
    if (this.messageChannel) {
      try { this.messageChannel.port1.close(); } catch (_) {}
      try { this.messageChannel.port2.close(); } catch (_) {}
      this.messageChannel = null;
    }

    if (this.worker) {
      this.worker.postMessage({ type: 'DISCONNECT' });
      liveKitDiagnosticService.trackCleanup('LiveWebSocketWorker', ['worker_thread', 'message_channel'], this.currentSocketId);
      
      const oldWorker = this.worker;
      this.worker = null;
      setTimeout(() => {
        try {
          oldWorker.terminate();
        } catch (_) {}
      }, 50);
    }
  }
}
