/**
 * Alya Assistant - Unified Client-Side ConversationStore
 * 
 * Singleton class that manages unified conversation state across both
 * Live Voice and Text Chat modes.
 * 
 * Tracks:
 * - Full chronological dialogue history (merging Text and Voice turns)
 * - Active task & target application/device
 * - Action/execution state
 * - Unresolved references & anaphoric pronoun mapping ("it", "that", "this", etc.)
 * - Reactive subscriptions for instant UI updates
 * - Seamless persistence across mode switches (Text <-> Live)
 */

import { LocationContext } from './locationService';

export type ConversationMode = 'text' | 'voice';

export interface DialogueTurn {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  mode: ConversationMode;
  timestamp: number;
  isoTimestamp: string;
  sessionId: string;
  sequence: number;
  requestId?: string;
  replyToId?: string;
  status?: 'sending' | 'completed' | 'interrupted' | 'cancelled';
  intent?: string;
  action?: {
    command: string;
    params?: any;
    summary?: string;
  };
}

export interface ActiveTask {
  app?: string;
  action?: string;
  query?: string;
  targetDevice?: string;
  room?: string;
  url?: string;
  details?: Record<string, any>;
}

export interface ActionState {
  lastCommand?: string;
  params?: any;
  status: 'idle' | 'pending' | 'success' | 'failed';
  result?: string;
  timestamp: number;
}

export interface UnresolvedReferences {
  it?: string;
  that?: string;
  this?: string;
  target?: string;
  previousItem?: string;
  lastSearchQuery?: string;
  lastLocation?: string;
  lastApp?: string;
  lastEntity?: string;
}

export interface UnifiedConversationState {
  userId: string;
  conversationId: string;
  activeRequestId: string | null;
  activeTurnId: string | null;
  sequenceCounter: number;
  currentTopic: string;
  userIntent: string;
  history: DialogueTurn[];
  activeTask: ActiveTask | null;
  actionState: ActionState;
  unresolvedReferences: UnresolvedReferences;
  responseMode: 'SHORT' | 'NORMAL' | '3-LINE' | 'DETAILED';
  lastMode: ConversationMode;
  currentLocation: LocationContext | null;
  lastUpdated: number;
}

const STORAGE_KEY = 'alya_unified_conversation_store';
const MAX_LOCAL_TURNS = 50;

export class ConversationStore {
  private static instance: ConversationStore | null = null;
  private state: UnifiedConversationState;
  private listeners: Set<(state: UnifiedConversationState) => void> = new Set();

  private constructor() {
    this.state = this.loadInitialState();
  }

  /**
   * Singleton accessor
   */
  public static getInstance(): ConversationStore {
    if (!ConversationStore.instance) {
      ConversationStore.instance = new ConversationStore();
    }
    return ConversationStore.instance;
  }

  /**
   * Generates a guaranteed globally unique message ID with high-precision timestamp
   */
  public static generateMessageId(prefix: string = 'msg'): string {
    const timestamp = Date.now();
    const randomHex = Math.random().toString(36).substring(2, 9) + Math.random().toString(36).substring(2, 6);
    return `${prefix}_${timestamp}_${randomHex}`;
  }

  /**
   * Loads initial state from localStorage or initializes clean defaults
   */
  private loadInitialState(): UnifiedConversationState {
    const defaultUserId = typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_user_id') || 'default_user') : 'default_user';
    const defaultConvId = typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_active_conversation_id') || 'main') : 'main';

    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          const fullHistory = Array.isArray(parsed.history) ? parsed.history : [];
          // Fast startup: keep only the most recent MAX_LOCAL_TURNS initially
          const loadedHistory = fullHistory.slice(-MAX_LOCAL_TURNS);
          return {
            userId: parsed.userId || defaultUserId,
            conversationId: parsed.conversationId || defaultConvId,
            activeRequestId: null,
            activeTurnId: null,
            sequenceCounter: parsed.sequenceCounter || fullHistory.length || 0,
            currentTopic: parsed.currentTopic || 'General Conversation',
            userIntent: parsed.userIntent || 'greeting',
            history: loadedHistory,
            activeTask: parsed.activeTask || null,
            actionState: parsed.actionState || { status: 'idle', timestamp: Date.now() },
            unresolvedReferences: parsed.unresolvedReferences || {},
            responseMode: parsed.responseMode || 'NORMAL',
            lastMode: parsed.lastMode || 'text',
            currentLocation: parsed.currentLocation || null,
            lastUpdated: parsed.lastUpdated || Date.now()
          };
        }
      } catch (e) {
        console.warn('[ConversationStore] Error loading cached store:', e);
      }
    }

    return {
      userId: defaultUserId,
      conversationId: defaultConvId,
      activeRequestId: null,
      activeTurnId: null,
      sequenceCounter: 0,
      currentTopic: 'General Conversation',
      userIntent: 'greeting',
      history: [],
      activeTask: null,
      actionState: { status: 'idle', timestamp: Date.now() },
      unresolvedReferences: {},
      responseMode: 'NORMAL',
      lastMode: 'text',
      currentLocation: null,
      lastUpdated: Date.now()
    };
  }

  /**
   * Returns a copy of the current unified state
   */
  public getState(): UnifiedConversationState {
    return {
      ...this.state,
      history: [...this.state.history],
      unresolvedReferences: { ...this.state.unresolvedReferences },
      activeTask: this.state.activeTask ? { ...this.state.activeTask } : null,
      actionState: { ...this.state.actionState }
    };
  }

  /**
   * Updates unified conversation state directly and notifies subscribers
   */
  public updateState(updates: Partial<UnifiedConversationState> | ((prev: UnifiedConversationState) => Partial<UnifiedConversationState>)): void {
    if (typeof updates === 'function') {
      const partial = updates(this.state);
      this.state = {
        ...this.state,
        ...partial,
        lastUpdated: Date.now()
      };
    } else {
      this.state = {
        ...this.state,
        ...updates,
        lastUpdated: Date.now()
      };
    }
    this.persist();
    this.notify();
  }

  /**
   * Starts a new user turn, invalidating and cancelling any stale or orphaned in-flight AI response streams.
   */
  public startTurn(turn: {
    content: string;
    mode: ConversationMode;
    id?: string;
    requestId?: string;
    intent?: string;
  }): { turn: DialogueTurn; requestId: string } {
    const now = Date.now();
    const turnId = turn.id || ConversationStore.generateMessageId('msg_user');
    const requestId = turn.requestId || `req_${now}_${Math.random().toString(36).substring(2, 7)}`;

    // 1. Invalidate previous in-flight assistant responses if any were unfinished
    if (this.state.activeRequestId && this.state.activeRequestId !== requestId) {
      this.cancelPendingTurns('superseded_by_newer_message');
    }

    this.state.sequenceCounter += 1;
    const currentSeq = this.state.sequenceCounter;

    this.state.activeRequestId = requestId;
    this.state.activeTurnId = turnId;

    const turnEntry: DialogueTurn = {
      id: turnId,
      role: 'user',
      content: turn.content,
      mode: turn.mode,
      timestamp: now,
      isoTimestamp: new Date(now).toISOString(),
      sessionId: this.state.conversationId,
      sequence: currentSeq,
      requestId,
      status: 'completed',
      intent: turn.intent
    };

    this.state.history.push(turnEntry);
    if (this.state.history.length > MAX_LOCAL_TURNS) {
      this.state.history = this.state.history.slice(-MAX_LOCAL_TURNS);
    }

    this.state.lastMode = turn.mode;
    this.state.lastUpdated = now;
    if (turn.intent) this.state.userIntent = turn.intent;

    this.inferStateFromTurn(turnEntry);
    this.persist();
    this.notify();

    return { turn: turnEntry, requestId };
  }

  /**
   * Checks if an incoming AI response or stream chunk belongs to the current active turn and conversation session.
   * Discards stale or orphaned responses from older superseded user turns.
   */
  public isRequestActive(requestId?: string, conversationId?: string): boolean {
    if (conversationId && conversationId !== this.state.conversationId) {
      return false;
    }
    if (requestId && this.state.activeRequestId && requestId !== this.state.activeRequestId) {
      return false;
    }
    return true;
  }

  /**
   * Cancels active pending turns and marks unfinished assistant responses as cancelled or interrupted
   */
  public cancelPendingTurns(reason: string = 'interrupted'): void {
    const oldReqId = this.state.activeRequestId;
    this.state.activeRequestId = null;
    this.state.activeTurnId = null;

    // Mark any trailing sending/interrupted turns
    for (let i = this.state.history.length - 1; i >= 0; i--) {
      const turn = this.state.history[i];
      if (turn.status === 'sending' || (oldReqId && turn.requestId === oldReqId && turn.role === 'assistant')) {
        turn.status = 'cancelled';
      }
    }

    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Completes an assistant turn with unique ID, timestamp, and sequence matching the parent user message.
   */
  public completeTurn(assistantTurn: {
    content: string;
    mode: ConversationMode;
    id?: string;
    requestId?: string;
    replyToId?: string;
    intent?: string;
    action?: { command: string; params?: any; summary?: string };
  }): DialogueTurn | null {
    // If request is stale or was superseded, discard silently to prevent out-of-order responses
    if (assistantTurn.requestId && !this.isRequestActive(assistantTurn.requestId)) {
      console.warn(`[ConversationStore] Discarding stale/orphaned AI response for request ${assistantTurn.requestId}`);
      return null;
    }

    const now = Date.now();
    const turnId = assistantTurn.id || ConversationStore.generateMessageId('msg_ast');
    this.state.sequenceCounter += 1;

    const turnEntry: DialogueTurn = {
      id: turnId,
      role: 'assistant',
      content: assistantTurn.content,
      mode: assistantTurn.mode,
      timestamp: now,
      isoTimestamp: new Date(now).toISOString(),
      sessionId: this.state.conversationId,
      sequence: this.state.sequenceCounter,
      requestId: assistantTurn.requestId || this.state.activeRequestId || undefined,
      replyToId: assistantTurn.replyToId || this.state.activeTurnId || undefined,
      status: 'completed',
      intent: assistantTurn.intent,
      action: assistantTurn.action
    };

    this.state.history.push(turnEntry);
    if (this.state.history.length > MAX_LOCAL_TURNS) {
      this.state.history = this.state.history.slice(-MAX_LOCAL_TURNS);
    }

    this.state.activeRequestId = null;
    this.state.lastMode = assistantTurn.mode;
    this.state.lastUpdated = now;

    this.inferStateFromTurn(turnEntry);
    this.persist();
    this.notify();

    return turnEntry;
  }

  /**
   * Adds a new dialogue turn (from either Live Voice or Text Chat) with backward compatibility
   */
  public addTurn(turn: {
    role: 'user' | 'assistant';
    content: string;
    mode: ConversationMode;
    intent?: string;
    action?: { command: string; params?: any; summary?: string };
    id?: string;
    requestId?: string;
    replyToId?: string;
  }): DialogueTurn {
    const now = Date.now();
    const turnId = turn.id || ConversationStore.generateMessageId(turn.role === 'user' ? 'msg_user' : 'msg_ast');
    this.state.sequenceCounter += 1;

    const turnEntry: DialogueTurn = {
      id: turnId,
      role: turn.role,
      content: turn.content,
      mode: turn.mode,
      timestamp: now,
      isoTimestamp: new Date(now).toISOString(),
      sessionId: this.state.conversationId,
      sequence: this.state.sequenceCounter,
      requestId: turn.requestId,
      replyToId: turn.replyToId,
      status: 'completed',
      intent: turn.intent,
      action: turn.action
    };

    this.state.history.push(turnEntry);
    if (this.state.history.length > MAX_LOCAL_TURNS) {
      this.state.history = this.state.history.slice(-MAX_LOCAL_TURNS);
    }

    this.state.lastMode = turn.mode;
    this.state.lastUpdated = now;
    if (turn.intent) this.state.userIntent = turn.intent;

    // Automatically analyze turn to update references, activeTask, and topic
    this.inferStateFromTurn(turnEntry);

    this.persist();
    this.notify();
    return turnEntry;
  }

  /**
   * Updates or clears the active task
   */
  public updateActiveTask(task: Partial<ActiveTask> | null): void {
    if (task === null) {
      this.state.activeTask = null;
    } else {
      this.state.activeTask = {
        ...(this.state.activeTask || {}),
        ...task
      };
    }
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Updates the action state (command execution status)
   */
  public setActionState(actionState: Partial<ActionState>): void {
    this.state.actionState = {
      ...this.state.actionState,
      ...actionState,
      timestamp: Date.now()
    };
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Updates unresolved references directly
   */
  public setUnresolvedReferences(refs: Partial<UnresolvedReferences>): void {
    this.state.unresolvedReferences = {
      ...this.state.unresolvedReferences,
      ...refs
    };
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Sets current conversation topic
   */
  public setCurrentTopic(topic: string): void {
    this.state.currentTopic = topic;
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Sets current active session identifiers
   */
  public setSession(userId: string, conversationId: string): void {
    if (this.state.userId !== userId || this.state.conversationId !== conversationId) {
      this.state.userId = userId;
      this.state.conversationId = conversationId;
      this.state.lastUpdated = Date.now();
      this.persist();
      this.notify();
    }
  }

  /**
   * Sets response mode (SHORT, NORMAL, 3-LINE, DETAILED)
   */
  public setResponseMode(mode: 'SHORT' | 'NORMAL' | '3-LINE' | 'DETAILED'): void {
    this.state.responseMode = mode;
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Resolves anaphoric reference (e.g. "it", "that", "this", "previous one")
   */
  public resolveReference(pronoun: string): string | undefined {
    const key = pronoun.toLowerCase().trim();
    if (key === 'it') return this.state.unresolvedReferences.it || this.state.unresolvedReferences.lastEntity || this.state.unresolvedReferences.lastApp;
    if (key === 'that' || key === 'this') return this.state.unresolvedReferences.that || this.state.unresolvedReferences.it || this.state.unresolvedReferences.previousItem;
    if (key === 'previous' || key === 'previous one' || key === 'last one') return this.state.unresolvedReferences.previousItem;
    return (this.state.unresolvedReferences as any)[key];
  }

  /**
   * Clears state for a new conversation session
   */
  public clearState(newConversationId?: string): void {
    this.state.history = [];
    this.state.activeTask = null;
    this.state.actionState = { status: 'idle', timestamp: Date.now() };
    this.state.unresolvedReferences = {};
    this.state.currentTopic = 'General Conversation';
    if (newConversationId) {
      this.state.conversationId = newConversationId;
    }
    this.state.lastUpdated = Date.now();
    this.persist();
    this.notify();
  }

  /**
   * Subscribes to reactive store state updates
   */
  public subscribe(listener: (state: UnifiedConversationState) => void): () => void {
    this.listeners.add(listener);
    listener(this.getState());
    return () => {
      this.listeners.delete(listener);
    };
  }

  /**
   * Internal helper to extract context & update references from new turn
   */
  private inferStateFromTurn(turn: DialogueTurn): void {
    const text = turn.content.toLowerCase();

    // App references
    if (text.includes('youtube')) {
      this.state.activeTask = { ...(this.state.activeTask || {}), app: 'YouTube' };
      this.state.unresolvedReferences.lastApp = 'YouTube';
      this.state.unresolvedReferences.it = 'YouTube';
      this.state.currentTopic = 'YouTube';
    } else if (text.includes('chrome') || text.includes('google')) {
      this.state.activeTask = { ...(this.state.activeTask || {}), app: 'Chrome' };
      this.state.unresolvedReferences.lastApp = 'Chrome';
      this.state.unresolvedReferences.it = 'Chrome';
      this.state.currentTopic = 'Web Browser';
    } else if (text.includes('camera')) {
      this.state.activeTask = { ...(this.state.activeTask || {}), app: 'Camera' };
      this.state.unresolvedReferences.lastApp = 'Camera';
      this.state.unresolvedReferences.it = 'Camera';
      this.state.currentTopic = 'Camera';
    } else if (text.includes('spotify') || text.includes('song') || text.includes('music')) {
      this.state.activeTask = { ...(this.state.activeTask || {}), app: 'Spotify' };
      this.state.unresolvedReferences.lastApp = 'Spotify';
      this.state.unresolvedReferences.it = 'Music';
      this.state.currentTopic = 'Music';
    }

    // Smart device references
    if (text.includes('light') || text.includes('batti') || text.includes('alo')) {
      this.state.unresolvedReferences.lastEntity = 'Smart Light';
      this.state.unresolvedReferences.it = 'Smart Light';
      this.state.currentTopic = 'Smart Lighting';
    } else if (text.includes('fan') || text.includes('pakha')) {
      this.state.unresolvedReferences.lastEntity = 'Fan';
      this.state.unresolvedReferences.it = 'Fan';
      this.state.currentTopic = 'Fan';
    } else if (text.includes('ac') || text.includes('air conditioner') || text.includes('cooling')) {
      this.state.unresolvedReferences.lastEntity = 'Air Conditioner';
      this.state.unresolvedReferences.it = 'Air Conditioner';
      this.state.currentTopic = 'Air Conditioner';
    } else if (text.includes('torch') || text.includes('flashlight')) {
      this.state.unresolvedReferences.lastEntity = 'Phone Flashlight';
      this.state.unresolvedReferences.it = 'Phone Flashlight';
      this.state.currentTopic = 'Flashlight';
    }

    // Weather location references
    if (text.includes('weather') || text.includes('mausam') || text.includes('barish') || text.includes('temperature')) {
      this.state.currentTopic = 'Weather';
      const locMatch = turn.content.match(/(?:in|at|for|near|of)\s+([a-zA-Z\s]+)/i);
      if (locMatch && locMatch[1]) {
        const city = locMatch[1].replace(/(?:today|aaj|kal|tomorrow|weather|mausam)/gi, '').trim();
        if (city) {
          this.state.unresolvedReferences.lastLocation = city;
          this.state.unresolvedReferences.it = `Weather in ${city}`;
        }
      }
    }

    // Search query references
    const searchMatch = turn.content.match(/(?:search|find|lookup|dhoondo|dekhao)\s+(?:for\s+)?(.+)/i);
    if (searchMatch && searchMatch[1]) {
      const q = searchMatch[1].trim();
      this.state.unresolvedReferences.lastSearchQuery = q;
      this.state.unresolvedReferences.previousItem = q;
      if (this.state.activeTask) {
        this.state.activeTask.query = q;
      }
    }

    // Action tracking
    if (turn.role === 'assistant' && turn.action) {
      this.state.actionState = {
        lastCommand: turn.action.command,
        params: turn.action.params,
        status: 'success',
        result: turn.action.summary,
        timestamp: turn.timestamp
      };
    }
  }

  /**
   * Persists state to localStorage
   */
  private persist(): void {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn('[ConversationStore] Error persisting state:', e);
    }
  }

  /**
   * Notifies subscribers
   */
  private notify(): void {
    const snapshot = this.getState();
    this.listeners.forEach(listener => {
      try {
        listener(snapshot);
      } catch (err) {
        console.error('[ConversationStore] Listener callback error:', err);
      }
    });
  }
}
