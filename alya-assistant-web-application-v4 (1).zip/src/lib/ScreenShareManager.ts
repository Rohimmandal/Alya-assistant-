/**
 * src/lib/ScreenShareManager.ts
 * 
 * Production Screen Sharing Pipeline for Alya Assistant.
 * 
 * Mandates:
 * 1. Uses navigator.mediaDevices.getDisplayMedia({ video: true, audio: false }).
 * 2. ONLY marks state as 'active' when MediaStream is truly live (track.readyState === 'live' && stream.active).
 * 3. Listens to track.onended to instantly revert state to 'inactive' when user stops sharing via browser bar.
 * 4. Completely decoupled from the Live audio session: starting or stopping screen sharing
 *    does NOT interfere with the AudioContext, does NOT interrupt speech, and does NOT trigger reconnects.
 * 5. Provides captureFrame() to extract frames for visual perception without closing the stream.
 */

export type ScreenShareStatus = 'inactive' | 'requesting' | 'active' | 'error';

export interface ScreenShareListener {
  id: string;
  onStatusChange: (status: ScreenShareStatus, stream: MediaStream | null) => void;
  onError?: (errorMessage: string) => void;
}

export class ScreenShareManager {
  private static instance: ScreenShareManager | null = null;

  private currentStream: MediaStream | null = null;
  private currentStatus: ScreenShareStatus = 'inactive';
  private listeners: Map<string, ScreenShareListener> = new Map();
  private lastCapturedFrame: string | null = null;

  private constructor() {}

  public static getInstance(): ScreenShareManager {
    if (!ScreenShareManager.instance) {
      ScreenShareManager.instance = new ScreenShareManager();
    }
    return ScreenShareManager.instance;
  }

  public getStatus(): ScreenShareStatus {
    // Dynamically verify if track died without event
    if (this.currentStatus === 'active') {
      const track = this.currentStream?.getVideoTracks()[0];
      if (!track || track.readyState !== 'live' || !this.currentStream?.active) {
        this.stopScreenShare('track_lost');
      }
    }
    return this.currentStatus;
  }

  public isSharingActive(): boolean {
    return this.getStatus() === 'active';
  }

  public getCurrentStream(): MediaStream | null {
    return this.currentStream;
  }

  public getLastCapturedFrame(): string | null {
    return this.lastCapturedFrame;
  }

  public subscribe(listener: ScreenShareListener): () => void {
    this.listeners.set(listener.id, listener);
    // Inform immediately of current state
    listener.onStatusChange(this.currentStatus, this.currentStream);
    return () => {
      this.listeners.delete(listener.id);
    };
  }

  /**
   * Starts screen sharing pipeline.
   * Guarantees zero interference with active Live audio sessions.
   */
  public async startScreenShare(): Promise<MediaStream | null> {
    if (typeof navigator === 'undefined' || !navigator.mediaDevices?.getDisplayMedia) {
      const err = 'Screen sharing is not supported in this browser environment.';
      this.notifyError(err);
      return null;
    }

    if (this.isSharingActive() && this.currentStream) {
      console.log('[ScreenShareManager] Screen sharing is already active.');
      return this.currentStream;
    }

    this.setStatus('requesting');

    try {
      // Audio is explicitly set to false to prevent conflicting with microphone / LiveKit audio pipelines
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          displaySurface: 'browser'
        },
        audio: false
      });

      const track = stream.getVideoTracks()[0];
      if (!track || track.readyState !== 'live' || !stream.active) {
        throw new Error('Screen capture stream is not live.');
      }

      this.currentStream = stream;

      // Listen for browser's native "Stop sharing" chrome bar click
      track.onended = () => {
        console.log('[ScreenShareManager] User stopped screen sharing via browser controls.');
        this.stopScreenShare('user_browser_ended');
      };

      // Only mark state as 'active' when track is truly live
      this.setStatus('active', stream);
      console.log('[ScreenShareManager] Screen sharing pipeline is now ACTIVE.');

      // Proactively capture initial frame for assistant visual awareness
      this.captureFrame().catch(() => {});

      return stream;
    } catch (err: any) {
      const message = err.name === 'NotAllowedError' 
        ? 'Screen sharing permission was cancelled or denied.' 
        : err.message || 'Failed to initialize screen sharing.';
      
      console.warn('[ScreenShareManager] Screen sharing initiation failed:', message);
      this.stopScreenShare('permission_denied');
      this.notifyError(message);
      return null;
    }
  }

  /**
   * Forcibly terminates screen sharing pipeline.
   * Does NOT touch AudioContext or LiveSession connection.
   */
  public stopScreenShare(reason: string = 'manual_stop'): void {
    if (this.currentStream) {
      try {
        this.currentStream.getTracks().forEach((track) => {
          track.onended = null;
          track.stop();
        });
      } catch (e) {
        console.warn('[ScreenShareManager] Error stopping tracks:', e);
      }
      this.currentStream = null;
    }

    this.lastCapturedFrame = null;
    this.setStatus('inactive', null);
    console.log(`[ScreenShareManager] Screen sharing stopped (${reason}). Live session unaffected.`);
  }

  /**
   * Captures a single visual frame from the active video stream without interrupting the stream
   */
  public async captureFrame(): Promise<string> {
    if (!this.currentStream || !this.isSharingActive()) {
      return '';
    }

    const track = this.currentStream.getVideoTracks()[0];
    if (!track || track.readyState !== 'live') {
      return '';
    }

    try {
      // 1. Preferred ImageCapture API
      if ((window as any).ImageCapture) {
        try {
          const imageCapture = new (window as any).ImageCapture(track);
          const bitmap = await imageCapture.grabFrame();
          const canvas = document.createElement('canvas');
          canvas.width = bitmap.width;
          canvas.height = bitmap.height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(bitmap, 0, 0);
            const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
            this.lastCapturedFrame = dataUrl;
            return dataUrl;
          }
        } catch (grabErr) {
          console.warn('[ScreenShareManager] ImageCapture grabFrame notice:', grabErr);
        }
      }

      // 2. Universal HTML5 Video fallback
      const dataUrl = await new Promise<string>((resolve) => {
        const video = document.createElement('video');
        video.muted = true;
        video.playsInline = true;
        video.srcObject = this.currentStream;
        
        video.onloadedmetadata = () => {
          video.play().then(() => {
            const canvas = document.createElement('canvas');
            canvas.width = video.videoWidth || 1280;
            canvas.height = video.videoHeight || 720;
            const ctx = canvas.getContext('2d');
            if (ctx) {
              ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
              resolve(canvas.toDataURL('image/jpeg', 0.85));
            } else {
              resolve('');
            }
          }).catch(() => resolve(''));
        };
        video.onerror = () => resolve('');
        setTimeout(() => resolve(''), 2000);
      });

      if (dataUrl) {
        this.lastCapturedFrame = dataUrl;
      }
      return dataUrl;
    } catch (err) {
      console.warn('[ScreenShareManager] Frame capture error:', err);
      return '';
    }
  }

  private setStatus(status: ScreenShareStatus, stream: MediaStream | null = null) {
    this.currentStatus = status;
    this.listeners.forEach((listener) => {
      try {
        listener.onStatusChange(status, stream);
      } catch (err) {
        console.warn(`[ScreenShareManager] Error in listener ${listener.id}:`, err);
      }
    });
  }

  private notifyError(errorMessage: string) {
    this.listeners.forEach((listener) => {
      try {
        listener.onError?.(errorMessage);
      } catch {}
    });
  }
}

export const screenShareManager = ScreenShareManager.getInstance();
