/**
 * UserProfileManager.ts
 * Centralized user profile configuration utility and resolution service for Alya Assistant.
 * Defines AlyaUserProfile type and resolves specific profile configurations for
 * rohimmandal433@gmail.com / rohimmandal433@gamil.com (owner) and sarkarhiru91@gmail.com (personal assistant user).
 * Exposed for use in both Text Chat and Live conversation components.
 */

import { UserProfileService, AlyaUserProfile, AlyaUserRole } from './userProfileService';

export type { AlyaUserProfile, AlyaUserRole };

export class UserProfileManager {
  /**
   * Resolves and returns the AlyaUserProfile for the specified authenticated email and user ID.
   */
  public static getProfile(email?: string | null, userId?: string | null): AlyaUserProfile {
    return UserProfileService.getProfile(email, userId);
  }

  /**
   * Resolves user profile for the authenticated user (alias for getProfile).
   */
  public static resolveUserProfile(email?: string | null, userId?: string | null): AlyaUserProfile {
    return this.getProfile(email, userId);
  }

  /**
   * Helper to check if the provided email belongs to the primary verified system owner.
   */
  public static isOwner(email?: string | null): boolean {
    const profile = this.getProfile(email);
    return profile.role === 'owner';
  }

  /**
   * Helper to retrieve active profile configuration cached in localStorage.
   */
  public static getCurrentActiveProfile(): AlyaUserProfile {
    const email = typeof localStorage !== 'undefined' ? localStorage.getItem('alya_user_email') : null;
    const userId = typeof localStorage !== 'undefined' ? localStorage.getItem('alya_user_id') : null;
    return this.getProfile(email, userId);
  }
}

export const userProfileManager = UserProfileManager;
