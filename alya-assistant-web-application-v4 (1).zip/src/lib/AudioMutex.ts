/**
 * AudioMutex & SingletonAudioPlayer
 * Enforces strict mutual exclusion across all audio playback sessions in Alya Assistant.
 * Guarantees that tapping play on any chat message or triggering TTS immediately
 * and synchronously terminates all existing audio streams before starting a new one.
 */

export type StopHandler = () => void;

export class AudioMutex {
  private static activeSessionId: string | null = null;
  private static stopHandlers: Set<StopHandler> = new Set();
  private static isAcquiring = false;
  private static audioElement: HTMLAudioElement | null = null;

  /**
   * Returns the global singleton HTMLAudioElement instance for chat playback
   */
  public static getAudioElement(): HTMLAudioElement {
    if (!this.audioElement && typeof window !== 'undefined') {
      this.audioElement = new Audio();
      this.audioElement.id = 'alya-singleton-audio-player';
      this.audioElement.preload = 'auto';
    }
    return this.audioElement!;
  }

  /**
   * Programmatically pauses and resets the singleton audio source
   */
  public static resetAudioElement(): void {
    if (this.audioElement) {
      try {
        this.audioElement.pause();
        this.audioElement.currentTime = 0;
        this.audioElement.removeAttribute('src');
        this.audioElement.load(); // Reset source state
      } catch (err) {
        console.warn('[AudioMutex] Error resetting audio element:', err);
      }
    }
  }

  /**
   * Registers a stop handler that will be invoked when the mutex is triggered
   */
  public static registerStopHandler(handler: StopHandler): () => void {
    this.stopHandlers.add(handler);
    return () => {
      this.stopHandlers.delete(handler);
    };
  }

  /**
   * Forcibly halts all active audio playback sessions across the entire application.
   */
  public static stopAllPlayback(excludeSessionId?: string): void {
    console.log('[AudioMutex] Stopping all active audio playback sessions...');
    this.activeSessionId = null;

    // Synchronously reset singleton HTMLAudioElement
    this.resetAudioElement();

    // Invoke all registered stop callbacks
    this.stopHandlers.forEach((handler) => {
      try {
        handler();
      } catch (err) {
        console.warn('[AudioMutex] Error executing stop handler:', err);
      }
    });

    if (typeof window !== 'undefined') {
      // Cancel Web Speech API if active
      if ('speechSynthesis' in window) {
        try {
          window.speechSynthesis.cancel();
        } catch (_) {}
      }

      // Dispatch global stop event for UI state synchronization
      window.dispatchEvent(new CustomEvent('alya:audio-mutex-stop', {
        detail: { excludeSessionId }
      }));
      
      // Dispatch legacy events for compatibility with older components
      window.dispatchEvent(new CustomEvent('alya:speech-ended'));
    }
  }

  /**
   * Acquires the exclusive audio lock for a new session.
   * Explicitly terminates any existing playback session before returning.
   */
  public static async acquireLock(sessionId: string): Promise<boolean> {
    if (this.isAcquiring) {
      // Prevent race conditions during rapid tapping
      this.stopAllPlayback();
      await new Promise(r => setTimeout(r, 10));
    }

    this.isAcquiring = true;

    try {
      // Stop all previous sessions
      this.stopAllPlayback(sessionId);
      
      // Brief 15ms tick to ensure hardware audio buffers and nodes flush completely
      await new Promise(r => setTimeout(r, 15));

      this.activeSessionId = sessionId;
      console.log(`[AudioMutex] Lock acquired exclusively for session: ${sessionId}`);
      return true;
    } finally {
      this.isAcquiring = false;
    }
  }

  /**
   * Releases the mutex lock if the caller is the current active session.
   */
  public static releaseLock(sessionId: string): void {
    if (this.activeSessionId === sessionId) {
      console.log(`[AudioMutex] Lock released for session: ${sessionId}`);
      this.activeSessionId = null;
    }
  }

  public static getActiveSessionId(): string | null {
    return this.activeSessionId;
  }

  public static isLocked(): boolean {
    return this.activeSessionId !== null;
  }
}
