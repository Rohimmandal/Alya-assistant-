import Dexie, { Table } from 'dexie';

export interface Conversation {
  id?: number;
  timestamp: number;
  sender: 'user' | 'assistant';
  text: string;
  metadata?: Record<string, any>;
}

export interface Capability {
  id: string; // Capability name (e.g., 'flashlight')
  lastUpdated: number;
  enabled: boolean;
  config?: Record<string, any>;
}

export class OfflineDatabase extends Dexie {
  conversations!: Table<Conversation>;
  capabilities!: Table<Capability>;

  constructor() {
    super('AlyaOfflineDatabase');
    this.version(1).stores({
      conversations: '++id, timestamp, sender',
      capabilities: 'id, lastUpdated'
    });
  }
}

export const offlineDb = new OfflineDatabase();
