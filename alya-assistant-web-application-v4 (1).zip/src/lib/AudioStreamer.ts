/**
 * Alya Assistant AudioStreamer
 * 
 * High-Performance Gapless AudioStreamer for Gemini Live (24kHz PCM).
 * 
 * Core Architectural Guarantees:
 * 1. Gapless Timeline Scheduling: Schedules 24kHz PCM audio buffers sequentially along the AudioContext timeline.
 * 2. Zero-Stutter Playback: Dynamically tracks the playhead to prevent underflows without choppy pre-buffer locks.
 * 3. Native Resampling: Directly provisions 24000Hz AudioBuffers, allowing browser Web Audio hardware to natively resample.
 * 4. Real-Time Analyser & Waveform Integration: Feeds the audio graph through Gain, Analyser, Filter, and Compressor.
 * 5. Instant Barge-In Interruption: Synchronously halts and flushes all active sources on user interruption.
 * 6. Centralized Audio Lock: Integrates with AudioPlaybackManager and AudioCoordinator to prevent cross-component audio collisions.
 */

import { AudioDiagnosticsLogger } from '../utils/audioDiagnostics';
import { AudioManager } from '../lib/AudioManager';
import { audioPipelineDiagnostics } from './AudioPipelineDiagnostics';
import { audioCoordinator } from './AudioCoordinator';
import { audioPlaybackManager } from './AudioPlaybackManager';
import { audioContextManager } from './AudioContextManager';

export class AudioStreamer {
  private streamId: string = `live_stream_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private volumeGain: GainNode | null = null;
  private muteGain: GainNode | null = null;
  private filterNode: BiquadFilterNode | null = null;
  private compressor: DynamicsCompressorNode | null = null;

  private nextStartTime: number = 0;
  private activeSources: Set<AudioBufferSourceNode> = new Set();
  private isPlaying: boolean = false;
  private onPlaybackStateChange?: (isPlaying: boolean) => void;

  private currentSequence: number = 0;
  private isInterrupted: boolean = false;
  private isSpeakerMode: boolean = false; // Default: Calling / Earpiece mode (40% volume)
  private playStateTimer: any = null;
  private autoRecoveryAttached: boolean = false;

  constructor(onPlaybackStateChange?: (isPlaying: boolean) => void) {
    this.onPlaybackStateChange = onPlaybackStateChange;
    this.setupInterruptionListeners();

    // Register cancel handler with AudioPlaybackManager
    audioPlaybackManager.registerCancelHandler(this.streamId, (reason) => {
      this.handleExternalHardReset(reason || 'audio_playback_manager_cancelled');
    });

    // Subscribe to coordinator reset
    audioCoordinator.onHardReset((event) => {
      if (!event.streamId || event.streamId === this.streamId) {
        this.handleExternalHardReset(event.reason, event.sequence);
      }
    });
  }

  private handleExternalHardReset(reason: string, sequence?: number): void {
    if (sequence !== undefined && sequence > this.currentSequence) {
      this.currentSequence = sequence;
    }
    this.stop();
  }

  private setupInterruptionListeners(): void {
    if (typeof window === 'undefined' || this.autoRecoveryAttached) return;

    const handleUserGesture = async () => {
      if (this.audioCtx && (this.audioCtx.state === 'suspended' || (this.audioCtx.state as string) === 'interrupted')) {
        try {
          await this.audioCtx.resume();
          AudioDiagnosticsLogger.logStateTransition('AudioStreamer', 'resumed_via_gesture', { state: this.audioCtx.state });
        } catch (e) {}
      }
    };

    window.addEventListener('pointerdown', handleUserGesture, { passive: true });
    window.addEventListener('touchstart', handleUserGesture, { passive: true });
    window.addEventListener('keydown', handleUserGesture, { passive: true });

    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible' && this.audioCtx && this.audioCtx.state === 'suspended') {
        if (this.isPlaying || this.activeSources.size > 0) {
          this.audioCtx.resume().catch(() => {});
        }
      }
    });

    this.autoRecoveryAttached = true;
  }

  public async initAudioContext(): Promise<AudioContext> {
    if (!this.audioCtx || this.audioCtx.state === 'closed') {
      try {
        this.audioCtx = await audioPlaybackManager.getSharedAudioContext(24000);
      } catch {
        const AudioCtxClass = window.AudioContext || (window as any).webkitAudioContext;
        try {
          this.audioCtx = new AudioCtxClass({ sampleRate: 24000, latencyHint: 'interactive' });
        } catch {
          this.audioCtx = new AudioCtxClass();
        }
      }

      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.7;

      this.volumeGain = this.audioCtx.createGain();
      const initialVol = this.isSpeakerMode ? 1.0 : 0.4;
      this.volumeGain.gain.setValueAtTime(initialVol, this.audioCtx.currentTime);

      this.muteGain = this.audioCtx.createGain();
      this.muteGain.gain.setValueAtTime(1.0, this.audioCtx.currentTime);

      this.filterNode = this.audioCtx.createBiquadFilter();
      this.filterNode.type = 'highpass';
      this.filterNode.frequency.setValueAtTime(this.isSpeakerMode ? 80 : 300, this.audioCtx.currentTime);
      this.filterNode.Q.setValueAtTime(0.707, this.audioCtx.currentTime);

      this.compressor = this.audioCtx.createDynamicsCompressor();
      this.compressor.threshold.setValueAtTime(-12, this.audioCtx.currentTime);
      this.compressor.knee.setValueAtTime(8, this.audioCtx.currentTime);
      this.compressor.ratio.setValueAtTime(4, this.audioCtx.currentTime);
      this.compressor.attack.setValueAtTime(0.003, this.audioCtx.currentTime);
      this.compressor.release.setValueAtTime(0.08, this.audioCtx.currentTime);

      this.muteGain.connect(this.volumeGain);
      this.volumeGain.connect(this.analyser);
      this.analyser.connect(this.filterNode);
      this.filterNode.connect(this.compressor);
      this.compressor.connect(this.audioCtx.destination);

      audioCoordinator.registerNode(this.streamId, this.volumeGain);
      audioCoordinator.registerNode(this.streamId, this.muteGain);
      audioCoordinator.registerNode(this.streamId, this.analyser);
      audioCoordinator.registerNode(this.streamId, this.filterNode);
      audioCoordinator.registerNode(this.streamId, this.compressor);
    }

    if (this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume().catch(() => {});
    }

    return this.audioCtx;
  }

  public interruptAndClear(newSequence?: number): void {
    this.stop();
    this.startTurn(newSequence);
  }

  public startTurn(sequence?: number): void {
    this.isInterrupted = false;
    if (sequence !== undefined) {
      this.currentSequence = sequence;
    } else {
      this.currentSequence++;
    }
    this.nextStartTime = 0;
  }

  /**
   * Enqueues and plays a base64 PCM 16-bit 24kHz Mono audio chunk gaplessly.
   */
  public async playChunk(
    base64Audio: string,
    turnSequence?: number,
    flushFirst: boolean = false,
    serverTimestamp?: number
  ): Promise<void> {
    if (!base64Audio) return;

    if (flushFirst) {
      this.interruptAndClear(turnSequence);
    } else if (turnSequence !== undefined) {
      if (turnSequence < this.currentSequence) {
        return; // Stale chunk from older turn
      }
      if (turnSequence > this.currentSequence) {
        this.interruptAndClear(turnSequence);
      }
    }

    if (this.isInterrupted) return;

    // Track network packet arrival for jitter estimation
    audioContextManager.trackAudioPacketArrival();

    try {
      const ctx = await this.initAudioContext();
      if (!ctx || ctx.state === 'closed') return;

      if (ctx.state === 'suspended') {
        try {
          await ctx.resume();
        } catch {}
      }

      // Decode base64 to binary
      const binaryString = atob(base64Audio);
      const len = binaryString.length;
      if (len < 4) return;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Check for optional 44-byte WAV header
      let offset = 0;
      if (
        len >= 44 &&
        bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[3] === 0x46 // 'RIFF'
      ) {
        offset = 44;
      }

      const pcmBytes = len - offset;
      if (pcmBytes <= 1) return;

      const sampleCount = Math.floor(pcmBytes / 2);
      if (sampleCount === 0) return;

      // Create native 24kHz mono AudioBuffer
      const audioBuffer = ctx.createBuffer(1, sampleCount, 24000);
      const channelData = audioBuffer.getChannelData(0);
      const dataView = new DataView(bytes.buffer, bytes.byteOffset + offset, sampleCount * 2);

      for (let i = 0; i < sampleCount; i++) {
        let sample = dataView.getInt16(i * 2, true) / 32768.0;
        
        // Warm soft-limiting wave shaping saturation to eliminate digital clipping cracks & pops
        if (sample > 0.8) {
          sample = 0.8 + 0.2 * Math.tanh((sample - 0.8) / 0.2);
        } else if (sample < -0.8) {
          sample = -0.8 + 0.2 * Math.tanh((sample + 0.8) / 0.2);
        }
        
        channelData[i] = Math.max(-1.0, Math.min(1.0, sample));
      }

      // Process robust dynamic gain normalization to target -18dBFS
      audioContextManager.processDynamicGain(channelData);

      // 2ms Anti-Click Micro Cross-Fade on Chunk Boundaries to prevent digital clicks, pops & cracks
      const fadeSamples = Math.min(Math.floor(24000 * 0.002), Math.floor(sampleCount / 4));
      if (fadeSamples > 0) {
        for (let i = 0; i < fadeSamples; i++) {
          channelData[i] *= (i / fadeSamples); // Fade-in
          channelData[sampleCount - 1 - i] *= (i / fadeSamples); // Fade-out
        }
      }

      // Strictly sequential timeline scheduling with zero overlap & zero frame dropping guarantee:
      // Dynamically adjust safety cushion based on real-time network jitter variance
      const currentTime = ctx.currentTime;
      const jitterOffset = audioContextManager.getDynamicJitterOffset();
      if (this.nextStartTime < currentTime) {
        this.nextStartTime = currentTime + Math.max(0.150, jitterOffset);
      }

      const scheduleTime = this.nextStartTime;
      this.nextStartTime += audioBuffer.duration;

      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      if (this.muteGain) {
        source.connect(this.muteGain);
      } else {
        source.connect(ctx.destination);
      }

      source.start(scheduleTime);
      this.activeSources.add(source);

      // Track playback state
      if (!this.isPlaying) {
        this.isPlaying = true;
        this.onPlaybackStateChange?.(true);
        try {
          audioPlaybackManager.cancelAllAudio('live_stream_turn', this.streamId);
          AudioManager.getInstance().requestAudioFocus('AUDIO_FOCUS_GAIN_TRANSIENT_MAY_DUCK');
          AudioManager.getInstance().onAssistantSpeakingStart();
        } catch (e) {}
      }

      source.onended = () => {
        source.disconnect();
        this.activeSources.delete(source);

        if (this.playStateTimer) clearTimeout(this.playStateTimer);
        this.playStateTimer = setTimeout(() => {
          if (this.activeSources.size === 0 && ctx.currentTime >= this.nextStartTime - 0.01) {
            if (this.isPlaying) {
              this.isPlaying = false;
              this.onPlaybackStateChange?.(false);
              try {
                AudioManager.getInstance().onAssistantSpeakingEnd();
                AudioManager.getInstance().requestAudioFocus('AUDIO_FOCUS_LOSS');
              } catch (e) {}
            }
          }
        }, 300); // 300ms tail flush safety delay to ensure Alya completely finishes speaking all words before state transition
      };

    } catch (err) {
      console.warn('[AudioStreamer] playChunk error:', err);
    }
  }

  public stop(): void {
    this.isInterrupted = true;
    if (this.playStateTimer) {
      clearTimeout(this.playStateTimer);
      this.playStateTimer = null;
    }

    for (const source of this.activeSources) {
      try {
        source.onended = null;
        source.stop();
        source.disconnect();
      } catch {}
    }
    this.activeSources.clear();
    this.nextStartTime = 0;

    if (this.isPlaying) {
      this.isPlaying = false;
      this.onPlaybackStateChange?.(false);
      try {
        AudioManager.getInstance().onAssistantSpeakingEnd();
        AudioManager.getInstance().requestAudioFocus('AUDIO_FOCUS_LOSS');
      } catch (e) {}
    }
  }

  public setVolume(volume: number): void {
    if (this.volumeGain && this.audioCtx) {
      const vol = Math.max(0, Math.min(2.0, volume));
      this.volumeGain.gain.setValueAtTime(vol, this.audioCtx.currentTime);
    }
  }

  /**
   * Speaker Control Mode:
   * - ON: Main Loudspeaker (100% volume level = 1.0), full spectrum output
   * - OFF: Earpiece / Calling Mode (40% volume level = 0.4), telephone bandpass shaping and routing
   */
  public async setSpeakerMode(isSpeakerOn: boolean): Promise<void> {
    this.isSpeakerMode = isSpeakerOn;
    const targetVolume = isSpeakerOn ? 1.0 : 0.4;
    this.setVolume(targetVolume);

    if (this.filterNode && this.audioCtx) {
      // 80Hz for main loudspeaker; 300Hz highpass for earpiece voice clarity
      this.filterNode.frequency.setValueAtTime(isSpeakerOn ? 80 : 300, this.audioCtx.currentTime);
    }

    // Attempt hardware sink routing where supported by browser AudioContext / AudioDestination
    if (this.audioCtx && 'setSinkId' in (this.audioCtx as any)) {
      try {
        const devices = await navigator.mediaDevices.enumerateDevices();
        const audioOutputs = devices.filter(d => d.kind === 'audiooutput');
        
        if (isSpeakerOn) {
          // Find external / loudspeaker device or default
          const speakerDev = audioOutputs.find(d => 
            d.label.toLowerCase().includes('speaker') || 
            d.label.toLowerCase().includes('loudspeaker') ||
            d.deviceId === 'default'
          );
          if (speakerDev) {
            await (this.audioCtx as any).setSinkId(speakerDev.deviceId);
          }
        } else {
          // Find earpiece / telephone receiver device
          const earpieceDev = audioOutputs.find(d => 
            d.label.toLowerCase().includes('earpiece') || 
            d.label.toLowerCase().includes('receiver') ||
            d.label.toLowerCase().includes('phone') ||
            d.label.toLowerCase().includes('telephony')
          );
          if (earpieceDev) {
            await (this.audioCtx as any).setSinkId(earpieceDev.deviceId);
          }
        }
      } catch (e) {
        console.log('[AudioStreamer] Hardware audio sink routing notice:', e);
      }
    }
  }

  public getIsSpeakerMode(): boolean {
    return this.isSpeakerMode;
  }

  public getAnalyser(): AnalyserNode | null {
    return this.analyser;
  }

  public getFrequencyData(array: Uint8Array): void {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(array as any);
    } else {
      array.fill(0);
    }
  }

  public flushResidual(): void {
    this.nextStartTime = 0;
  }

  public async resume(): Promise<void> {
    if (this.audioCtx && this.audioCtx.state === 'suspended') {
      await this.audioCtx.resume().catch(() => {});
    }
  }

  public close(): void {
    this.stop();
  }
}
