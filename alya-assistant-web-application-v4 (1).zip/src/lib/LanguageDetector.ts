/**
 * Comprehensive Multilingual Language Detector & Global Registry for Alya Assistant
 * Supports 170+ world languages and regional dialects organized by country.
 * Includes script analysis, dialect detection, phonetic keywords, and BCP-47 mapping.
 */

export interface LanguageInfo {
  code: string;       // BCP-47 tag, e.g., 'en-US', 'raj-IN', 'bn-BD'
  shortCode: string;  // 2-3 letter code, e.g., 'en', 'bn', 'raj'
  name: string;       // English display name
  nativeName: string; // Native name / script
  country: string;    // Sovereign country / region name
  region: string;     // Geographical continent / zone
  flag: string;       // Country flag emoji
  scriptPattern?: RegExp;
  keywords?: string[];
}

export const SUPPORTED_LANGUAGES: LanguageInfo[] = [
  // 0. Auto Detection
  {
    code: 'auto',
    shortCode: 'auto',
    name: 'Auto-Detect',
    nativeName: 'স্বয়ংক্রিয় / Automatic Mirroring',
    country: 'Global',
    region: 'Global',
    flag: '🌐'
  },

  // ==========================================
  // INDIA (45 languages & regional dialects)
  // ==========================================
  {
    code: 'hi-IN',
    shortCode: 'hi',
    name: 'Hindi (हिंदी)',
    nativeName: 'हिन्दी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['karo', 'chalao', 'band', 'jalao', 'sab', 'dekh', 'kya', 'kaise', 'accha', 'thoda', 'badhao', 'batao', 'namaste', 'shukriya']
  },
  {
    code: 'bn-IN',
    shortCode: 'bn',
    name: 'Bangla (বাংলা - ভারত)',
    nativeName: 'বাংলা (ভারত)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['koro', 'chalu', 'bondho', 'jaliye', 'bariye', 'komao', 'dao', 'amar', 'shob', 'dekho', 'kemon', 'acho', 'valo', 'bolo']
  },
  {
    code: 'raj-IN',
    shortCode: 'raj',
    name: 'Rajbongshi (কামতাপুরী / রাজবংশী)',
    nativeName: 'রাজবংশী (Kamtapuri / কোচ)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF\u0900-\u097F]/,
    keywords: ['mora', 'tora', 'hamar', 'tomar', 'kemon', 'karis', 'koro', 'achis', 'acho', 'khober', 'dekh', 'bujhi', 'jani', 'kisu', 'kotha', 'baat', 'muina', 'kiya', 'bhaat']
  },
  {
    code: 'as-IN',
    shortCode: 'as',
    name: 'Assamese (অসমীয়া)',
    nativeName: 'অসমীয়া',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['bhal', 'kori', 'kora', 'namaskar', 'kenekoi', 'kisu', 'hobo']
  },
  {
    code: 'pa-IN',
    shortCode: 'pa',
    name: 'Punjabi (ਪੰਜਾਬੀ)',
    nativeName: 'ਪੰਜਾਬੀ (ਭਾਰਤ)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0A00-\u0A7F]/,
    keywords: ['sat', 'sri', 'akal', 'kiddan', 'tussi', 'changa', 'dass']
  },
  {
    code: 'gu-IN',
    shortCode: 'gu',
    name: 'Gujarati (ગુજરાતી)',
    nativeName: 'ગુજરાતી',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0A80-\u0AFF]/,
    keywords: ['kem', 'cho', 'saras', 'majama', 'aabhar']
  },
  {
    code: 'mr-IN',
    shortCode: 'mr',
    name: 'Marathi (मराठी)',
    nativeName: 'मराठी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaskar', 'kasa', 'kay', 'changla', 'dhanyavad']
  },
  {
    code: 'ta-IN',
    shortCode: 'ta',
    name: 'Tamil (தமிழ்)',
    nativeName: 'தமிழ்',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0B80-\u0BFF]/,
    keywords: ['vanakkam', 'eppadi', 'irukkeenga', 'nandri']
  },
  {
    code: 'te-IN',
    shortCode: 'te',
    name: 'Telugu (తెలుగు)',
    nativeName: 'తెలుగు',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0C00-\u0C7F]/,
    keywords: ['namaskaram', 'ela', 'unnaru', 'dhanyavadamulu']
  },
  {
    code: 'kn-IN',
    shortCode: 'kn',
    name: 'Kannada (ಕನ್ನಡ)',
    nativeName: 'ಕನ್ನಡ',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0C80-\u0CFF]/,
    keywords: ['namaskara', 'hegiddira', 'chennagi', 'dhanyavada']
  },
  {
    code: 'ml-IN',
    shortCode: 'ml',
    name: 'Malayalam (മലയാളം)',
    nativeName: 'മലയാളം',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0D00-\u0D7F]/,
    keywords: ['namaskaram', 'engane', 'undu', 'nandi']
  },
  {
    code: 'or-IN',
    shortCode: 'or',
    name: 'Odia (ଓଡ଼ିଆ)',
    nativeName: 'ଓଡ଼ିଆ',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0B00-\u0B7F]/,
    keywords: ['namaskar', 'kemiti', 'achhanti', 'dhanyabad']
  },
  {
    code: 'ur-IN',
    shortCode: 'ur',
    name: 'Urdu (اردو - بھارت)',
    nativeName: 'اردو (بھارت)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['adaab', 'shukriya', 'kya', 'haal', 'hai']
  },
  {
    code: 'sa-IN',
    shortCode: 'sa',
    name: 'Sanskrit (संस्कृतम्)',
    nativeName: 'संस्कृतम्',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaste', 'namaskara', 'katham', 'asti', 'dhanyavadah']
  },
  {
    code: 'mai-IN',
    shortCode: 'mai',
    name: 'Maithili (मैथिली)',
    nativeName: 'मैथिली / মৈথিলী',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F\u0980-\u09FF]/,
    keywords: ['pranam', 'aham', 'ahan', 'nik', 'achhi', 'ki', 'bhel']
  },
  {
    code: 'bho-IN',
    shortCode: 'bho',
    name: 'Bhojpuri (भोजपुरी)',
    nativeName: 'भोजपुरी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['ka', 'haal', 'ba', 'thik', 'bani', 'rauwa', 'hum', 'karela']
  },
  {
    code: 'mag-IN',
    shortCode: 'mag',
    name: 'Magahi (मगही)',
    nativeName: 'मगही',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['kaha', 'jaa', 'hai', 'hum', 'tohar', 'baat']
  },
  {
    code: 'hne-IN',
    shortCode: 'hne',
    name: 'Chhattisgarhi (छत्तीसगढ़ी)',
    nativeName: 'छत्तीसगढ़ी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['jai', 'johar', 'kasan', 'has', 'bane', 'mor', 'tor']
  },
  {
    code: 'bgc-IN',
    shortCode: 'bgc',
    name: 'Haryanvi (हरियाणवी)',
    nativeName: 'हरियाणवी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['ram', 'ram', 'ke', 'haal', 'sai', 'manne', 'tanne', 'bata']
  },
  {
    code: 'mwr-IN',
    shortCode: 'mwr',
    name: 'Marwari (मारवाड़ी)',
    nativeName: 'मारवाड़ी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['khamma', 'ghani', 'kai', 'haal', 'hai', 'mhane', 'thane']
  },
  {
    code: 'ks-IN',
    shortCode: 'ks',
    name: 'Kashmiri (کٲشُر / कश्मीरी)',
    nativeName: 'کٲشُر (بھارت)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF\u0900-\u097F]/,
    keywords: ['adaab', 'kya', 'sa', 'varai', 'chhu']
  },
  {
    code: 'sd-IN',
    shortCode: 'sd',
    name: 'Sindhi (سنڌي / सिंधी)',
    nativeName: 'سنڌي / सिन्धी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF\u0900-\u097F]/,
    keywords: ['keda', 'haal', 'aahin', 'meherbani']
  },
  {
    code: 'kok-IN',
    shortCode: 'kok',
    name: 'Konkani (कोंकणी)',
    nativeName: 'कोंकणी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['dev', 'boro', 'dis', 'diun', 'koso', 'asa']
  },
  {
    code: 'mni-IN',
    shortCode: 'mni',
    name: 'Manipuri (মৈতৈলোন্)',
    nativeName: 'মৈতৈলোন্ (Manipuri)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF\uABC0-\uABFF]/,
    keywords: ['khurumjari', 'kamdourige', 'fajei', 'thagatchari']
  },
  {
    code: 'meit-IN',
    shortCode: 'meit',
    name: 'Meitei (Meiteilon)',
    nativeName: 'মৈতৈলোন্ (Meitei)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\uABC0-\uABFF\u0980-\u09FF]/
  },
  {
    code: 'brx-IN',
    shortCode: 'brx',
    name: 'Bodo (बड़ो)',
    nativeName: 'बड़ो / Boro',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['khulumby', 'mwzang', 'dong', 'mabwrwi']
  },
  {
    code: 'sat-IN',
    shortCode: 'sat',
    name: 'Santali (ᱥᱟᱱᱛᱟᱲᱤ)',
    nativeName: 'ᱥᱟᱱᱛᱟᱲᱤ (Ol Chiki)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u1C50-\u1C7F]/,
    keywords: ['johar', 'chet', 'leka', 'menakma']
  },
  {
    code: 'doi-IN',
    shortCode: 'doi',
    name: 'Dogri (डोगरी)',
    nativeName: 'डोगरी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaste', 'ke', 'haal', 'hai', 'shukriya']
  },
  {
    code: 'tcy-IN',
    shortCode: 'tcy',
    name: 'Tulu (ತುಳು)',
    nativeName: 'ತುಳು',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0C80-\u0CFF]/,
    keywords: ['solmelu', 'encha', 'ullaru']
  },
  {
    code: 'awa-IN',
    shortCode: 'awa',
    name: 'Awadhi (अवधी)',
    nativeName: 'अवधी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['ram', 'ram', 'kaisen', 'aho', 'humar']
  },
  {
    code: 'bns-IN',
    shortCode: 'bns',
    name: 'Bundeli (बुंदेली)',
    nativeName: 'बुंदेली',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['jai', 'ram', 'ji', 'ki', 'kaiso', 'hai']
  },
  {
    code: 'gbm-IN',
    shortCode: 'gbm',
    name: 'Garhwali (गढ़वाली)',
    nativeName: 'गढ़वाली',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaskar', 'kannu', 'chho', 'bhal']
  },
  {
    code: 'kfy-IN',
    shortCode: 'kfy',
    name: 'Kumaoni (कुमाऊँनी)',
    nativeName: 'कुमाऊँनी',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaste', 'kaso', 'chho', 'bhalu']
  },
  {
    code: 'lus-IN',
    shortCode: 'lus',
    name: 'Mizo (Mizo ṭawng)',
    nativeName: 'Mizo ṭawng',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    keywords: ['chibai', 'i', 'dam', 'em', 'ka', 'lawm', 'e']
  },
  {
    code: 'grt-IN',
    shortCode: 'grt',
    name: 'Garo (A·chik - India)',
    nativeName: 'A·chik (India)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    keywords: ['salam', 'mittela', 'nama', 'nama']
  },
  {
    code: 'kha-IN',
    shortCode: 'kha',
    name: 'Khasi (Ka Ktien Khasi - India)',
    nativeName: 'Ka Ktien Khasi (India)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    keywords: ['khublei', 'kumno', 'phi', 'don']
  },
  {
    code: 'trp-IN',
    shortCode: 'trp',
    name: 'Kokborok (ককবরক - India)',
    nativeName: 'ককবরক (Tripura)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['khulumkha', 'baha', 'tong', 'hambai']
  },
  {
    code: 'anp-IN',
    shortCode: 'anp',
    name: 'Angika (अंगिका)',
    nativeName: 'अंगिका',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['pranam', 'kaisen', 'chhe', 'humar', 'tohar']
  },
  {
    code: 'lbj-IN',
    shortCode: 'lbj',
    name: 'Ladakhi (ལ་དྭགས་སྐད་)',
    nativeName: 'ལ་དྭགས་སྐད་',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0F00-\u0FFF]/,
    keywords: ['julley', 'khamzang', 'yod']
  },
  {
    code: 'dis-IN',
    shortCode: 'dis',
    name: 'Dimasa (দিমাসা)',
    nativeName: 'দিমাসা (Grao)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['khulumby', 'kaham', 'dong']
  },
  {
    code: 'lep-IN',
    shortCode: 'lep',
    name: 'Lepcha (Róng ring)',
    nativeName: 'ᱨᱳᱝ (Róng)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    keywords: ['khaduk', 'achulay']
  },
  {
    code: 'scl-IN',
    shortCode: 'scl',
    name: 'Shina (شینا)',
    nativeName: 'شینا (Shina)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'bft-IN',
    shortCode: 'bft',
    name: 'Balti (بلتی)',
    nativeName: 'بلتی (Balti)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'dkh-IN',
    shortCode: 'dkh',
    name: 'Dakhini (دکنی)',
    nativeName: 'دکنی (Deccani Urdu)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['kya', 're', 'nakko', 'hau', 'kare', 'kaiku']
  },
  {
    code: 'en-IN',
    shortCode: 'en',
    name: 'English (India)',
    nativeName: 'English (India)',
    country: 'India',
    region: 'South Asia',
    flag: '🇮🇳'
  },

  // ==========================================
  // BANGLADESH (10 languages & regional tongues)
  // ==========================================
  {
    code: 'bn-BD',
    shortCode: 'bn',
    name: 'Bangla (বাংলা - বাংলাদেশ)',
    nativeName: 'বাংলা (বাংলাদেশ)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['kemon', 'acho', 'valo', 'koro', 'amar', 'shob', 'dekho', 'dhonnobad', 'apni', 'tumi', 'shunechi']
  },
  {
    code: 'ccp-BD',
    shortCode: 'ccp',
    name: 'Chakma (চাকমা)',
    nativeName: '𑄌𑄋𑄴𑄟𑄳𑄦 (Changma)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    keywords: ['joi', 'namaskar', 'dhonnobad', 'changma']
  },
  {
    code: 'rmz-BD',
    shortCode: 'rmz',
    name: 'Marma (মারমা)',
    nativeName: 'মারমা (Marma / Rakhine)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩'
  },
  {
    code: 'trp-BD',
    shortCode: 'trp',
    name: 'Tripuri (ত্রিপুরী / Kokborok)',
    nativeName: 'ত্রিপুরী (Kokborok BD)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    scriptPattern: /[\u0980-\u09FF]/
  },
  {
    code: 'mni-BD',
    shortCode: 'mni',
    name: 'Manipuri (মণিপুরী - বাংলাদেশ)',
    nativeName: 'মৈতৈলোন্ (মণিপুরী BD)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    scriptPattern: /[\u0980-\u09FF]/
  },
  {
    code: 'kha-BD',
    shortCode: 'kha',
    name: 'Khasi (খাসি - বাংলাদেশ)',
    nativeName: 'Ka Ktien Khasi (BD)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩'
  },
  {
    code: 'grt-BD',
    shortCode: 'grt',
    name: 'Garo (গারো - বাংলাদেশ)',
    nativeName: 'A·chik (গারো BD)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩'
  },
  {
    code: 'syl-BD',
    shortCode: 'syl',
    name: 'Sylheti (সিলেটি)',
    nativeName: 'সিলটী নাগরি / সিলেটি',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['kila', 'aso', 'bhalo', 'ho', 'kita', 'khoi', 'fura']
  },
  {
    code: 'ctg-BD',
    shortCode: 'ctg',
    name: 'Chittagonian (চাঁটগাঁইয়া)',
    nativeName: 'চাঁটগাঁইয়া (Chatgaya)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩',
    scriptPattern: /[\u0980-\u09FF]/,
    keywords: ['ken', 'aso', 'bhal', 'kisu', 'gawya']
  },
  {
    code: 'rhg-BD',
    shortCode: 'rhg',
    name: 'Rohingya (Ruáingga)',
    nativeName: '𐴌𐴗𐴥𐴝𐴞𐴚𐴒𐴙𐴝 (Ruáingga)',
    country: 'Bangladesh',
    region: 'South Asia',
    flag: '🇧🇩'
  },

  // ==========================================
  // JAPAN (4 languages)
  // ==========================================
  {
    code: 'ja-JP',
    shortCode: 'ja',
    name: 'Japanese (日本語)',
    nativeName: '日本語',
    country: 'Japan',
    region: 'East Asia',
    flag: '🇯🇵',
    scriptPattern: /[\u3040-\u30FF\u4E00-\u9FAF]/,
    keywords: ['konnichiwa', 'arigatou', 'denki', 'tsukete', 'keshite', 'ohayou', 'hajimemashite', 'sou', 'desu']
  },
  {
    code: 'ain-JP',
    shortCode: 'ain',
    name: 'Ainu (アイヌ・イタㇰ)',
    nativeName: 'Ainu itak (アイヌ語)',
    country: 'Japan',
    region: 'East Asia',
    flag: '🇯🇵',
    keywords: ['irankarapte', 'iyairaykere']
  },
  {
    code: 'ryu-JP',
    shortCode: 'ryu',
    name: 'Okinawan (うちなーぐち)',
    nativeName: 'うちなーぐち (Uchinaaguchi)',
    country: 'Japan',
    region: 'East Asia',
    flag: '🇯🇵',
    keywords: ['haisai', 'haitai', 'nifeedeebiru']
  },
  {
    code: 'ryuk-JP',
    shortCode: 'ryuk',
    name: 'Ryukyuan (琉球諸語)',
    nativeName: '琉球諸語 (Ryukyuan)',
    country: 'Japan',
    region: 'East Asia',
    flag: '🇯🇵'
  },

  // ==========================================
  // CHINA (15 languages & regional dialects)
  // ==========================================
  {
    code: 'zh-CN',
    shortCode: 'zh',
    name: 'Mandarin (普通话)',
    nativeName: '普通话 (简体中文)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/,
    keywords: ['nihao', 'xiexie', 'kaideng', 'guandeng', 'zenmeyang', 'zaijian']
  },
  {
    code: 'yue-CN',
    shortCode: 'yue',
    name: 'Cantonese (粤语 / 廣東話)',
    nativeName: '粤语 / 廣東話',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/,
    keywords: ['neih hou', 'mgoi', 'doze', 'zoucan']
  },
  {
    code: 'wuu-CN',
    shortCode: 'wuu',
    name: 'Wu (吴语)',
    nativeName: '吴语 (苏浙话)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'hak-CN',
    shortCode: 'hak',
    name: 'Hakka (客家话)',
    nativeName: '客家话 (Hak-kâ-fa)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'nan-CN',
    shortCode: 'nan',
    name: 'Min Nan (闽南语 / Hokkien)',
    nativeName: '闽南语 (Bân-lâm-gú)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'mnp-CN',
    shortCode: 'mnp',
    name: 'Min Bei (闽北语)',
    nativeName: '闽北语',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'teo-CN',
    shortCode: 'teo',
    name: 'Teochew (潮州话)',
    nativeName: '潮州话 (Diē-tsiu-uē)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'shh-CN',
    shortCode: 'shh',
    name: 'Shanghainese (上海话)',
    nativeName: '上海话 (滬語)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u4E00-\u9FFF]/,
    keywords: ['nong', 'hao', 'xia', 'xia']
  },
  {
    code: 'bo-CN',
    shortCode: 'bo',
    name: 'Tibetan (བོད་སྐད་)',
    nativeName: 'བོད་སྐད་',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u0F00-\u0FFF]/,
    keywords: ['tashi', 'delek', 'thukjeche']
  },
  {
    code: 'ug-CN',
    shortCode: 'ug',
    name: 'Uyghur (ئۇيغۇرچە)',
    nativeName: 'ئۇيغۇرچە',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['essalamu', 'eleykum', 'rehmet']
  },
  {
    code: 'mn-CN',
    shortCode: 'mn',
    name: 'Mongolian (Монгол хэл)',
    nativeName: 'Монгол хэл / ᠮᠣᠩᠭᠣᠯ',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    keywords: ['sain', 'bainuu', 'bayarlalaa']
  },
  {
    code: 'kk-CN',
    shortCode: 'kk',
    name: 'Kazakh (Қазақ тілі)',
    nativeName: 'Қазақ тілі / قازاقشا',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳'
  },
  {
    code: 'ky-CN',
    shortCode: 'ky',
    name: 'Kyrgyz (Кыргызча)',
    nativeName: 'Кыргызча',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳'
  },
  {
    code: 'ko-CN',
    shortCode: 'ko',
    name: 'Korean (조선말 - Yanbian)',
    nativeName: '조선말 (Yanbian)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳',
    scriptPattern: /[\uAC00-\uD7AF\u1100-\u11FF]/
  },
  {
    code: 'za-CN',
    shortCode: 'za',
    name: 'Zhuang (Vahcuengh)',
    nativeName: 'Vahcuengh (壮语)',
    country: 'China',
    region: 'East Asia',
    flag: '🇨🇳'
  },

  // ==========================================
  // SOUTH KOREA & NORTH KOREA
  // ==========================================
  {
    code: 'ko-KR',
    shortCode: 'ko',
    name: 'Korean (한국어)',
    nativeName: '한국어 (대한민국)',
    country: 'South Korea',
    region: 'East Asia',
    flag: '🇰🇷',
    scriptPattern: /[\uAC00-\uD7AF\u1100-\u11FF]/,
    keywords: ['annyeong', 'gamsahamnida', 'ne', 'gomawo', 'saranghae']
  },
  {
    code: 'jje-KR',
    shortCode: 'jje',
    name: 'Jeju (제주어)',
    nativeName: '제주말 (제주어)',
    country: 'South Korea',
    region: 'East Asia',
    flag: '🇰🇷',
    scriptPattern: /[\uAC00-\uD7AF\u1100-\u11FF]/,
    keywords: ['honjeo', 'obseo']
  },
  {
    code: 'ko-KP',
    shortCode: 'ko',
    name: 'Korean (조선말 - North Korea)',
    nativeName: '조선말 (조선민주주의인민공화국)',
    country: 'North Korea',
    region: 'East Asia',
    flag: '🇰🇵',
    scriptPattern: /[\uAC00-\uD7AF\u1100-\u11FF]/
  },

  // ==========================================
  // NEPAL (11 languages)
  // ==========================================
  {
    code: 'ne-NP',
    shortCode: 'ne',
    name: 'Nepali (नेपाली)',
    nativeName: 'नेपाली',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['namaste', 'sanchai', 'hunuhunchha', 'dhanyabad', 'hajur']
  },
  {
    code: 'mai-NP',
    shortCode: 'mai',
    name: 'Maithili (मैथिली - नेपाल)',
    nativeName: 'मैथिली (नेपाल)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'bho-NP',
    shortCode: 'bho',
    name: 'Bhojpuri (भोजपुरी - नेपाल)',
    nativeName: 'भोजपुरी (नेपाल)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'thq-NP',
    shortCode: 'thq',
    name: 'Tharu (थारु)',
    nativeName: 'थारु भाषा',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'taj-NP',
    shortCode: 'taj',
    name: 'Tamang (तामाङ)',
    nativeName: 'तामाङ ग्योई',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'new-NP',
    shortCode: 'new',
    name: 'Newari (नेपाल भाषा)',
    nativeName: 'नेपाल भाषा (Nepal Bhasa)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/,
    keywords: ['jojolapa', 'subhaye']
  },
  {
    code: 'mgp-NP',
    shortCode: 'mgp',
    name: 'Magar (मगर भाषा)',
    nativeName: 'मगर ढुट',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'gvr-NP',
    shortCode: 'gvr',
    name: 'Gurung (गुरुङ)',
    nativeName: 'तमु क्युई (Gurung)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵'
  },
  {
    code: 'rjs-NP',
    shortCode: 'rjs',
    name: 'Rai (राई कुरा)',
    nativeName: 'राई (Rai languages)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵'
  },
  {
    code: 'lif-NP',
    shortCode: 'lif',
    name: 'Limbu (याक्थुङ्)',
    nativeName: 'ᤕᤠᤰᤌᤢᤱ (Yakthung)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    keywords: ['sewaro']
  },
  {
    code: 'xsr-NP',
    shortCode: 'xsr',
    name: 'Sherpa (शेर्पा)',
    nativeName: 'ཤར་པའི་སྐད་ཡིག (Sherpa)',
    country: 'Nepal',
    region: 'South Asia',
    flag: '🇳🇵',
    scriptPattern: /[\u0F00-\u0FFF\u0900-\u097F]/,
    keywords: ['tashi', 'delek']
  },

  // ==========================================
  // PAKISTAN (9 languages)
  // ==========================================
  {
    code: 'ur-PK',
    shortCode: 'ur',
    name: 'Urdu (اردو)',
    nativeName: 'اردو (پاکستان)',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['assalam', 'o', 'alaikum', 'shukriya', 'karo', 'chalao', 'band', 'kya', 'haal', 'hai']
  },
  {
    code: 'pa-PK',
    shortCode: 'pa',
    name: 'Punjabi (پنجابی - شاہ مکھی)',
    nativeName: 'پنجابی (شاہ مکھی)',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['kiddan', 'tussi', 'theek', 'ho']
  },
  {
    code: 'sd-PK',
    shortCode: 'sd',
    name: 'Sindhi (سنڌي)',
    nativeName: 'سنڌي (پاڪستان)',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'ps-PK',
    shortCode: 'ps',
    name: 'Pashto (پښتو)',
    nativeName: 'پښتو',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['pakheir', 'dera', 'manana', 'tsanga', 'ye']
  },
  {
    code: 'bal-PK',
    shortCode: 'bal',
    name: 'Balochi (بلوچی)',
    nativeName: 'بلوچی',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'skr-PK',
    shortCode: 'skr',
    name: 'Saraiki (سرائیکی)',
    nativeName: 'سرائیکی',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'hno-PK',
    shortCode: 'hno',
    name: 'Hindko (ہندکو)',
    nativeName: 'ہندکو',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'ks-PK',
    shortCode: 'ks',
    name: 'Kashmiri (کٲشُر - Azad Kashmir)',
    nativeName: 'کٲشُر',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'brh-PK',
    shortCode: 'brh',
    name: 'Brahui (براہوئی)',
    nativeName: 'براہوئی',
    country: 'Pakistan',
    region: 'South Asia',
    flag: '🇵🇰',
    scriptPattern: /[\u0600-\u06FF]/
  },

  // ==========================================
  // SRI LANKA (3 languages)
  // ==========================================
  {
    code: 'si-LK',
    shortCode: 'si',
    name: 'Sinhala (සිංහල)',
    nativeName: 'සිංහල',
    country: 'Sri Lanka',
    region: 'South Asia',
    flag: '🇱🇰',
    scriptPattern: /[\u0D80-\u0DFF]/,
    keywords: ['ayubowan', 'sthuthi', 'kohomada']
  },
  {
    code: 'ta-LK',
    shortCode: 'ta',
    name: 'Tamil (தமிழ் - இலங்கை)',
    nativeName: 'தமிழ் (இலங்கை)',
    country: 'Sri Lanka',
    region: 'South Asia',
    flag: '🇱🇰',
    scriptPattern: /[\u0B80-\u0BFF]/
  },
  {
    code: 'en-LK',
    shortCode: 'en',
    name: 'English (Sri Lanka)',
    nativeName: 'English (Sri Lanka)',
    country: 'Sri Lanka',
    region: 'South Asia',
    flag: '🇱🇰'
  },

  // ==========================================
  // BHUTAN (4 languages)
  // ==========================================
  {
    code: 'dz-BT',
    shortCode: 'dz',
    name: 'Dzongkha (རྫོང་ཁ)',
    nativeName: 'རྫོང་ཁ',
    country: 'Bhutan',
    region: 'South Asia',
    flag: '🇧🇹',
    scriptPattern: /[\u0F00-\u0FFF]/,
    keywords: ['kuzuzangpo', 'kadriche']
  },
  {
    code: 'ne-BT',
    shortCode: 'ne',
    name: 'Nepali (नेपाली - भुटान)',
    nativeName: 'नेपाली (भुटान)',
    country: 'Bhutan',
    region: 'South Asia',
    flag: '🇧🇹',
    scriptPattern: /[\u0900-\u097F]/
  },
  {
    code: 'tsj-BT',
    shortCode: 'tsj',
    name: 'Sharchopkha (Tshangla)',
    nativeName: 'ཤར་ཕྱོགས་པའི་ཁ (Tshangla)',
    country: 'Bhutan',
    region: 'South Asia',
    flag: '🇧🇹',
    scriptPattern: /[\u0F00-\u0FFF]/
  },
  {
    code: 'ne-Lhot',
    shortCode: 'lhot',
    name: 'Lhotshamkha',
    nativeName: 'ल्होत्साम्खा (Lhotshamkha)',
    country: 'Bhutan',
    region: 'South Asia',
    flag: '🇧🇹',
    scriptPattern: /[\u0900-\u097F]/
  },

  // ==========================================
  // MYANMAR (7 languages)
  // ==========================================
  {
    code: 'my-MM',
    shortCode: 'my',
    name: 'Burmese (မြန်မာစာ)',
    nativeName: 'မြန်မာဘာသာ',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲',
    scriptPattern: /[\u1000-\u109F]/,
    keywords: ['mingalaba', 'kyayzupare']
  },
  {
    code: 'shn-MM',
    shortCode: 'shn',
    name: 'Shan (လိၵ်ႈတႆး)',
    nativeName: 'လိၵ်ႈတႆး (Tai Yai)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲',
    scriptPattern: /[\u1000-\u109F]/
  },
  {
    code: 'kar-MM',
    shortCode: 'kar',
    name: 'Karen (ကညီကျိာ်)',
    nativeName: 'ကညီကျိာ် (Karen)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲'
  },
  {
    code: 'kac-MM',
    shortCode: 'kac',
    name: 'Kachin (Jinghpaw)',
    nativeName: 'Jinghpaw (Kachin)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲'
  },
  {
    code: 'cnh-MM',
    shortCode: 'cnh',
    name: 'Chin (Lai holh)',
    nativeName: 'Lai holh (Chin)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲'
  },
  {
    code: 'mnw-MM',
    shortCode: 'mnw',
    name: 'Mon (ဘာသာ မန်)',
    nativeName: 'ဘာသာ မန် (Mon)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲',
    scriptPattern: /[\u1000-\u109F]/
  },
  {
    code: 'rki-MM',
    shortCode: 'rki',
    name: 'Rakhine (ရခိုင်ဘာသာ)',
    nativeName: 'ရခိုင်ဘာသာ (Arakanese)',
    country: 'Myanmar',
    region: 'Southeast Asia',
    flag: '🇲🇲',
    scriptPattern: /[\u1000-\u109F]/
  },

  // ==========================================
  // THAILAND (6 languages)
  // ==========================================
  {
    code: 'th-TH',
    shortCode: 'th',
    name: 'Thai (ไทย)',
    nativeName: 'ภาษาไทย',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭',
    scriptPattern: /[\u0E00-\u0E7F]/,
    keywords: ['sawasdee', 'khop', 'khun', 'chai', 'mai']
  },
  {
    code: 'tts-TH',
    shortCode: 'tts',
    name: 'Isan (ภาษาอีสาน)',
    nativeName: 'ພາສາອີສານ / ภาษาอีสาน',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭',
    scriptPattern: /[\u0E00-\u0E7F]/,
    keywords: ['sabai', 'dee', 'bor', 'khoi', 'jao']
  },
  {
    code: 'nod-TH',
    shortCode: 'nod',
    name: 'Kam Mueang (คำเมือง)',
    nativeName: 'กำเมือง (Northern Thai)',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭',
    scriptPattern: /[\u0E00-\u0E7F]/
  },
  {
    code: 'mfa-TH',
    shortCode: 'mfa',
    name: 'Malay (Pattani Malay)',
    nativeName: 'Bahasa Melayu Patani',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭'
  },
  {
    code: 'ksw-TH',
    shortCode: 'ksw',
    name: 'Karen (Sgaw Karen)',
    nativeName: 'ကညီကျိာ် (Sgaw Karen)',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭'
  },
  {
    code: 'hmn-TH',
    shortCode: 'hmn',
    name: 'Hmong (Hmoob)',
    nativeName: 'Hmoob (Thailand)',
    country: 'Thailand',
    region: 'Southeast Asia',
    flag: '🇹🇭',
    keywords: ['nyob', 'zoo', 'ua', 'tsaug']
  },

  // ==========================================
  // VIETNAM (6 languages)
  // ==========================================
  {
    code: 'vi-VN',
    shortCode: 'vi',
    name: 'Vietnamese (Tiếng Việt)',
    nativeName: 'Tiếng Việt',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳',
    keywords: ['xin', 'chao', 'cam', 'on', 'khong', 'ban', 'khoe', 'khong']
  },
  {
    code: 'km-VN',
    shortCode: 'km',
    name: 'Khmer (Khmer Krom)',
    nativeName: 'ភាសាខ្មែរ (Khmer Krom)',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳'
  },
  {
    code: 'tyz-VN',
    shortCode: 'tyz',
    name: 'Tay (Tiếng Tày)',
    nativeName: 'Tiếng Tày',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳'
  },
  {
    code: 'blt-VN',
    shortCode: 'blt',
    name: 'Thai (Tiếng Thái - VN)',
    nativeName: 'Tiếng Thái (Tai Dam)',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳'
  },
  {
    code: 'hmn-VN',
    shortCode: 'hmn',
    name: 'Hmong (Tiếng H’Mông)',
    nativeName: 'Hmoob (Vietnam)',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳'
  },
  {
    code: 'cja-VN',
    shortCode: 'cja',
    name: 'Cham (Tiếng Chăm)',
    nativeName: 'Cam (Western Cham)',
    country: 'Vietnam',
    region: 'Southeast Asia',
    flag: '🇻🇳'
  },

  // ==========================================
  // INDONESIA (7 languages)
  // ==========================================
  {
    code: 'id-ID',
    shortCode: 'id',
    name: 'Indonesian (Bahasa Indonesia)',
    nativeName: 'Bahasa Indonesia',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['halo', 'terima', 'kasih', 'nyalakan', 'matikan', 'bagaimana', 'kabar']
  },
  {
    code: 'jv-ID',
    shortCode: 'jv',
    name: 'Javanese (Basa Jawa)',
    nativeName: 'Basa Jawa',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['sugeng', 'enjang', 'matur', 'nuwun', 'piye', 'kabare']
  },
  {
    code: 'su-ID',
    shortCode: 'su',
    name: 'Sundanese (Basa Sunda)',
    nativeName: 'Basa Sunda',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['sampurasun', 'hatur', 'nuhun', 'kumaha']
  },
  {
    code: 'mad-ID',
    shortCode: 'mad',
    name: 'Madurese (Basa Madhura)',
    nativeName: 'Basa Madhura',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['salamet', 'mator', 'saklangkong']
  },
  {
    code: 'ban-ID',
    shortCode: 'ban',
    name: 'Balinese (Basa Bali)',
    nativeName: 'Basa Bali',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['om', 'swastyastu', 'suksma', 'kenken', 'kabare']
  },
  {
    code: 'min-ID',
    shortCode: 'min',
    name: 'Minangkabau (Baso Minang)',
    nativeName: 'Baso Minang',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['tarimo', 'kasih', 'baa', 'kaba']
  },
  {
    code: 'bug-ID',
    shortCode: 'bug',
    name: 'Buginese (Basa Ugi)',
    nativeName: 'Basa Ugi (Lontara)',
    country: 'Indonesia',
    region: 'Southeast Asia',
    flag: '🇮🇩',
    keywords: ['kurru', 'sumange']
  },

  // ==========================================
  // MALAYSIA (7 languages)
  // ==========================================
  {
    code: 'ms-MY',
    shortCode: 'ms',
    name: 'Malay (Bahasa Melayu)',
    nativeName: 'Bahasa Melayu (Malaysia)',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾',
    keywords: ['selamat', 'pagi', 'terima', 'kasih', 'apa', 'khabar']
  },
  {
    code: 'en-MY',
    shortCode: 'en',
    name: 'English (Malaysia)',
    nativeName: 'Malaysian English',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾'
  },
  {
    code: 'zh-MY',
    shortCode: 'zh',
    name: 'Chinese (华语 - 马来西亚)',
    nativeName: '马来西亚华语',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'ta-MY',
    shortCode: 'ta',
    name: 'Tamil (தமிழ் - மலேசியா)',
    nativeName: 'தமிழ் (மலேசியா)',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾',
    scriptPattern: /[\u0B80-\u0BFF]/
  },
  {
    code: 'iba-MY',
    shortCode: 'iba',
    name: 'Iban (Jaku Iban)',
    nativeName: 'Jaku Iban',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾',
    keywords: ['oloo', 'terima', 'kasih']
  },
  {
    code: 'dtp-MY',
    shortCode: 'dtp',
    name: 'Kadazan (Boros Kadazan)',
    nativeName: 'Boros Kadazan',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾',
    keywords: ['kotobian', 'tadau', 'pansikahan']
  },
  {
    code: 'kzt-MY',
    shortCode: 'kzt',
    name: 'Dusun (Boros Dusun)',
    nativeName: 'Boros Dusun',
    country: 'Malaysia',
    region: 'Southeast Asia',
    flag: '🇲🇾'
  },

  // ==========================================
  // SINGAPORE (4 languages)
  // ==========================================
  {
    code: 'en-SG',
    shortCode: 'en',
    name: 'English (Singapore)',
    nativeName: 'Singapore English',
    country: 'Singapore',
    region: 'Southeast Asia',
    flag: '🇸🇬'
  },
  {
    code: 'ms-SG',
    shortCode: 'ms',
    name: 'Malay (Singapore)',
    nativeName: 'Bahasa Melayu (Singapura)',
    country: 'Singapore',
    region: 'Southeast Asia',
    flag: '🇸🇬'
  },
  {
    code: 'zh-SG',
    shortCode: 'zh',
    name: 'Mandarin (华语 - 新加坡)',
    nativeName: '新加坡华语',
    country: 'Singapore',
    region: 'Southeast Asia',
    flag: '🇸🇬',
    scriptPattern: /[\u4E00-\u9FFF]/
  },
  {
    code: 'ta-SG',
    shortCode: 'ta',
    name: 'Tamil (தமிழ் - சிங்கப்பூர்)',
    nativeName: 'தமிழ் (சிங்கப்பூர்)',
    country: 'Singapore',
    region: 'Southeast Asia',
    flag: '🇸🇬',
    scriptPattern: /[\u0B80-\u0BFF]/
  },

  // ==========================================
  // PHILIPPINES (8 languages)
  // ==========================================
  {
    code: 'fil-PH',
    shortCode: 'fil',
    name: 'Filipino (Tagalog)',
    nativeName: 'Wikang Filipino',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['kamusta', 'salamat', 'opo', 'magandang', 'umaga', 'paalam']
  },
  {
    code: 'en-PH',
    shortCode: 'en',
    name: 'English (Philippines)',
    nativeName: 'Philippine English',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭'
  },
  {
    code: 'ceb-PH',
    shortCode: 'ceb',
    name: 'Cebuano (Bisaya)',
    nativeName: 'Binisaya (Cebuano)',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['kumusta', 'salamat', 'maayong', 'buntag']
  },
  {
    code: 'ilo-PH',
    shortCode: 'ilo',
    name: 'Ilocano (Ilokano)',
    nativeName: 'Ti Pagsasao nga Ilokano',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['naimbag', 'nga', 'agasapa', 'agyamanak']
  },
  {
    code: 'hil-PH',
    shortCode: 'hil',
    name: 'Hiligaynon (Ilonggo)',
    nativeName: 'Ilonggo (Hiligaynon)',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['maayong', 'aga', 'madamo', 'nga', 'salamat']
  },
  {
    code: 'war-PH',
    shortCode: 'war',
    name: 'Waray (Winaray)',
    nativeName: 'Winaray (Waray-Waray)',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['maupay', 'nga', 'aga', 'damo', 'nga', 'salamat']
  },
  {
    code: 'pam-PH',
    shortCode: 'pam',
    name: 'Kapampangan (Pampango)',
    nativeName: 'Amanung Kapampangan',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['komusta', 'dakal', 'a', 'salamat']
  },
  {
    code: 'pag-PH',
    shortCode: 'pag',
    name: 'Pangasinan (Pangasinense)',
    nativeName: 'Salitan Pangasinan',
    country: 'Philippines',
    region: 'Southeast Asia',
    flag: '🇵🇭',
    keywords: ['masantos', 'ya', 'kabuas', 'salamat']
  },

  // ==========================================
  // AUSTRALIA (3 languages)
  // ==========================================
  {
    code: 'en-AU',
    shortCode: 'en',
    name: 'English (Australia)',
    nativeName: 'Australian English',
    country: 'Australia',
    region: 'Oceania',
    flag: '🇦🇺'
  },
  {
    code: 'en-AU-slang',
    shortCode: 'en',
    name: 'Australian Strine (Aussie)',
    nativeName: 'Strine / Aussie Slang',
    country: 'Australia',
    region: 'Oceania',
    flag: '🇦🇺',
    keywords: ['g\'day', 'mate', 'howzit', 'fair', 'dinkum', 'no', 'worries', 'cheers']
  },
  {
    code: 'aus-AU',
    shortCode: 'aus',
    name: 'Aboriginal Languages',
    nativeName: 'First Nations Aboriginal Languages',
    country: 'Australia',
    region: 'Oceania',
    flag: '🇦🇺'
  },

  // ==========================================
  // NEW ZEALAND (3 languages)
  // ==========================================
  {
    code: 'en-NZ',
    shortCode: 'en',
    name: 'English (New Zealand)',
    nativeName: 'New Zealand English',
    country: 'New Zealand',
    region: 'Oceania',
    flag: '🇳🇿'
  },
  {
    code: 'mi-NZ',
    shortCode: 'mi',
    name: 'Māori (Te Reo Māori)',
    nativeName: 'Te Reo Māori',
    country: 'New Zealand',
    region: 'Oceania',
    flag: '🇳🇿',
    keywords: ['kia', 'ora', 'tenā', 'koe', 'ngā', 'mihi', 'haere', 'mai']
  },
  {
    code: 'nzs-NZ',
    shortCode: 'nzs',
    name: 'New Zealand Sign Language',
    nativeName: 'NZSL',
    country: 'New Zealand',
    region: 'Oceania',
    flag: '🇳🇿'
  },

  // ==========================================
  // UNITED STATES (7 languages)
  // ==========================================
  {
    code: 'en-US',
    shortCode: 'en',
    name: 'English (United States)',
    nativeName: 'American English',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸',
    keywords: ['hello', 'turn', 'on', 'off', 'switch', 'what', 'how', 'thanks', 'weather', 'light']
  },
  {
    code: 'es-US',
    shortCode: 'es',
    name: 'Spanish (US / Español)',
    nativeName: 'Español estadounidense',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸',
    keywords: ['hola', 'como', 'estas', 'enciende', 'apaga', 'gracias']
  },
  {
    code: 'fr-US',
    shortCode: 'fr',
    name: 'French (Louisiana / Cajun)',
    nativeName: 'Français louisianais',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸'
  },
  {
    code: 'haw-US',
    shortCode: 'haw',
    name: 'Hawaiian (ʻŌlelo Hawaiʻi)',
    nativeName: 'ʻŌlelo Hawaiʻi',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸',
    keywords: ['aloha', 'mahalo', 'pehea', 'ʻoe']
  },
  {
    code: 'nv-US',
    shortCode: 'nv',
    name: 'Navajo (Diné bizaad)',
    nativeName: 'Diné bizaad',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸',
    keywords: ['yá\'át\'ééh', 'ahéhee\'']
  },
  {
    code: 'chr-US',
    shortCode: 'chr',
    name: 'Cherokee (ᏣᎳᎩ)',
    nativeName: 'ᏣᎳᎩ ᎦᏬᏂᎯᏍᏗ (Tsalagi)',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸',
    keywords: ['osiyo', 'wado']
  },
  {
    code: 'ike-US',
    shortCode: 'ike',
    name: 'Inuktitut / Inupiaq',
    nativeName: 'Iñupiatun (Alaska)',
    country: 'United States',
    region: 'Americas',
    flag: '🇺🇸'
  },

  // ==========================================
  // CANADA (5 languages)
  // ==========================================
  {
    code: 'en-CA',
    shortCode: 'en',
    name: 'English (Canada)',
    nativeName: 'Canadian English',
    country: 'Canada',
    region: 'Americas',
    flag: '🇨🇦'
  },
  {
    code: 'fr-CA',
    shortCode: 'fr',
    name: 'French (Français canadien)',
    nativeName: 'Français canadien',
    country: 'Canada',
    region: 'Americas',
    flag: '🇨🇦',
    keywords: ['bonjour', 'merci', 'allume', 'éteins', 'comment', 'allez', 'vous']
  },
  {
    code: 'iku-CA',
    shortCode: 'iku',
    name: 'Inuktitut (ᐃᓄᒃᑎᑐᑦ)',
    nativeName: 'ᐃᓄᒃᑎᑐᑦ (Eastern Canadian)',
    country: 'Canada',
    region: 'Americas',
    flag: '🇨🇦',
    keywords: ['ainngai', 'qujannamiik']
  },
  {
    code: 'cr-CA',
    shortCode: 'cr',
    name: 'Cree (Nēhiyawēwin)',
    nativeName: 'ᓀᐦᐃᔭᐍwin / Nēhiyawēwin',
    country: 'Canada',
    region: 'Americas',
    flag: '🇨🇦',
    keywords: ['tansi', 'kinanaskomitin']
  },
  {
    code: 'oj-CA',
    shortCode: 'oj',
    name: 'Ojibwe (Anishinaabemowin)',
    nativeName: 'Anishinaabemowin',
    country: 'Canada',
    region: 'Americas',
    flag: '🇨🇦',
    keywords: ['boozhoo', 'miigwech']
  },

  // ==========================================
  // MEXICO (5 languages)
  // ==========================================
  {
    code: 'es-MX',
    shortCode: 'es',
    name: 'Spanish (Español de México)',
    nativeName: 'Español mexicano',
    country: 'Mexico',
    region: 'Americas',
    flag: '🇲🇽',
    keywords: ['hola', 'que', 'onda', 'gracias', 'orale', 'enciende', 'apaga']
  },
  {
    code: 'nah-MX',
    shortCode: 'nah',
    name: 'Nahuatl (Nāhuatlahtōlli)',
    nativeName: 'Nāhuatlahtōlli',
    country: 'Mexico',
    region: 'Americas',
    flag: '🇲🇽',
    keywords: ['niltze', 'tlazohcamati']
  },
  {
    code: 'myn-MX',
    shortCode: 'myn',
    name: 'Mayan (Maaya t\'àan)',
    nativeName: 'Maaya t\'àan (Yucatec)',
    country: 'Mexico',
    region: 'Americas',
    flag: '🇲🇽',
    keywords: ['ba\'ax', 'ka', 'wa\'alik', 'yuum', 'bo\'otik']
  },
  {
    code: 'mix-MX',
    shortCode: 'mix',
    name: 'Mixtec (Tu\'un sávi)',
    nativeName: 'Tu\'un sávi',
    country: 'Mexico',
    region: 'Americas',
    flag: '🇲🇽'
  },
  {
    code: 'zap-MX',
    shortCode: 'zap',
    name: 'Zapotec (Diidxazá)',
    nativeName: 'Diidxazá',
    country: 'Mexico',
    region: 'Americas',
    flag: '🇲🇽'
  },

  // ==========================================
  // BRAZIL (3 languages)
  // ==========================================
  {
    code: 'pt-BR',
    shortCode: 'pt',
    name: 'Portuguese (Português do Brasil)',
    nativeName: 'Português brasileiro',
    country: 'Brazil',
    region: 'Americas',
    flag: '🇧🇷',
    keywords: ['ola', 'obrigado', 'tudo', 'bem', 'ligar', 'desligar', 'luz', 'musica']
  },
  {
    code: 'es-BR',
    shortCode: 'es',
    name: 'Spanish (Portuñol / Fronterizo)',
    nativeName: 'Portuñol fronteiriço',
    country: 'Brazil',
    region: 'Americas',
    flag: '🇧🇷'
  },
  {
    code: 'gn-BR',
    shortCode: 'gn',
    name: 'Guarani (Avañe\'ẽ - Brasil)',
    nativeName: 'Avañe\'ẽ (Brasil)',
    country: 'Brazil',
    region: 'Americas',
    flag: '🇧🇷'
  },

  // ==========================================
  // ARGENTINA (3 languages)
  // ==========================================
  {
    code: 'es-AR',
    shortCode: 'es',
    name: 'Spanish (Español rioplatense)',
    nativeName: 'Español rioplatense',
    country: 'Argentina',
    region: 'Americas',
    flag: '🇦🇷',
    keywords: ['che', 'hola', 'como', 'andas', 'gracias', 'prende', 'apaga']
  },
  {
    code: 'gn-AR',
    shortCode: 'gn',
    name: 'Guarani (Avañe\'ẽ correntino)',
    nativeName: 'Avañe\'ẽ (Corrientes)',
    country: 'Argentina',
    region: 'Americas',
    flag: '🇦🇷'
  },
  {
    code: 'qu-AR',
    shortCode: 'qu',
    name: 'Quechua (Runa Simi santiagueño)',
    nativeName: 'Quichua santiagueño',
    country: 'Argentina',
    region: 'Americas',
    flag: '🇦🇷'
  },

  // ==========================================
  // CHILE (3 languages)
  // ==========================================
  {
    code: 'es-CL',
    shortCode: 'es',
    name: 'Spanish (Español de Chile)',
    nativeName: 'Español chileno',
    country: 'Chile',
    region: 'Americas',
    flag: '🇨🇱',
    keywords: ['hola', 'como', 'estai', 'wena', 'gracias']
  },
  {
    code: 'arn-CL',
    shortCode: 'arn',
    name: 'Mapudungun (Mapuche)',
    nativeName: 'Mapudungun',
    country: 'Chile',
    region: 'Americas',
    flag: '🇨🇱',
    keywords: ['mari', 'mari', 'chaltu']
  },
  {
    code: 'rap-CL',
    shortCode: 'rap',
    name: 'Rapa Nui (Easter Island)',
    nativeName: 'Vananga Rapa Nui',
    country: 'Chile',
    region: 'Americas',
    flag: '🇨🇱',
    keywords: ['iorana', 'maururu']
  },

  // ==========================================
  // PERU (3 languages)
  // ==========================================
  {
    code: 'es-PE',
    shortCode: 'es',
    name: 'Spanish (Español de Perú)',
    nativeName: 'Español peruano',
    country: 'Peru',
    region: 'Americas',
    flag: '🇵🇪',
    keywords: ['hola', 'como', 'estas', 'gracias']
  },
  {
    code: 'qu-PE',
    shortCode: 'qu',
    name: 'Quechua (Runa Simi)',
    nativeName: 'Runa Simi (Qhichwa)',
    country: 'Peru',
    region: 'Americas',
    flag: '🇵🇪',
    keywords: ['allianllachu', 'sulpayki', 'allillanmi']
  },
  {
    code: 'ay-PE',
    shortCode: 'ay',
    name: 'Aymara (Aymar aru)',
    nativeName: 'Aymar aru',
    country: 'Peru',
    region: 'Americas',
    flag: '🇵🇪',
    keywords: ['kamisaraki', 'waliki', 'yuspajara']
  },

  // ==========================================
  // COLOMBIA (3 languages)
  // ==========================================
  {
    code: 'es-CO',
    shortCode: 'es',
    name: 'Spanish (Español de Colombia)',
    nativeName: 'Español colombiano',
    country: 'Colombia',
    region: 'Americas',
    flag: '🇨🇴',
    keywords: ['hola', 'que', 'mas', 'parce', 'bien', 'gracias']
  },
  {
    code: 'guc-CO',
    shortCode: 'guc',
    name: 'Wayuu (Wayuunaiki)',
    nativeName: 'Wayuunaiki',
    country: 'Colombia',
    region: 'Americas',
    flag: '🇨🇴',
    keywords: ['anashi', 'analu']
  },
  {
    code: 'pbb-CO',
    shortCode: 'pbb',
    name: 'Nasa Yuwe (Paez)',
    nativeName: 'Nasa Yuwe',
    country: 'Colombia',
    region: 'Americas',
    flag: '🇨🇴'
  },

  // ==========================================
  // UNITED KINGDOM (6 languages)
  // ==========================================
  {
    code: 'en-GB',
    shortCode: 'en',
    name: 'English (United Kingdom)',
    nativeName: 'British English',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧',
    keywords: ['hello', 'cheerio', 'thank', 'you', 'brilliant', 'lights']
  },
  {
    code: 'cy-GB',
    shortCode: 'cy',
    name: 'Welsh (Cymraeg)',
    nativeName: 'Cymraeg',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧',
    keywords: ['shwmae', 'diolch', 'bore', 'da']
  },
  {
    code: 'gd-GB',
    shortCode: 'gd',
    name: 'Scottish Gaelic (Gàidhlig)',
    nativeName: 'Gàidhlig',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧',
    keywords: ['halò', 'tapadh', 'leat', 'madainn', 'mhath']
  },
  {
    code: 'ga-GB',
    shortCode: 'ga',
    name: 'Irish (Gaeilge - N. Ireland)',
    nativeName: 'Gaeilge (Tuaisceart Éireann)',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧'
  },
  {
    code: 'kw-GB',
    shortCode: 'kw',
    name: 'Cornish (Kernewek)',
    nativeName: 'Kernewek',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧',
    keywords: ['dydh', 'da', 'meur', 'ras']
  },
  {
    code: 'gv-GB',
    shortCode: 'gv',
    name: 'Manx (Gaelg)',
    nativeName: 'Gaelg (Ellan Vannin)',
    country: 'United Kingdom',
    region: 'Europe',
    flag: '🇬🇧',
    keywords: ['moghrey', 'mie', 'gura', 'mie', 'eu']
  },

  // ==========================================
  // IRELAND (2 languages)
  // ==========================================
  {
    code: 'ga-IE',
    shortCode: 'ga',
    name: 'Irish (Gaeilge)',
    nativeName: 'Gaeilge',
    country: 'Ireland',
    region: 'Europe',
    flag: '🇮🇪',
    keywords: ['dia', 'duit', 'go', 'raibh', 'maith', 'agat', 'slán']
  },
  {
    code: 'en-IE',
    shortCode: 'en',
    name: 'English (Ireland)',
    nativeName: 'Hiberno-English',
    country: 'Ireland',
    region: 'Europe',
    flag: '🇮🇪',
    keywords: ['grand', 'craic', 'cheers']
  },

  // ==========================================
  // FRANCE (7 languages)
  // ==========================================
  {
    code: 'fr-FR',
    shortCode: 'fr',
    name: 'French (Français)',
    nativeName: 'Français',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷',
    keywords: ['bonjour', 'merci', 'eteins', 'allume', 'musique', 'comment', 'allez', 'lumiere']
  },
  {
    code: 'oc-FR',
    shortCode: 'oc',
    name: 'Occitan (Occitan)',
    nativeName: 'Lenga d\'òc',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷',
    keywords: ['adieu', 'gramaci', 'bonjorn']
  },
  {
    code: 'br-FR',
    shortCode: 'br',
    name: 'Breton (Brezhoneg)',
    nativeName: 'Brezhoneg',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷',
    keywords: ['demat', 'trugarez', 'kenavo']
  },
  {
    code: 'co-FR',
    shortCode: 'co',
    name: 'Corsican (Corsu)',
    nativeName: 'Corsu',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷',
    keywords: ['bonghjornu', 'grazie']
  },
  {
    code: 'gsw-FR',
    shortCode: 'gsw',
    name: 'Alsatian (Elsässisch)',
    nativeName: 'Elsässerditsch',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷',
    keywords: ['hallo', 'danke', 'salü']
  },
  {
    code: 'eu-FR',
    shortCode: 'eu',
    name: 'Basque (Euskara - Iparralde)',
    nativeName: 'Euskara (Iparralde)',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷'
  },
  {
    code: 'ca-FR',
    shortCode: 'ca',
    name: 'Catalan (Català septentrional)',
    nativeName: 'Català (Rosselló)',
    country: 'France',
    region: 'Europe',
    flag: '🇫🇷'
  },

  // ==========================================
  // GERMANY (5 languages)
  // ==========================================
  {
    code: 'de-DE',
    shortCode: 'de',
    name: 'German (Deutsch)',
    nativeName: 'Deutsch',
    country: 'Germany',
    region: 'Europe',
    flag: '🇩🇪',
    keywords: ['hallo', 'danke', 'licht', 'anmachen', 'ausschalten', 'wie', 'geht', 'guten', 'tag']
  },
  {
    code: 'nds-DE',
    shortCode: 'nds',
    name: 'Low German (Plattdüütsch)',
    nativeName: 'Plattdüütsch',
    country: 'Germany',
    region: 'Europe',
    flag: '🇩🇪',
    keywords: ['moin', 'dank', 'di']
  },
  {
    code: 'da-DE',
    shortCode: 'da',
    name: 'Danish (Sydslesvigdansk)',
    nativeName: 'Dansk (Sydslesvig)',
    country: 'Germany',
    region: 'Europe',
    flag: '🇩🇪'
  },
  {
    code: 'fy-DE',
    shortCode: 'fy',
    name: 'Frisian (Saterfriesisch / Frasch)',
    nativeName: 'Seeltersk / Friisk',
    country: 'Germany',
    region: 'Europe',
    flag: '🇩🇪'
  },
  {
    code: 'rom-DE',
    shortCode: 'rom',
    name: 'Romani (Romani čhib)',
    nativeName: 'Romani čhib',
    country: 'Germany',
    region: 'Europe',
    flag: '🇩🇪'
  },

  // ==========================================
  // SPAIN (7 languages)
  // ==========================================
  {
    code: 'es-ES',
    shortCode: 'es',
    name: 'Spanish (Español / Castellano)',
    nativeName: 'Español',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['hola', 'buenos', 'dias', 'gracias', 'enciende', 'apaga', 'luz', 'musica', 'por', 'favor']
  },
  {
    code: 'ca-ES',
    shortCode: 'ca',
    name: 'Catalan (Català)',
    nativeName: 'Català',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['hola', 'bon', 'dia', 'gràcies', 'encén', 'apaga']
  },
  {
    code: 'gl-ES',
    shortCode: 'gl',
    name: 'Galician (Galego)',
    nativeName: 'Galego',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['ola', 'boas', 'grazas', 'acende', 'apaga']
  },
  {
    code: 'eu-ES',
    shortCode: 'eu',
    name: 'Basque (Euskara)',
    nativeName: 'Euskara',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['kaixo', 'eskerrik', 'asko', 'egun', 'on']
  },
  {
    code: 'ast-ES',
    shortCode: 'ast',
    name: 'Asturian (Asturianu)',
    nativeName: 'Asturianu (Bable)',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['hola', 'gracies', 'bon', 'dia']
  },
  {
    code: 'an-ES',
    shortCode: 'an',
    name: 'Aragonese (Aragonés)',
    nativeName: 'Aragonés',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸',
    keywords: ['ola', 'gracias', 'buen', 'día']
  },
  {
    code: 'oc-ES',
    shortCode: 'oc',
    name: 'Occitan / Aranese (Aranés)',
    nativeName: 'Aranés (Val d\'Aran)',
    country: 'Spain',
    region: 'Europe',
    flag: '🇪🇸'
  },

  // ==========================================
  // PORTUGAL (1 language)
  // ==========================================
  {
    code: 'pt-PT',
    shortCode: 'pt',
    name: 'Portuguese (Português de Portugal)',
    nativeName: 'Português europeu',
    country: 'Portugal',
    region: 'Europe',
    flag: '🇵🇹',
    keywords: ['olá', 'bom', 'dia', 'obrigado', 'obrigada', 'ligar', 'desligar']
  },

  // ==========================================
  // ITALY (6 languages)
  // ==========================================
  {
    code: 'it-IT',
    shortCode: 'it',
    name: 'Italian (Italiano)',
    nativeName: 'Italiano',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹',
    keywords: ['ciao', 'grazie', 'accendi', 'spegni', 'luce', 'come', 'stai', 'buongiorno']
  },
  {
    code: 'scn-IT',
    shortCode: 'scn',
    name: 'Sicilian (Sicilianu)',
    nativeName: 'Sicilianu',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹',
    keywords: ['ciau', 'grazzi', 'bonjornu']
  },
  {
    code: 'nap-IT',
    shortCode: 'nap',
    name: 'Neapolitan (Napulitano)',
    nativeName: 'Napulitano',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹',
    keywords: ['ciao', 'grazie', 'comm', 'stai']
  },
  {
    code: 'lmo-IT',
    shortCode: 'lmo',
    name: 'Lombard (Lumbard)',
    nativeName: 'Lumbaart',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹'
  },
  {
    code: 'sc-IT',
    shortCode: 'sc',
    name: 'Sardinian (Sardu)',
    nativeName: 'Limba sarda',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹'
  },
  {
    code: 'vec-IT',
    shortCode: 'vec',
    name: 'Venetian (Vèneto)',
    nativeName: 'Lengua vèneta',
    country: 'Italy',
    region: 'Europe',
    flag: '🇮🇹'
  },

  // ==========================================
  // RUSSIA (10 languages)
  // ==========================================
  {
    code: 'ru-RU',
    shortCode: 'ru',
    name: 'Russian (Русский)',
    nativeName: 'Русский язык',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/,
    keywords: ['privet', 'spasibo', 'vklyuchi', 'vyklyuchi', 'svet', 'kak', 'dela', 'здравствуйте', 'привет', 'спасибо']
  },
  {
    code: 'tt-RU',
    shortCode: 'tt',
    name: 'Tatar (Татарча)',
    nativeName: 'Татар теле',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/,
    keywords: ['isänmesez', 'räxmät']
  },
  {
    code: 'ba-RU',
    shortCode: 'ba',
    name: 'Bashkir (Башҡортса)',
    nativeName: 'Башҡорт теле',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'ce-RU',
    shortCode: 'ce',
    name: 'Chechen (Нохчийн мотт)',
    nativeName: 'Нохчийн мотт',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/,
    keywords: ['marsha', 'voghiiyla', 'barkalla']
  },
  {
    code: 'cv-RU',
    shortCode: 'cv',
    name: 'Chuvash (Чӑвашла)',
    nativeName: 'Чӑваш чӗлхи',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'av-RU',
    shortCode: 'av',
    name: 'Avar (МагӀарул мацӀ)',
    nativeName: 'МагӀарул мацӀ',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'os-RU',
    shortCode: 'os',
    name: 'Ossetian (Ирон ӕвзаг)',
    nativeName: 'Ирон ӕвзаг',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'sah-RU',
    shortCode: 'sah',
    name: 'Yakut (Саха тыла)',
    nativeName: 'Саха тыла (Sakha)',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'bua-RU',
    shortCode: 'bua',
    name: 'Buryat (Буряад хэлэн)',
    nativeName: 'Буряад хэлэн',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },
  {
    code: 'tyv-RU',
    shortCode: 'tyv',
    name: 'Tuvan (Тыва дыл)',
    nativeName: 'Тыва дыл',
    country: 'Russia',
    region: 'Europe / North Asia',
    flag: '🇷🇺',
    scriptPattern: /[\u0400-\u04FF]/
  },

  // ==========================================
  // MIDDLE EAST, MEDITERRANEAN & AFRICA
  // ==========================================
  {
    code: 'tr-TR',
    shortCode: 'tr',
    name: 'Turkish (Türkçe)',
    nativeName: 'Türkçe',
    country: 'Turkey',
    region: 'Middle East',
    flag: '🇹🇷',
    keywords: ['merhaba', 'tesekkurler', 'isigi', 'ac', 'kapat', 'nasilsin', 'gunaydin']
  },
  {
    code: 'ku-TR',
    shortCode: 'ku',
    name: 'Kurdish (Kurdî)',
    nativeName: 'Kurdî (Kurmancî)',
    country: 'Turkey',
    region: 'Middle East',
    flag: '🇹🇷',
    keywords: ['silav', 'spas', 'choni']
  },
  {
    code: 'ar-SA',
    shortCode: 'ar',
    name: 'Arabic (العربية - السعودية)',
    nativeName: 'العربية (المملكة العربية السعودية)',
    country: 'Saudi Arabia',
    region: 'Middle East',
    flag: '🇸🇦',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['marhaban', 'shukran', 'tashghil', 'itfa', 'kaifa', 'haluk', 'مرحبا', 'شكرا']
  },
  {
    code: 'ar-AE',
    shortCode: 'ar',
    name: 'Arabic (العربية - الإمارات)',
    nativeName: 'العربية (الإمارات العربية المتحدة)',
    country: 'United Arab Emirates',
    region: 'Middle East',
    flag: '🇦🇪',
    scriptPattern: /[\u0600-\u06FF]/
  },
  {
    code: 'ar-EG',
    shortCode: 'ar',
    name: 'Arabic (العربية - مصر)',
    nativeName: 'العربية المصرية',
    country: 'Egypt',
    region: 'Middle East & North Africa',
    flag: '🇪🇬',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['ezzayak', 'shokran', 'tamam', 'mashy']
  },
  {
    code: 'fa-IR',
    shortCode: 'fa',
    name: 'Persian / Farsi (فارسی)',
    nativeName: 'فارسی',
    country: 'Iran',
    region: 'Middle East',
    flag: '🇮🇷',
    scriptPattern: /[\u0600-\u06FF]/,
    keywords: ['salam', 'mamnoon', 'mersi', 'hale', 'shoma', 'chetore']
  },
  {
    code: 'he-IL',
    shortCode: 'he',
    name: 'Hebrew (עברית)',
    nativeName: 'עברית',
    country: 'Israel',
    region: 'Middle East',
    flag: '🇮🇱',
    scriptPattern: /[\u0590-\u05FF]/,
    keywords: ['shalom', 'toda', 'ma', 'nishme', 'beseder']
  },
  {
    code: 'el-GR',
    shortCode: 'el',
    name: 'Greek (Ελληνικά)',
    nativeName: 'Ελληνικά',
    country: 'Greece',
    region: 'Europe',
    flag: '🇬🇷',
    scriptPattern: /[\u0370-\u03FF]/,
    keywords: ['geia', 'sas', 'efcharisto', 'kalimera']
  },
  {
    code: 'nl-NL',
    shortCode: 'nl',
    name: 'Dutch (Nederlands)',
    nativeName: 'Nederlands',
    country: 'Netherlands',
    region: 'Europe',
    flag: '🇳🇱',
    keywords: ['hallo', 'dankje', 'alstublieft', 'hoe', 'gaat', 'het']
  },
  {
    code: 'sv-SE',
    shortCode: 'sv',
    name: 'Swedish (Svenska)',
    nativeName: 'Svenska',
    country: 'Sweden',
    region: 'Europe',
    flag: '🇸🇪',
    keywords: ['hej', 'tack', 'hur', 'mar', 'du']
  },
  {
    code: 'no-NO',
    shortCode: 'no',
    name: 'Norwegian (Norsk)',
    nativeName: 'Norsk (Bokmål)',
    country: 'Norway',
    region: 'Europe',
    flag: '🇳🇴',
    keywords: ['hei', 'takk', 'hvordan', 'gar', 'det']
  },
  {
    code: 'da-DK',
    shortCode: 'da',
    name: 'Danish (Dansk)',
    nativeName: 'Dansk',
    country: 'Denmark',
    region: 'Europe',
    flag: '🇩🇰',
    keywords: ['hej', 'tak', 'hvordan', 'har', 'du', 'det']
  },
  {
    code: 'fi-FI',
    shortCode: 'fi',
    name: 'Finnish (Suomi)',
    nativeName: 'Suomi',
    country: 'Finland',
    region: 'Europe',
    flag: '🇫🇮',
    keywords: ['hei', 'kiitos', 'mita', 'kuuluu']
  },
  {
    code: 'pl-PL',
    shortCode: 'pl',
    name: 'Polish (Polski)',
    nativeName: 'Polski',
    country: 'Poland',
    region: 'Europe',
    flag: '🇵🇱',
    keywords: ['czesc', 'dziekuje', 'jak', 'sie', 'masz']
  },
  {
    code: 'uk-UA',
    shortCode: 'uk',
    name: 'Ukrainian (Українська)',
    nativeName: 'Українська',
    country: 'Ukraine',
    region: 'Europe',
    flag: '🇺🇦',
    scriptPattern: /[\u0400-\u04FF]/,
    keywords: ['pryvit', 'diakuiu', 'yak', 'spravy', 'добрий', 'день']
  },
  {
    code: 'sw-KE',
    shortCode: 'sw',
    name: 'Swahili (Kiswahili)',
    nativeName: 'Kiswahili',
    country: 'Kenya',
    region: 'Africa',
    flag: '🇰🇪',
    keywords: ['jambo', 'habari', 'asante', 'sana', 'karibu']
  },
  {
    code: 'zu-ZA',
    shortCode: 'zu',
    name: 'Zulu (isiZulu)',
    nativeName: 'isiZulu',
    country: 'South Africa',
    region: 'Africa',
    flag: '🇿🇦',
    keywords: ['sawubona', 'ngiyabonga', 'unjani']
  },
  {
    code: 'xh-ZA',
    shortCode: 'xh',
    name: 'Xhosa (isiXhosa)',
    nativeName: 'isiXhosa',
    country: 'South Africa',
    region: 'Africa',
    flag: '🇿🇦',
    keywords: ['molo', 'enkosi', 'unjani']
  },
  {
    code: 'af-ZA',
    shortCode: 'af',
    name: 'Afrikaans (Afrikaans)',
    nativeName: 'Afrikaans',
    country: 'South Africa',
    region: 'Africa',
    flag: '🇿🇦',
    keywords: ['hallo', 'dankie', 'hoe', 'gaan', 'dit']
  },
  {
    code: 'ha-NG',
    shortCode: 'ha',
    name: 'Hausa (Harshen Hausa)',
    nativeName: 'Harshen Hausa',
    country: 'Nigeria',
    region: 'Africa',
    flag: '🇳🇬',
    keywords: ['sannu', 'na', 'gode', 'yaya', 'dai']
  },
  {
    code: 'yo-NG',
    shortCode: 'yo',
    name: 'Yoruba (Èdè Yorùbá)',
    nativeName: 'Èdè Yorùbá',
    country: 'Nigeria',
    region: 'Africa',
    flag: '🇳🇬',
    keywords: ['bawo', 'e', 'se', 'pupo']
  },
  {
    code: 'ig-NG',
    shortCode: 'ig',
    name: 'Igbo (Asụsụ Igbo)',
    nativeName: 'Asụsụ Igbo',
    country: 'Nigeria',
    region: 'Africa',
    flag: '🇳🇬',
    keywords: ['ndewo', 'daalu', 'kedu']
  },
  {
    code: 'am-ET',
    shortCode: 'am',
    name: 'Amharic (አማርኛ)',
    nativeName: 'አማርኛ',
    country: 'Ethiopia',
    region: 'Africa',
    flag: '🇪🇹',
    scriptPattern: /[\u1200-\u137F]/,
    keywords: ['selam', 'ameseginalehu', 'endet', 'neh']
  }
];

export class LanguageDetector {
  /**
   * Automatically detects the spoken/written language of any input text
   */
  public static detectLanguage(text: string): LanguageInfo {
    if (!text || !text.trim()) {
      return SUPPORTED_LANGUAGES.find(l => l.code === 'en-US')!;
    }

    const trimmed = text.trim();
    const lower = trimmed.toLowerCase();

    // 1. Script Pattern Matching (Devanagari, Bengali, Hanzi, Hiragana, Cyrillic, Arabic, etc.)
    // Priority check for specific regional scripts
    for (const lang of SUPPORTED_LANGUAGES) {
      if (lang.scriptPattern && lang.scriptPattern.test(trimmed)) {
        // If keywords match this specific script language, prefer it
        if (lang.keywords && lang.keywords.some(k => lower.includes(k))) {
          return lang;
        }
      }
    }

    // Secondary script check
    for (const lang of SUPPORTED_LANGUAGES) {
      if (lang.scriptPattern && lang.scriptPattern.test(trimmed)) {
        return lang;
      }
    }

    // 2. Dialect and Keyword Matching (Rajbanshi, Banglish, Hinglish, Spanish, etc.)
    for (const lang of SUPPORTED_LANGUAGES) {
      if (lang.keywords && lang.keywords.length > 0) {
        const matches = lang.keywords.filter(k => lower.includes(k));
        if (matches.length > 0) {
          return lang;
        }
      }
    }

    // Default to English (US)
    return SUPPORTED_LANGUAGES.find(l => l.code === 'en-US')!;
  }

  /**
   * Get LanguageInfo by BCP-47 tag, shortCode, or name
   */
  public static getLanguageInfo(codeOrShort: string): LanguageInfo {
    if (!codeOrShort || codeOrShort === 'auto') {
      return SUPPORTED_LANGUAGES[0]; // Auto-Detect
    }

    const clean = codeOrShort.toLowerCase().trim();
    const found = SUPPORTED_LANGUAGES.find(
      l => l.code.toLowerCase() === clean || 
           l.shortCode.toLowerCase() === clean ||
           l.name.toLowerCase().includes(clean)
    );
    return found || SUPPORTED_LANGUAGES.find(l => l.code === 'en-US')!;
  }

  /**
   * Get all distinct countries with flags and language counts
   */
  public static getAllCountries(): { country: string; flag: string; count: number }[] {
    const map = new Map<string, { flag: string; count: number }>();
    
    for (const l of SUPPORTED_LANGUAGES) {
      if (l.country === 'Global') continue;
      if (!map.has(l.country)) {
        map.set(l.country, { flag: l.flag, count: 1 });
      } else {
        const item = map.get(l.country)!;
        item.count++;
      }
    }

    return Array.from(map.entries()).map(([country, data]) => ({
      country,
      flag: data.flag,
      count: data.count
    }));
  }

  /**
   * Filter languages by Country
   */
  public static getLanguagesByCountry(country: string): LanguageInfo[] {
    if (!country || country === 'All') {
      return SUPPORTED_LANGUAGES;
    }
    return SUPPORTED_LANGUAGES.filter(l => l.country.toLowerCase() === country.toLowerCase());
  }
}
