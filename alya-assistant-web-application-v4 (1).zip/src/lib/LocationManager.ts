/**
 * LocationManager.ts
 * Real-time Location Tracking Service for Alya Assistant.
 * Integrates with HTML5/Android Geolocation watchPosition API, maintains active coordinate state,
 * supports native Android background location updates via WebSocket bridge, and exposes a React hook.
 */

import { useState, useEffect, useCallback } from 'react';
import { locationService, LocationContext, LocationPermissionState } from './locationService';
import { ConversationStore } from './ConversationStore';

export type LocationUpdateCallback = (context: LocationContext) => void;

class LocationManagerImpl {
  private watchId: number | null = null;
  private heartbeatTimer: any = null;
  private currentContext: LocationContext | null = null;
  private subscribers: Set<LocationUpdateCallback> = new Set();
  private isTrackingState: boolean = false;
  private lastError: string | null = null;
  private readonly HEARTBEAT_INTERVAL_MS = 30000; // 30s heartbeat tracker interval

  constructor() {
    this.currentContext = locationService.getLastKnownLocation();
    this.setupAndroidBridgeListener();
  }

  /**
   * Listen for native Android companion background location updates sent over WebSocket
   */
  private setupAndroidBridgeListener(): void {
    if (typeof window === 'undefined') return;

    window.addEventListener('message', async (event: MessageEvent) => {
      const data = event.data;
      if (data && (data.type === 'ANDROID_LOCATION_UPDATE' || data.type === 'COMPANION_LOCATION_UPDATE')) {
        const { lat, lon, accuracy, locality, region, country } = data.payload || data;
        if (typeof lat === 'number' && typeof lon === 'number') {
          const geoInfo = (locality && country) 
            ? { locality, region: region || '', country, formattedAddress: `${locality}, ${country}` }
            : await locationService.reverseGeocode(lat, lon);

          const context: LocationContext = {
            latitude: lat,
            longitude: lon,
            accuracy: accuracy || 10,
            timestamp: Date.now(),
            locality: geoInfo.locality,
            region: geoInfo.region,
            country: geoInfo.country,
            formattedAddress: geoInfo.formattedAddress,
            source: 'gps',
            accuracyType: 'precise'
          };

          this.updateContext(context);
        }
      }
    });
  }

  /**
   * Ingests native Android location update payload
   */
  public handleAndroidLocationUpdate(payload: {
    lat: number;
    lon: number;
    accuracy?: number;
    locality?: string;
    region?: string;
    country?: string;
  }): void {
    const context: LocationContext = {
      latitude: payload.lat,
      longitude: payload.lon,
      accuracy: payload.accuracy || 10,
      timestamp: Date.now(),
      locality: payload.locality,
      region: payload.region,
      country: payload.country,
      source: 'gps',
      accuracyType: 'precise'
    };
    this.updateContext(context);
  }

  /**
   * Starts real-time continuous geolocation tracking with high-accuracy settings
   */
  public startTracking(): void {
    if (typeof window === 'undefined' || !('geolocation' in navigator)) {
      this.lastError = 'Geolocation is not supported in this environment.';
      console.warn('[LocationManager]', this.lastError);
      return;
    }

    if (this.isTrackingState && this.watchId !== null) return;

    this.isTrackingState = true;
    this.lastError = null;

    // Immediately fetch initial position with high accuracy
    locationService.getCurrentLocation(8000).then((res) => {
      if (res.success && res.context) {
        this.updateContext(res.context);
      }
    });

    // Watch position changes in real-time with high-accuracy browser configuration
    this.watchId = navigator.geolocation.watchPosition(
      async (position) => {
        const lat = position.coords.latitude;
        const lon = position.coords.longitude;
        const accuracy = position.coords.accuracy;
        const accuracyType = accuracy <= 100 ? 'precise' : 'approximate';

        const geoInfo = await locationService.reverseGeocode(lat, lon);

        const context: LocationContext = {
          latitude: lat,
          longitude: lon,
          accuracy,
          timestamp: position.timestamp,
          locality: geoInfo.locality,
          region: geoInfo.region,
          country: geoInfo.country,
          formattedAddress: geoInfo.formattedAddress,
          source: 'gps',
          accuracyType
        };

        this.updateContext(context);
      },
      (err) => {
        this.lastError = err.message;
        console.warn('[LocationManager] watchPosition error:', err.message);
      },
      {
        enableHighAccuracy: true, // Use GPS hardware sensor
        timeout: 10000,           // 10s timeout
        maximumAge: 5000          // 5s max age for fresh coordinates
      }
    );

    this.startHeartbeat();

    console.log('[LocationManager] Real-time high-accuracy tracking initialized.');
  }

  /**
   * Starts periodic heartbeat tracker to refresh location and push continuous state updates
   */
  private startHeartbeat(): void {
    this.stopHeartbeat();
    this.heartbeatTimer = setInterval(async () => {
      if (!this.isTrackingState) return;
      try {
        const res = await locationService.getCurrentLocation(5000);
        if (res.success && res.context) {
          this.updateContext(res.context);
        } else if (this.currentContext) {
          // Re-broadcast current context heartbeat to keep weather/capability modules synchronized
          this.updateContext({ ...this.currentContext, timestamp: Date.now() });
        }
      } catch (e) {
        console.warn('[LocationManager] Heartbeat check note:', e);
      }
    }, this.HEARTBEAT_INTERVAL_MS);
  }

  private stopHeartbeat(): void {
    if (this.heartbeatTimer) {
      clearInterval(this.heartbeatTimer);
      this.heartbeatTimer = null;
    }
  }

  public stopTracking(): void {
    if (this.watchId !== null && typeof navigator !== 'undefined' && navigator.geolocation) {
      navigator.geolocation.clearWatch(this.watchId);
      this.watchId = null;
    }
    this.stopHeartbeat();
    this.isTrackingState = false;
    console.log('[LocationManager] Real-time coordinate tracking stopped.');
  }

  private updateContext(context: LocationContext): void {
    this.currentContext = context;
    
    // Push update to Unified Conversation State Manager
    try {
      ConversationStore.getInstance().updateState({ currentLocation: context });
    } catch (e) {
      console.warn('[LocationManager] Failed to push update to ConversationStore:', e);
    }

    for (const sub of this.subscribers) {
      try {
        sub(context);
      } catch (e) {
        console.warn('[LocationManager] Subscriber error:', e);
      }
    }
  }

  public getCurrentContext(): LocationContext | null {
    return this.currentContext || locationService.getLastKnownLocation();
  }

  public isTracking(): boolean {
    return this.isTrackingState;
  }

  public getLastError(): string | null {
    return this.lastError;
  }

  public subscribe(callback: LocationUpdateCallback): () => void {
    this.subscribers.add(callback);
    if (this.currentContext) {
      callback(this.currentContext);
    }
    return () => {
      this.subscribers.delete(callback);
    };
  }
}

export const locationManager = new LocationManagerImpl();

/**
 * Custom React Hook for real-time location tracking
 */
export function useLocationTracker(autoStart: boolean = true) {
  const [location, setLocation] = useState<LocationContext | null>(locationManager.getCurrentContext());
  const [isTracking, setIsTracking] = useState<boolean>(locationManager.isTracking());
  const [permissionState, setPermissionState] = useState<LocationPermissionState>('prompt');
  const [error, setError] = useState<string | null>(locationManager.getLastError());

  useEffect(() => {
    locationService.checkPermissionState().then(setPermissionState);

    if (autoStart) {
      locationManager.startTracking();
      setIsTracking(true);
    }

    const unsubscribe = locationManager.subscribe((newContext) => {
      setLocation(newContext);
      setError(locationManager.getLastError());
    });

    return () => {
      unsubscribe();
    };
  }, [autoStart]);

  const refreshLocation = useCallback(async () => {
    const res = await locationService.getCurrentLocation(8000);
    if (res.success && res.context) {
      setLocation(res.context);
      setError(null);
    } else if (res.error) {
      setError(res.error);
    }
    return res;
  }, []);

  return {
    location,
    isTracking,
    permissionState,
    error,
    refreshLocation,
    startTracking: () => {
      locationManager.startTracking();
      setIsTracking(true);
    },
    stopTracking: () => {
      locationManager.stopTracking();
      setIsTracking(false);
    }
  };
}
