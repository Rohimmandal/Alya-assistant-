/**
 * GlobalAudioStateManager.ts
 *
 * Monitors microphone activity, assistant voice engine state, and active media element playback.
 * Automatically ducks non-assistant media tracks (HTML5 video/audio elements) whenever Alya's
 * voice engine or TTS service is producing output, and restores original volume levels once output completes.
 */

import { browserAutomation } from './BrowserAutomationController';
import { audioContextManager } from './AudioContextManager';

export class GlobalAudioStateManager {
  private static instance: GlobalAudioStateManager | null = null;
  private isMonitoring: boolean = false;
  private isAssistantActive: boolean = false;
  private checkInterval: any = null;

  private constructor() {}

  public static getInstance(): GlobalAudioStateManager {
    if (!GlobalAudioStateManager.instance) {
      GlobalAudioStateManager.instance = new GlobalAudioStateManager();
    }
    return GlobalAudioStateManager.instance;
  }

  public startMonitoring(): void {
    if (this.isMonitoring || typeof window === 'undefined') return;
    this.isMonitoring = true;

    console.log('[GlobalAudioStateManager] Starting global audio state and media element monitoring...');

    // Listen for speech state changes from AudioContextManager or VoiceEngine
    window.addEventListener('alya:speech-state-changed', (e: Event) => {
      const detail = (e as CustomEvent)?.detail;
      const speaking = Boolean(detail?.speaking);
      this.handleAssistantOutputState(speaking);
    });

    // Periodic DOM media scan to ensure newly mounted media elements are ducked if assistant is speaking
    this.checkInterval = setInterval(() => {
      if (this.isAssistantActive) {
        this.enforceMediaDucking(true);
      }
    }, 1500);
  }

  public stopMonitoring(): void {
    if (!this.isMonitoring) return;
    this.isMonitoring = false;
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    console.log('[GlobalAudioStateManager] Stopped global audio monitoring.');
  }

  private handleAssistantOutputState(speaking: boolean): void {
    if (this.isAssistantActive === speaking) return;
    this.isAssistantActive = speaking;

    console.log(`[GlobalAudioStateManager] Assistant output state changed -> ${speaking ? 'SPEAKING (Ducking Media)' : 'IDLE (Restoring Media)'}`);
    this.enforceMediaDucking(speaking);
  }

  private enforceMediaDucking(duck: boolean): void {
    try {
      browserAutomation.duckMedia(duck);
    } catch (e) {
      console.warn('[GlobalAudioStateManager] Failed to enforce media ducking:', e);
    }
  }

  public getAssistantActiveState(): boolean {
    return this.isAssistantActive;
  }
}

export const globalAudioStateManager = GlobalAudioStateManager.getInstance();
