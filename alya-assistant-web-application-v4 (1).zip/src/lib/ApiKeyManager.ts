/**
 * Alya Assistant - ApiKeyManager Utility
 * 
 * Centralizes the storage, retrieval, and validation of user-provided Gemini API keys.
 * 
 * Rules:
 * 1. Check localStorage for 'user_gemini_api_key' before making any Gemini API call.
 * 2. If 'user_gemini_api_key' exists and is valid, initialize the Google Generative AI client using this key.
 * 3. If no key is saved in settings, fallback to the default process.env API key.
 * 4. When a user updates/saves a new API key in Settings, the stored key in localStorage is immediately updated
 *    and used for subsequent requests.
 */

import { secureStorage } from './secureStorage';

export const GEMINI_API_KEY_STORAGE_KEY = 'user_gemini_api_key';

/**
 * Retrieves the currently active Gemini API key.
 * Checks localStorage for 'user_gemini_api_key' first.
 * Falls back to default process.env / NEXT_PUBLIC_GEMINI_API_KEY.
 */
export const getActiveApiKey = (): string => {
  if (typeof window !== 'undefined') {
    try {
      const userKey = localStorage.getItem('user_gemini_api_key') ||
        localStorage.getItem('alya_gemini_api_key') ||
        localStorage.getItem('gemini_api_key') ||
        localStorage.getItem('user_api_key');

      if (userKey && userKey.trim() !== '') {
        return userKey.trim();
      }
    } catch (e) {
      console.warn('[ApiKeyManager] Error reading localStorage key:', e);
    }
  }

  // Fallback to environment variables
  return (
    (typeof process !== 'undefined' && (process.env?.NEXT_PUBLIC_GEMINI_API_KEY || process.env?.GEMINI_API_KEY || process.env?.GOOGLE_API_KEY)) ||
    (typeof import.meta !== 'undefined' && ((import.meta as any).env?.VITE_GEMINI_API_KEY || (import.meta as any).env?.VITE_GOOGLE_API_KEY)) ||
    ''
  );
};

class ApiKeyManager {
  private static instance: ApiKeyManager | null = null;
  private currentApiKey: string = '';

  private constructor() {
    this.initFromStorage();
  }

  public static getInstance(): ApiKeyManager {
    if (!ApiKeyManager.instance) {
      ApiKeyManager.instance = new ApiKeyManager();
    }
    return ApiKeyManager.instance;
  }

  private initFromStorage(): void {
    this.currentApiKey = getActiveApiKey();
  }

  public getApiKey(): string {
    const key = getActiveApiKey();
    this.currentApiKey = key;
    return key;
  }

  public async setApiKey(newKey: string): Promise<void> {
    let cleanKey = (newKey || '').trim();
    if ((cleanKey.startsWith('"') && cleanKey.endsWith('"')) || (cleanKey.startsWith("'") && cleanKey.endsWith("'"))) {
      cleanKey = cleanKey.slice(1, -1).trim();
    }
    this.currentApiKey = cleanKey;

    if (typeof window !== 'undefined') {
      if (cleanKey) {
        localStorage.setItem('user_gemini_api_key', cleanKey);
        localStorage.setItem('alya_gemini_api_key', cleanKey);
        localStorage.setItem('gemini_api_key', cleanKey);
        localStorage.setItem('user_api_key', cleanKey);
        try {
          await secureStorage.saveSecureApiKey(cleanKey);
        } catch (e) {
          console.warn('[ApiKeyManager] Secure storage sync warning:', e);
        }
      } else {
        localStorage.removeItem('user_gemini_api_key');
        localStorage.removeItem('alya_gemini_api_key');
        localStorage.removeItem('gemini_api_key');
        localStorage.removeItem('user_api_key');
        try {
          await secureStorage.clearSecureApiKey();
        } catch {}
      }

      window.dispatchEvent(new CustomEvent('alya:api-key-updated', {
        detail: { hasKey: Boolean(cleanKey), keyMask: secureStorage.maskApiKey(cleanKey) }
      }));
    }
  }
}

export const apiKeyManager = ApiKeyManager.getInstance();
