/**
 * userProfileService.ts
 * Centralized user profile and account-based personalization layer for Alya Assistant.
 * Separates profiles for Rohim Mandal (owner) and Hiru Sarkar (personal assistant user)
 * ensuring zero data leakage and role-tailored behavior.
 */

export type AlyaUserRole = 'owner' | 'personal_assistant_user' | 'standard';

export interface AlyaUserProfile {
  userId: string;
  email: string;
  role: AlyaUserRole;
  displayName: string;
  personalityMode: string;
  permissions: string[];
  preferences: Record<string, unknown>;
}

export class UserProfileService {
  /**
   * Resolves the centralized Alya user profile based on email or user ID.
   */
  public static getProfile(email?: string | null, userId?: string | null): AlyaUserProfile {
    const cleanEmail = (email || '').trim().toLowerCase();
    
    if (cleanEmail === 'rohimmandal433@gmail.com' || cleanEmail === 'rohimmandal433@gamil.com') {
      return {
        userId: userId || 'owner_rohim',
        email: cleanEmail,
        role: 'owner',
        displayName: 'Rohim Mandal',
        personalityMode: 'Sassy, playful, loyal, and warm personal companion with high emotional intelligence and affectionate banter.',
        permissions: ['all_devices', 'full_automation', 'admin', 'media_control', 'contacts', 'messaging', 'screen_share'],
        preferences: { preferredLanguage: 'auto', voice: 'Kore', theme: 'space_dark' }
      };
    }

    if (cleanEmail === 'sarkarhiru91@gmail.com') {
      return {
        userId: userId || 'pa_hiru',
        email: cleanEmail,
        role: 'personal_assistant_user',
        displayName: 'Hiru Sarkar',
        personalityMode: 'Task-oriented, highly practical, concise, efficient, and professional personal assistant.',
        permissions: ['device_control', 'media_control', 'contacts', 'messaging'],
        preferences: { preferredLanguage: 'en', voice: 'Kore', theme: 'space_dark' }
      };
    }

    return {
      userId: userId || 'standard_user',
      email: cleanEmail || 'guest@alya.ai',
      role: 'standard',
      displayName: 'User',
      personalityMode: 'Helpful, courteous, witty, and charming assistant.',
      permissions: ['media_control', 'standard'],
      preferences: { preferredLanguage: 'auto', voice: 'Kore', theme: 'space_dark' }
    };
  }
}
