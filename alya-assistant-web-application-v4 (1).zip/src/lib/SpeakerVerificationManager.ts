/**
 * SpeakerVerificationManager.ts
 *
 * Real-time, browser-native biometric speaker verification system for Alya Assistant.
 * Uses pitch detection (autocorrelation) and Mel-filterbank spectral profiling to enroll and verify the owner.
 * Stores secure feature embeddings locally to prevent raw voice recording leaks.
 */

export interface VoiceFeatures {
  pitchMean: number;
  pitchStdDev: number;
  spectralCentroid: number;
  spectralFlatness: number;
  melBands: number[];
}

export interface SpeakerProfile {
  enrolled: boolean;
  timestamp: number;
  features: VoiceFeatures;
}

export class SpeakerVerificationManager {
  private static instance: SpeakerVerificationManager | null = null;
  private currentProfile: SpeakerProfile | null = null;

  // Enrollment State
  private enrollmentSamples: VoiceFeatures[] = [];
  private activeSampleFrames: VoiceFeatures[] = [];

  private constructor() {
    this.loadProfile();
  }

  public static getInstance(): SpeakerVerificationManager {
    if (!SpeakerVerificationManager.instance) {
      SpeakerVerificationManager.instance = new SpeakerVerificationManager();
    }
    return SpeakerVerificationManager.instance;
  }

  private loadProfile(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const stored = localStorage.getItem('alya_owner_voice_profile');
      if (stored) {
        this.currentProfile = JSON.parse(stored);
        console.log('[SpeakerVerification] Loaded enrolled owner voice profile.');
      }
    } catch (e) {
      console.error('[SpeakerVerification] Failed to load voice profile:', e);
    }
  }

  public isEnrolled(): boolean {
    return this.currentProfile ? this.currentProfile.enrolled : false;
  }

  public getProfile(): SpeakerProfile | null {
    return this.currentProfile;
  }

  public resetEnrollment(): void {
    this.currentProfile = null;
    this.enrollmentSamples = [];
    this.activeSampleFrames = [];
    if (typeof localStorage !== 'undefined') {
      localStorage.removeItem('alya_owner_voice_profile');
    }
    console.log('[SpeakerVerification] Speaker enrollment has been reset.');
  }

  /**
   * Processes a single real-time frame during enrollment or verification.
   * Extracts fundamental frequency (F0 pitch), spectral centroid, spectral flatness, and 16 Mel bands.
   */
  public extractFeatures(timeData: Float32Array, freqData: Uint8Array, sampleRate: number): VoiceFeatures | null {
    // 1. Calculate RMS energy to ignore silent/noise frames
    let sumSquares = 0;
    for (let i = 0; i < timeData.length; i++) {
      sumSquares += timeData[i] * timeData[i];
    }
    const rms = Math.sqrt(sumSquares / timeData.length);
    if (rms < 0.015) return null; // Ignore silent or extremely quiet frames

    // 2. Pitch Detection using Autocorrelation (F0)
    const pitch = this.detectPitch(timeData, sampleRate);

    // 3. Spectral & Mel-Bands Feature Extraction
    const numBins = freqData.length;
    const binWidth = (sampleRate / 2) / numBins;
    
    let totalEnergy = 0;
    let weightedSum = 0;
    let logSum = 0;
    let arithmeticSum = 0;

    for (let i = 0; i < numBins; i++) {
      const val = freqData[i] / 255.0; // Normalize 0-1
      const freq = i * binWidth;
      
      totalEnergy += val;
      weightedSum += val * freq;
      
      const clampedVal = Math.max(1e-5, val);
      logSum += Math.log(clampedVal);
      arithmeticSum += clampedVal;
    }

    const spectralCentroid = totalEnergy > 0 ? weightedSum / totalEnergy : 0;
    
    // Spectral Flatness
    const geomMean = Math.exp(logSum / numBins);
    const arithMean = arithmeticSum / numBins;
    const spectralFlatness = arithMean > 0 ? geomMean / arithMean : 0;

    // Filter Mel-bands (16 bands)
    const maxMel = 2595 * Math.log10(1 + (sampleRate / 2) / 700);
    const melBandSize = maxMel / 16;
    const melBands = new Array(16).fill(0);
    const melWeights = new Array(16).fill(0);

    for (let i = 0; i < numBins; i++) {
      const val = freqData[i] / 255.0;
      const freq = i * binWidth;
      const mel = 2595 * Math.log10(1 + freq / 700);
      const bandIdx = Math.min(15, Math.floor(mel / melBandSize));
      melBands[bandIdx] += val;
      melWeights[bandIdx]++;
    }

    for (let i = 0; i < 16; i++) {
      if (melWeights[i] > 0) {
        melBands[i] /= melWeights[i];
      }
    }

    return {
      pitchMean: pitch,
      pitchStdDev: 0, // Computed across a sequence of frames
      spectralCentroid,
      spectralFlatness,
      melBands
    };
  }

  /**
   * Fundamental frequency F0 pitch detection via autocorrelation.
   */
  private detectPitch(timeData: Float32Array, sampleRate: number): number {
    const bufferSize = timeData.length;
    const r = new Float32Array(bufferSize);
    
    for (let lag = 0; lag < bufferSize; lag++) {
      let sum = 0;
      for (let i = 0; i < bufferSize - lag; i++) {
        sum += timeData[i] * timeData[i + lag];
      }
      r[lag] = sum;
    }

    // Find the first zero-crossing
    let zeroCrossing = 0;
    for (let i = 0; i < bufferSize - 1; i++) {
      if (r[i] > 0 && r[i + 1] < 0) {
        zeroCrossing = i;
        break;
      }
    }

    // Find peak after first zero-crossing
    let maxVal = -1;
    let maxLag = -1;
    for (let i = zeroCrossing; i < bufferSize; i++) {
      if (r[i] > maxVal) {
        maxVal = r[i];
        maxLag = i;
      }
    }

    if (maxLag > -1) {
      const pitch = sampleRate / maxLag;
      if (pitch >= 65 && pitch <= 350) { // Normal human vocal pitch range (F0)
        return pitch;
      }
    }
    return 0; // Unvoiced frame
  }

  /**
   * Starts capturing a single enrollment sample.
   */
  public startSampleCapture(): void {
    this.activeSampleFrames = [];
  }

  /**
   * Records a frame for the active sample.
   */
  public recordEnrollmentFrame(timeData: Float32Array, freqData: Uint8Array, sampleRate: number): void {
    const features = this.extractFeatures(timeData, freqData, sampleRate);
    if (features) {
      this.activeSampleFrames.push(features);
    }
  }

  /**
   * Compiles and saves the active sample. Returns true if sample had sufficient voiced content.
   */
  public compileSample(): boolean {
    // Filter out frames where pitch wasn't detected to ensure clean voice pitch mean
    const voicedFrames = this.activeSampleFrames.filter(f => f.pitchMean > 0);
    if (voicedFrames.length < 5) {
      console.warn('[SpeakerVerification] Sample compilation failed: Insufficient voiced frames.');
      return false;
    }

    const average = this.averageFeatures(this.activeSampleFrames);
    this.enrollmentSamples.push(average);
    this.activeSampleFrames = [];
    console.log(`[SpeakerVerification] Compiled sample ${this.enrollmentSamples.length}. Voiced frames: ${voicedFrames.length}`);
    return true;
  }

  /**
   * Finalizes the speaker enrollment by averaging all samples and saving the profile.
   */
  public finalizeEnrollment(): boolean {
    if (this.enrollmentSamples.length < 3) {
      console.error('[SpeakerVerification] Cannot finalize enrollment: Need at least 3 samples.');
      return false;
    }

    const finalFeatures = this.averageFeatures(this.enrollmentSamples);
    
    this.currentProfile = {
      enrolled: true,
      timestamp: Date.now(),
      features: finalFeatures
    };

    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('alya_owner_voice_profile', JSON.stringify(this.currentProfile));
    }

    console.log('[SpeakerVerification] Biometric owner voice profile enrolled successfully!', finalFeatures);
    return true;
  }

  /**
   * Verifies if a real-time speech segment matches the enrolled owner's profile.
   * Takes an array of captured frames from the active speaking turn.
   */
  public verifySpeakerSegment(frames: VoiceFeatures[]): { verified: boolean; confidence: number } {
    if (!this.isEnrolled() || !this.currentProfile) {
      return { verified: true, confidence: 1.0 }; // Fallback to verified if no biometric profile enrolled yet
    }

    const voicedFrames = frames.filter(f => f.pitchMean > 0);
    if (voicedFrames.length < 4) {
      // Insufficient speech frames to verify (could be ambient noise or brief tap sounds)
      return { verified: false, confidence: 0.0 };
    }

    const liveAverage = this.averageFeatures(frames);
    const enrolled = this.currentProfile.features;

    // 1. Fundamental Pitch (F0) Similarity (Weight: 35%)
    let pitchSimilarity = 0;
    if (liveAverage.pitchMean > 0 && enrolled.pitchMean > 0) {
      const diff = Math.abs(liveAverage.pitchMean - enrolled.pitchMean);
      pitchSimilarity = Math.max(0, 1 - (diff / enrolled.pitchMean));
    }

    // 2. Spectral Centroid Similarity (Weight: 15%)
    const centroidDiff = Math.abs(liveAverage.spectralCentroid - enrolled.spectralCentroid);
    const centroidSimilarity = Math.max(0, 1 - (centroidDiff / enrolled.spectralCentroid));

    // 3. Mel-Envelope Vector Cosine Similarity (Weight: 50%)
    const melCosine = this.cosineSimilarity(liveAverage.melBands, enrolled.melBands);

    // Weighted Combined Confidence Index
    const confidence = (pitchSimilarity * 0.35) + (centroidSimilarity * 0.15) + (melCosine * 0.50);

    // Verified threshold (configurable, default: 0.82 / 82% similarity matching)
    const verified = confidence >= 0.80;

    console.log(`[SpeakerVerification] Verification: confidence=${(confidence * 100).toFixed(1)}% (Pitch: ${(pitchSimilarity * 100).toFixed(0)}%, Mel: ${(melCosine * 100).toFixed(0)}%), verified=${verified}`);
    return { verified, confidence };
  }

  private averageFeatures(frames: VoiceFeatures[]): VoiceFeatures {
    const count = frames.length;
    let pitchSum = 0;
    let voicedCount = 0;
    let centroidSum = 0;
    let flatnessSum = 0;
    const melBandsSum = new Array(16).fill(0);

    frames.forEach(f => {
      if (f.pitchMean > 0) {
        pitchSum += f.pitchMean;
        voicedCount++;
      }
      centroidSum += f.spectralCentroid;
      flatnessSum += f.spectralFlatness;
      for (let i = 0; i < 16; i++) {
        melBandsSum[i] += f.melBands[i];
      }
    });

    const pitchMean = voicedCount > 0 ? pitchSum / voicedCount : 0;
    
    // Calculate pitch standard deviation if multiple voiced frames
    let pitchVarSum = 0;
    if (voicedCount > 1) {
      frames.forEach(f => {
        if (f.pitchMean > 0) {
          pitchVarSum += Math.pow(f.pitchMean - pitchMean, 2);
        }
      });
    }
    const pitchStdDev = voicedCount > 1 ? Math.sqrt(pitchVarSum / voicedCount) : 0;

    return {
      pitchMean,
      pitchStdDev,
      spectralCentroid: centroidSum / count,
      spectralFlatness: flatnessSum / count,
      melBands: melBandsSum.map(val => val / count)
    };
  }

  private cosineSimilarity(vecA: number[], vecB: number[]): number {
    let dotProduct = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < vecA.length; i++) {
      dotProduct += vecA[i] * vecB[i];
      normA += vecA[i] * vecA[i];
      normB += vecB[i] * vecB[i];
    }
    const denom = Math.sqrt(normA) * Math.sqrt(normB);
    return denom > 0 ? dotProduct / denom : 0;
  }
}

export const speakerVerificationManager = SpeakerVerificationManager.getInstance();
