/**
 * LiveSession.ts
 * Manages the bidirectional Gemini Live / LiveKit WebSocket stream powered by a high-priority WebWorker
 * for network transport and a strict 20ms AudioWorklet pipeline for zero-latency PCM audio.
 * 
 * Features:
 * - Detailed log-based diagnostics via LiveKitDiagnosticService
 * - 10-Second Connecting Timeout Monitor with automatic state reset and auto-reconnect
 * - Explicit connection lifecycle cleanup of previous WebSocket & Worker instances
 * - Robust state machine with exponential backoff & jitter
 */

import { LiveWebSocketWorker, WebSocketWorkerStatus } from './liveWebSocketWorker';
import { VoiceEngine } from './VoiceEngine';
import { liveKitDiagnosticService } from './LiveKitDiagnosticService';
import { audioPlaybackManager } from './AudioPlaybackManager';
import { speakerVerificationManager } from './SpeakerVerificationManager.ts';

export type LiveSessionState = 'disconnected' | 'connecting' | 'listening' | 'thinking' | 'speaking' | 'reconnecting' | 'timeout' | 'failed';

export interface LiveSessionCallbacks {
  onAudioChunk: (base64Audio: string, sequence?: number, flushFirst?: boolean, serverTimestamp?: number) => void;
  onInterrupted: () => void;
  onError: (error: string) => void;
  onStatusChange: (status: LiveSessionState) => void;
  onTranscript?: (text: string, role: 'user' | 'assistant', sequence: number, metadata?: any) => void;
  onToolCall?: (toolCall: any) => void;
  onAnalyserReady?: (analyser: AnalyserNode | null) => void;
}

export class LiveSession {
  private state: LiveSessionState = 'disconnected';
  private callbacks: LiveSessionCallbacks;
  private wsWorker: LiveWebSocketWorker | null = null;
  private voiceEngine: VoiceEngine | null = null;
  private isAssistantSpeaking: boolean = false;
  private activeSequence: number = 1;
  
  // Biometric & Turn Complete tracking states
  private isTurnCompletePending: boolean = false;
  private isSpeakerVerified: boolean = false;
  private isSpeakerRejected: boolean = false;
  private activeTurnFeatures: any[] = [];
  private unverifiedAudioBuffer: string[] = [];
  private silenceCounter: number = 0;
  private hasSpokenInTurn: boolean = false;
  private ttsCompleteTimeout: any = null;

  // Reconnection & Handshake State - Continuous Session Persistence (Never auto-terminates)
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 999999;
  private reconnectTimer: any = null;
  private connectingTimeoutTimer: any = null;
  private readonly CONNECTING_TIMEOUT_MS = 8000; // 8-second timeout threshold

  private lastUrl: string = '';
  private lastUserId: string = '';
  private lastApiKey: string = '';
  private lastLanguage: string = 'auto';
  private lastConversationId: string = 'main';
  private lastVoice: string = 'Aoede';
  private lastLocation: { lat?: number; lon?: number; city?: string } | undefined = undefined;

  // Barge-In Detection State: Tuned threshold to prevent speaker acoustic echo false-triggers
  private bargeInCount: number = 0;
  private readonly BARGE_IN_THRESHOLD = 0.055; 
  private readonly BARGE_IN_REQUIRED_CHUNKS = 5; // ~100ms of sustained human voice
  private assistantSpeakingStartedAt: number = 0;

  public static readonly VALID_VOICES = ['Aoede', 'Kore', 'Ursa', 'Callirrhoe', 'Leda', 'Zephyr'] as const;

  constructor(callbacks: LiveSessionCallbacks) {
    this.callbacks = callbacks;
  }

  public setAssistantSpeaking(speaking: boolean) {
    const wasSpeaking = this.isAssistantSpeaking;
    this.isAssistantSpeaking = speaking;
    if (speaking && !wasSpeaking) {
      this.assistantSpeakingStartedAt = Date.now();
      this.bargeInCount = 0;
    }
    if (this.voiceEngine) {
      this.voiceEngine.setAssistantMode(speaking ? 'speaking' : (this.state === 'listening' ? 'listening' : 'idle'));
    }

    if (this.ttsCompleteTimeout) {
      clearTimeout(this.ttsCompleteTimeout);
      this.ttsCompleteTimeout = null;
    }

    if (wasSpeaking && !speaking && this.isTurnCompletePending) {
      console.log('[LiveSession] Audio playback completed. Delaying state transition by 200ms safety buffer...');
      this.ttsCompleteTimeout = setTimeout(() => {
        this.ttsCompleteTimeout = null;
        if (!this.isAssistantSpeaking && this.isTurnCompletePending) {
          console.log('[LiveSession] 200ms safety buffer completed. Transitioning to listening state.');
          this.isTurnCompletePending = false;
          this.setSessionState('listening');
        }
      }, 200); // 200ms safety buffer
    }
  }

  private setSessionState(newState: LiveSessionState) {
    this.state = newState;
    // Sync assistant speaking flag for barge-in monitor
    this.isAssistantSpeaking = (newState === 'speaking');
    
    this.callbacks.onStatusChange(this.state);
    if (this.voiceEngine) {
      if (newState === 'listening') {
        this.voiceEngine.setAssistantMode('listening');
      } else if (newState === 'speaking') {
        this.voiceEngine.setAssistantMode('speaking');
      } else {
        this.voiceEngine.setAssistantMode('idle');
      }
    }
  }

  public getState(): LiveSessionState {
    return this.state;
  }

  /**
   * Starts the 10-second timeout monitor for the 'connecting' / 'reconnecting' state.
   */
  private startConnectingTimeoutMonitor() {
    this.clearConnectingTimeout();

    liveKitDiagnosticService.log('debug', 'timeout', `Started 10s connecting watchdog timer.`);

    this.connectingTimeoutTimer = setTimeout(() => {
      if (this.state === 'connecting' || this.state === 'reconnecting') {
        liveKitDiagnosticService.trackTimeoutTriggered(this.CONNECTING_TIMEOUT_MS, this.reconnectAttempts);
        this.handleConnectingTimeout();
      }
    }, this.CONNECTING_TIMEOUT_MS);
  }

  private clearConnectingTimeout() {
    if (this.connectingTimeoutTimer) {
      clearTimeout(this.connectingTimeoutTimer);
      this.connectingTimeoutTimer = null;
    }
  }

  /**
   * Handles timeout when connection remains in 'connecting' for > 8 seconds.
   * Performs an explicit state reset, full resource cleanup, and transitions to failed state.
   */
  private handleConnectingTimeout() {
    liveKitDiagnosticService.log(
      'warn', 
      'timeout', 
      `Connection remained in '${this.state}' for >8s. Triggering explicit state reset and transition to 'failed'.`
    );

    // 1. Clean up previous WebSocket and worker resources
    this.cleanupPreviousInstances('Connecting timeout reset');

    // 2. Transition state and notify listeners
    this.setSessionState('failed');
  }

  /**
   * Explicitly cleans up previous WebSocket, Worker, and audio pipelines before re-initializing
   */
  private cleanupPreviousInstances(reason: string = 'Pre-initialization cleanup') {
    const resources: string[] = [];

    // Clear active timeout timers
    this.clearConnectingTimeout();
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      resources.push('reconnect_timer');
    }

    // Clean up worker
    if (this.wsWorker) {
      try {
        this.wsWorker.disconnect();
      } catch (err) {
        console.warn('[LiveSession] Worker disconnect notice:', err);
      }
      this.wsWorker = null;
      resources.push('websocket_worker');
    }

    // Clean up VoiceEngine if active
    if (this.voiceEngine) {
      try {
        this.voiceEngine.stopDiagnosticMonitor();
        this.voiceEngine.stop();
      } catch (err) {
        console.warn('[LiveSession] VoiceEngine stop notice:', err);
      }
      this.voiceEngine = null;
      resources.push('voice_engine');
    }

    this.callbacks.onAnalyserReady?.(null);

    liveKitDiagnosticService.trackCleanup('LiveSession', resources);
    liveKitDiagnosticService.log('cleanup', 'cleanup', `Cleaned previous instances: ${reason}`, { resources });
  }

  public connect(
    userId: string, 
    apiKey: string = '', 
    language?: string, 
    location?: { lat?: number; lon?: number; city?: string },
    conversationId: string = 'main',
    voiceName?: string
  ) {
    if (this.state === 'connecting' || this.state === 'listening' || this.state === 'speaking' || this.state === 'reconnecting') {
      liveKitDiagnosticService.log('warn', 'lifecycle', `Connect ignored: session is already in active state '${this.state}'.`);
      return;
    }

    this.lastUserId = userId;
    this.lastApiKey = apiKey;
    this.lastLanguage = language || (typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_preferred_lang') || localStorage.getItem('alya_language') || 'auto') : 'auto');
    this.lastLocation = location;
    this.lastConversationId = conversationId || (typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_active_conversation_id') || 'main') : 'main');
    this.lastVoice = voiceName || (typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_voice_name') || 'Aoede') : 'Aoede');
    if (!LiveSession.VALID_VOICES.includes(this.lastVoice as any)) {
      this.lastVoice = 'Aoede';
    }

    this.reconnectAttempts = 0;
    this.activeSequence = 1;

    // Clean previous instances before fresh connection
    this.cleanupPreviousInstances('New connect request');

    this.setSessionState('connecting');
    liveKitDiagnosticService.trackStateChange('connecting', {
      userId,
      language: this.lastLanguage,
      conversationId: this.lastConversationId,
      voice: this.lastVoice
    });

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const url = new URL(`${protocol}//${window.location.host}/ws/gemini-live`);
    url.searchParams.set('userId', userId);
    url.searchParams.set('conversationId', this.lastConversationId);
    url.searchParams.set('clientType', 'voice');
    url.searchParams.set('voice', this.lastVoice);
    url.searchParams.set('voiceName', this.lastVoice);
    const storedEmail = typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_user_email') || '') : '';
    if (storedEmail) url.searchParams.set('userEmail', storedEmail);
    if (apiKey && (apiKey.startsWith('AIza') || apiKey.startsWith('AQ.')) && apiKey.length > 20) {
      url.searchParams.set('apiKey', apiKey);
    }
    if (this.lastLanguage) url.searchParams.set('language', this.lastLanguage);
    if (location?.lat !== undefined && location?.lon !== undefined) {
      url.searchParams.set('lat', String(location.lat));
      url.searchParams.set('lon', String(location.lon));
      if (location.city) url.searchParams.set('city', location.city);
    }
    // Unique connection ID
    url.searchParams.set('cid', Math.random().toString(36).substring(2, 10));
    
    this.lastUrl = url.toString();
    liveKitDiagnosticService.log('info', 'network', `Connecting to WebSocket endpoint: ${url.pathname}`, {
      userId,
      language: this.lastLanguage
    });

    // 1. Initialize High-Priority WebWorker
    this.wsWorker = new LiveWebSocketWorker(
      (data) => this.handleWorkerMessage(data),
      (status, details) => this.handleWorkerStatus(status, details)
    );

    // 2. Initialize VoiceEngine for strict 20ms audio capture
    this.voiceEngine = new VoiceEngine(16000, 320, this.lastLanguage);

    // 3. Start 10-Second Connecting State Timeout Monitor
    this.startConnectingTimeoutMonitor();

    // 4. Connect WebWorker to WebSocket
    this.wsWorker.connect(this.lastUrl);
  }

  /**
   * Sub-second transparent reconnection state machine with optional UI state preservation
   */
  public attemptReconnect(isTimeoutTriggered: boolean = false, preserveUiState: boolean = false) {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }

    if (this.state === 'disconnected') {
      liveKitDiagnosticService.log('info', 'lifecycle', 'Skipping reconnect: Session is explicitly disconnected.');
      return;
    }

    // Halt any active audio playback to prevent overlapping audio on reconnect
    this.interrupt();

    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      liveKitDiagnosticService.log('error', 'lifecycle', `Max reconnection attempts (${this.maxReconnectAttempts}) reached. Terminating session.`);
      this.callbacks.onError('Connection lost after repeated retries. Please verify network and retry.');
      this.disconnect();
      return;
    }

    this.reconnectAttempts++;
    
    // Sub-second recovery: do NOT change UI state if preserving UI state
    if (!preserveUiState) {
      this.setSessionState('reconnecting');
    }
    
    liveKitDiagnosticService.trackStateChange('reconnecting', {
      attempt: this.reconnectAttempts,
      maxAttempts: this.maxReconnectAttempts,
      isTimeoutTriggered,
      preserveUiState
    });

    // Sub-second 50ms delay for transparent recovery, or exponential backoff
    const delay = preserveUiState ? 50 : Math.min(1000 * Math.pow(2, this.reconnectAttempts - 1) + Math.random() * 400, 12000);
    
    liveKitDiagnosticService.log('warn', 'network', `Scheduling ${preserveUiState ? 'sub-second transparent' : 'standard'} reconnection attempt ${this.reconnectAttempts}/${this.maxReconnectAttempts} in ${Math.round(delay)}ms`);

    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      if (this.lastUrl && this.state !== 'disconnected') {
        liveKitDiagnosticService.log('info', 'network', `Executing sub-second reconnection attempt ${this.reconnectAttempts}...`);
        
        // Clean up dangling previous worker instances before creating a new connection
        if (this.wsWorker) {
          this.wsWorker.reset();
        } else {
          this.wsWorker = new LiveWebSocketWorker(
            (data) => this.handleWorkerMessage(data),
            (status, details) => this.handleWorkerStatus(status, details)
          );
        }

        if (!this.voiceEngine) {
          this.voiceEngine = new VoiceEngine(16000, 320, this.lastLanguage);
        }

        // Start 10-second timeout monitor for this reconnection attempt
        this.startConnectingTimeoutMonitor();
        
        this.wsWorker.connect(this.lastUrl);
      }
    }, delay);
  }

  /**
   * Starts microphone capture and binds AudioWorklet port to WebWorker
   */
  private async startAudioCapture(): Promise<void> {
    if (!this.voiceEngine) return;

    try {
      this.isSpeakerVerified = false;
      this.isSpeakerRejected = false;
      this.activeTurnFeatures = [];
      this.unverifiedAudioBuffer = [];
      this.silenceCounter = 0;

      await this.voiceEngine.start((pcmArrayBuffer) => {
        if (this.wsWorker && this.state !== 'disconnected') {
          const int16 = new Int16Array(pcmArrayBuffer);
          let sumSquares = 0;
          for (let i = 0; i < int16.length; i++) {
            const val = int16[i] / 32768.0;
            sumSquares += val * val;
          }
          const rms = Math.sqrt(sumSquares / int16.length);

          // Get Analyser and extract real-time features
          const analyser = this.getAnalyser();
          let currentFrameFeatures: any = null;
          if (analyser) {
            const fftSize = analyser.fftSize;
            const timeData = new Float32Array(fftSize);
            const freqData = new Uint8Array(fftSize / 2);
            analyser.getFloatTimeDomainData(timeData);
            analyser.getByteFrequencyData(freqData);
            currentFrameFeatures = speakerVerificationManager.extractFeatures(timeData, freqData, 16000);
          }

          // Robust Barge-In Listener: Monitors mic stream for user speech while assistant is speaking
          if (this.isAssistantSpeaking) {
            const timeSinceSpeakingStart = Date.now() - this.assistantSpeakingStartedAt;
            // Extended echo guard (1500ms) with higher RMS threshold to completely eliminate speaker echo self-barge-in
            const activeBargeThreshold = timeSinceSpeakingStart < 1500 ? 0.22 : 0.08;
            const requiredChunks = timeSinceSpeakingStart < 1500 ? 12 : this.BARGE_IN_REQUIRED_CHUNKS;

            if (rms > activeBargeThreshold) {
              if (currentFrameFeatures) {
                this.activeTurnFeatures.push(currentFrameFeatures);
              }
              this.bargeInCount++;
              
              if (this.bargeInCount >= requiredChunks) {
                console.log(`[LiveSession] User Barge-in confirmed (RMS: ${rms.toFixed(3)}). Halting assistant playback immediately.`);
                this.interrupt();
                this.callbacks.onInterrupted();
                this.setSessionState('listening');
                this.bargeInCount = 0;
                this.activeTurnFeatures = [];
              }
            } else {
              this.bargeInCount = Math.max(0, this.bargeInCount - 1);
              if (this.activeTurnFeatures.length > 0 && rms < 0.02) {
                this.activeTurnFeatures = [];
              }
            }
            
            return; // Don't send user audio to backend while assistant is still speaking
          } else {
            this.bargeInCount = 0;
          }

          // Voice Activity & Dynamic State Machine: Listening -> Thinking
          const isSpeechActive = rms >= 0.025;
          if (isSpeechActive) {
            this.silenceCounter = 0;
            this.hasSpokenInTurn = true;
            if (this.state === 'thinking') {
              // User resumed talking, switch back to listening
              this.setSessionState('listening');
            }
            if (currentFrameFeatures) {
              this.activeTurnFeatures.push(currentFrameFeatures);
            }
            
            // Dynamic YouTube Ducking: Duck the YouTube iframe volume immediately during active voice capture
            try {
              window.dispatchEvent(new CustomEvent('alya:youtube-control', { detail: { action: 'duck' } }));
            } catch {}
          } else {
            this.silenceCounter++;

            // Natural Turn Completion: User finished speech turn (~360ms silence)
            if (this.hasSpokenInTurn && this.silenceCounter >= 18) {
              this.hasSpokenInTurn = false;
              // Remain attentive in listening state. Intelligent thinking state is only triggered
              // if backend identifies a complex query or tool execution, keeping simple queries instant.
            }

            if (this.silenceCounter > 40) { // ~800ms of consecutive silence -> reset speaker state for next turn
              this.activeTurnFeatures = [];
              this.unverifiedAudioBuffer = [];

              // Restore YouTube volume once user finishes speaking
              try {
                window.dispatchEvent(new CustomEvent('alya:youtube-control', { detail: { action: 'unduck' } }));
              } catch {}
            }
          }

          // Convert PCM chunk to Base64
          const bytes = new Uint8Array(pcmArrayBuffer);
          let binary = '';
          const len = bytes.byteLength;
          for (let i = 0; i < len; i += 8192) {
            const chunk = bytes.subarray(i, Math.min(i + 8192, len));
            binary += String.fromCharCode.apply(null, Array.from(chunk));
          }
          const base64 = btoa(binary);

          // Direct ultra-low-latency real-time PCM audio streaming to Gemini Live
          this.wsWorker.send({
            type: 'AUDIO_CHUNK',
            audio: base64,
            realtimeInput: { mediaChunks: [{ mimeType: 'audio/pcm;rate=16000', data: base64 }] },
            sequence: this.activeSequence
          });
        }
      });

      const analyser = this.voiceEngine.getAnalyser();
      this.callbacks.onAnalyserReady?.(analyser);
    } catch (err: any) {
      liveKitDiagnosticService.trackError(`Microphone capture initialization error: ${err.message}`, err);
      this.callbacks.onError(err.message || 'Microphone access failed.');
      this.disconnect();
    }
  }

  private handleWorkerStatus(status: WebSocketWorkerStatus, details?: any) {
    liveKitDiagnosticService.log('info', 'lifecycle', `Worker status received: [${status}]`, details);
    
    if (status === 'open') {
      // Clear 10-second timeout monitor as connection is established!
      this.clearConnectingTimeout();
      
      const wasReconnecting = (this.state === 'reconnecting' || this.state === 'timeout');
      this.reconnectAttempts = 0;
      if (this.reconnectTimer) {
        clearTimeout(this.reconnectTimer);
        this.reconnectTimer = null;
      }

      if (this.wsWorker) {
        const storedId = localStorage.getItem('alya_user_id');
        const storedEmail = localStorage.getItem('alya_user_email');
        const storedName = localStorage.getItem('alya_user_name');
        const activeVoice = this.lastVoice || (typeof localStorage !== 'undefined' ? (localStorage.getItem('alya_voice_name') || 'Aoede') : 'Aoede');

        this.wsWorker.send({
          type: 'SETUP',
          userId: this.lastUserId || storedId || 'default_user',
          userEmail: storedEmail || '',
          displayName: storedName || '',
          language: this.lastLanguage,
          location: this.lastLocation,
          conversationId: this.lastConversationId,
          voice: activeVoice,
          voiceName: activeVoice,
          setup: {
            model: "gemini-3.8-live",
            generationConfig: {
              responseModalities: ["AUDIO"],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: activeVoice || "Aoede"
                  }
                }
              }
            },
            systemInstruction: {
              parts: [
                {
                  text: "You are Alya, a friendly, intelligent, and helpful personal voice assistant. Respond naturally, concisely, and conversationally in real-time."
                }
              ]
            }
          },
          sequence: this.activeSequence,
          clientTime: new Date().toISOString(),
          clientTimeZone: Intl.DateTimeFormat().resolvedOptions().timeZone
        });
      }

      if (this.voiceEngine) {
        this.voiceEngine.startDiagnosticMonitor();
      }

      if (!wasReconnecting) {
        this.startAudioCapture();
      } else {
        liveKitDiagnosticService.log('info', 'lifecycle', 'Session successfully restored after reconnection.');
        this.setSessionState('listening');
      }
    } else if (status === 'timeout') {
      this.handleConnectingTimeout();
    } else if (status === 'closed') {
      this.clearConnectingTimeout();
      if (this.state !== 'disconnected') {
        this.attemptReconnect();
      }
    } else if (status === 'error') {
      this.clearConnectingTimeout();
      if (this.state !== 'disconnected' && this.state !== 'reconnecting') {
        this.attemptReconnect();
      }
    }
  }

  private handleWorkerMessage(data: any) {
    if (!data) return;

    if (data.type === 'LIVE_READY' || data.type === 'SETUP_COMPLETE') {
      this.clearConnectingTimeout();
      this.setSessionState('listening');
      liveKitDiagnosticService.trackStateChange('connected', { liveReady: true });
    } else if (data.type === 'LIVE_THINKING') {
      this.setSessionState('thinking');
    } else if (data.type === 'LIVE_AUDIO' && data.audio) {
      const seq = data.sequence !== undefined ? data.sequence : this.activeSequence;
      if (seq < this.activeSequence) {
        return; // Stale chunk from previous turn
      }
      if (seq > this.activeSequence || data.isNewTurn || data.flushFirst) {
        this.activeSequence = seq;
      }
      this.setSessionState('speaking');
      this.callbacks.onAudioChunk(
        data.audio, 
        this.activeSequence, 
        data.flushFirst || data.isNewTurn,
        data.serverTimestamp || data.timestamp || Date.now()
      );
    } else if (data.type === 'LIVE_TRANSCRIPT') {
      const seq = data.sequence !== undefined ? data.sequence : this.activeSequence;
      if (seq < this.activeSequence) {
        return;
      }
      if (seq > this.activeSequence) {
        this.activeSequence = seq;
      }
      if (this.voiceEngine && data.text) {
        this.voiceEngine.pushTranscriptForSentenceTermination(data.text);
      }
      this.callbacks.onTranscript?.(data.text, data.role || 'assistant', this.activeSequence, data);
    } else if (data.type === 'LIVE_TURN_COMPLETE') {
      const seq = data.sequence !== undefined ? data.sequence : this.activeSequence;
      this.activeSequence = Math.max(this.activeSequence, seq + 1);
      if (this.voiceEngine) {
        this.voiceEngine.flushFinalSentenceBuffer();
      }
      
      // Complete Response Playback: Only return to listening state once Alya actually finishes speaking
      if (this.isAssistantSpeaking) {
        console.log('[LiveSession] Turn completed on server. Playback is active. Delaying listening state until audio finishes.');
        this.isTurnCompletePending = true;
      } else {
        this.isTurnCompletePending = false;
        this.setSessionState('listening');
      }
    } else if (data.type === 'LIVE_INTERRUPTED' || data.interrupted) {
      const seq = data.sequence !== undefined ? data.sequence : this.activeSequence;
      if (seq >= this.activeSequence) {
        this.activeSequence = seq;
        this.isTurnCompletePending = false;
        this.setSessionState('listening');
        this.callbacks.onInterrupted();
      }
    } else if (data.type === 'LIVE_TOOL_CALL') {
      this.callbacks.onToolCall?.(data.toolCall);
    } else if (data.type === 'LIVE_ERROR') {
      const errorMsg = data.error || 'Live stream error.';
      liveKitDiagnosticService.trackError(errorMsg, data);
      
      // Immediately surface error and disconnect to prevent infinite "Connecting..." loops
      this.callbacks.onError(errorMsg);
      this.disconnect();
    }
  }

  public setVoice(voiceName: string) {
    if (LiveSession.VALID_VOICES.includes(voiceName as any)) {
      this.lastVoice = voiceName;
      if (typeof localStorage !== 'undefined') {
        localStorage.setItem('alya_voice_name', voiceName);
      }
      if (this.wsWorker && this.state !== 'disconnected') {
        this.wsWorker.send({
          type: 'VOICE_UPDATE',
          voice: voiceName,
          voiceName
        });
      }
    }
  }

  public updateLocation(location: { lat?: number; lon?: number; city?: string }) {
    this.lastLocation = location;
    if (this.wsWorker && this.state !== 'disconnected') {
      this.wsWorker.send({
        type: 'LOCATION_UPDATE',
        location
      });
    }
  }

  public sendAudioChunk(pcmBase64: string) {
    if (this.wsWorker && this.state !== 'disconnected') {
      this.wsWorker.send({ type: 'AUDIO_CHUNK', audio: pcmBase64, sequence: this.activeSequence });
    }
  }

  public setMute(mute: boolean) {
    if (this.voiceEngine) {
      this.voiceEngine.setMute(mute);
    }
  }

  public pause() {
    if (this.voiceEngine) {
      this.voiceEngine.pause();
    }
    this.interrupt();
  }

  public resume() {
    if (this.voiceEngine) {
      this.voiceEngine.resume();
    }
  }

  public interrupt() {
    this.activeSequence += 1;
    // Immediately terminate active audio playback and clear buffers for instant barge-in
    if (this.voiceEngine) {
      this.voiceEngine.clearPlaybackQueue();
    }
    // Synchronize with global audio manager to clear any other concurrent audio sources
    try {
      audioPlaybackManager.cancelAllAudio('barge_in');
    } catch (_) {}

    if (this.wsWorker) {
      this.wsWorker.send({ type: 'INTERRUPT', sequence: this.activeSequence });
    }
  }

  public getAnalyser(): AnalyserNode | null {
    return this.voiceEngine ? this.voiceEngine.getAnalyser() : null;
  }

  public getHighpassFreq(): number {
    return this.voiceEngine ? this.voiceEngine.getHighpassFreq() : 100;
  }

  public setHighpassFreq(freq: number): void {
    if (this.voiceEngine) {
      this.voiceEngine.setHighpassFreq(freq);
    }
  }

  public forceReconnect(): void {
    liveKitDiagnosticService.log('info', 'network', 'User forced manual reconnection.');
    this.reconnectAttempts = 0;
    this.attemptReconnect(true);
  }

  /**
   * End-Call event: releases microphone resources, terminates AudioWorklet and WebWorker cleanly
   */
  public disconnect() {
    liveKitDiagnosticService.log('info', 'lifecycle', 'Disconnecting LiveSession and freeing all resources.');
    this.cleanupPreviousInstances('Explicit user disconnect');
    this.setSessionState('disconnected');
    liveKitDiagnosticService.trackStateChange('disconnected', { manual: true });
  }
}
