/**
 * TimeUtility.ts
 * Centralized service for resolving user's IANA timezone and local time using browser APIs.
 */

export interface TimeResolution {
  ianaTimeZone: string;
  localTime: string;
  localDate: string;
  isoString: string;
  timestamp: number;
}

export class TimeUtility {
  /**
   * Resolves the user's current local time and timezone metadata.
   */
  public static resolveCurrentTime(): TimeResolution {
    const now = new Date();
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    
    return {
      ianaTimeZone: timeZone,
      localTime: now.toLocaleTimeString('en-US', { timeZone }),
      localDate: now.toLocaleDateString('en-US', { timeZone }),
      isoString: now.toISOString(),
      timestamp: now.getTime()
    };
  }

  /**
   * Formats a given timestamp into a human-readable local string based on resolved timezone.
   */
  public static formatTimestamp(timestamp: number): string {
    const date = new Date(timestamp);
    const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    return date.toLocaleString('en-US', { timeZone });
  }
}
