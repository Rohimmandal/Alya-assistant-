/**
 * Alya Assistant - LiveKit WebRTC Voice Client
 * Handles real-time WebRTC audio streaming, LiveKit room connections,
 * Voice Activity Detection (VAD), barge-in interruption, and automatic session recovery.
 *
 * Features:
 * - 10-Second Connecting Timeout Monitor with automatic state reset and retry
 * - Explicit lifecycle cleanup of previous Room & WebSocket instances before re-initialization
 * - Comprehensive logging through LiveKitDiagnosticService
 */

import { Room, RoomEvent, Track, LocalAudioTrack, createLocalAudioTrack } from 'livekit-client';
import { liveKitDiagnosticService } from './LiveKitDiagnosticService';
import { LiveKitHandshakeTracer } from './LiveKitHandshakeTracer';

export interface LiveKitVoiceClientOptions {
  userId?: string;
  roomName?: string;
  language?: string;
  onText?: (text: string) => void;
  onAudio?: (base64Audio: string, sequence?: number, flushFirst?: boolean) => void;
  onConnected?: () => void;
  onDisconnected?: () => void;
  onError?: (error: string) => void;
  onInterrupted?: () => void;
}

export class LiveKitVoiceClient {
  private room: Room | null = null;
  private localAudioTrack: LocalAudioTrack | null = null;
  private options: LiveKitVoiceClientOptions;
  private isConnected: boolean = false;
  private wsFallback: WebSocket | null = null;
  private reconnectAttempts: number = 0;
  private maxReconnectAttempts: number = 5;
  private reconnectTimer: any = null;
  private connectingTimeoutTimer: any = null;
  private readonly CONNECTING_TIMEOUT_MS = 8000;
  private activeSocketId: string = '';

  constructor(options: LiveKitVoiceClientOptions) {
    this.options = options;
  }

  /**
   * Cleans up all previous Room, WebSocket, and AudioTrack instances before re-initializing
   */
  private cleanupPreviousInstances(reason: string = 'Pre-initialization cleanup') {
    const resources: string[] = [];
    this.clearConnectingTimeout();

    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
      resources.push('reconnect_timer');
    }

    if (this.localAudioTrack) {
      try {
        this.localAudioTrack.stop();
      } catch (_) {}
      this.localAudioTrack = null;
      resources.push('local_audio_track');
    }

    if (this.room) {
      try {
        this.room.disconnect();
      } catch (_) {}
      this.room = null;
      resources.push('webrtc_room');
    }

    if (this.wsFallback) {
      try {
        this.wsFallback.onopen = null;
        this.wsFallback.onmessage = null;
        this.wsFallback.onerror = null;
        this.wsFallback.onclose = null;
        if (this.wsFallback.readyState === 0 || this.wsFallback.readyState === 1) {
          this.wsFallback.close(1000, reason);
        }
      } catch (_) {}
      this.wsFallback = null;
      resources.push('ws_fallback_socket');
    }

    this.isConnected = false;
    liveKitDiagnosticService.trackCleanup('LiveKitVoiceClient', resources, this.activeSocketId);
  }

  private startConnectingTimeoutMonitor(onTimeoutCallback: () => void) {
    this.clearConnectingTimeout();
    this.connectingTimeoutTimer = setTimeout(() => {
      liveKitDiagnosticService.trackTimeoutTriggered(this.CONNECTING_TIMEOUT_MS, this.reconnectAttempts, this.activeSocketId);
      onTimeoutCallback();
    }, this.CONNECTING_TIMEOUT_MS);
  }

  private clearConnectingTimeout() {
    if (this.connectingTimeoutTimer) {
      clearTimeout(this.connectingTimeoutTimer);
      this.connectingTimeoutTimer = null;
    }
  }

  /**
   * Connect to LiveKit Room using authenticated server JWT token with timeout watchdog
   */
  async connect(): Promise<boolean> {
    this.activeSocketId = 'lk_' + Math.random().toString(36).substring(2, 9);
    this.cleanupPreviousInstances('New connect request');

    LiveKitHandshakeTracer.startTrace(this.activeSocketId, '/api/livekit/token', { userId: this.options.userId });

    liveKitDiagnosticService.trackSocketCreated(this.activeSocketId, '/api/livekit/token', 'livekit_webrtc');
    liveKitDiagnosticService.trackStateChange('connecting', {
      attempt: this.reconnectAttempts + 1,
      userId: this.options.userId
    }, this.activeSocketId);
    
    // Start 10-second timeout monitor for WebRTC room connection
    this.startConnectingTimeoutMonitor(() => {
      const timeoutErr = new Error('LiveKit connection timed out after 10 seconds in connecting state.');
      LiveKitHandshakeTracer.recordStep(this.activeSocketId, 'TIMEOUT', { message: timeoutErr.message });
      liveKitDiagnosticService.trackError(timeoutErr.message, { state: 'connecting', durationMs: this.CONNECTING_TIMEOUT_MS }, this.activeSocketId);
      this.cleanupPreviousInstances('WebRTC 10s connection timeout');
      this.options.onError?.('Connection timed out after 10 seconds. Please click retry to connect.');
      this.options.onDisconnected?.();
    });

    try {
      liveKitDiagnosticService.log('info', 'lifecycle', `Fetching LiveKit token... (Attempt ${this.reconnectAttempts + 1})`, undefined, this.activeSocketId);
      
      let { token, serverUrl } = await this.fetchToken();

      // Client-side JWT token verification helper
      const checkToken = (jwt: string) => {
        if (!jwt || typeof jwt !== 'string') return { status: 'invalid' as const, error: 'Empty token' };
        const parts = jwt.trim().split('.');
        if (parts.length !== 3) return { status: 'invalid' as const, error: `Malformed JWT structure` };
        try {
          const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
          const now = Math.floor(Date.now() / 1000);
          if (payload.exp && payload.exp <= now) {
            return { status: 'expired' as const, error: `Token expired` };
          }
          if (payload.exp && payload.exp - now < 30) {
            return { status: 'nearing_expiration' as const, payload };
          }
          return { status: 'valid' as const, payload };
        } catch (e: any) {
          return { status: 'invalid' as const, error: e?.message || 'Invalid payload encoding' };
        }
      };

      let tokenCheck = checkToken(token);
      if (tokenCheck.status === 'nearing_expiration') {
        liveKitDiagnosticService.log('warn', 'webrtc', 'LiveKit token nearing expiration, refreshing...', undefined, this.activeSocketId);
        ({ token, serverUrl } = await this.fetchToken());
        tokenCheck = checkToken(token);
      }

      if (tokenCheck.status !== 'valid') {
        LiveKitHandshakeTracer.recordStep(this.activeSocketId, 'WS_ERROR', { error: tokenCheck.error || tokenCheck.status });
        liveKitDiagnosticService.log('error', 'webrtc', `Client-side token verification failed: ${tokenCheck.error || tokenCheck.status}`, undefined, this.activeSocketId);
        throw new Error(`Invalid or expired LiveKit token: ${tokenCheck.error || tokenCheck.status}`);
      }
      liveKitDiagnosticService.log('info', 'webrtc', 'LiveKit token successfully verified on client.', { identity: tokenCheck.payload?.sub || tokenCheck.payload?.identity }, this.activeSocketId);

      this.room = new Room({
        adaptiveStream: true,
        dynacast: true,
        audioCaptureDefaults: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        }
      });

      this.room.on(RoomEvent.Connected, () => {
        this.clearConnectingTimeout();
        this.isConnected = true;
        this.reconnectAttempts = 0;
        LiveKitHandshakeTracer.recordStep(this.activeSocketId, 'WS_OPEN', { room: this.options.roomName });
        liveKitDiagnosticService.trackStateChange('connected', { room: this.options.roomName }, this.activeSocketId);
        this.options.onConnected?.();
      });

      this.room.on(RoomEvent.Disconnected, (reason) => {
        this.clearConnectingTimeout();
        this.isConnected = false;
        LiveKitHandshakeTracer.recordStep(this.activeSocketId, 'WS_CLOSE', { reason: String(reason) });
        liveKitDiagnosticService.trackStateChange('disconnected', { reason: String(reason) }, this.activeSocketId);
        this.options.onDisconnected?.();
        this.attemptReconnect();
      });

      this.room.on(RoomEvent.TrackSubscribed, (track) => {
        if (track.kind === Track.Kind.Audio) {
          const audioElement = track.attach();
          audioElement.play().catch((err) => liveKitDiagnosticService.log('warn', 'audio', 'Audio element play notice', { err: err?.message }));
        }
      });

      this.room.on(RoomEvent.DataReceived, (payload) => {
        try {
          const str = new TextDecoder().decode(payload);
          const data = JSON.parse(str);
          if (data.type === 'LIVE_TEXT' && this.options.onText) {
            this.options.onText(data.text);
          }
          if (data.type === 'LIVE_INTERRUPTED' && this.options.onInterrupted) {
            this.options.onInterrupted();
          }
        } catch {}
      });

      // Connect to WebRTC LiveKit server
      await this.room.connect(serverUrl, token);

      // Publish local audio track
      this.localAudioTrack = await createLocalAudioTrack({
        echoCancellation: true,
        noiseSuppression: true,
        autoGainControl: true,
      });

      await this.room.localParticipant.publishTrack(this.localAudioTrack);
      return true;

    } catch (err: any) {
      this.clearConnectingTimeout();
      liveKitDiagnosticService.log('warn', 'webrtc', 'WebRTC direct connection failed or unsupported, routing to WebSocket agent bridge fallback.', {
        error: err?.message || err
      }, this.activeSocketId);
      return this.connectWebSocketFallback();
    }
  }

  /**
   * WebSocket Agent Bridge fallback with strict 10s connecting timeout and explicit pre-cleanup
   */
  private connectWebSocketFallback(): Promise<boolean> {
    return new Promise((resolve) => {
      this.cleanupPreviousInstances('Pre-fallback initialization');
      
      const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      const userId = this.options.userId || 'default_user';
      const wsUrl = `${protocol}//${window.location.host}/livekit/ws?clientType=voice&userId=${encodeURIComponent(userId)}`;

      this.activeSocketId = 'wsfb_' + Math.random().toString(36).substring(2, 9);
      liveKitDiagnosticService.trackSocketCreated(this.activeSocketId, wsUrl, 'ws_fallback');
      liveKitDiagnosticService.trackStateChange('connecting', { fallback: true }, this.activeSocketId);

      // 10-second timeout monitor for fallback WebSocket
      this.startConnectingTimeoutMonitor(() => {
        const timeoutErr = new Error('WebSocket connection timed out after 10 seconds in connecting state.');
        liveKitDiagnosticService.trackError(timeoutErr.message, { state: 'connecting', fallback: true }, this.activeSocketId);
        this.cleanupPreviousInstances('Fallback 10s connection timeout');
        this.options.onError?.('Connection timed out after 10 seconds. Please click retry to connect.');
        this.options.onDisconnected?.();
        resolve(false);
      });

      try {
        this.wsFallback = new WebSocket(wsUrl);

        this.wsFallback.onopen = () => {
          this.clearConnectingTimeout();
          this.isConnected = true;
          this.reconnectAttempts = 0;
          liveKitDiagnosticService.trackStateChange('connected', { fallback: true }, this.activeSocketId);

          this.wsFallback?.send(JSON.stringify({
            type: 'LIVE_START',
            language: this.options.language || (typeof localStorage !== 'undefined' ? localStorage.getItem('alya_preferred_lang') : 'auto') || 'auto'
          }));
          this.options.onConnected?.();
          resolve(true);
        };

        this.wsFallback.onmessage = (event) => {
          try {
            const msg = JSON.parse(event.data);
            if (msg.type === 'LIVE_TEXT' && this.options.onText) {
              this.options.onText(msg.text);
            }
            if (msg.type === 'LIVE_AUDIO' && this.options.onAudio) {
              this.options.onAudio(msg.audio, msg.sequence, msg.flushFirst || msg.isNewTurn);
            }
            if (msg.type === 'LIVE_INTERRUPTED' && this.options.onInterrupted) {
              this.options.onInterrupted();
            }
          } catch {}
        };

        this.wsFallback.onerror = () => {
          this.clearConnectingTimeout();
          liveKitDiagnosticService.trackError('WebSocket fallback transport error', undefined, this.activeSocketId);
          this.options.onError?.('Voice connection failed.');
          resolve(false);
        };

        this.wsFallback.onclose = () => {
          this.clearConnectingTimeout();
          const wasConnected = this.isConnected;
          this.isConnected = false;
          liveKitDiagnosticService.trackStateChange('disconnected', { wasConnected }, this.activeSocketId);
          this.options.onDisconnected?.();
          
          if (wasConnected) {
            this.attemptReconnect();
          }
        };
      } catch (err: any) {
        this.clearConnectingTimeout();
        liveKitDiagnosticService.trackError(`WebSocket initialization exception: ${err?.message}`, err, this.activeSocketId);
        resolve(false);
      }
    });
  }

  private attemptReconnect() {
    if (this.reconnectTimer) return;
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      liveKitDiagnosticService.log('error', 'lifecycle', 'Max reconnection attempts reached in LiveKitVoiceClient.');
      this.options.onError?.('Connection lost after multiple retry attempts.');
      return;
    }

    this.reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, this.reconnectAttempts) + Math.random() * 500, 15000);
    liveKitDiagnosticService.log('warn', 'network', `LiveKitVoiceClient scheduling reconnect attempt ${this.reconnectAttempts} in ${Math.round(delay)}ms`);
    
    this.reconnectTimer = setTimeout(() => {
      this.reconnectTimer = null;
      this.connect().catch((err) => console.error('[LiveKitVoiceClient] Reconnect failed:', err));
    }, delay);
  }

  /**
   * Send live text input to Alya Agent
   */
  sendTextInput(text: string) {
    if (this.wsFallback && this.wsFallback.readyState === WebSocket.OPEN) {
      this.wsFallback.send(JSON.stringify({
        type: 'LIVE_TEXT_INPUT',
        text,
        language: this.options.language || 'auto'
      }));
    } else if (this.room && this.isConnected) {
      const encoder = new TextEncoder();
      const data = encoder.encode(JSON.stringify({ type: 'LIVE_TEXT_INPUT', text }));
      this.room.localParticipant.publishData(data, { reliable: true });
    }
  }

  /**
   * Notify Alya Agent of user barge-in / interruption
   */
  interrupt() {
    if (this.wsFallback && this.wsFallback.readyState === WebSocket.OPEN) {
      this.wsFallback.send(JSON.stringify({ type: 'LIVE_INTERRUPT' }));
    }
  }

  /**
   * Mute or unmute microphone
   */
  setMicrophoneMuted(muted: boolean) {
    if (this.localAudioTrack) {
      if (muted) {
        this.localAudioTrack.mute();
      } else {
        this.localAudioTrack.unmute();
      }
    }
  }

  /**
   * Disconnect voice session and cleanly release all resources
   */
  disconnect() {
    this.cleanupPreviousInstances('Explicit disconnect call');
    this.options.onDisconnected?.();
  }

  private async fetchToken(): Promise<{ token: string, serverUrl: string }> {
      const res = await fetch('/api/livekit/token', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roomName: this.options.roomName || 'alya-voice-room',
          userId: this.options.userId || 'web_user',
          name: 'Alya User'
        })
      });

      if (!res.ok) {
        throw new Error(`Token endpoint returned ${res.status}`);
      }

      const data = await res.json();
      LiveKitHandshakeTracer.recordStep(this.activeSocketId, 'TOKEN_FETCH', { status: res.status });
      return data;
  }
}
