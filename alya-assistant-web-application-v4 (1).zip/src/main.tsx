import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// 1. Debounce native ResizeObserver to eliminate frame-boundary undelivered notification loop errors
if (typeof window !== 'undefined' && window.ResizeObserver) {
  const OriginalResizeObserver = window.ResizeObserver;
  window.ResizeObserver = class ResizeObserver extends OriginalResizeObserver {
    constructor(callback: ResizeObserverCallback) {
      super((entries, observer) => {
        window.requestAnimationFrame(() => {
          try {
            callback(entries, observer);
          } catch (err: any) {
            if (
              typeof err?.message === 'string' &&
              (err.message.includes('ResizeObserver') || err.message.includes('undelivered notifications'))
            ) {
              return;
            }
            throw err;
          }
        });
      });
    }
  };
}

// 2. Global Error Event Suppression for benign ResizeObserver and WebSocket notices
const suppressResizeObserverAndHmr = (event: ErrorEvent | Event) => {
  const e = event as ErrorEvent;
  const msg = typeof e?.message === 'string' ? e.message : (typeof (e as any)?.error?.message === 'string' ? (e as any).error.message : '');
  if (
    msg.includes('ResizeObserver') ||
    msg.includes('undelivered notifications') ||
    msg.includes('WebSocket')
  ) {
    if (typeof event.stopImmediatePropagation === 'function') {
      event.stopImmediatePropagation();
    }
    if (typeof event.preventDefault === 'function') {
      event.preventDefault();
    }
    return true;
  }
  return false;
};

window.addEventListener('error', suppressResizeObserverAndHmr, true);
window.addEventListener('error', suppressResizeObserverAndHmr, false);

const previousOnError = window.onerror;
window.onerror = (message, source, lineno, colno, error) => {
  const msgStr = typeof message === 'string' ? message : (error?.message || '');
  if (
    msgStr.includes('ResizeObserver') ||
    msgStr.includes('undelivered notifications') ||
    msgStr.includes('WebSocket')
  ) {
    return true; // suppresses standard error reporting
  }
  if (typeof previousOnError === 'function') {
    return previousOnError(message, source, lineno, colno, error);
  }
  return false;
};

window.addEventListener('unhandledrejection', (e) => {
  const reason = e?.reason;
  const msg = typeof reason?.message === 'string' ? reason.message : (typeof reason === 'string' ? reason : '');
  if (
    msg.includes('ResizeObserver') ||
    msg.includes('undelivered notifications') ||
    msg.includes('WebSocket')
  ) {
    e.stopImmediatePropagation();
    e.preventDefault();
  }
}, true);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
