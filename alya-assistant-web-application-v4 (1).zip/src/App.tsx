/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AuthProvider, useAuth } from './lib/AuthContext';
import { GlobalSettingsProvider } from './lib/GlobalSettingsContext';
import { LoginView } from './components/LoginView';
import { MainLayout } from './components/MainLayout';
import { PersistenceErrorBoundary } from './PersistenceErrorBoundary';
import { AudioDiagnosticsHUD } from './components/AudioDiagnosticsHUD';
import { useAudioContextSync } from './hooks/useAudioContextSync';

function AppContent() {
  const { user, loading } = useAuth();
  useAudioContextSync(); // Synchronize AudioContextManager volume ducking state globally

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-50 dark:bg-slate-950">
        <div className="w-8 h-8 border-4 border-slate-300 border-t-slate-900 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!user) {
    return <LoginView />;
  }

  return <MainLayout />;
}

export default function App() {
  return (
    <PersistenceErrorBoundary>
      <AuthProvider>
        <GlobalSettingsProvider>
          <div className="min-h-screen bg-white text-slate-900 selection:bg-slate-200">
            <AppContent />
            <AudioDiagnosticsHUD />
          </div>
        </GlobalSettingsProvider>
      </AuthProvider>
    </PersistenceErrorBoundary>
  );
}
