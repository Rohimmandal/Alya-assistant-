export const BACKCHANNEL_FILLERS = [
  "Hmm...",
  "Yeah...",
  "Okay...",
  "Right...",
  "I see...",
  "Interesting...",
  "Got it..."
];

export const getRandomFiller = (): string => {
  return BACKCHANNEL_FILLERS[Math.floor(Math.random() * BACKCHANNEL_FILLERS.length)];
};
