import OpenAI from 'openai';

export interface GenerateTextOptions {
  contents: string | Array<any>;
  systemInstruction?: string;
  temperature?: number;
  model?: string;
  mood?: string;
  enableSearch?: boolean;
}

export const openaiService = {
  async generateText(options: GenerateTextOptions, customApiKey: string): Promise<{ text: string }> {
    const client = new OpenAI({ apiKey: customApiKey });

    const messages: any[] = [
      { role: 'system', content: options.systemInstruction || "You are a helpful assistant." },
    ];

    if (Array.isArray(options.contents)) {
      // Need to convert to OpenAI format if needed
      messages.push({ role: 'user', content: options.contents.map(c => c.text || c).join('\n') });
    } else {
      messages.push({ role: 'user', content: options.contents });
    }

    const response = await client.chat.completions.create({
      model: options.model || 'gpt-4o',
      messages,
      temperature: options.temperature || 0.7,
    });

    return { text: response.choices[0].message.content || '' };
  }
};
