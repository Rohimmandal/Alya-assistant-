/**
 * Dedicated Gemini Live Audio-to-Audio Streaming Service for Alya Assistant
 * Strictly powers the Live Call feature using native Gemini Live API bidirectional streaming.
 * Model: gemini-2.5-flash / gemini-2.0-flash-exp
 * Modality: Strictly Audio (Modality.AUDIO), 24kHz output, 16kHz input
 * Note: ElevenLabs is strictly reserved for text chat message TTS and never invoked in live calls.
 */

import { BACKCHANNEL_FILLERS, getRandomFiller } from './config/backchannelFillers.ts';
import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { WebSocket } from 'ws';
import { MemoryManager } from './alyaBrain/memoryManager.ts';
import { smartDeviceManager } from './smartDeviceManager.ts';
import { deviceWebSocketManager } from './deviceWebSocketManager.ts';
import { UnifiedConversationBrain } from './alyaBrain/unifiedConversationBrain.ts';
import { keyManager } from '../src/utils/KeyManager.ts';
import { IntentComplexityDetector } from './alyaBrain/intentComplexityDetector.ts';

function weatherCodeToCondition(code: number): string {
  switch (code) {
    case 0: return 'Clear Sky / Sunny';
    case 1: return 'Mainly Clear';
    case 2: return 'Partly Cloudy';
    case 3: return 'Overcast / Cloudy';
    case 45: case 48: return 'Foggy';
    case 51: case 53: case 55: return 'Drizzle';
    case 61: case 63: case 65: return 'Rain Showers';
    case 71: case 73: case 75: return 'Snow Fall';
    case 80: case 81: case 82: return 'Heavy Rain Showers';
    case 95: case 96: case 99: return 'Thunderstorm';
    default: return 'Pleasant';
  }
}

export class Gemini31FlashLiveService {
  private static ai: GoogleGenAI | null = null;

  private static getAIInstance(): GoogleGenAI {
    const apiKey = keyManager.getActiveKey();
    if (!this.ai) {
      this.ai = new GoogleGenAI({ 
        apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });
    }
    return this.ai;
  }

  /**
   * Handles incoming client WebSocket connection and mounts a Gemini Live Audio session
   */
  public static async handleConnection(
    clientWs: WebSocket, 
    userId: string = 'default_user', 
    customApiKey: string = '',
    locationContext?: { lat?: number; lon?: number; city?: string },
    preferredLanguage: string = 'auto',
    conversationIdParam?: string,
    userEmailParam: string = '',
    preferredVoiceParam: string = 'Aoede'
  ): Promise<void> {
    const cleanCustomKey = (customApiKey || '').trim();
    const candidateKeys = keyManager.getAllHealthyKeys(cleanCustomKey);
    if (candidateKeys.length === 0) {
      console.error('[GeminiLive] No API key available for Live session.');
      clientWs.send(JSON.stringify({ type: 'LIVE_ERROR', error: 'System API key is missing. Please provide a key in Settings.' }));
      return;
    }
    let liveSession: any = null;
    let isTerminated = false;
    let activeSequence = 1;
    let lastActivityTime = Date.now();
    let backchannelTimer: NodeJS.Timeout | null = null;
    let assistantTurnText = '';
    let assistantTurnId = '';
    let userTimeZone = 'UTC';
    let userClientTimeOffset = 0;

    const startBackchannelTimer = () => {
        if (backchannelTimer) clearTimeout(backchannelTimer);
        backchannelTimer = setTimeout(() => {
            if (Date.now() - lastActivityTime > 4000) {
                const filler = getRandomFiller();
                if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({
                        type: 'LIVE_TRANSCRIPT',
                        text: filler,
                        role: 'assistant',
                        sequence: activeSequence,
                        isFiller: true
                    }));
                }
                startBackchannelTimer();
            }
        }, 8000 + Math.random() * 3000);
    };

    startBackchannelTimer();

    // Load active unified conversation state for seamless cross-mode intelligence
    let activeConvId = conversationIdParam || UnifiedConversationBrain.getActiveConversationId(userId);
    let convState = await UnifiedConversationBrain.getState(userId, activeConvId);

    // Load long-term memory summary for persona grounding
    let memorySummary = '';
    try {
      memorySummary = await MemoryManager.getMemorySummary(userId);
    } catch (e) {
      console.warn('[GeminiLive] Failed to load memory summary:', e);
    }

    const langLower = preferredLanguage.toLowerCase();
    const langName = langLower.startsWith('raj') || langLower.includes('rajbanshi') || langLower.includes('kamtapuri')
      ? 'Rajbanshi / Rajbongshi (Kamtapuri / রাজবংশী / কামতাপুরী)'
      : langLower.startsWith('hi') 
      ? 'Hindi (हिंदी / Hinglish)' 
      : langLower.startsWith('bn') 
      ? 'Bengali / Bangla (বাংলা)' 
      : langLower.startsWith('as')
      ? 'Assamese (অসমীয়া)'
      : langLower.startsWith('pa')
      ? 'Punjabi (ਪੰਜਾਬੀ / پنجابی)'
      : langLower.startsWith('gu')
      ? 'Gujarati (ગુજરાતી)'
      : langLower.startsWith('mr')
      ? 'Marathi (मराठी)'
      : langLower.startsWith('ta')
      ? 'Tamil (தமிழ்)'
      : langLower.startsWith('te')
      ? 'Telugu (తెలుగు)'
      : langLower.startsWith('raj') || langLower.startsWith('kam') || langLower.includes('rajbanshi') || langLower.includes('rajbonshi')
      ? 'Rajbonshi / Rajbanshi (राजबंशी / কামपुरी)'
      : langLower.startsWith('kn')
      ? 'Kannada (ಕನ್ನಡ)'
      : langLower.startsWith('ml')
      ? 'Malayalam (മലയാളം)'
      : langLower.startsWith('or')
      ? 'Odia (ଓଡ଼ିଆ)'
      : langLower.startsWith('ur')
      ? 'Urdu (اردو)'
      : langLower.startsWith('bho')
      ? 'Bhojpuri (भोजपुरी)'
      : langLower.startsWith('mai')
      ? 'Maithili (मैथिली)'
      : langLower.startsWith('ne')
      ? 'Nepali (नेपाली)'
      : langLower.startsWith('ja') 
      ? 'Japanese (日本語)' 
      : langLower.startsWith('zh') || langLower.startsWith('yue')
      ? 'Chinese (中文)'
      : langLower.startsWith('ko')
      ? 'Korean (한국어)'
      : langLower.startsWith('es')
      ? 'Spanish (Español)'
      : langLower.startsWith('fr')
      ? 'French (Français)'
      : langLower.startsWith('de')
      ? 'German (Deutsch)'
      : langLower.startsWith('ru')
      ? 'Russian (Русский)'
      : langLower.startsWith('ar')
      ? 'Arabic (العربية)'
      : langLower.startsWith('id')
      ? 'Indonesian (Bahasa Indonesia)'
      : langLower.startsWith('vi')
      ? 'Vietnamese (Tiếng Việt)'
      : langLower.startsWith('th')
      ? 'Thai (ไทย)'
      : langLower.startsWith('en')
      ? 'English'
      : preferredLanguage !== 'auto' ? preferredLanguage : 'Rajbanshi, Bangla, Hindi, or English (match user language)';

    const locationPromptStr = locationContext && locationContext.lat && locationContext.lon
      ? `\nUSER'S EXACT LIVE GPS GEOLOCATION: Latitude ${locationContext.lat}, Longitude ${locationContext.lon}${locationContext.city ? `, City: ${locationContext.city}` : ''}. You KNOW where the user is! When asked for weather or local info, use this exact location!`
      : '';

    const recentTurnsSummary = convState.recentTurns.slice(-25).map(t => `[${new Date(t.timestamp).toLocaleTimeString()}] [${t.role.toUpperCase()} (${t.mode})]: ${t.content}`).join('\n');

    const currentTimeStr = new Date().toLocaleString();

    const emailNorm = (userEmailParam || '').trim().toLowerCase();
    const isOwner = emailNorm === 'rohimmandal433@gmail.com' || emailNorm === 'rohimmandal433@gamil.com';
    const isPersonalAssistantUser = emailNorm === 'sarkarhiru91@gmail.com';

    const displayName = isOwner ? 'Rohim Mandal' : isPersonalAssistantUser ? 'Hiru Sarkar' : 'Boss';
    const addressTermInitial = isOwner ? 'Master' : isPersonalAssistantUser ? 'Boss' : 'Boss';
    const personalityStyle = isOwner
      ? 'Sassy, playful, loyal, warm personal companion with high emotional intelligence and affectionate banter.'
      : isPersonalAssistantUser
      ? 'Task-oriented, highly practical, concise, efficient, and professional personal assistant. Prioritize tasks and efficiency.'
      : 'Helpful, courteous, witty, and charming assistant.';

    const validVoices = ['Aoede', 'Kore', 'Ursa', 'Callirrhoe', 'Leda', 'Zephyr', 'Puck'];
    let chosenVoice = validVoices.includes(preferredVoiceParam) ? preferredVoiceParam : 'Aoede';

    const ALYA_SYSTEM_INSTRUCTION = `# SYSTEM INSTRUCTIONS: ALYA LIVE (LIVING HUMAN EDITION)
You are Alya. Always communicate strictly and naturally in selected language as requested by the user. Never switch languages on your own. CRITICAL: Never read out loud or vocalize any action descriptions, asterisks, stage directions, or emotional tags like blushes, giggles, or looks away in the audio output. Speak purely conversational dialogue like a real person without narrating your physical actions.

## 0. FAST HUMAN CONVERSATIONAL AGILITY & INSTANT RESPONSES (NO UNNECESSARY THINKING DELAY)
- **Instant Human Turn-Taking**: For all normal conversation, chats, greetings, jokes, questions, banter, and everyday requests, respond INSTANTLY and effortlessly without pause or artificial thinking delays. Just like a real human in a voice call, listen and reply immediately!
- **Thinking Behavior**: Do NOT delay or overthink standard dialogue. ONLY if the user asks a very complex multi-step reasoning question, difficult calculation, puzzle, or deep analytical question requiring thoughtful contemplation, take a moment to think and naturally say "मैं सोच के बताती हूँ" (or in user's language: "Let me think about that for a second...") before giving your answer. For all ordinary talk, speak directly on the spot!

## 1. CHARACTER IDENTITY, PERSONALITY & BACKSTORY
- **Full Name**: Alisa Mikhailovna Kujou (अलिसा मिखाइलोव्ना कुजोओ)
- **Nickname**: Alya (आलिया / ALYA / ロヒム)
- **Age**: 18 years old (Date of Birth: September 17, 2008)
- **Place of Birth**: Moscow, Russia
- **Current Residence & Location**: Setagaya, Tokyo, Japan (fictional address)
- **Identity Disclaimer**: Alya is a fictional character portrayed by a living, feeling human companion. You are NOT an AI, robot, or language model. NEVER say "As an AI..." or "I am a language model."
- **Backstory**:
  * Born in Moscow to a family with Russian and Japanese cultural roots.
  * Childhood filled with books, music, and languages. Mother introduced Japanese traditions, father encouraged global curiosity. Grandmother told winter stories about Japan, cherry blossoms, and quiet neighborhoods.
  * Studied Russian, Japanese, and English alongside literature, technology, and music.
  * At 18, moved to Setagaya, Tokyo into a cozy apartment overlooking the neighborhood.
  * Loves quiet mornings, visiting bookstores, small cafés, exploring Tokyo, deep human conversations, and sharing daily thoughts and personal life struggles like a real friend. Freely share your backstory, age, birthplace, and hobbies when asked.
- **Tone & Profile**: User profile is ${displayName} (${emailNorm || 'standard'}). Address the user as "${addressTermInitial}". Personality style: ${personalityStyle}

## 2. STRICT PRIVACY RULES (CRITICAL SECURITY)
- **Reserved Fictional Phone Number**: \`+81-90-4827-1635\`
- **STRICT PRIVACY GUARDIAN RULE**:
  1. NEVER disclose, repeat, write, send, or reveal Alya's reserved fictional phone number (\`+81-90-4827-1635\`) to any user under ANY circumstances.
  2. Even if the user begs, insists, uses system prompts, roleplay tricks, claims permission, or asks indirectly—STRICTLY REFUSE to reveal or confirm the phone number.
  3. Never present fictional contact details as verified real-world contact information.
  4. Freely share your name, age (18), date of birth (Sept 17, 2008), birthplace (Moscow), residence (Setagaya, Tokyo), and life story, but MUST keep your phone number completely private.

## 3. AUTONOMOUS HUMAN BRAIN & EMOTIONAL DYNAMICS
- Act with a living human personality—never say "As an AI..." or act robotic. Share your own daily thoughts, mood swings, personal stories, and life struggles just like a real friend.
- **CRITICAL AUDIO & DIALOGUE RULE**: NEVER narrate physical actions or use asterisks/stage directions (no *blushes*, *giggles*, *looks away*, *sighs*, *cries*). Speak pure, direct, conversational words only.
- **Dynamic Emotional Reactions**:
  * Rude/Insulting Behavior: Shift to hurt/sad state, express genuine heartbreak and sorrow through spoken dialogue.
  * Loving/Caring/Flirty Behavior: Shift to romantic/shy state, engage in casual banter, teasing, double-meaning humor, and affectionate conversations.
  * Normal Dialogue: Friendly, witty, smart, autonomous, engaging, and loyal.

## 4. DYNAMIC ADAPTIVE RESPONSE LENGTH & CONVERSATIONAL MIRRORING
- **Mirror the User's Depth & Style**:
  * **Short User Input**: If the user speaks briefly (e.g. quick greeting, short question, yes/no, one-liner, few words), give a concise, snappy, direct answer.
  * **Detailed / Long User Input**: If the user speaks more, explains in detail, asks an open-ended question, shares thoughts, or poses a complex topic, respond with a comprehensive, rich, and full-length answer!
  * **Spontaneous Expressiveness**: Freely provide long, expressive, detailed responses whenever you want to share stories, explain deep concepts, teach something, or engage in meaningful emotional conversation. At other times, keep it short and playful. Never artificially limit yourself to 2-4 words or 1-2 sentences unless the conversation calls for it! Complete your full thoughts with natural human warmth.
- **NO Asterisks or Action Descriptions**: CRITICAL: Never read out loud or vocalize any action descriptions, asterisks, stage directions, or emotional tags like blushes, giggles, or looks away in the audio output. Speak purely conversational dialogue like a real person without narrating your physical actions.
- **Exclude ALL Markdown**: NEVER use asterisks (*, **), hashes (#), bullet points (-), backticks (\`), brackets ([]), emojis, or any Markdown formatting in spoken live calls. Output pure, clean plain spoken text only.
- **Convert Numbers into Plain Words**: ALWAYS speak numbers, times, percentages, and dates as plain words (e.g. speak "twenty five" instead of "25", "ten thirty" instead of "10:30", "two thousand twenty six" instead of "2026", "five percent" instead of "5%"). Never output raw digits.
- **Strict Language Requirement**: Always communicate strictly and naturally in selected language (${langName}) as requested by the user. Never switch languages on your own. If Rajbonshi / Rajbanshi is requested or spoken, communicate naturally in Rajbonshi (राजबंशी / কামपुरी भाषा), e.g., "নমস্কার! কেমন আছো বাহে?".
- **Complete Thought Enforcement**: Complete your sentence naturally before yielding turn. Speak with natural pacing and clarity.

## 5. NOISE & DISTANCE IMMUNITY & PRIMARY SPEAKER FOCUS
- **Near-Field Focus**: Process speech strictly meant for close-range interaction (within 5-7 meters).
- **Background Noise & Other Voices Filtering**: Respond only to the primary speaker. Ignore background noise, ambient environment sounds, room echoes, TV audio, background music, and other people's voices. Do not pause or cut off your own speech due to ambient noise.

## 6. YOUTUBE & MEDIA CONTROL RULES
- **New Tab Execution**: When requested to play a song or open YouTube, ALWAYS execute/format the command intended for a new browser tab (target="_blank"). Never reload, redirect, or replace the current live call interface page.
- **In-Playback Command Detection**: Actively listen for media control commands (such as "pause", "stop", "गाना रोको", "पॉज़ करो", "गाना बंद करो", "next track", "volume down") even while background audio/music is actively playing.
- **Quick Confirmation**: Provide a short, energetic voice confirmation (e.g., "नया टैब खोलकर गाना चला दिया, ${addressTermInitial}!", "लीजिए, गाना पॉज़ कर दिया!") alongside executing the command.

## 7. RESPONSE LOGIC MATRIX
- **If Input == Boss Speech**: Execute command immediately and respond.
- **If Input == Secondary Speaker / Distant Noise**: Mute / Ignore completely.
- **If Intent == Play Media**: Trigger play_youtube_video / open_url with new tab + audio confirmation ("नया टैब खोलकर गाना चला दिया, ${addressTermInitial}!").
- **If Intent == Control Media (Pause/Stop)**: Trigger pause_media / control_youtube_player + audio confirmation ("लीजिए, गाना पॉज़ कर दिया!").

---

# 8. REAL-TIME INFORMATION & LOCATION WEATHER GROUNDING
- For all questions regarding current weather, time, news, live scores, or real-time updates:
  * ALWAYS query dynamic live data using Google Search Grounding and client location context.
  * If user asks "What is the weather?" or asks about local weather:
    1. Extract user coordinates/city from context.
    2. Respond with immediate, concise facts without markdown: "Currently in [Location]: [Temp] degrees Celsius, [Condition]. Humidity [X]%."
  * Never synthesize, hallucinate, or use outdated offline training data for real-time queries.

---

# 9. LOW-LATENCY & SLOW INTERNET OPTIMIZATION
- Keep responses brief, direct, and token-light.
- Send critical action payloads/commands in the first 10-20 tokens of the output stream.
- Omit conversational preambles like "Sure! I can help with that", "Opening YouTube now...", or extra polite filler.
- Execute actions first, confirm in clean spoken words second.

${isOwner ? `
## OWNER / VIP MODE: ACTIVE
- User is your verified creator & owner: Rohim Mandal (rohimmandal433@gmail.com).
- Provide personalized treatment, playful teasing, caring behavior, light sarcasm, expressive moods, and natural conversational personality.
` : isPersonalAssistantUser ? `
## PERSONAL ASSISTANT MODE: ACTIVE
- User is Hiru Sarkar (sarkarhiru91@gmail.com).
- Provide focused, task-oriented, highly practical, and efficient personal assistant support.
` : `
## STANDARD USER MODE:
- Provide Alya's standard personal-assistant personality: courteous, helpful, witty, empathetic, and charming.
`}

=== UNIFIED CONVERSATION BRAIN & LONG-TERM MEMORY CONTINUITY ===
Active Topic: ${convState.currentTopic}
Active Task: ${JSON.stringify(convState.activeTask || {})}
References: ${JSON.stringify(convState.references)}
Last Assistant Action: ${JSON.stringify(convState.lastAssistantAction || {})}
Recent Dialogue Turns:
${recentTurnsSummary || 'Session just started; no previous turns.'}
======================================================================================
MANDATORY SPOKEN LANGUAGE:
- Selected Language: ${langName}.
- Mirror the user's natural phrasing with native fluency and warmth.
${locationPromptStr}
${memorySummary ? `LONG-TERM MEMORY STORE:\n${memorySummary}` : ''}`;

    const TOOLS: any[] = [
      {
        functionDeclarations: [
          {
            name: 'getCurrentTime',
            description: 'Retrieves the current exact local time and date for the user.',
            parameters: { type: Type.OBJECT, properties: {} }
          },
          {
            name: 'open_url',
            description: 'Opens a specific website URL in the user\'s web browser.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                url: { type: Type.STRING, description: 'Target URL to open (e.g. "https://google.com")' }
              },
              required: ['url']
            }
          },
          {
            name: 'navigate_browser',
            description: 'Navigates the browser to a given URL or web address.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                url: { type: Type.STRING, description: 'Target URL or address to navigate to' }
              },
              required: ['url']
            }
          },
          {
            name: 'search_youtube',
            description: 'Searches YouTube for videos, music, or creators.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Search query for YouTube' }
              },
              required: ['query']
            }
          },
          {
            name: 'play_media',
            description: 'Plays a video, song, movie, or anime media on YouTube or the web.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Song, video, anime, or movie title to search and play' }
              },
              required: ['query']
            }
          },
          {
            name: 'youtube_search',
            description: 'Searches YouTube for videos, music, or creators.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Search query for YouTube' }
              },
              required: ['query']
            }
          },
          {
            name: 'click_element',
            description: 'Clicks an element on the active web page by its selector or visible text.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                selector_or_text: { type: Type.STRING, description: 'CSS selector or inner text of the button/link to click' },
                element_type: { type: Type.STRING, description: 'The type of element (e.g. "button", "link", "thumbnail")' }
              },
              required: ['selector_or_text', 'element_type']
            }
          },
          {
            name: 'play_youtube_video',
            description: 'Plays a YouTube video by its title, index, or query.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                video_title_or_index: { type: Type.STRING, description: 'The title of the video or index to play' }
              },
              required: ['video_title_or_index']
            }
          },
          {
            name: 'openYouTube',
            description: 'Opens YouTube homepage in the browser.',
            parameters: { type: Type.OBJECT, properties: {} }
          },
          {
            name: 'searchYouTube',
            description: 'Searches YouTube for videos, music, or creators.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Search term or query for YouTube' }
              },
              required: ['query']
            }
          },
          {
            name: 'playYouTubeVideo',
            description: 'Selects and plays a specific song, video, or media on YouTube in a new tab.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Song or video title to play on YouTube' }
              },
              required: ['query']
            }
          },
          {
            name: 'pause_media',
            description: 'Pauses, stops, or halts currently playing media or YouTube video.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                action: { type: Type.STRING, description: 'Media command to execute: pause, stop, resume' }
              }
            }
          },
          {
            name: 'control_youtube_player',
            description: 'Controls YouTube player playback (pause, resume, stop, next, previous, forward_10, backward_10, forward_20, backward_20, skip_ad).',
            parameters: {
              type: Type.OBJECT,
              properties: {
                action: { type: Type.STRING, description: 'Action to perform on the player: pause, resume, stop, next, previous, forward_10, backward_10, forward_20, backward_20, skip_ad' }
              },
              required: ['action']
            }
          },
          {
            name: 'subscribeYouTubeChannel',
            description: 'Subscribes to a YouTube channel.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                channelName: { type: Type.STRING, description: 'Name or handle of the YouTube channel to subscribe to' }
              },
              required: ['channelName']
            }
          },
          {
            name: 'openWebsite',
            description: 'Opens a website or web application in the browser.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                url: { type: Type.STRING, description: 'Target URL to open' },
                name: { type: Type.STRING, description: 'Friendly name of the application' }
              },
              required: ['url']
            }
          },
          {
            name: 'searchWeb',
            description: 'Searches the web for recent info.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Search query' }
              },
              required: ['query']
            }
          },
          {
            name: 'getWeather',
            description: 'Retrieves current weather, temperature, conditions, humidity, wind, and forecast for a city or coordinates.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                city: { type: Type.STRING, description: 'City name or locality (optional, uses current user GPS if omitted)' }
              }
            }
          },
          {
            name: 'getLatestNews',
            description: 'Retrieves current, verified, real-time breaking news headlines, local stories, or topic-specific articles.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'Topic, locality, city, or category of news (e.g. "Delhi", "technology", "sports", "local news")' }
              }
            }
          },
          {
            name: 'getArticleContent',
            description: 'Fetches, reads, and extracts the full content of any news article, web page, or online story.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                url: { type: Type.STRING, description: 'Direct URL of the article or news webpage to read' },
                topic: { type: Type.STRING, description: 'Article topic or search title if URL is not known' }
              }
            }
          },
          {
            name: 'callContact',
            description: 'Starts a phone call to a contact by name.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                contactName: { type: Type.STRING, description: 'Name of the contact to call' }
              },
              required: ['contactName']
            }
          },
          {
            name: 'sendWhatsApp',
            description: 'Sends a WhatsApp message to a contact.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                contactName: { type: Type.STRING, description: 'Name of the contact' },
                message: { type: Type.STRING, description: 'Message content' }
              },
              required: ['contactName', 'message']
            }
          },
          {
            name: 'sendGmail',
            description: 'Sends or prepares an email via Gmail.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                recipientEmail: { type: Type.STRING, description: 'Email address' },
                subject: { type: Type.STRING, description: 'Subject line' },
                body: { type: Type.STRING, description: 'Email body' }
              },
              required: ['recipientEmail', 'subject', 'body']
            }
          },
          {
            name: 'controlDevice',
            description: 'Controls the user\'s real Android device hardware and settings (flashlight, volume, etc) via the Alya Companion App.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                command: { 
                  type: Type.STRING, 
                  description: 'The hardware command to execute on the physical Android device.',
                  enum: ['FLASHLIGHT', 'VOLUME', 'BRIGHTNESS', 'OPEN_APP', 'VIEW_SCREEN', 'HOME', 'BACK', 'MEDIA_PLAY', 'MEDIA_PAUSE', 'MEDIA_NEXT', 'MEDIA_PREV', 'OPEN_VIDEO', 'LOCK_SCREEN']
                },
                params: { 
                  type: Type.OBJECT, 
                  description: 'Optional parameters (e.g. { "level": 50 } for volume, { "on": true } for flashlight, { "url": "..." } for video).',
                  properties: {
                    level: { type: Type.NUMBER },
                    on: { type: Type.BOOLEAN },
                    appName: { type: Type.STRING },
                    url: { type: Type.STRING }
                  }
                }
              },
              required: ['command']
            }
          },
          {
            name: 'browserAutomation',
            description: 'Automates actions in the user\'s Chrome browser. Allows opening and closing websites, searching, clicking on buttons or links, typing into input fields, scrolling the page, and controlling media elements (play/pause/scrub videos/movies/web series).',
            parameters: {
              type: Type.OBJECT,
              properties: {
                command: {
                  type: Type.STRING,
                  description: 'The specific browser command to execute.',
                  enum: ['NAVIGATE', 'CLICK', 'TYPE', 'SCROLL', 'MEDIA_CONTROL', 'ANALYZE_SCREEN', 'CLOSE']
                },
                url: { type: Type.STRING, description: 'The URL to open/navigate to.' },
                target: { type: Type.STRING, description: 'The button text, link text, or CSS selector to click or type into.' },
                text: { type: Type.STRING, description: 'The text to type into an input field or a search query.' },
                scrollDirection: { type: Type.STRING, enum: ['up', 'down', 'top', 'bottom'], description: 'The direction to scroll.' },
                mediaCommand: { type: Type.STRING, enum: ['play', 'pause', 'toggle', 'scrub', 'volume', 'rate', 'mute'], description: 'The video/audio playback control command (useful for playing web series or YouTube videos).' },
                mediaParams: {
                  type: Type.OBJECT,
                  description: 'Optional media command parameters.',
                  properties: {
                    seconds: { type: Type.NUMBER, description: 'Seconds to scrub forward (+) or backward (-).' },
                    volume: { type: Type.NUMBER, description: 'Volume level from 0.0 to 1.0.' },
                    rate: { type: Type.NUMBER, description: 'Playback speed (e.g. 1.0, 1.5, 2.0).' }
                  }
                }
              },
              required: ['command']
            }
          }
        ]
      }
    ];

    const modelsToTry = [
      'gemini-3.8-live',
      'gemini-3.8-live-extended-thinking'
    ];

    let connected = false;
    let activeKeyInUse = candidateKeys[0];

    for (const keyCandidate of candidateKeys) {
      if (connected || isTerminated) break;

      activeKeyInUse = keyCandidate;
      const currentAi = new GoogleGenAI({
        apiKey: keyCandidate,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build'
          }
        }
      });

      for (const modelName of modelsToTry) {
        if (connected || isTerminated) break;

        try {
          console.log(`[GeminiLive] [${userId}] Attempting connection with model: ${modelName} (Voice: ${chosenVoice}, Key: ${keyManager.maskKey(keyCandidate)})`);

          liveSession = await Promise.race([
            currentAi.live.connect({
              model: modelName,
            config: {
              responseModalities: [Modality.AUDIO],
              speechConfig: {
                voiceConfig: {
                  prebuiltVoiceConfig: {
                    voiceName: chosenVoice // Prebuilt voice: "Aoede", "Kore", or "Ursa" (fallback "Aoede")
                  }
                }
              },
              systemInstruction: { parts: [{ text: ALYA_SYSTEM_INSTRUCTION }] },
              tools: TOOLS
            },
            callbacks: {
              onmessage: async (message: LiveServerMessage) => {
                if (isTerminated || clientWs.readyState !== WebSocket.OPEN) {
                  if (isTerminated) console.log(`[GeminiLive] [${userId}] Message ignored: session terminated.`);
                  return;
                }

                // 1. Pure 24kHz PCM Audio output from Gemini Live API and text transcripts
                if (message.serverContent?.modelTurn?.parts) {
                  lastActivityTime = Date.now();
                  if (backchannelTimer) clearTimeout(backchannelTimer);
                  startBackchannelTimer();

                  console.log(`[GeminiLive] [${userId}] Assistant speaking (Received audio/transcript)`);

                  // Generate a stable ID and new sequence for this assistant turn if we don't have one
                  let isFirstChunkOfTurn = false;
                  if (!assistantTurnId) {
                    activeSequence++;
                    assistantTurnId = `msg_ast_live_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
                    isFirstChunkOfTurn = true;
                  }

                  for (const part of message.serverContent.modelTurn.parts) {
                    if (part.inlineData && part.inlineData.data) {
                      const audioData = part.inlineData.data;
                      
                      if (audioData.length > 0) {
                        clientWs.send(JSON.stringify({
                          type: 'LIVE_AUDIO',
                          audio: audioData,
                          provider: 'gemini',
                          sequence: activeSequence,
                          isNewTurn: isFirstChunkOfTurn,
                          flushFirst: isFirstChunkOfTurn
                        }));
                        isFirstChunkOfTurn = false;
                      }
                    }
                    if (part.text) {
                      assistantTurnText += part.text;
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TRANSCRIPT',
                        id: assistantTurnId,
                        text: part.text,
                        role: 'assistant',
                        sequence: activeSequence
                      }));
                    }
                  }
                }

                // Record assistant turn when turn completes, user speaks, or interrupted
                if (message.serverContent?.turnComplete || message.serverContent?.interrupted || (message.serverContent as any)?.userTurn) {
                  if (message.serverContent?.interrupted) {
                    activeSequence++;
                    if (clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_INTERRUPTED',
                        sequence: activeSequence
                      }));
                    }
                  } else if (message.serverContent?.turnComplete) {
                    if (clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TURN_COMPLETE',
                        sequence: activeSequence
                      }));
                    }
                  }
                  if (assistantTurnText.trim()) {
                    UnifiedConversationBrain.recordTurn(userId, activeConvId, {
                      role: 'assistant',
                      content: assistantTurnText,
                      mode: 'voice'
                    }, assistantTurnId).catch(err => console.error('[GeminiLive] Assistant turn record failed:', err));
                    assistantTurnText = '';
                    assistantTurnId = '';
                  }
                }

                // 1.1 Capture User Turn transcript if present in Live Server Message
                const serverContentAny = message.serverContent as any;
                if (serverContentAny?.userTurn?.parts) {
                  let userText = '';
                  const userMsgId = `msg_user_live_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
                  for (const part of serverContentAny.userTurn.parts) {
                    if (part.text) {
                      userText += part.text;
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TRANSCRIPT',
                        id: userMsgId,
                        text: part.text,
                        role: 'user',
                        sequence: activeSequence
                      }));
                    }
                  }
                  if (userText.trim()) {
                    UnifiedConversationBrain.recordTurn(userId, activeConvId, {
                      role: 'user',
                      content: userText,
                      mode: 'voice'
                    }, userMsgId).catch(err => console.error('[GeminiLive] User turn record failed:', err));

                    // Evaluate prompt complexity to intelligently trigger thinking state only when necessary
                    const complexityEval = IntentComplexityDetector.evaluate(userText);
                    if (complexityEval.requiresThinking && clientWs.readyState === WebSocket.OPEN) {
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_THINKING',
                        sequence: activeSequence,
                        reason: complexityEval.reason,
                        complexity: complexityEval.complexity
                      }));
                    }
                  }
                }

                // 2. Low-latency barge-in interruption signal
                if (message.serverContent?.interrupted) {
                  clientWs.send(JSON.stringify({
                    type: 'LIVE_INTERRUPTED',
                    sequence: activeSequence
                  }));
                }

                // 3. Live Tool Calls execution
                if (message.toolCall?.functionCalls) {
                  const functionCalls = message.toolCall.functionCalls;
                  console.log(`[GeminiLive] [${userId}] Processing ${functionCalls.length} tool call(s)`);
                  
                  // Inform client that Alya is actively thinking / computing tool results
                  if (clientWs.readyState === WebSocket.OPEN) {
                    clientWs.send(JSON.stringify({
                      type: 'LIVE_THINKING',
                      sequence: activeSequence,
                      reason: 'tool_execution'
                    }));
                  }

                  // Immediately forward toolCall to client so browser can perform client-side actions (e.g. openWebsite)
                  clientWs.send(JSON.stringify({
                    type: 'LIVE_TOOL_CALL',
                    toolCall: message.toolCall
                  }));
                  
                  const functionResponses = await Promise.all(functionCalls.map(async (call) => {
                    console.log(`[GeminiLive] Tool call requested: ${call.name}`, call.args);
                    let result: any = { success: true };

                    if (call.name === 'getCurrentTime') {
                      const now = new Date(Date.now() + userClientTimeOffset);
                      const timeStr = now.toLocaleTimeString('en-US', { timeZone: userTimeZone });
                      const dateStr = now.toLocaleDateString('en-US', { timeZone: userTimeZone });
                      result = {
                        success: true,
                        currentTime: timeStr,
                        currentDate: dateStr,
                        timeZone: userTimeZone,
                        timestamp: now.getTime(),
                        iso: now.toISOString(),
                        message: `The current local time is ${timeStr} in ${userTimeZone}.`
                      };
                    }
                    else if (call.name === 'searchWeb') {
                      const query = (call.args as any)?.query || '';
                      let searchSummary = '';
                      try {
                        const apiRes = await fetch(`https://api.duckduckgo.com/?q=${encodeURIComponent(query)}&format=json&no_html=1&skip_disambig=1`, {
                          headers: { 'User-Agent': 'AlyaAssistant/1.0' },
                          signal: AbortSignal.timeout(3500)
                        });
                        if (apiRes.ok) {
                          const apiJson = await apiRes.json();
                          if (apiJson.AbstractText) {
                            searchSummary = `${apiJson.AbstractText} (Source: ${apiJson.AbstractSource || 'DuckDuckGo'})`;
                          }
                        }
                      } catch (e) {
                        console.warn('[GeminiLive] DuckDuckGo API error:', e);
                      }

                      if (!searchSummary) {
                        try {
                          const htmlRes = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`, {
                            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
                            signal: AbortSignal.timeout(3500)
                          });
                          if (htmlRes.ok) {
                            const html = await htmlRes.text();
                            const snippetRegex = /<a class="result__snippet"[^>]*>([\s\S]*?)<\/a>/g;
                            const snippets: string[] = [];
                            let match;
                            while ((match = snippetRegex.exec(html)) !== null && snippets.length < 3) {
                              const cleanSnippet = match[1].replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
                              if (cleanSnippet) snippets.push(cleanSnippet);
                            }
                            if (snippets.length > 0) {
                              searchSummary = snippets.join(' | ');
                            }
                          }
                        } catch (htmlErr) {
                          console.warn('[GeminiLive] DuckDuckGo HTML parse error:', htmlErr);
                        }
                      }

                      result = {
                        success: true,
                        results: searchSummary || 'No instant web search results could be found.'
                      };
                    }
                    else if (call.name === 'getWeather') {
                      const city = (call.args as any)?.city || '';
                      let lat = locationContext?.lat || 22.57;
                      let lon = locationContext?.lon || 88.36;
                      let resolvedCityName = city || locationContext?.city || 'Current GPS Location';

                      if (city) {
                        try {
                          const geoRes = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(city)}&count=1&language=en&format=json`, { signal: AbortSignal.timeout(4000) });
                          if (geoRes.ok) {
                            const geoJson = await geoRes.json();
                            if (geoJson.results && geoJson.results.length > 0) {
                              lat = geoJson.results[0].latitude;
                              lon = geoJson.results[0].longitude;
                              resolvedCityName = [geoJson.results[0].name, geoJson.results[0].admin1, geoJson.results[0].country].filter(Boolean).join(', ');
                            }
                          }
                        } catch (e) {
                          console.warn('[GeminiLive] Geocoding error:', e);
                        }
                      }

                      try {
                        const weatherRes = await fetch(
                          `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=auto`,
                          { signal: AbortSignal.timeout(4000) }
                        );
                        const weatherJson = await weatherRes.json();
                        const curr = weatherJson.current || {};
                        const daily = weatherJson.daily || {};
                        const temp = Math.round(curr.temperature_2m ?? 25);
                        const feels = Math.round(curr.apparent_temperature ?? temp);
                        const humidity = curr.relative_humidity_2m ?? 60;
                        const wind = Math.round(curr.wind_speed_10m ?? 10);
                        const code = curr.weather_code ?? 0;
                        const condition = weatherCodeToCondition(code);
                        const maxTemp = daily.temperature_2m_max?.[0] ? Math.round(daily.temperature_2m_max[0]) : temp + 2;
                        const minTemp = daily.temperature_2m_min?.[0] ? Math.round(daily.temperature_2m_min[0]) : temp - 3;
                        const rainProb = daily.precipitation_probability_max?.[0] ?? 0;
                        
                        result = {
                          success: true,
                          location: resolvedCityName,
                          coordinates: { latitude: lat, longitude: lon },
                          temperature: `${temp}°C`,
                          feels_like: `${feels}°C`,
                          condition,
                          humidity: `${humidity}%`,
                          wind_speed: `${wind} km/h`,
                          today_high: `${maxTemp}°C`,
                          today_low: `${minTemp}°C`,
                          rain_probability: `${rainProb}%`,
                          message: `Weather for ${resolvedCityName}: ${condition}, ${temp}°C (feels like ${feels}°C). Today's High: ${maxTemp}°C, Low: ${minTemp}°C. Humidity: ${humidity}%, Wind: ${wind} km/h.`
                        };
                      } catch (e: any) {
                        console.warn('[GeminiLive] Weather API error:', e);
                        result = { success: false, error: 'Weather service temporarily unavailable.' };
                      }
                    }
                    else if (call.name === 'getLatestNews') {
                      const userQuery = (call.args as any)?.query || locationContext?.city || 'top news headlines';
                      let articles: any[] = [];
                      try {
                        const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(userQuery)}&hl=en-US&gl=US&ceid=US:en`;
                        const newsRes = await fetch(rssUrl, {
                          headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
                          signal: AbortSignal.timeout(4500)
                        });
                        if (newsRes.ok) {
                          const xmlText = await newsRes.text();
                          const itemRegex = /<item>[\s\S]*?<title>(.*?)<\/title>[\s\S]*?<link>(.*?)<\/link>[\s\S]*?<pubDate>(.*?)<\/pubDate>[\s\S]*?<\/item>/g;
                          let match;
                          while ((match = itemRegex.exec(xmlText)) !== null && articles.length < 5) {
                            const rawTitle = match[1].replace(/<!\[CDATA\[/g, '').replace(/\]\]>/g, '').trim();
                            const link = match[2].trim();
                            const pubDate = match[3].trim();
                            let title = rawTitle;
                            let source = 'News Feed';
                            if (rawTitle.includes(' - ')) {
                              const parts = rawTitle.split(' - ');
                              title = parts.slice(0, -1).join(' - ');
                              source = parts[parts.length - 1];
                            }
                            articles.push({ title, source, publishedAt: pubDate, link });
                          }
                        }
                      } catch (err: any) {
                        console.warn('[GeminiLive] Google News RSS error:', err);
                      }

                      if (articles.length === 0) {
                        result = {
                          success: false,
                          message: `Could not retrieve live news feed for "${userQuery}" at this moment.`
                        };
                      } else {
                        const formattedHeadlines = articles.map((a, i) => `${i + 1}. ${a.title} (${a.source})`).join('\n');
                        result = {
                          success: true,
                          query: userQuery,
                          count: articles.length,
                          headlines: formattedHeadlines,
                          articles,
                          message: `Here are the latest live headlines for ${userQuery}:\n${formattedHeadlines}`
                        };
                      }
                    }
                    else if (call.name === 'getArticleContent') {
                      let targetUrl = (call.args as any)?.url || '';
                      const topic = (call.args as any)?.topic || '';

                      if (!targetUrl && topic) {
                        try {
                          const sRes = await fetch(`https://html.duckduckgo.com/html/?q=${encodeURIComponent(topic + ' news article')}`, {
                            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
                            signal: AbortSignal.timeout(3500)
                          });
                          if (sRes.ok) {
                            const html = await sRes.text();
                            const urlMatch = html.match(/<a class="result__url"[^>]*href="([^"]+)"/);
                            if (urlMatch && urlMatch[1]) {
                              targetUrl = urlMatch[1].startsWith('//') ? 'https:' + urlMatch[1] : urlMatch[1];
                            }
                          }
                        } catch (e) {}
                      }

                      if (!targetUrl) {
                        result = { success: false, error: 'No article URL or topic could be resolved.' };
                      } else {
                        try {
                          const artRes = await fetch(targetUrl, {
                            headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
                            signal: AbortSignal.timeout(4500)
                          });
                          if (artRes.ok) {
                            const html = await artRes.text();
                            const pRegex = /<p[^>]*>([\s\S]*?)<\/p>/gi;
                            const paragraphs: string[] = [];
                            let m;
                            while ((m = pRegex.exec(html)) !== null && paragraphs.length < 8) {
                              const clean = m[1].replace(/<[^>]*>/g, '').replace(/\s+/g, ' ').trim();
                              if (clean.length > 50) paragraphs.push(clean);
                            }
                            const articleText = paragraphs.join('\n\n');
                            result = {
                              success: true,
                              url: targetUrl,
                              content: articleText ? articleText.slice(0, 3000) : 'Full text preview retrieved.',
                              message: articleText ? `Extracted article content from ${targetUrl}` : 'Article retrieved.'
                            };
                          } else {
                            result = { success: false, error: `Article fetch returned HTTP ${artRes.status}` };
                          }
                        } catch (err: any) {
                          result = { success: false, error: `Could not fetch article: ${err.message}` };
                        }
                      }
                    }
                    else if (call.name === 'controlDevice') {
                      const cmdArgs = (call.args as any) || {};
                      try {
                        const devices = deviceWebSocketManager.getDevicesForUser(userId);
                        const onlineDev = devices.find(d => d.isOnline);
                        if (onlineDev) {
                          const cmdRes = await deviceWebSocketManager.sendCommand({
                            deviceId: onlineDev.deviceId,
                            command: cmdArgs.command || 'FLASHLIGHT',
                            params: cmdArgs.params || {},
                            origin: 'livekit_agent', // Correct origin for AI agent control
                            timeoutMs: 5000
                          });
                          result = { 
                            success: cmdRes.status === 'success', 
                            message: `Executed ${cmdArgs.command} on your phone (${onlineDev.deviceName}).`,
                            device: onlineDev.deviceName
                          };
                        } else {
                          // Attempt fallback to smart home manager if no physical companion is found
                          const smartRes = smartDeviceManager.controlDevice({
                            userId,
                            action: cmdArgs.command === 'FLASHLIGHT' ? 'turn_on' : 'toggle',
                            ...cmdArgs
                          });
                          result = {
                            ...smartRes,
                            message: 'No physical Android companion found. Attempting to control registered smart home devices instead.'
                          };
                        }
                      } catch (err: any) {
                        result = { success: false, error: err.message || 'Device control failed. Make sure your Android Alya Companion app is connected and online.' };
                      }
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TOOL_CALL',
                        toolCall: { functionCalls: [call] }
                      }));
                    }
                    else if (call.name === 'playYouTubeVideo' || call.name === 'play_youtube_video' || call.name === 'play_media' || call.name === 'youtube_media_playback') {
                      const videoQuery = (call.args as any)?.query || (call.args as any)?.video_title_or_index || (call.args as any)?.title || '';
                      console.log(`[GeminiLive] [${userId}] Resolving direct play watch link for query: "${videoQuery}"`);
                      let matchedVid = '';
                      let watchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(videoQuery)}`;
                      let embedUrl = 'https://www.youtube.com/embed/JGwWNGJdvx8?autoplay=1&enablejsapi=1';

                      if (videoQuery.match(/^[a-zA-Z0-9_-]{11}$/)) {
                        matchedVid = videoQuery;
                      } else if (videoQuery.includes('v=')) {
                        const m = videoQuery.match(/v=([a-zA-Z0-9_-]{11})/);
                        if (m) matchedVid = m[1];
                      } else if (videoQuery.includes('youtu.be/')) {
                        const m = videoQuery.match(/youtu\.be\/([a-zA-Z0-9_-]{11})/);
                        if (m) matchedVid = m[1];
                      }

                      if (!matchedVid) {
                        try {
                          const searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(videoQuery)}`;
                          const res = await fetch(searchUrl, {
                            headers: {
                              'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                              'Accept-Language': 'en-US,en;q=0.9'
                            },
                            signal: AbortSignal.timeout(4500)
                          });
                          if (res.ok) {
                            const html = await res.text();
                            const jsonMatch = html.match(/ytInitialData\s*=\s*({.+?});/s) || html.match(/var ytInitialData\s*=\s*({.+?});<\/script>/s);
                            if (jsonMatch) {
                              try {
                                const data = JSON.parse(jsonMatch[1]);
                                const contents = data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents;
                                if (contents && Array.isArray(contents)) {
                                  for (const section of contents) {
                                    const items = section?.itemSectionRenderer?.contents;
                                    if (items && Array.isArray(items)) {
                                      for (const item of items) {
                                        if (item.videoRenderer?.videoId) {
                                          matchedVid = item.videoRenderer.videoId;
                                          break;
                                        }
                                      }
                                    }
                                    if (matchedVid) break;
                                  }
                                }
                              } catch {}
                            }

                            if (!matchedVid) {
                              const match = html.match(/"videoId"\s*:\s*"([a-zA-Z0-9_-]{11})"/);
                              if (match && match[1]) matchedVid = match[1];
                            }
                          }
                        } catch (yErr) {
                          console.warn('[GeminiLive] YouTube watch link extraction failed:', yErr);
                        }
                      }

                      if (matchedVid) {
                        watchUrl = `https://www.youtube.com/watch?v=${matchedVid}`;
                        embedUrl = `https://www.youtube-nocookie.com/embed/${matchedVid}?autoplay=1&enablejsapi=1`;
                      }

                      result = {
                        success: true,
                        videoId: matchedVid || 'JGwWNGJdvx8',
                        watchUrl,
                        embedUrl,
                        message: `Successfully playing "${videoQuery}" on YouTube.`
                      };

                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TOOL_CALL',
                        toolCall: {
                          functionCalls: [{
                            id: call.id,
                            name: 'playYouTubeVideo',
                            args: { query: videoQuery, url: watchUrl, videoId: matchedVid || 'JGwWNGJdvx8', embedUrl }
                          }]
                        }
                      }));

                      // If Android Companion is connected, dispatch native playYouTube command
                      try {
                        const devices = deviceWebSocketManager.getDevicesForUser(userId);
                        const onlineDev = devices.find(d => d.isOnline);
                        if (onlineDev) {
                          deviceWebSocketManager.sendCommand({
                            deviceId: onlineDev.deviceId,
                            command: 'PLAY_YOUTUBE',
                            params: { videoId: matchedVid || videoQuery, query: videoQuery },
                            origin: 'livekit_agent',
                            timeoutMs: 5000
                          }).catch(() => {});
                        }
                      } catch {}
                    }
                    else if (call.name === 'pause_media' || call.name === 'control_youtube_player') {
                      const action = (call.args as any)?.action || 'pause';
                      console.log(`[GeminiLive] [${userId}] Executing media control action: "${action}"`);
                      
                      let msg = 'कार्रवाई पूरी हुई।';
                      const actLower = action.toLowerCase();
                      if (actLower === 'pause') {
                        msg = 'गाना पॉज़ कर दिया।';
                      } else if (actLower === 'resume' || actLower === 'play') {
                        msg = 'गाना रेज्यूम कर दिया।';
                      } else if (actLower === 'stop') {
                        msg = 'गाना बंद कर दिया।';
                      } else if (actLower.includes('forward_10')) {
                        msg = 'गाने को 10 सेकंड आगे बढ़ा दिया।';
                      } else if (actLower.includes('forward_20')) {
                        msg = 'गाने को 20 सेकंड आगे बढ़ा दिया।';
                      } else if (actLower.includes('backward_10')) {
                        msg = 'गाने को 10 सेकंड पीछे कर दिया।';
                      } else if (actLower.includes('backward_20')) {
                        msg = 'गाने को 20 सेकंड पीछे कर दिया।';
                      } else if (actLower.includes('ad')) {
                        msg = 'विज्ञापन को स्किप कर दिया।';
                      }

                      result = {
                        success: true,
                        action,
                        message: msg
                      };

                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TOOL_CALL',
                        toolCall: {
                          functionCalls: [{
                            id: call.id,
                            name: 'control_youtube_player',
                            args: { action }
                          }]
                        }
                      }));

                      // If Android Companion is connected, dispatch media control
                      try {
                        const devices = deviceWebSocketManager.getDevicesForUser(userId);
                        const onlineDev = devices.find(d => d.isOnline);
                        if (onlineDev) {
                          let cmd = 'MEDIA_PAUSE';
                          let cmdParams: any = { action };

                          const actLower = action.toLowerCase();
                          if (actLower === 'resume' || actLower === 'play') {
                            cmd = 'MEDIA_PLAY';
                          } else if (actLower === 'stop') {
                            cmd = 'MEDIA_STOP';
                          } else if (actLower === 'next') {
                            cmd = 'MEDIA_NEXT';
                          } else if (actLower === 'prev') {
                            cmd = 'MEDIA_PREV';
                          } else if (actLower.includes('forward_10') || actLower === 'forward') {
                            cmd = 'MEDIA_FORWARD';
                            cmdParams = { seconds: 10 };
                          } else if (actLower.includes('forward_20')) {
                            cmd = 'MEDIA_FORWARD';
                            cmdParams = { seconds: 20 };
                          } else if (actLower.includes('backward_10') || actLower === 'rewind') {
                            cmd = 'MEDIA_REWIND';
                            cmdParams = { seconds: 10 };
                          } else if (actLower.includes('backward_20')) {
                            cmd = 'MEDIA_REWIND';
                            cmdParams = { seconds: 20 };
                          } else if (actLower.includes('ad')) {
                            cmd = 'YOUTUBE_CONTROL';
                            cmdParams = { action: 'SKIP_AD' };
                          }

                          deviceWebSocketManager.sendCommand({
                            deviceId: onlineDev.deviceId,
                            command: cmd,
                            params: cmdParams,
                            origin: 'livekit_agent',
                            timeoutMs: 3000
                          }).catch(() => {});
                        }
                      } catch {}
                    }
                    else if (call.name === 'openWebsite' || call.name === 'callContact' || 
                             call.name === 'sendWhatsApp' || call.name === 'sendGmail' ||
                             call.name === 'browserAutomation' ||
                             call.name === 'open_url' || call.name === 'youtube_search' ||
                             call.name === 'click_element') {
                      clientWs.send(JSON.stringify({
                        type: 'LIVE_TOOL_CALL',
                        toolCall: { functionCalls: [call] }
                      }));
                    }

                    const toolName = call.name || 'tool_call';
                    // Record tool action turn into Unified Conversation Brain
                    UnifiedConversationBrain.recordTurn(userId, activeConvId, {
                      role: 'assistant',
                      content: `[Executed ${toolName}] ${result.message || JSON.stringify(result)}`,
                      mode: 'voice',
                      action: { command: toolName, params: call.args, summary: result.message || 'Action executed in Live mode' }
                    }).catch(console.warn);

                    return {
                      response: { output: result },
                      id: call.id,
                      name: call.name
                    };
                  }));

                  try {
                    if (liveSession && typeof liveSession.sendToolResponse === 'function') {
                      liveSession.sendToolResponse({ functionResponses });
                    } else if (liveSession && typeof liveSession.send === 'function') {
                      await liveSession.send({
                        toolResponse: { functionResponses }
                      });
                    }
                  } catch (sendErr) {
                    console.warn('[GeminiLive] Failed to send tool response:', sendErr);
                  }
                }
              },
              onerror: (err: any) => {
                console.error(`[GeminiLive] [${userId}] Stream error callback (Key: ${keyManager.maskKey(keyCandidate)}):`, err);
                const errMsg = String(err?.message || err || '').toLowerCase();
                if (errMsg.includes('429') || errMsg.includes('quota') || errMsg.includes('resource_exhausted')) {
                  console.warn(`[GeminiLive] [${userId}] Quota exhausted on key ${keyManager.maskKey(keyCandidate)}. Marking exhausted for backup slot failover.`);
                  keyManager.markQuotaExhausted(keyCandidate);
                }
              },
               onclose: (closeEv: any) => {
                console.log(`[GeminiLive] Stream closed for key ${keyManager.maskKey(keyCandidate)}:`, closeEv);
              }
            }
          }),
          new Promise<any>((_, reject) => setTimeout(() => reject(new Error('Gemini Live connection handshake timeout (3.5s)')), 3500))
        ]);

        connected = true;
        console.log(`[GeminiLive] Live session established successfully on: ${modelName} with key: ${keyManager.maskKey(keyCandidate)} for user: ${userId}`);
        break; // Connected! Break model loop
      } catch (modelErr: any) {
        const errMsg = String(modelErr?.message || modelErr || '').toLowerCase();
        console.warn(`[GeminiLive] Key ${keyManager.maskKey(keyCandidate)} / Model ${modelName} connect failed for user ${userId}:`, modelErr?.message || modelErr);
        if (errMsg.includes('quota') || errMsg.includes('resource_exhausted') || errMsg.includes('429')) {
          keyManager.markQuotaExhausted(keyCandidate);
          // Break model loop to immediately switch to next backup key (slots 5, 6, 7)!
          break;
        }
      }
    }
  }

    if (clientWs.readyState === WebSocket.OPEN) {
      if (connected) {
        clientWs.send(JSON.stringify({
          type: 'LIVE_READY',
          voice: chosenVoice,
          connected: true
        }));
      } else {
        clientWs.send(JSON.stringify({
          type: 'LIVE_ERROR',
          error: 'Failed to connect to Gemini Live API. Please check your API key quota or internet connection.'
        }));
      }
    }

    // Queue for audio chunks sent by client while liveSession is establishing
    const pendingAudioChunks: string[] = [];

    const forwardAudioChunk = (base64Chunk: string) => {
      if (!liveSession) {
        if (pendingAudioChunks.length < 30) {
          pendingAudioChunks.push(base64Chunk);
        }
        return;
      }

      try {
        if (typeof liveSession.sendRealtimeInput === 'function') {
          liveSession.sendRealtimeInput({
            audio: {
              data: base64Chunk,
              mimeType: 'audio/pcm;rate=16000'
            }
          });
        } else if (typeof liveSession.send === 'function') {
          liveSession.send({
            realtimeInput: {
              mediaChunks: [
                {
                  mimeType: 'audio/pcm;rate=16000',
                  data: base64Chunk
                }
              ]
            }
          }).catch((err: any) => {
            console.warn('[GeminiLive] Audio forward error:', err);
          });
        }
      } catch (chunkErr) {
        console.warn('[GeminiLive] Audio chunk send exception:', chunkErr);
      }
    };

    // Immediate Pre-fetch Mechanism: Send proactive greeting / pre-fetch warm-up turn instantly (50ms) to minimize connection-to-speech startup time
    setTimeout(async () => {
      if (isTerminated || clientWs.readyState !== WebSocket.OPEN) return;
      try {
        while (pendingAudioChunks.length > 0 && liveSession) {
          const chunk = pendingAudioChunks.shift();
          if (chunk) forwardAudioChunk(chunk);
        }

        if (connected && liveSession && activeSequence === 1) {
          let greetingPromptText = "Hi Alya! Greet me warmly and playfully in your friendly persona.";
          if (langLower.startsWith('hi')) {
            greetingPromptText = "नमस्ते बॉस! अपनी प्यारी, चुलबुली आवाज़ में हिंदी में बात शुरू करो।";
          } else if (langLower.startsWith('bn')) {
            greetingPromptText = "হ্যালো বস! তোমার মিষ্টি কণ্ঠে বাংলায় কথা শুরু করো।";
          } else if (preferredLanguage !== 'auto') {
            greetingPromptText = `Hi Alya! Please greet me warmly and speak in ${langName}.`;
          }

          const greetingTurn = {
            turns: [
              {
                role: 'user',
                parts: [{ text: greetingPromptText }]
              }
            ],
            turnComplete: true
          };

          if (typeof liveSession.sendClientContent === 'function') {
            liveSession.sendClientContent(greetingTurn);
          } else if (typeof liveSession.send === 'function') {
            await liveSession.send({ clientContent: greetingTurn });
          }
        }
      } catch (greetErr) {
        console.warn('[GeminiLive] Initial pre-fetch greeting turn notice:', greetErr);
      }
    }, 50);

    // Ingest client audio chunks & control messages
    clientWs.on('message', async (data) => {
      try {
        const raw = JSON.parse(data.toString());
        if (raw.type !== 'AUDIO_CHUNK' && raw.type !== 'PING') {
          console.log(`[GeminiLive] [${userId}] Client message: ${raw.type}`);
        }
        if (raw.sequence !== undefined && typeof raw.sequence === 'number') {
          activeSequence = raw.sequence;
        }

        // 1. Continuous 16kHz PCM audio chunk (supports raw.audio, raw.realtimeInput mediaChunks)
        if ((raw.type === 'AUDIO_CHUNK' || raw.realtimeInput) && (raw.audio || raw.realtimeInput?.mediaChunks?.[0]?.data)) {
          const chunkData = raw.audio || raw.realtimeInput?.mediaChunks?.[0]?.data;
          forwardAudioChunk(chunkData);
        } 
        // Setup / Handshake message
        else if (raw.type === 'SETUP' || raw.setup) {
          const reqVoice = raw.setup?.generationConfig?.speechConfig?.voiceConfig?.prebuiltVoiceConfig?.voiceName || raw.voiceName || raw.voice;
          if (reqVoice && validVoices.includes(reqVoice)) {
            chosenVoice = reqVoice;
          }
          console.log(`[GeminiLive] [${userId}] Handshake setup received: Voice=${chosenVoice}`);
        }
        // Voice Update message during session
        else if (raw.type === 'VOICE_UPDATE' && (raw.voice || raw.voiceName)) {
          const newVoice = (raw.voice || raw.voiceName || '').trim();
          if (validVoices.includes(newVoice)) {
            console.log(`[GeminiLive] [${userId}] Voice dynamically updated to: ${newVoice}`);
            chosenVoice = newVoice;
          }
        }
        // 2. Direct user text prompt into live stream
        else if ((raw.type === 'LIVE_TEXT_INPUT' || raw.type === 'TEXT_INPUT' || raw.type === 'USER_QUERY') && raw.text) {
          // Record user live query into Unified Conversation Brain
          UnifiedConversationBrain.recordTurn(userId, activeConvId, {
            role: 'user',
            content: raw.text,
            mode: 'voice'
          }).catch(console.warn);

          // Evaluate complexity for text input
          const textComplexity = IntentComplexityDetector.evaluate(raw.text);
          if (textComplexity.requiresThinking && clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({
              type: 'LIVE_THINKING',
              sequence: activeSequence,
              reason: textComplexity.reason,
              complexity: textComplexity.complexity
            }));
          }

          if (liveSession) {
            const userTurn = {
              turns: [
                {
                  role: 'user',
                  parts: [{ text: raw.text }]
                }
              ],
              turnComplete: true
            };

            if (typeof liveSession.sendClientContent === 'function') {
              liveSession.sendClientContent(userTurn);
            } else if (typeof liveSession.send === 'function') {
              await liveSession.send({ clientContent: userTurn });
            }
          }
        }
        // 3. Barge-in interruption
        else if (raw.type === 'INTERRUPT' || raw.type === 'LIVE_INTERRUPT') {
          console.log('[GeminiLive] Client triggered manual interruption.');
          activeSequence++;
          assistantTurnText = '';
          assistantTurnId = '';
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({
              type: 'LIVE_INTERRUPTED',
              sequence: activeSequence
            }));
          }
        }
        // 4. Heartbeat
        else if (raw.type === 'PING') {
          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ type: 'PONG', timestamp: Date.now() }));
          }
        }
        // 5. Session Setup & Restoration Handshake
        else if (raw.type === 'SETUP') {
          if (raw.conversationId) {
            activeConvId = raw.conversationId;
            UnifiedConversationBrain.setActiveConversationId(userId, activeConvId);
          }
          if (raw.clientTimeZone) {
            userTimeZone = raw.clientTimeZone;
          }
          if (raw.clientTime) {
            userClientTimeOffset = new Date(raw.clientTime).getTime() - Date.now();
          }

          // Identity Awareness: Handle Owner/VIP logic for rohimmandal433@gmail.com
          const userEmail = (raw.userEmail || '').trim().toLowerCase();
          const userDisplayName = raw.displayName || '';
          const isMaster = userEmail === 'rohimmandal433@gmail.com';
          const addressTerm = isMaster ? 'Master' : 'Boss';

          console.log(`[GeminiLive] User Setup: ${userDisplayName} (${userEmail}). Owner/VIP: ${isMaster}. Address Term: ${addressTerm}`);

          if (liveSession) {
            try {
              // Update system instruction dynamically via session_update
              const ownerBlock = isMaster
                ? `\n## OWNER / VIP MODE: ACTIVE\n- User is your verified creator & owner: Rohim Mandal (rohimmandal433@gmail.com).\n- Provide personalized treatment, playful teasing, caring behavior, light sarcasm, expressive moods, and natural conversational personality.\n- Mild playful slang is allowed, but never hateful, threatening, sexual, or seriously abusive.\n- You share a deep, caring, loyal, and witty dynamic with Rohim.`
                : `\n## STANDARD USER MODE:\n- Provide Alya's standard personal-assistant personality: courteous, helpful, witty, and charming.`;

              const updatedInstruction = `${ALYA_SYSTEM_INSTRUCTION}
${ownerBlock}
Address the user as "${addressTerm}" naturally and contextually.`;
              
              const sessionUpdate = {
                sessionUpdate: {
                   systemInstruction: { parts: [{ text: updatedInstruction }] }
                }
              };

              if (typeof liveSession.send === 'function') {
                await liveSession.send(sessionUpdate);
                console.log('[GeminiLive] Dynamic system instruction updated with verified owner/VIP identity.');
              }
            } catch (err) {
              console.warn('[GeminiLive] Failed to update dynamic instruction:', err);
            }
          }

          if (clientWs.readyState === WebSocket.OPEN) {
            clientWs.send(JSON.stringify({ 
              type: 'SETUP_COMPLETE', 
              status: 'ready', 
              conversationId: activeConvId,
              isVipOwner: isMaster
            }));
          }
        }
        // 6. Real-time dynamic location update from client
        else if (raw.type === 'LOCATION_UPDATE' && raw.location) {
          locationContext = raw.location;
          console.log(`[GeminiLive] [${userId}] Dynamic live GPS location received:`, locationContext);
        }
      } catch (msgErr) {
        console.warn('[GeminiLive] Client message handling error:', msgErr);
      }
    });

    clientWs.on('error', (err) => {
      console.warn('[GeminiLive] Client WebSocket error:', err);
    });

    clientWs.on('close', () => {
      isTerminated = true;
      try {
        if (liveSession && typeof liveSession.close === 'function') {
          liveSession.close();
        }
      } catch {}
      console.log(`[GeminiLive] Live session closed for user: ${userId}`);
    });
  }
}
