/**
 * Alya Assistant - LiveKit WebRTC Token & Room Service
 * Uses livekit-server-sdk to securely issue short-lived JWT access tokens for
 * Web and Android clients connecting to LiveKit rooms.
 * NEVER exposes LIVEKIT_API_SECRET to the client app.
 */

import { AccessToken } from 'livekit-server-sdk';
import { livekitConfig } from './config/livekitConfig.ts';

export interface GenerateTokenOptions {
  roomName?: string;
  identity?: string;
  name?: string;
  userId?: string;
  metadata?: Record<string, any>;
  ttlSeconds?: number;
}

export class LiveKitServerService {
  /**
   * Helper function to verify LiveKit JWT token structure and expiration before connection.
   * Identifies malformed, tampered, or expired tokens before initiating WebSocket handshake.
   */
  static verifyLiveKitToken(token: string): { valid: boolean; payload?: any; error?: string } {
    if (!token || typeof token !== 'string') {
      return { valid: false, error: 'Token is empty or not a valid string.' };
    }

    const parts = token.trim().split('.');
    if (parts.length !== 3) {
      return { valid: false, error: `Malformed JWT structure: expected 3 parts, got ${parts.length}.` };
    }

    try {
      // Decode JWT payload (second part)
      const payloadBase64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
      const jsonPayload = decodeURIComponent(
        atob(payloadBase64)
          .split('')
          .map((c) => '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2))
          .join('')
      );
      const payload = JSON.parse(jsonPayload);

      // Check expiration if 'exp' claim is present
      if (payload.exp && typeof payload.exp === 'number') {
        const nowSec = Math.floor(Date.now() / 1000);
        if (payload.exp <= nowSec) {
          return { valid: false, error: `JWT token has expired (exp: ${payload.exp}, current: ${nowSec}).`, payload };
        }
      }

      return { valid: true, payload };
    } catch (err: any) {
      return { valid: false, error: `Failed to decode or parse JWT payload: ${err?.message || err}` };
    }
  }

  /**
   * Issue short-lived, authenticated JWT access token for LiveKit Room join.
   */
  static async createJoinToken(options: GenerateTokenOptions): Promise<{
    token: string;
    serverUrl: string;
    roomName: string;
    identity: string;
    expiresAt: number;
  }> {
    const roomName = options.roomName || livekitConfig.defaultRoom;
    const userId = options.userId || 'user_' + Math.random().toString(36).substr(2, 8);
    const identity = options.identity || `${userId}_${Math.random().toString(36).substr(2, 6)}`;
    const name = options.name || 'Alya User';
    const ttl = options.ttlSeconds || 3600; // 1 hour token TTL

    const apiKey = livekitConfig.apiKey;
    const apiSecret = livekitConfig.apiSecret;

    const at = new AccessToken(apiKey, apiSecret, {
      identity,
      name,
      ttl,
      metadata: JSON.stringify(options.metadata || { userId, clientType: 'alya_voice' })
    });

    at.addGrant({
      roomJoin: true,
      room: roomName,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true
    });

    const jwtToken = await at.toJwt();
    const expiresAt = Date.now() + ttl * 1000;

    return {
      token: jwtToken,
      serverUrl: livekitConfig.url,
      roomName,
      identity,
      expiresAt
    };
  }
}
