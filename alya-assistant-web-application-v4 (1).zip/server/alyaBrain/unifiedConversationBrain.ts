/**
 * Alya Assistant - Unified Conversation Brain
 * 
 * Single source of truth for conversational state and memory across:
 * 1. Live Voice Mode (Gemini Live Audio & LiveKit WebRTC)
 * 2. Text Chat Mode (Web Chat & Companion Chat)
 * 
 * Provides:
 * - Real-time conversational state tracking across modes
 * - Short-term memory & anaphoric reference resolution ("it", "that", "this", "search for...", "same one", "again", "first result")
 * - Sequential command resolution ("Open YouTube" -> "Search Minecraft" -> "Open first result")
 * - Unified Firestore synchronization for both Live Voice and Text Chat
 * - Rapid message queueing & duplicate suppression
 */

import { Firestore, getFirestore } from 'firebase-admin/firestore';
import { getApps, initializeApp, getApp } from 'firebase-admin/app';
import fs from 'fs';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';

export interface TurnLog {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  mode: 'text' | 'voice';
  timestamp: number;
  intent?: string;
  action?: {
    command: string;
    params?: any;
    summary?: string;
  };
}

export interface ConversationState {
  userId: string;
  conversationId: string;
  currentTopic: string;
  userIntent: string;
  activeTask?: {
    app?: string;
    action?: string;
    query?: string;
    targetDevice?: string;
    room?: string;
    url?: string;
    details?: any;
  };
  relevantContext: {
    lastEntity?: string;
    lastLocation?: string;
    lastApp?: string;
    lastCommand?: string;
    lastResult?: string;
    lastSearchQuery?: string;
    keyEntities: Record<string, string>;
  };
  references: {
    it?: string;
    that?: string;
    this?: string;
    target?: string;
    previousItem?: string;
  };
  pendingAction?: {
    command: string;
    params?: any;
    prompt?: string;
  };
  lastAssistantAction?: {
    command: string;
    params?: any;
    summary?: string;
    timestamp: number;
  };
  recentTurns: TurnLog[];
  responseMode: 'SHORT' | 'NORMAL' | '3-LINE' | 'DETAILED';
  lastUpdated: number;
}

export interface ResolvedContext {
  normalizedText: string;
  resolvedIntent: string;
  resolvedTopic: string;
  resolvedApp?: string;
  resolvedEntity?: string;
  resolvedLocation?: string;
  resolvedAction?: {
    tool: string;
    params: Record<string, any>;
  };
  referenceResolutions: Record<string, string>;
  isContinuation: boolean;
  internalStatePrompt: string;
}

export class UnifiedConversationBrain {
  private static states = new Map<string, ConversationState>(); // Key: `${userId}_${conversationId}`
  private static activeUserSessions = new Map<string, string>(); // Key: userId -> active conversationId
  private static db: Firestore | null = null;
  private static firestoreDisabled = false;
  private static isDbInitialized = false;

  private static getDb(): Firestore | null {
    if (this.firestoreDisabled) return null;
    if (this.isDbInitialized) return this.db;
    this.isDbInitialized = true;
    try {
      const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
      if (fs.existsSync(configPath)) {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        let app: any;
        try {
          app = getApps().length > 0 ? getApp() : initializeApp({ projectId: config.projectId });
        } catch {
          app = initializeApp({ projectId: config.projectId });
        }

        if (config.firestoreDatabaseId) {
          this.db = getFirestore(app, config.firestoreDatabaseId);
        } else {
          this.db = getFirestore(app);
        }
        return this.db;
      }
    } catch (e) {
      this.firestoreDisabled = true;
      return null;
    }
    return this.db;
  }

  /**
   * Retrieves or initializes the active unified state for a conversation.
   */
  public static async getState(userId: string = 'default_user', conversationId: string = 'main'): Promise<ConversationState> {
    const key = `${userId}_${conversationId}`;
    let state = this.states.get(key);

    if (!state) {
      state = {
        userId,
        conversationId,
        currentTopic: 'General Conversation',
        userIntent: 'greeting',
        relevantContext: {
          keyEntities: {}
        },
        references: {},
        recentTurns: [],
        responseMode: 'NORMAL',
        lastUpdated: Date.now()
      };
      this.states.set(key, state);

      // Attempt to populate from Firestore if available
      try {
        const db = this.getDb();
        if (db) {
          const msgsRef = db.collection('users').doc(userId).collection('conversations').doc(conversationId).collection('messages');
          const snapshot = await msgsRef.orderBy('timestamp', 'desc').limit(50).get();
          if (!snapshot.empty) {
            const loadedTurns: TurnLog[] = [];
            snapshot.docs.reverse().forEach((docSnap) => {
              const data = docSnap.data();
              loadedTurns.push({
                id: docSnap.id,
                role: data.role || 'user',
                content: data.content || '',
                mode: data.mode || (data.agentName?.includes('Live') ? 'voice' : 'text'),
                timestamp: data.timestamp?.toDate ? data.timestamp.toDate().getTime() : Date.now(),
                intent: data.intent,
                action: data.commandExecution ? { command: data.commandExecution.command || '', params: data.commandExecution.params } : undefined
              });
            });
            state.recentTurns = loadedTurns;
            this.recalculateStateFromTurns(state);
          }
        }
      } catch (err: any) {
        const errMsg = err?.message || String(err);
        if (errMsg.includes('PERMISSION_DENIED') || errMsg.includes('7') || errMsg.includes('disabled')) {
          this.firestoreDisabled = true;
          this.db = null;
        }
      }
    }

    this.activeUserSessions.set(userId, conversationId);
    return state;
  }

  /**
   * Gets the active conversationId for a given user.
   */
  public static getActiveConversationId(userId: string = 'default_user'): string {
    return this.activeUserSessions.get(userId) || 'main';
  }

  /**
   * Sets the active conversationId for a user.
   */
  public static setActiveConversationId(userId: string = 'default_user', conversationId: string): void {
    this.activeUserSessions.set(userId, conversationId);
  }

  /**
   * Records a completed conversational turn into the unified brain and optionally persists to Firestore.
   */
  public static async recordTurn(
    userId: string,
    conversationId: string,
    turn: {
      role: 'user' | 'assistant';
      content: string;
      mode: 'text' | 'voice';
      intent?: string;
      action?: { command: string; params?: any; summary?: string };
    },
    providedId?: string
  ): Promise<ConversationState> {
    const state = await this.getState(userId, conversationId);
    const turnLog: TurnLog = {
      id: providedId || uuidv4(),
      role: turn.role,
      content: turn.content,
      mode: turn.mode,
      timestamp: Date.now(),
      intent: turn.intent,
      action: turn.action
    };

    // Add to recent turns queue (maintain max 20 recent turns in memory)
    state.recentTurns.push(turnLog);
    if (state.recentTurns.length > 20) {
      state.recentTurns.shift();
    }

    state.lastUpdated = Date.now();

    // Update state context & entities based on turn
    this.updateStateFromNewTurn(state, turnLog);

    // Synchronize to Firestore doc in background so Live and Text share exact persistent history without I/O blocking
    if (!this.firestoreDisabled) {
      const syncToFirestore = async () => {
        try {
          const db = this.getDb();
          if (db) {
            console.log(`[UnifiedBrain] Persisting turn ${turnLog.id} for user ${userId} to Firestore...`);
            const msgDocRef = db.collection('users').doc(userId).collection('conversations').doc(conversationId).collection('messages').doc(turnLog.id);
            await msgDocRef.set({
              id: turnLog.id,
              role: turnLog.role,
              content: turnLog.content,
              mode: turnLog.mode,
              userId,
              conversationId,
              intent: turnLog.intent || state.userIntent,
              agentName: turnLog.mode === 'voice' ? 'Alya Live Voice' : 'Alya Assistant',
              timestamp: new Date(),
              commandExecution: turnLog.action ? {
                status: 'success',
                command: turnLog.action.command,
                params: turnLog.action.params,
                result: turnLog.action.summary
              } : undefined
            }, { merge: true });

            // Touch conversation session doc
            const convDocRef = db.collection('users').doc(userId).collection('conversations').doc(conversationId);
            await convDocRef.set({
              id: conversationId,
              userId,
              updatedAt: new Date()
            }, { merge: true });
            console.log(`[UnifiedBrain] Successfully persisted turn ${turnLog.id}`);
          } else {
            console.warn('[UnifiedBrain] Firestore DB is null, skipping persistence.');
          }
        } catch (e: any) {
          const errMsg = e?.message || String(e);
          console.error('[UnifiedBrain] Firestore persistence error:', errMsg);
          if (errMsg.includes('PERMISSION_DENIED') || errMsg.includes('7') || errMsg.includes('disabled')) {
            this.firestoreDisabled = true;
            this.db = null;
          }
        }
      };
      syncToFirestore().catch((e) => console.error('[UnifiedBrain] Background sync failed:', e));
    } else {
      console.warn('[UnifiedBrain] Firestore is disabled, skipping persistence.');
    }

    return state;
  }

  /**
   * Recalculates context and references from loaded history turns.
   */
  private static recalculateStateFromTurns(state: ConversationState): void {
    for (const turn of state.recentTurns) {
      this.updateStateFromNewTurn(state, turn);
    }
  }

  /**
   * Updates state based on a new turn.
   */
  private static updateStateFromNewTurn(state: ConversationState, turn: TurnLog): void {
    const text = turn.content.toLowerCase();

    // Extract App references
    if (text.includes('youtube')) {
      state.activeTask = { ...state.activeTask, app: 'YouTube' };
      state.relevantContext.lastApp = 'YouTube';
      state.currentTopic = 'YouTube';
      state.references.it = 'YouTube';
    } else if (text.includes('chrome') || text.includes('google')) {
      state.activeTask = { ...state.activeTask, app: 'Chrome' };
      state.relevantContext.lastApp = 'Chrome';
      state.currentTopic = 'Web Browser';
      state.references.it = 'Chrome';
    } else if (text.includes('camera')) {
      state.activeTask = { ...state.activeTask, app: 'Camera' };
      state.relevantContext.lastApp = 'Camera';
      state.currentTopic = 'Camera';
      state.references.it = 'Camera';
    } else if (text.includes('spotify')) {
      state.activeTask = { ...state.activeTask, app: 'Spotify' };
      state.relevantContext.lastApp = 'Spotify';
      state.currentTopic = 'Music';
      state.references.it = 'Spotify';
    }

    // Extract Smart Home / Device references
    if (text.includes('light') || text.includes('batti') || text.includes('alo')) {
      state.currentTopic = 'Smart Lighting';
      state.references.it = 'Light';
      state.relevantContext.lastEntity = 'Smart Light';
    } else if (text.includes('fan') || text.includes('pakha')) {
      state.currentTopic = 'Fan';
      state.references.it = 'Fan';
      state.relevantContext.lastEntity = 'Fan';
    } else if (text.includes('ac') || text.includes('air conditioner') || text.includes('cooling')) {
      state.currentTopic = 'Air Conditioner';
      state.references.it = 'AC';
      state.relevantContext.lastEntity = 'Air Conditioner';
    } else if (text.includes('torch') || text.includes('flashlight')) {
      state.currentTopic = 'Flashlight';
      state.references.it = 'Phone Flashlight';
      state.relevantContext.lastEntity = 'Phone Flashlight';
    } else if (text.includes('volume') || text.includes('sound')) {
      state.currentTopic = 'Volume';
      state.references.it = 'Volume';
      state.relevantContext.lastEntity = 'Volume Level';
    }

    // Extract Location / Weather references
    if (text.includes('weather') || text.includes('mausam') || text.includes('barish') || text.includes('temperature')) {
      state.currentTopic = 'Weather';
      const locMatch = turn.content.match(/(?:in|at|for|near|of)\s+([a-zA-Z\s]+)/i);
      if (locMatch && locMatch[1]) {
        const city = locMatch[1].replace(/(?:today|aaj|kal|tomorrow|weather|mausam)/gi, '').trim();
        if (city) {
          state.relevantContext.lastLocation = city;
          state.references.it = `Weather in ${city}`;
        }
      }
    }

    // Track last assistant action
    if (turn.role === 'assistant' && turn.action) {
      state.lastAssistantAction = {
        command: turn.action.command,
        params: turn.action.params,
        summary: turn.action.summary,
        timestamp: turn.timestamp
      };
    }
  }

  /**
   * Understands and resolves user input BEFORE generating tool actions or responses.
   * Resolves:
   * - Anaphoric pronouns ("it", "that", "this", "usko", "ise", "eita", "oita")
   * - Elliptical / Follow-up queries ("search for Minecraft", "kal kaisa hoga?", "next one", "make it brighter", "volume badhao", "turn it off")
   * - Sequential application workflows ("Open YouTube" -> "Search Minecraft" -> "Open first result")
   */
  public static resolveInput(
    text: string,
    state: ConversationState
  ): ResolvedContext {
    const rawText = text.trim();
    const lower = rawText.toLowerCase();
    const referenceResolutions: Record<string, string> = {};
    let isContinuation = false;
    let resolvedIntent = 'general_conversation';
    let resolvedTopic = state.currentTopic || 'General Conversation';
    let resolvedApp = state.relevantContext.lastApp;
    let resolvedEntity = state.relevantContext.lastEntity;
    let resolvedLocation = state.relevantContext.lastLocation;
    let resolvedAction: { tool: string; params: Record<string, any> } | undefined = undefined;

    const recentUserTurns = state.recentTurns.filter(t => t.role === 'user');
    const lastUserTurn = recentUserTurns.length > 0 ? recentUserTurns[recentUserTurns.length - 1].content : '';
    const lastAssistantTurn = state.recentTurns.filter(t => t.role === 'assistant').slice(-1)[0]?.content || '';

    // 1. ANAPHORIC PRONOUN DETECTION & RESOLUTION ("it", "that", "this", "ise", "usko", "eita", "oita")
    const hasPronoun = /\b(it|that|this|them|same|again|wahi|ise|usko|usse|eita|oita|take)\b/i.test(lower);
    if (hasPronoun) {
      isContinuation = true;
      if (state.references.it) {
        referenceResolutions['it'] = state.references.it;
      }
      if (state.references.that) {
        referenceResolutions['that'] = state.references.that;
      }
    }

    // 2. SEQUENTIAL APP COMMANDS ("Open YouTube" -> "Search Minecraft videos" -> "Open first result")
    const searchMatch = lower.match(/(?:search|find|lookup|dhoondo|dekhao|khojo)\s+(?:for\s+)?(.+)/i);
    if (searchMatch && !lower.includes('google') && !lower.includes('web search')) {
      const query = searchMatch[1].trim();
      // If user recently opened or talked about YouTube
      if (resolvedApp === 'YouTube' || state.currentTopic === 'YouTube' || lastUserTurn.toLowerCase().includes('youtube') || lastAssistantTurn.toLowerCase().includes('youtube')) {
        isContinuation = true;
        resolvedIntent = 'app_action';
        resolvedTopic = 'YouTube Search';
        resolvedAction = {
          tool: 'web_open_url',
          params: {
            url: `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`,
            title: `YouTube Search: ${query}`,
            app: 'YouTube',
            query
          }
        };
      }
    }

    // 3. "OPEN THE FIRST / SECOND / THIRD RESULT" or "PLAY IT"
    if (
      lower.includes('first result') || lower.includes('1st result') || lower.includes('pehla result') || lower.includes('prothom') ||
      lower.includes('second result') || lower.includes('play it') || lower.includes('chalao') || lower.includes('play the first')
    ) {
      isContinuation = true;
      if (resolvedApp === 'YouTube' || state.currentTopic.includes('YouTube')) {
        resolvedIntent = 'app_action';
        resolvedAction = {
          tool: 'web_open_url',
          params: {
            url: state.activeTask?.query ? `https://www.youtube.com/results?search_query=${encodeURIComponent(state.activeTask.query)}` : 'https://www.youtube.com',
            title: 'Playing YouTube result'
          }
        };
      }
    }

    // 4. WEATHER CONTINUATION ("What about tomorrow?", "Kal kaisa rahega?", "Delhi ka weather -> and Kolkata?", "Will it rain?")
    if (
      lower.includes('tomorrow') || lower.includes('kal') || lower.includes('and rain') || lower.includes('barish') ||
      (lower.includes('what about') && (state.currentTopic === 'Weather' || resolvedTopic === 'Weather'))
    ) {
      if (state.currentTopic === 'Weather' || resolvedLocation) {
        isContinuation = true;
        resolvedIntent = 'weather_query';
        resolvedTopic = 'Weather';
        const targetCity = resolvedLocation || 'Current Location';
        resolvedAction = {
          tool: 'get_real_weather',
          params: {
            location: targetCity,
            isTomorrow: lower.includes('tomorrow') || lower.includes('kal')
          }
        };
      }
    }

    // 5. DEVICE / SMART HOME CONTINUATION ("make it brighter", "turn it off", "make it cooler", "volume badhao", "stop it")
    if (
      lower.includes('make it brighter') || lower.includes('brighter') || lower.includes('dim it') ||
      lower.includes('turn it off') || lower.includes('band kardo') || lower.includes('off koro') ||
      lower.includes('make it cooler') || lower.includes('make it hotter')
    ) {
      isContinuation = true;
      resolvedIntent = 'device_control';
      if (resolvedEntity === 'Air Conditioner' || state.currentTopic === 'Air Conditioner') {
        resolvedAction = {
          tool: 'smart_ac_control',
          params: {
            action: lower.includes('off') ? 'turn_off' : 'set_temperature',
            temperature: lower.includes('cooler') ? 20 : 24
          }
        };
      } else if (resolvedEntity === 'Phone Flashlight' || state.currentTopic === 'Flashlight') {
        resolvedAction = {
          tool: 'device_flashlight',
          params: {
            enabled: !lower.includes('off') && !lower.includes('band') && !lower.includes('nibhao')
          }
        };
      } else {
        // Default to light
        resolvedAction = {
          tool: 'smart_light_control',
          params: {
            action: lower.includes('off') || lower.includes('band') ? 'turn_off' : 'set_brightness',
            brightness: lower.includes('brighter') ? 90 : (lower.includes('dim') ? 30 : 50)
          }
        };
      }
    }

    // 6. BUILD CONCISE INTERNAL CONVERSATION STATE REPRESENTATION
    const recentSummary = state.recentTurns.slice(-4).map(t => `[${t.role.toUpperCase()} (${t.mode})]: ${t.content}`).join('\n');
    
    const internalStatePrompt = `=== UNIFIED CONVERSATION BRAIN INTERNAL STATE ===
CURRENT_TOPIC: ${resolvedTopic}
USER_INTENT: ${resolvedIntent}
ACTIVE_TASK: ${JSON.stringify(state.activeTask || { app: resolvedApp, entity: resolvedEntity })}
RELEVANT_CONTEXT: ${JSON.stringify({ lastLocation: resolvedLocation, lastApp: resolvedApp, lastEntity: resolvedEntity, ...referenceResolutions })}
REFERENCES: ${JSON.stringify(state.references)}
PENDING_ACTION: ${state.pendingAction ? JSON.stringify(state.pendingAction) : 'None'}
LAST_ASSISTANT_ACTION: ${state.lastAssistantAction ? JSON.stringify(state.lastAssistantAction) : 'None'}
RESPONSE_MODE: ${state.responseMode}
RECENT_DIALOGUE_TURNS:
${recentSummary || 'No previous turns in active session.'}
=================================================`;

    return {
      normalizedText: rawText,
      resolvedIntent,
      resolvedTopic,
      resolvedApp,
      resolvedEntity,
      resolvedLocation,
      resolvedAction,
      referenceResolutions,
      isContinuation,
      internalStatePrompt
    };
  }
}
