/**
 * intentComplexityDetector.ts (Server-side)
 * 
 * Evaluates prompt complexity to intelligently trigger thinking state
 * only for analytical or multi-step queries, preserving immediate response times
 * for simple conversations.
 */

export interface ComplexityEvaluation {
  complexity: 'simple' | 'moderate' | 'complex';
  requiresThinking: boolean;
  score: number; // 0 (trivial) to 10 (highly complex)
  expectedResponseLength: 'concise' | 'balanced' | 'comprehensive';
  reason: string;
}

export class IntentComplexityDetector {
  /**
   * Evaluates prompt text and intent to determine if intentional thinking is required.
   */
  public static evaluate(text: string, intent?: string): ComplexityEvaluation {
    const trimmed = (text || '').trim();
    if (!trimmed) {
      return {
        complexity: 'simple',
        requiresThinking: false,
        score: 0,
        expectedResponseLength: 'concise',
        reason: 'empty_prompt'
      };
    }

    const lower = trimmed.toLowerCase();
    const words = trimmed.split(/\s+/).filter(Boolean);
    const wordCount = words.length;

    // 1. FAST SIMPLE QUERY MATCHERS (Greetings, acknowledgments, casual small talk, basic status)
    const simpleGreetings = /^(hi|hello|hey|namaste|salaam|kemon acho|kaise ho|kaisa hai|good morning|good afternoon|good evening|good night|hola|yo|kii|sun rahi ho|are you there|can you hear me|awaz aa rahi hai|who are you|tum kaun ho|aap kaun hain|naam kya hai|what is your name|thanks|thank you|shukriya|dhanyawad|bye|alvida|ok|okay|theek hai|haan|accha|achha|acha|yes|no|nahi|na|hmm|suno|dekho|kya haal|kya kar rahi ho)\b/i;
    
    if (wordCount <= 4 && simpleGreetings.test(lower)) {
      return {
        complexity: 'simple',
        requiresThinking: false,
        score: 1,
        expectedResponseLength: 'concise',
        reason: 'simple_greeting'
      };
    }

    // 2. Simple Media / Device One-Liner Controls
    if (wordCount <= 5 && /^(play|pause|stop|resume|next|prev|mute|unmute|flashlight on|flashlight off|torch jalao|roko|chalao|band karo|volume up|volume down|play music|play song|gaana chalao)\b/i.test(lower)) {
      return {
        complexity: 'simple',
        requiresThinking: false,
        score: 1,
        expectedResponseLength: 'concise',
        reason: 'simple_media_command'
      };
    }

    // 3. COMPLEXITY TRIGGERS: Math, calculation, logic puzzles, step-by-step reasoning
    const mathLogicRegex = /\b(calculate|solve|solution|math|hisab|square root|cube root|multiplied by|divided by|percentage|equation|formula|riddle|paheli|puzzle|logic problem|derivation|integral|derivative)\b/i;
    const isMathOrLogic = mathLogicRegex.test(lower) || /[0-9]+\s*[\+\-\*\/x\^%]\s*[0-9]+/i.test(lower);

    // Deep analysis / Reasoning / Planning triggers
    const deepAnalysisRegex = /\b(explain in detail|bistar se|deep explanation|step by step|compare and contrast|pros and cons|difference between|why did|how does.*work|how do i build|how do i create|plan an itinerary|write an essay|write a script|detailed guide|analysis of|root cause|troubleshoot|strategy for)\b/i;
    const isDeepAnalysis = deepAnalysisRegex.test(lower);

    // Coding / Technical Problem
    const codingRegex = /\b(write code|function to|algorithm|debug this|syntax error|typescript|javascript|python|sql query|regex|regular expression|backend architecture|write a program)\b/i;
    const isCoding = codingRegex.test(lower);

    // Long elaborate queries (> 20 words)
    const isVeryLongPrompt = wordCount >= 20;

    if (isMathOrLogic || isDeepAnalysis || isCoding || isVeryLongPrompt) {
      let reason = 'deep_reasoning';
      if (isMathOrLogic) reason = 'math_calculation';
      else if (isDeepAnalysis) reason = 'detailed_analysis';
      else if (isCoding) reason = 'technical_coding';
      else if (isVeryLongPrompt) reason = 'elaborate_multi_sentence_query';

      return {
        complexity: 'complex',
        requiresThinking: true,
        score: Math.min(10, 6 + Math.floor(wordCount / 10)),
        expectedResponseLength: 'comprehensive',
        reason
      };
    }

    // 4. Moderate Queries: Standard conversational queries (Weather, Time, general knowledge)
    const isShortQuery = wordCount <= 7;
    return {
      complexity: 'moderate',
      requiresThinking: false,
      score: 3,
      expectedResponseLength: isShortQuery ? 'concise' : 'balanced',
      reason: 'standard_conversation'
    };
  }
}
