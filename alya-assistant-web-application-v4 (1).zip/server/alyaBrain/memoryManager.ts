import { Firestore, Timestamp, getFirestore } from 'firebase-admin/firestore';
import { getApp, getApps, initializeApp } from 'firebase-admin/app';
import fs from 'fs';
import path from 'path';

export type MemoryCategory = 
  | 'personal_fact' 
  | 'preference' 
  | 'routine' 
  | 'project' 
  | 'emotional' 
  | 'smart_home' 
  | 'milestone' 
  | 'general';

export interface Memory {
  id: string;
  userId: string;
  key: string;
  value: string;
  content: string;
  category: MemoryCategory;
  importance: number; // 1 to 10 scale
  isPinned: boolean;
  tags: string[];
  source: 'web_chat' | 'live_voice' | 'manual_input' | 'auto_extraction';
  sizeBytes: number;
  accessCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface MemoryStats {
  totalCount: number;
  totalSizeBytes: number;
  capacityTB: number; // 1000 TB Enterprise Memory Pool
  usedPercentageTB: number;
  categoryBreakdown: Record<MemoryCategory, number>;
  pinnedCount: number;
  highImportanceCount: number;
}

export class MemoryManager {
  private static db: Firestore | null = null;
  private static firestoreDisabled = false;
  private static localVault: Map<string, Memory[]> = new Map();
  private static vaultFilePath = path.resolve(process.cwd(), 'data', 'alya_memory_vault.json');
  private static isInitialized = false;

  private static ensureInitialized() {
    if (this.isInitialized) return;
    this.isInitialized = true;
    try {
      const dataDir = path.dirname(this.vaultFilePath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      if (fs.existsSync(this.vaultFilePath)) {
        const raw = fs.readFileSync(this.vaultFilePath, 'utf8');
        const parsed = JSON.parse(raw);
        for (const [uid, mems] of Object.entries(parsed)) {
          if (Array.isArray(mems)) {
            this.localVault.set(uid, mems.map((m: any) => ({
              ...m,
              createdAt: new Date(m.createdAt),
              updatedAt: new Date(m.updatedAt)
            })));
          }
        }
      }
    } catch (e) {
      console.warn('[MemoryManager] Initializing local vault cache:', e);
    }
  }

  private static persistLocalVault() {
    try {
      const dataDir = path.dirname(this.vaultFilePath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      const serializable: Record<string, any[]> = {};
      for (const [uid, mems] of this.localVault.entries()) {
        serializable[uid] = mems;
      }
      fs.writeFileSync(this.vaultFilePath, JSON.stringify(serializable, null, 2), 'utf8');
    } catch {}
  }

  private static getDb(): Firestore | null {
    if (this.firestoreDisabled) return null;
    if (!this.db) {
      try {
        const configPath = path.resolve(process.cwd(), 'firebase-applet-config.json');
        if (fs.existsSync(configPath)) {
          const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
          const app = getApps().length > 0 ? getApp() : initializeApp({ projectId: config.projectId });
          if (config.firestoreDatabaseId) {
            this.db = getFirestore(app, config.firestoreDatabaseId);
            return this.db;
          }
        }
      } catch (e) {
        this.firestoreDisabled = true;
        return null;
      }
    }
    return this.db;
  }

  /**
   * Fetch user API key from Firestore
   */
  public static async getUserApiKey(userId: string): Promise<string | null> {
    const db = this.getDb();
    if (!db) return null;
    try {
      const doc = await db.collection('users').doc(userId).get();
      return doc.data()?.apiKey || null;
    } catch {
      return null;
    }
  }

  /**
   * Automatically infer tags and category from memory content
   */
  private static inferCategoryAndTags(content: string): { category: MemoryCategory; tags: string[]; importance: number } {
    const lower = content.toLowerCase();
    const tags = new Set<string>();
    let category: MemoryCategory = 'general';
    let importance = 5;

    if (lower.includes('like') || lower.includes('prefer') || lower.includes('favorite') || lower.includes('love') || lower.includes('pashand') || lower.includes('bhalobashi')) {
      category = 'preference';
      importance = 7;
      tags.add('user_preference');
    } else if (lower.includes('live in') || lower.includes('born in') || lower.includes('my name') || lower.includes('work as') || lower.includes('age') || lower.includes('family') || lower.includes('address')) {
      category = 'personal_fact';
      importance = 9;
      tags.add('identity');
    } else if (lower.includes('daily') || lower.includes('every day') || lower.includes('schedule') || lower.includes('routine') || lower.includes('wake up') || lower.includes('sleep at')) {
      category = 'routine';
      importance = 6;
      tags.add('habit');
    } else if (lower.includes('project') || lower.includes('code') || lower.includes('app') || lower.includes('build') || lower.includes('work') || lower.includes('office')) {
      category = 'project';
      importance = 8;
      tags.add('workload');
    } else if (lower.includes('feel') || lower.includes('happy') || lower.includes('sad') || lower.includes('worry') || lower.includes('excited') || lower.includes('stress')) {
      category = 'emotional';
      importance = 7;
      tags.add('sentiment');
    } else if (lower.includes('light') || lower.includes('fan') || lower.includes('ac') || lower.includes('device') || lower.includes('room') || lower.includes('tv')) {
      category = 'smart_home';
      importance = 6;
      tags.add('automation');
    } else if (lower.includes('birthday') || lower.includes('anniversary') || lower.includes('goal') || lower.includes('achievement') || lower.includes('won')) {
      category = 'milestone';
      importance = 10;
      tags.add('milestone');
    }

    if (lower.includes('urgent') || lower.includes('important') || lower.includes('critical')) {
      importance = 10;
    }

    // Add keyword tags
    const words = lower.split(/\s+/).filter(w => w.length > 3 && !['about', 'there', 'their', 'which', 'where', 'would', 'could', 'should'].includes(w));
    words.slice(0, 4).forEach(w => tags.add(w.replace(/[^a-z0-9]/g, '')));

    return { category, tags: Array.from(tags).filter(Boolean), importance };
  }

  /**
   * Save or update a memory point in Firestore
   */
  public static async saveMemory(
    userId: string, 
    content: string, 
    options?: {
      category?: MemoryCategory;
      key?: string;
      value?: string;
      importance?: number;
      isPinned?: boolean;
      tags?: string[];
      source?: 'web_chat' | 'live_voice' | 'manual_input' | 'auto_extraction';
    }
  ): Promise<Memory> {
    const cleanContent = (content || options?.value || '').trim();
    if (!cleanContent) throw new Error('Memory content cannot be empty');

    const inferred = this.inferCategoryAndTags(cleanContent);
    const category = options?.category || inferred.category;
    const key = options?.key || cleanContent.slice(0, 40);
    const value = options?.value || cleanContent;
    const importance = options?.importance || inferred.importance;
    const isPinned = options?.isPinned || false;
    const tags = Array.from(new Set([...inferred.tags, ...(options?.tags || [])]));
    const source = options?.source || 'manual_input';
    const sizeBytes = Buffer.byteLength(cleanContent, 'utf8') + Buffer.byteLength(key, 'utf8') + 120;

    const memoryId = Buffer.from(`${userId}_${key.slice(0, 15)}_${Date.now()}`).toString('base64').replace(/[^a-zA-Z0-9]/g, '').slice(0, 32);

    this.ensureInitialized();
    const newMemory: Memory = {
      id: memoryId,
      userId,
      key,
      value,
      content: cleanContent,
      category,
      importance,
      isPinned,
      tags,
      source,
      sizeBytes,
      accessCount: 1,
      createdAt: new Date(),
      updatedAt: new Date()
    };

    // Always update local persistent vault
    const userMemories = this.localVault.get(userId) || [];
    const existingIndex = userMemories.findIndex(m => m.id === memoryId);
    if (existingIndex >= 0) {
      userMemories[existingIndex] = newMemory;
    } else {
      userMemories.push(newMemory);
    }
    this.localVault.set(userId, userMemories);
    this.persistLocalVault();

    // Attempt sync to Firestore subcollection if available
    const db = this.getDb();
    if (db) {
      try {
        const docData = {
          id: memoryId,
          userId,
          key,
          value,
          content: cleanContent,
          category,
          importance,
          isPinned,
          tags,
          source,
          sizeBytes,
          accessCount: 1,
          createdAt: Timestamp.now(),
          updatedAt: Timestamp.now()
        };
        await db.collection('users').doc(userId).collection('memories').doc(memoryId).set(docData, { merge: true });
      } catch (err: any) {
        // If Firestore access is disabled or lacks admin credentials, gracefully continue with local vault
        this.firestoreDisabled = true;
      }
    }

    return newMemory;
  }

  /**
   * Retrieve memories with filters, search, and sorting
   */
  public static async getMemories(
    userId: string, 
    filters?: {
      category?: string;
      search?: string;
      isPinnedOnly?: boolean;
      limit?: number;
    }
  ): Promise<Memory[]> {
    this.ensureInitialized();
    const limitVal = filters?.limit || 100;
    let memories: Memory[] = [];

    const db = this.getDb();
    if (db) {
      try {
        const colRef = db.collection('users').doc(userId).collection('memories');
        const snapshot = await colRef.get();
        memories = snapshot.docs.map(doc => {
          const data = doc.data();
          return {
            id: doc.id,
            userId: data.userId || userId,
            key: data.key || data.topic || 'Memory',
            value: data.value || data.content || '',
            content: data.content || data.value || '',
            category: (data.category as MemoryCategory) || 'general',
            importance: data.importance || 5,
            isPinned: !!data.isPinned,
            tags: Array.isArray(data.tags) ? data.tags : [],
            source: data.source || 'manual_input',
            sizeBytes: data.sizeBytes || 128,
            accessCount: data.accessCount || 1,
            createdAt: data.createdAt?.toDate ? data.createdAt.toDate() : new Date(),
            updatedAt: data.updatedAt?.toDate ? data.updatedAt.toDate() : new Date()
          };
        });
      } catch (e) {
        this.firestoreDisabled = true;
      }
    }

    // Fall back to or merge with high-performance local vault
    if (memories.length === 0) {
      memories = [...(this.localVault.get(userId) || [])];
    } else {
      // Sync local vault with fetched records
      this.localVault.set(userId, memories);
      this.persistLocalVault();
    }

    // Apply memory filters
    if (filters?.category && filters.category !== 'all') {
      memories = memories.filter(m => m.category === filters.category);
    }

    if (filters?.isPinnedOnly) {
      memories = memories.filter(m => m.isPinned);
    }

    if (filters?.search && filters.search.trim()) {
      const q = filters.search.toLowerCase().trim();
      memories = memories.filter(m => 
        m.key.toLowerCase().includes(q) || 
        m.value.toLowerCase().includes(q) || 
        m.content.toLowerCase().includes(q) ||
        m.tags.some(t => t.toLowerCase().includes(q))
      );
    }

    // Sort: Pinned first, then high importance, then newest
    memories.sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      if (b.importance !== a.importance) return b.importance - a.importance;
      return b.createdAt.getTime() - a.createdAt.getTime();
    });

    return memories.slice(0, limitVal);
  }

  /**
   * Update an existing memory
   */
  public static async updateMemory(
    userId: string, 
    memoryId: string, 
    updates: Partial<Omit<Memory, 'id' | 'userId' | 'createdAt'>>
  ): Promise<void> {
    this.ensureInitialized();
    const userMemories = this.localVault.get(userId) || [];
    const target = userMemories.find(m => m.id === memoryId);
    if (target) {
      if (updates.key !== undefined) target.key = updates.key;
      if (updates.value !== undefined) {
        target.value = updates.value;
        target.content = updates.value;
        target.sizeBytes = Buffer.byteLength(updates.value, 'utf8') + 120;
      }
      if (updates.content !== undefined) {
        target.content = updates.content;
        target.value = updates.content;
        target.sizeBytes = Buffer.byteLength(updates.content, 'utf8') + 120;
      }
      if (updates.category !== undefined) target.category = updates.category;
      if (updates.importance !== undefined) target.importance = updates.importance;
      if (updates.isPinned !== undefined) target.isPinned = updates.isPinned;
      if (updates.tags !== undefined) target.tags = updates.tags;
      target.updatedAt = new Date();
      this.persistLocalVault();
    }

    const db = this.getDb();
    if (db) {
      try {
        const docRef = db.collection('users').doc(userId).collection('memories').doc(memoryId);
        const updatePayload: Record<string, any> = {
          updatedAt: Timestamp.now()
        };
        if (updates.key !== undefined) updatePayload.key = updates.key;
        if (updates.value !== undefined) {
          updatePayload.value = updates.value;
          updatePayload.content = updates.value;
          updatePayload.sizeBytes = Buffer.byteLength(updates.value, 'utf8') + 120;
        }
        if (updates.content !== undefined) {
          updatePayload.content = updates.content;
          updatePayload.value = updates.content;
          updatePayload.sizeBytes = Buffer.byteLength(updates.content, 'utf8') + 120;
        }
        if (updates.category !== undefined) updatePayload.category = updates.category;
        if (updates.importance !== undefined) updatePayload.importance = updates.importance;
        if (updates.isPinned !== undefined) updatePayload.isPinned = updates.isPinned;
        if (updates.tags !== undefined) updatePayload.tags = updates.tags;
        await docRef.set(updatePayload, { merge: true });
      } catch {
        this.firestoreDisabled = true;
      }
    }
  }

  /**
   * Delete a single memory
   */
  public static async deleteMemory(userId: string, memoryId: string): Promise<void> {
    this.ensureInitialized();
    const userMemories = this.localVault.get(userId) || [];
    this.localVault.set(userId, userMemories.filter(m => m.id !== memoryId));
    this.persistLocalVault();

    const db = this.getDb();
    if (db) {
      try {
        await db.collection('users').doc(userId).collection('memories').doc(memoryId).delete();
      } catch {
        this.firestoreDisabled = true;
      }
    }
  }

  /**
   * Bulk delete memories
   */
  public static async bulkDeleteMemories(userId: string, memoryIds: string[]): Promise<void> {
    this.ensureInitialized();
    const idSet = new Set(memoryIds);
    const userMemories = this.localVault.get(userId) || [];
    this.localVault.set(userId, userMemories.filter(m => !idSet.has(m.id)));
    this.persistLocalVault();

    const db = this.getDb();
    if (db) {
      try {
        const batch = db.batch();
        memoryIds.forEach(id => {
          const ref = db.collection('users').doc(userId).collection('memories').doc(id);
          batch.delete(ref);
        });
        await batch.commit();
      } catch {
        this.firestoreDisabled = true;
      }
    }
  }

  /**
   * Calculate 1000 TB Enterprise Memory Statistics
   */
  public static async getMemoryStats(userId: string): Promise<MemoryStats> {
    const memories = await this.getMemories(userId, { limit: 1000 });
    const totalSizeBytes = memories.reduce((acc, m) => acc + (m.sizeBytes || 128), 0);
    const capacityTB = 1000; // 1,000 Terabytes limit display
    const totalCapacityBytes = capacityTB * 1024 * 1024 * 1024 * 1024; // 1000 TB in bytes
    const usedPercentageTB = (totalSizeBytes / totalCapacityBytes) * 100;

    const categoryBreakdown: Record<MemoryCategory, number> = {
      personal_fact: 0,
      preference: 0,
      routine: 0,
      project: 0,
      emotional: 0,
      smart_home: 0,
      milestone: 0,
      general: 0
    };

    let pinnedCount = 0;
    let highImportanceCount = 0;

    memories.forEach(m => {
      if (categoryBreakdown[m.category] !== undefined) {
        categoryBreakdown[m.category]++;
      } else {
        categoryBreakdown.general++;
      }
      if (m.isPinned) pinnedCount++;
      if (m.importance >= 8) highImportanceCount++;
    });

    return {
      totalCount: memories.length,
      totalSizeBytes,
      capacityTB,
      usedPercentageTB,
      categoryBreakdown,
      pinnedCount,
      highImportanceCount
    };
  }

  /**
   * Generate structured memory summary for LLM prompt context injection
   */
  public static async getMemorySummary(userId: string): Promise<string> {
    const memories = await this.getMemories(userId, { limit: 30 });
    if (memories.length === 0) {
      return "I don't have any personal memories saved for you yet, but I am ready to remember your preferences and facts whenever you share them!~";
    }

    const pinned = memories.filter(m => m.isPinned);
    const highImportance = memories.filter(m => !m.isPinned && m.importance >= 7);
    const regular = memories.filter(m => !m.isPinned && m.importance < 7);

    const formatMemoryLine = (m: Memory) => `- [${m.category.toUpperCase()}] ${m.key}: ${m.value}`;

    let summary = "HIGH-PRIORITY RECALLED MEMORIES (1000 TB Enterprise Storage Bank):\n";

    if (pinned.length > 0) {
      summary += "★ PINNED KEY FACTS:\n" + pinned.map(formatMemoryLine).join('\n') + "\n";
    }

    if (highImportance.length > 0) {
      summary += "★ CORE PREFERENCES & FACTS:\n" + highImportance.map(formatMemoryLine).join('\n') + "\n";
    }

    if (regular.length > 0) {
      summary += "★ CONTEXTUAL MEMORIES:\n" + regular.slice(0, 15).map(formatMemoryLine).join('\n') + "\n";
    }

    return summary;
  }

  /**
   * Auto-extract key user facts/preferences from conversation turn
   */
  public static async autoExtractAndSave(userId: string, userMessage: string, assistantReply?: string): Promise<Memory | null> {
    const text = userMessage.trim();
    if (text.length < 6) return null;

    const lower = text.toLowerCase();

    // Check if user is sharing an explicit memory trigger ("remember that...", "my favorite...", "I live in...", "I work at...")
    const isExplicitTrigger = 
      lower.startsWith('remember that') || 
      lower.startsWith('remember') || 
      lower.includes('my favorite') || 
      lower.includes('my preference') || 
      lower.includes('i live in') || 
      lower.includes('i work at') || 
      lower.includes('my birthday is');

    if (isExplicitTrigger) {
      const cleanContent = text.replace(/^remember\s+that\s+/i, '').replace(/^remember\s+/i, '');
      return await this.saveMemory(userId, cleanContent, {
        source: 'auto_extraction',
        isPinned: lower.includes('important') || lower.includes('favorite')
      });
    }

    return null;
  }
}
