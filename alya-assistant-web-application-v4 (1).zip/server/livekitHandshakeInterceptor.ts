/**
 * LiveKitHandshakeInterceptor.ts
 * 
 * Server-side diagnostic module that intercepts the WebSocket connection lifecycle
 * specifically for '/livekit/ws' and '/livekit' paths.
 * Logs specific headers (Sec-WebSocket-Protocol, Sec-WebSocket-Version, Host, User-Agent, Origin),
 * remote address, and timing metrics (upgrade duration, handshake latency) to diagnose
 * DNS, latency, or protocol negotiation issues.
 */

import { IncomingMessage } from 'http';
import { Duplex } from 'stream';

export interface HandshakeInterceptionLog {
  timestamp: number;
  isoTime: string;
  path: string;
  remoteAddress: string;
  headers: {
    host?: string;
    userAgent?: string;
    secWebSocketProtocol?: string;
    secWebSocketVersion?: string;
    origin?: string;
    authorization?: string;
  };
  timing: {
    upgradeReceivedAt: number;
    handshakeDurationMs?: number;
  };
  diagnosis: {
    protocolMatch: boolean;
    hasAuthToken: boolean;
    status: 'SUCCESS' | 'REJECTED_PROTOCOL' | 'REJECTED_AUTH' | 'TIMEOUT';
  };
}

export class LiveKitHandshakeInterceptor {
  private static handshakeLogs: HandshakeInterceptionLog[] = [];
  private static maxLogs = 100;

  public static interceptUpgrade(
    request: IncomingMessage,
    socket: Duplex,
    head: Buffer,
    upgradeStartTime: number
  ): { allowed: boolean; reason?: string } {
    const now = Date.now();
    const handshakeDuration = Math.round((performance.now() - upgradeStartTime) * 100) / 100;
    const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
    const pathname = url.pathname;

    const headers = {
      host: request.headers['host'],
      userAgent: request.headers['user-agent'],
      secWebSocketProtocol: request.headers['sec-websocket-protocol'],
      secWebSocketVersion: request.headers['sec-websocket-version'],
      origin: request.headers['origin'],
      authorization: request.headers['authorization'] || (url.searchParams.has('token') ? 'present_in_query' : undefined)
    };

    const hasAuthToken = !!headers.authorization || url.searchParams.has('token');
    const requestedProtocol = headers.secWebSocketProtocol || '';
    const protocolMatch = !requestedProtocol || requestedProtocol.includes('livekit') || requestedProtocol.includes('json') || requestedProtocol.includes('websocket');

    let status: HandshakeInterceptionLog['diagnosis']['status'] = 'SUCCESS';
    let allowed = true;
    let reason = 'Handshake accepted';

    if (!protocolMatch) {
      status = 'REJECTED_PROTOCOL';
      allowed = false;
      reason = `Protocol negotiation mismatch: requested '${requestedProtocol}' not supported.`;
    }

    const logEntry: HandshakeInterceptionLog = {
      timestamp: now,
      isoTime: new Date(now).toISOString(),
      path: pathname,
      remoteAddress: request.socket.remoteAddress || 'unknown',
      headers,
      timing: {
        upgradeReceivedAt: now,
        handshakeDurationMs: handshakeDuration
      },
      diagnosis: {
        protocolMatch,
        hasAuthToken,
        status
      }
    };

    this.handshakeLogs.push(logEntry);
    if (this.handshakeLogs.length > this.maxLogs) {
      this.handshakeLogs.shift();
    }

    console.log(`[LiveKitHandshakeInterceptor] Handshake trace on ${pathname}:`, JSON.stringify(logEntry, null, 2));

    return { allowed, reason };
  }

  public static getLogs(): HandshakeInterceptionLog[] {
    return [...this.handshakeLogs];
  }
}
