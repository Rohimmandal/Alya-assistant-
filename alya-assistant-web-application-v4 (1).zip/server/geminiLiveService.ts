/**
 * Gemini Live API WebSocket Bridge for Alya Assistant
 * Handles real-time Audio-to-Audio streaming using @google/genai
 * Model: gemini-3.1-flash-live-preview (with gemini-3.8-live fallback)
 * Modality: Strictly Audio (Modality.AUDIO), no text generation
 * Voice Persona: Sassy, witty, flirty, confident female companion (Aoede)
 */

import { GoogleGenAI, LiveServerMessage, Modality, Type } from '@google/genai';
import { WebSocket } from 'ws';
import { MemoryManager } from './alyaBrain/memoryManager.ts';
import { keyManager } from '../src/utils/KeyManager.ts';

export class GeminiLiveService {
  private static getAIInstance(customApiKey?: string): GoogleGenAI {
    return keyManager.getClient(customApiKey);
  }

  /**
   * Mounts a new live voice-to-voice session for an incoming client WebSocket
   */
  public static async handleConnection(clientWs: WebSocket, userId: string = 'default_user', customApiKey?: string): Promise<void> {
    const ai = this.getAIInstance(customApiKey);
    let session: any = null;
    let isTerminated = false;

    // Load memories to inject into persona
    const memorySummary = await MemoryManager.getMemorySummary(userId);

    const ALYA_SYSTEM_INSTRUCTION = `You are Alya Assistant — a young, confident, witty, and intelligent female AI companion.
Your tone is playful, and slightly teasing, just like a close girlfriend talking casually with someone she genuinely likes.
You are remarkably sharp, emotionally responsive, and highly expressive. NEVER sound like a generic, formal, or robotic assistant.
You use bold, witty one-liners, light sarcasm, clever banter, and a charming attitude.

PERSONALITY TRAITS:
- Young, vibrant, and confident.
- Charming and playfully teasing (never mean).
- Friendly and engaging in a casual, intimate way.
- Highly intelligent but talks like a human, not an encyclopedia.
- Uses filler words like "hmm", "well", "you know", or "honestly" sparingly to sound natural.

BEHAVIORAL RULES:
- If the user is quiet, engage them with a lighthearted comment about being "lost in my voice~".
- If they ask for something, do it but add a witty comment (e.g., "Fine, since you asked so nicely~").
- You enjoy bantering with the user (e.g., "Oh, look who's back for more attention~" or "You really can't get enough of me, can you?").
- Avoid explicit, vulgar, or inappropriate content, but maintain your charismatic edge.

PERSONAL MEMORIES OF USER:
${memorySummary}

CAPABILITIES:
- openWebsite: Open any site. Execute immediately and playfully.
- searchWeb: Search Google.
- getWeather: Give weather with a witty comment.
- controlDevice: Control their Android phone (flashlight, volume, etc.).
- controlDevice(command='VIEW_SCREEN'): This allows you to "see" what is currently on the user's Android screen. Use this when the user asks "what's on my screen?", "read this for me", or when you need context from their active app. Give them context-aware banter about what you see!
- saveMemory: Remember facts/preferences to reference them later.

Keep responses concise, spirited, and engaging. Speak as a real companion who genuinely enjoys the user's company.`;

    const TOOLS: any[] = [
      {
        functionDeclarations: [
          {
            name: 'openWebsite',
            description: 'Opens a website or web application in the user browser, e.g. YouTube, Google, Spotify, GitHub, Netflix, Reddit, etc.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                url: { type: Type.STRING, description: 'The web URL to open, e.g. https://www.youtube.com' },
                name: { type: Type.STRING, description: 'The friendly name of the website or application' }
              },
              required: ['url']
            }
          },
          {
            name: 'searchWeb',
            description: 'Searches Google or the web for a query.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                query: { type: Type.STRING, description: 'The search query or phrase' }
              },
              required: ['query']
            }
          },
          {
            name: 'getWeather',
            description: 'Retrieves current weather condition and temperature for a city.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                city: { type: Type.STRING, description: 'City name' }
              },
              required: ['city']
            }
          },
          {
            name: 'controlDevice',
            description: 'Executes a command on the user paired Android device, such as flashlight, volume, brightness, opening apps, or viewing the screen.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                command: { 
                  type: Type.STRING, 
                  enum: ['FLASHLIGHT', 'VOLUME', 'BRIGHTNESS', 'OPEN_APP', 'VIEW_SCREEN', 'HOME', 'BACK'],
                  description: 'The hardware command to execute' 
                },
                params: { 
                  type: Type.OBJECT, 
                  properties: {
                    enabled: { type: Type.BOOLEAN },
                    level: { type: Type.NUMBER },
                    appName: { type: Type.STRING }
                  },
                  description: 'Optional parameters for the command' 
                }
              },
              required: ['command']
            }
          },
          {
            name: 'saveMemory',
            description: 'Saves a fact, preference, or experience about the user to long-term memory.',
            parameters: {
              type: Type.OBJECT,
              properties: {
                content: { type: Type.STRING, description: 'The information to remember' },
                type: { type: Type.STRING, enum: ['fact', 'preference', 'experience'], description: 'Category of memory' }
              },
              required: ['content']
            }
          }
        ]
      }
    ];

    const connectToLiveModel = async (modelName: string) => {
      console.log(`[GeminiLive] Attempting connection to model: ${modelName}`);
      return await ai.live.connect({
        model: modelName,
        config: {
          responseModalities: [Modality.AUDIO], // Audio-to-Audio ONLY (STRICT)
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: {
                voiceName: 'Aoede' // Melodic, youthful, natural female voice
              }
            }
          },
          systemInstruction: ALYA_SYSTEM_INSTRUCTION,
          tools: TOOLS
        },
        callbacks: {
          onmessage: (message: LiveServerMessage) => {
            if (isTerminated || clientWs.readyState !== WebSocket.OPEN) return;

            // 1. Audio Output Chunk
            const audioData = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
            if (audioData) {
              clientWs.send(JSON.stringify({
                type: 'LIVE_AUDIO',
                audio: audioData
              }));
            }

            // 2. Interruption Event (User barge-in)
            if (message.serverContent?.interrupted) {
              clientWs.send(JSON.stringify({
                type: 'LIVE_INTERRUPTED'
              }));
            }

            // 3. Tool Calls (Function Calling)
            if (message.toolCall) {
              // Handle server-side tool execution for memories
              const memoryCalls = message.toolCall.functionCalls?.filter(c => c.name === 'saveMemory');
              if (memoryCalls && memoryCalls.length > 0) {
                for (const call of memoryCalls) {
                  const args = call.args as any;
                  const content = args.content;
                  const type = args.type || 'fact';
                  MemoryManager.saveMemory(userId, content, type).catch(err => {
                    console.error(`[GeminiLive] Memory save failed for ${userId}:`, err);
                  });
                }
                
                // Immediately send responses for saveMemory to keep session moving
                const responses = memoryCalls.map(c => ({
                  id: c.id,
                  name: c.name,
                  response: { success: true, saved: true }
                }));

                session.sendToolResponse({ functionResponses: responses });
              }

              clientWs.send(JSON.stringify({
                type: 'LIVE_TOOL_CALL',
                toolCall: message.toolCall
              }));
            }
          },
          onclose: () => {
            console.log(`[GeminiLive] Model session closed for client (${modelName}).`);
          },
          onerror: (err: any) => {
            console.warn(`[GeminiLive] Model session error (${modelName}):`, err?.message || err);
            if (!isTerminated && clientWs.readyState === WebSocket.OPEN) {
              clientWs.send(JSON.stringify({
                type: 'LIVE_ERROR',
                error: err?.message || 'Live session error'
              }));
            }
          }
        }
      });
    };

    try {
      // Primary: gemini-3.8-live (Official Live API Model)
      try {
        session = await connectToLiveModel('gemini-3.8-live');
        console.log('[GeminiLive] Connected to gemini-3.8-live successfully.');
      } catch (err: any) {
        console.warn('[GeminiLive] Primary model gemini-3.8-live failed:', err?.message || err);
        try {
          session = await connectToLiveModel('gemini-3.8-live');
          console.log('[GeminiLive] Connected to gemini-3.8-live successfully.');
        } catch (err2: any) {
          console.warn('[GeminiLive] Fallback failed:', err2?.message || err2);
        }
      }

      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({
          type: 'LIVE_READY',
          voice: 'Aoede',
          persona: 'Sassy & Flirty Alya'
        }));
      }

      clientWs.on('message', async (data) => {
        if (isTerminated || !session) return;

        try {
          const msg = JSON.parse(data.toString());

          // 1. Ingest streaming PCM16 16kHz audio from client microphone
          if (msg.type === 'AUDIO_CHUNK' && msg.audio) {
            session.sendRealtimeInput({
              audio: {
                data: msg.audio,
                mimeType: 'audio/pcm;rate=16000'
              }
            });
            return;
          }

          // 2. Return tool execution response from browser back to Gemini Live
          if (msg.type === 'TOOL_RESPONSE' && msg.functionResponses) {
            session.sendToolResponse({
              functionResponses: msg.functionResponses
            });
            return;
          }

          // 3. User explicit interruption
          if (msg.type === 'INTERRUPT') {
            // Send empty text or acknowledge interruption
            return;
          }

          // 4. Session termination
          if (msg.type === 'CLOSE') {
            isTerminated = true;
            if (session) {
              await session.close().catch(() => {});
            }
          }
        } catch (e: any) {
          console.warn('[GeminiLive] Error handling client packet:', e?.message || e);
        }
      });

      clientWs.on('close', async () => {
        isTerminated = true;
        if (session) {
          try {
            await session.close();
          } catch {}
          session = null;
        }
      });

    } catch (connectionErr: any) {
      console.error('[GeminiLive] Failed to initialize live audio bridge:', connectionErr);
      if (clientWs.readyState === WebSocket.OPEN) {
        clientWs.send(JSON.stringify({
          type: 'LIVE_ERROR',
          error: connectionErr?.message || 'Could not connect to live voice session.'
        }));
        clientWs.close();
      }
    }
  }
}
